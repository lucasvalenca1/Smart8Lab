<h2 class="nav-tab-wrapper">
	<a href="#getting_started" class="nav-tab nav-tab-active"><?php esc_html_e( 'Getting Started', 'gym-express' ); ?></a>
	<a href="#add_ons" class="nav-tab"><span class="dashicons dashicons-star-empty"></span><span class="dashicons dashicons-star-empty"></span> <?php esc_html_e( 'Gym Express Pro', 'gym-express' ); ?> <span class="dashicons dashicons-star-empty"></span><span class="dashicons dashicons-star-empty"></span></a>
</h2>
