// Options
var options = {
  offset: 500
}

// Create a new instance of Headhesive.js and pass in some options
var header = new Headhesive('#masthead', options);
