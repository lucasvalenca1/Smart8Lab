<?php
	
	$the_wp_fitness_first_theme_color = get_theme_mod('the_wp_fitness_first_theme_color');
	$the_wp_fitness_second_theme_color = get_theme_mod('the_wp_fitness_second_theme_color');

	$custom_css = '';

	if($the_wp_fitness_first_theme_color != false){
		$custom_css .=' #sidebar .tagcloud a:hover, .nav-menu ul ul a, .woocommerce .cart .button, .woocommerce .cart input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce button.button.alt, .woocommerce a.button.alt, .woocommerce input.button.alt, h1.page-title, h1.search-title, .trainerbox h3:hover, .testbutton a:hover , #footer input[type="submit"], .read-more a, .pagination a:hover, .pagination .current , span.meta-nav , .woocommerce span.onsale, .title-box, #sidebar .tagcloud a:hover, #footer .tagcloud a:hover, .tags a:hover, #comments a.comment-reply-link, .back-to-top, .blogbtn a, .woocommerce-product-search button, a.button:hover, #slider .carousel-indicators .active {';
			$custom_css .='background-color: '.esc_html($the_wp_fitness_first_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_first_theme_color != false){
		$custom_css .='a, code, nav-menu ul li a:active, .nav-menu ul li a:hover, #header .logo a, .widget_calendar caption, .nav-menu ul ul a:hover, .nav-menu a:hover, .social-media i:hover, #header .logo p,   .woocommerce-message, .woocommerce-message::before,  h1.woocommerce-products-header__title,  .blog-sec h3 a, testbutton a,  #footer h3, .footerinner ul li a:hover, .read-more a:hover, .carousel-control-next-icon, .carousel-control-prev-icon, span.post-title, .testbutton a:hover,  .tags a i, #comments a.comment-reply-link:hover, #comments input[type="submit"].submit:hover, #header .logo a, #wrapper .related-posts h2.related-posts-main-title, #wrapper .related-posts h3 a, .woocommerce ul.products li.product span.woocommerce-Price-amount.amount, a.button {';
			$custom_css .='color: '.esc_html($the_wp_fitness_first_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_first_theme_color != false){
		$custom_css .=' 
		@media screen and (max-width:1000px){
		.nav-menu .current_page_item > a, .nav-menu .current-menu-item > a, .nav-menu .current_page_ancestor > a, .nav-menu ul li a:hover {';
			$custom_css .='color: '.esc_html($the_wp_fitness_first_theme_color).';';
		$custom_css .='} }';
	}
	if($the_wp_fitness_first_theme_color != false){
		$custom_css .=' .woocommerce-message, .testbutton a, .pagination .current, .pagination a:hover, .nav-menu ul ul, .nav-menu ul ul a:hover, hr.images_border, #sidebar .tagcloud a:hover, #footer .tagcloud a:hover, .tags a:hover, a.button, a.button:hover  {';
			$custom_css .='border-color: '.esc_html($the_wp_fitness_first_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_first_theme_color != false){
		$custom_css .='  .back-to-top::before{';
			$custom_css .='border-bottom-color: '.esc_html($the_wp_fitness_first_theme_color).';';
		$custom_css .='}';
	}

	if($the_wp_fitness_second_theme_color != false){
		$custom_css .='.bradcrumbs a, input[type="submit"], a.button, #comments input[type="submit"].submit, #sidebar input[type="submit"], #header, .woocommerce ul.products li.product .button:hover, .woocommerce button.button.alt:hover, .woocommerce a.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .inner, .read-more a:hover, .nav-menu ul ul a:hover, #comments a.comment-reply-link:hover, .blogbtn a:hover, .testbutton a:hover, #slider .carousel-indicators li {';
			$custom_css .='background-color: '.esc_html($the_wp_fitness_second_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_second_theme_color != false){
		$custom_css .='.pagination span, .pagination a, nav.woocommerce-MyAccount-navigation ul li a, h1.page-title, h1.search-title, .trainerbox h3 , #trainer h2 , .read-more a, .carousel-control-next-icon:hover, .carousel-control-prev-icon:hover, .about h3, .blog-sec h2 a, #sidebar h3, .pagination .current, #sidebar a.rsswidget, #sidebar .widget_calendar caption, #sidebar td#prev a, .testbutton a, #sidebar .tagcloud a:hover, #footer .tagcloud a:hover,  #sidebar ul li a:hover, #wrapper h1, span.meta-nav, #wrapper p a, .comment-meta.commentmetadata a, p.woocommerce-result-count, .woocommerce select.orderby, .woocommerce span.onsale, .woocommerce .cart .button, .woocommerce .cart input.button, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, h2.woocommerce-loop-product__title, span.woocommerce-Price-amount.amount , .woocommerce ul.products li.product a, .woocommerce div.product .product_title, .woocommerce button.button.alt, .woocommerce a.button.alt, .woocommerce input.button.alt, .woocommerce span a, .woocommerce table.shop_table td a, a.showcoupon, .blogbtn a, .woocommerce-product-search button{';
			$custom_css .='color: '.esc_html($the_wp_fitness_second_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_second_theme_color != false){
		$custom_css .='nav.woocommerce-MyAccount-navigation ul li,  .blog-sec, #sidebar form, #sidebar h3 , #wrapper, .pagination span, .pagination a, #sidebar aside, #wrapper, .woocommerce select.orderby{';
			$custom_css .='border-color: '.esc_html($the_wp_fitness_second_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_second_theme_color != false){
		$custom_css .=' a:focus, input:focus, textarea:focus {';
			$custom_css .='outline-color: '.esc_html($the_wp_fitness_second_theme_color).';';
		$custom_css .='}';
	}
	if($the_wp_fitness_second_theme_color != false){
		$custom_css .='  .back-to-top::after{';
			$custom_css .='border-bottom-color: '.esc_html($the_wp_fitness_second_theme_color).';';
		$custom_css .='}';
	}

	// Layout Options
	$the_wp_fitness_theme_layout = get_theme_mod( 'the_wp_fitness_theme_layout_options','Default Theme');
    if($the_wp_fitness_theme_layout == 'Default Theme'){
		$custom_css .='body{';
			$custom_css .='max-width: 100%;';
		$custom_css .='}';
	}else if($the_wp_fitness_theme_layout == 'Container Theme'){
		$custom_css .='body{';
			$custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$custom_css .='}';
		$custom_css .='.page-template-custom-front-page .menu-sec{';
			$custom_css .='right:0;';
		$custom_css .='}';
	}else if($the_wp_fitness_theme_layout == 'Box Container Theme'){
		$custom_css .='body{';
			$custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$custom_css .='}';
		$custom_css .='.page-template-custom-front-page .menu-sec{';
			$custom_css .='right:0;';
		$custom_css .='}';
		$custom_css .='#header .logo{';
			$custom_css .='padding:10px 15px 10px 25px;';
		$custom_css .='}';
	}


	/*-------------- Slider Opacity ----------------*/

	$the_wp_fitness_slider_layout = get_theme_mod( 'the_wp_fitness_slider_opacity_color','0.7');
	if($the_wp_fitness_slider_layout == '0'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.1'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.1';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.2'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.2';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.3'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.3';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.4'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.4';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.5'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.5';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.6'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.6';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.7'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.7';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.8'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.8';
		$custom_css .='}';
	}else if($the_wp_fitness_slider_layout == '0.9'){
		$custom_css .='#slider img{';
			$custom_css .='opacity:0.9';
		$custom_css .='}';
	}

	/*--------------Slider Content Layout ---------------*/

	$the_wp_fitness_slider_layout = get_theme_mod( 'the_wp_fitness_slider_alignment_option','Right Align');
    if($the_wp_fitness_slider_layout == 'Left Align'){
		$custom_css .='#slider .carousel-caption{';
			$custom_css .='text-align:left;';
		$custom_css .='}';
		$custom_css .='#slider .carousel-caption{';
		$custom_css .='left:15%; right:50%;';
		$custom_css .='}';
		$custom_css .='@media screen and (max-width: 1000px){
			#slider .carousel-caption{';
			$custom_css .='right:40%;';
		$custom_css .='} }';

	}else if($the_wp_fitness_slider_layout == 'Center Align'){
		$custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$custom_css .='text-align:center;';
		$custom_css .='}';
		$custom_css .='#slider .carousel-caption{';
		$custom_css .='left:30%; right:30%;';
		$custom_css .='}';
		$custom_css .='@media screen and (max-width: 1000px){
			#slider .carousel-caption{';
			$custom_css .='right:15%; left:15%;';
		$custom_css .='} }';

	}else if($the_wp_fitness_slider_layout == 'Right Align'){
		$custom_css .='#slider .carousel-caption{';
			$custom_css .='text-align:right;';
		$custom_css .='}';
		$custom_css .='#slider .carousel-caption{';
		$custom_css .='left:50%; right:15%;';
		$custom_css .='}';
		$custom_css .='@media screen and (max-width: 1000px){
			#slider .carousel-caption{';
			$custom_css .='left:40%;';
		$custom_css .='} }';
	}

	/*--------- Preloader Color Option -------*/
	$the_wp_fitness_preloader_color = get_theme_mod('the_wp_fitness_preloader_color');

	if($the_wp_fitness_preloader_color != false){
		$custom_css .=' .tg-loader{';
			$custom_css .='border-color: '.esc_html($the_wp_fitness_preloader_color).';';
		$custom_css .='} ';
		$custom_css .=' .tg-loader-inner{';
			$custom_css .='background-color: '.esc_html($the_wp_fitness_preloader_color).';';
		$custom_css .='} ';
	}

	$the_wp_fitness_preloader_bg_color = get_theme_mod('the_wp_fitness_preloader_bg_color');

	if($the_wp_fitness_preloader_bg_color != false){
		$custom_css .=' #overlayer{';
			$custom_css .='background-color: '.esc_html($the_wp_fitness_preloader_bg_color).';';
		$custom_css .='} ';
	}

	/*------------ Button Settings option-----------------*/

	$the_wp_fitness_top_button_padding = get_theme_mod('the_wp_fitness_top_button_padding');
	$the_wp_fitness_bottom_button_padding = get_theme_mod('the_wp_fitness_bottom_button_padding');
	$the_wp_fitness_left_button_padding = get_theme_mod('the_wp_fitness_left_button_padding');
	$the_wp_fitness_right_button_padding = get_theme_mod('the_wp_fitness_right_button_padding');
	if($the_wp_fitness_top_button_padding != false || $the_wp_fitness_bottom_button_padding != false || $the_wp_fitness_left_button_padding != false || $the_wp_fitness_right_button_padding != false){
		$custom_css .='.blogbtn a, .read-more a, .testbutton a, #comments input[type="submit"].submit{';
			$custom_css .='padding-top: '.esc_html($the_wp_fitness_top_button_padding).'px; padding-bottom: '.esc_html($the_wp_fitness_bottom_button_padding).'px; padding-left: '.esc_html($the_wp_fitness_left_button_padding).'px; padding-right: '.esc_html($the_wp_fitness_right_button_padding).'px; display:inline-block;';
		$custom_css .='}';
	}

	$the_wp_fitness_button_border_radius = get_theme_mod('the_wp_fitness_button_border_radius',0);
	$custom_css .='.blogbtn a, .read-more a, .testbutton a, #comments input[type="submit"].submit{';
		$custom_css .='border-radius: '.esc_html($the_wp_fitness_button_border_radius).'px;';
	$custom_css .='}';

	/*----------- Copyright css -----*/
	$the_wp_fitness_copyright_top_padding = get_theme_mod('the_wp_fitness_top_copyright_padding');
	$the_wp_fitness_copyright_bottom_padding = get_theme_mod('the_wp_fitness_bottom_copyright_padding');
	if($the_wp_fitness_copyright_top_padding != false || $the_wp_fitness_copyright_bottom_padding != false){
		$custom_css .='.inner{';
			$custom_css .='padding-top: '.esc_html($the_wp_fitness_copyright_top_padding).'px; padding-bottom: '.esc_html($the_wp_fitness_copyright_bottom_padding).'px; ';
		$custom_css .='}';
	} 

	$the_wp_fitness_copyright_alignment = get_theme_mod('the_wp_fitness_copyright_alignment', 'center');
	if($the_wp_fitness_copyright_alignment == 'center' ){
		$custom_css .='#footer .inner p{';
			$custom_css .='text-align: '. $the_wp_fitness_copyright_alignment .';';
		$custom_css .='}';
	}elseif($the_wp_fitness_copyright_alignment == 'left' ){
		$custom_css .='#footer .inner p{';
			$custom_css .=' text-align: '. $the_wp_fitness_copyright_alignment .';';
		$custom_css .='}';
	}elseif($the_wp_fitness_copyright_alignment == 'right' ){
		$custom_css .='#footer .inner p{';
			$custom_css .='text-align: '. $the_wp_fitness_copyright_alignment .';';
		$custom_css .='}';
	}

	$the_wp_fitness_copyright_font_size = get_theme_mod('the_wp_fitness_copyright_font_size');
	$custom_css .='#footer .inner p{';
		$custom_css .='font-size: '.esc_html($the_wp_fitness_copyright_font_size).'px;';
	$custom_css .='}';

	/*------ Slider Show/Hide ------*/
	$the_wp_fitness_slider = get_theme_mod('the_wp_fitness_slider_hide');
	if($the_wp_fitness_slider == false ){
		$custom_css .='.page-template-custom-front-page .menu-sec{';
			$custom_css .='position: static; ';
		$custom_css .='}';
	}