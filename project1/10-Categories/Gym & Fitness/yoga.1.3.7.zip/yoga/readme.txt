﻿=================
Yoga
=================
Contributors: Themeansar
Tags: three-columns, left-sidebar, right-sidebar, custom-logo, featured-images, threaded-comments, blog, e-commerce, news
Requires at least: 4.0.5
Tested up to: 4.8.1
Stable tag: 1.3.7

== Theme License & Copyright ==
yoga is distributed under the terms of the GNU GPL
yoga -Copyright 2018 yoga, Themeansar.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

=================
SHORT DESCRIPTION
=================
Yoga could be a WordPress theme designed for Yogaor blog website . With Yoga your web site is made to last and will stand out from the crowd. It comes with all focus these kind of Rehabilitation, physiotherapist, Medical Clinic, therapist, private Hospital, Sports therapy Clinic, Massage therapist. that supply Medical or therapy connected services.

===========
ABOUT THEME
=========== 
Theme has two, three, four footer layout feature.We focused on usability across various
devices, starting with smart phones.it is compatible with various devices. yoga is a
Cross-Browser Compatible theme that works on All leading web browsers. yoga is easy to use and 
user friendly theme. yoga has boxed and full-width layout feature.
Powerful but simple yoga theme content customized through customizer. to make your site attractive it has two 
widget sections first for “sidebar widget section” and second for “Footer widget section” . 

To make your website in two column use sidebar widget section. to set custom menu in header set primary location. we added social media links to added your social links.It boasts of beautifully designed page sections , Home, Blog and Default Page Template(page with right sidebar), Page Full-Width, Page Left Sidebar. yoga theme has more advanced feature to make your site awesome like: it has header top bar dark & lite color feature. you can also changed header color dark and lite styling. Theme compatible with woocommerce. yoga is a fully woocommerce tested theme. yoga is translation ready theme with WPML compatible & Many More….

This theme is compatible with Wordpress Version 4.4.2  and above and it supports the new theme customization API (https://codex.wordpress.org/Theme_Customization_API).

Supported browsers: Firefox, Opera, Chrome, Safari and IE10+ (Some css3 styles like shadows, rounder corners and 2D transform are not supported by IE8 and below).

/***** BUNDELED CSS ***/
============================================
This theme uses Underscores
============================================
 * yoga is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
 * Copyright: Automattic, automattic.com
 * Source: http://underscores.me/
 * License: GPLv2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
============================================
This theme uses Font Awesome for the theme icons
 * Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
 * Source: http://fontawesome.io
 * License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
======================================
This theme uses Bootstrap as a design tool
 * Bootstrap (http://getbootstrap.com/)
 * Copyright (c) 2011-2014 Twitter, Inc
 * Licensed under https://github.com/twbs/bootstrap/blob/master/LICENSE
======================================
This theme uses vadikom/smartmenus
 * Owner : https://github.com/vadikom
 * Copyright (c) Vasil Dinkov, Vadikom Web Ltd. ( https://github.com/vadikom/smartmenus/blob/master/LICENSE-MIT)
 * Licensed under https://github.com/vadikom/smartmenus
======================================
 This theme uses navwalker
 * Owner : hhttps://github.com/wp-bootstrap/wp-bootstrap-navwalker
 * Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>



/**** Images Source *****/
============================================
***** Screenshot Slider Image CCO StockSnap *****/
1. https://pixabay.com/en/people-woman-yoga-meditation-2587066/

***** Screenshot bredcrumb Image CCO by Devanath  *****/
2. https://pixabay.com/en/lotus-natural-water-meditation-zen-1205631/

***** Screenshot Service one Image CCO Pixabay *****/
3. https://www.pexels.com/photo/beautiful-cute-enjoyment-female-460307/

***** Screenshot Service two Image CCO Lindey Frances *****/
4. https://www.pexels.com/photo/shallow-focus-photography-of-female-dancing-747963/

***** Screenshot Service three Image CCO Pixabay *****/
5. https://www.pexels.com/photo/woman-doing-yoga-37351/


========================================================================================	
--- Version 0.1 ----
1. Relesed

--- Version 0.2 ----
1. update header design
2. social icon design

--- Version 0.3 ----
1. update design
2. change screenshot

--- Version 0.4 ----
1. Fixed theme review issue.

--- Version 0.5 ----
1. Fixed theme review issue.

--- Version 0.6 ----
1. Fixed theme review issue.

--- Version 0.7 ----
1. Add Homepage

--- Version 0.8 ----
1. Fix the styling issue

--- Version 0.9 ----
1. Fix the styling issue

--- Version 1.0 ----
1. Updata alpha color picker setting.

--- Version 1.1 ----
1. Fixed blog pagination issue.

--- Version 1.2 ----
1. Fixed styling issue.

--- Version 1.3 ----
1. Added pot file.

--- Version 1.3.1 ----
1. Fixed String issue.

--- Version 1.3.2 ----
1. Fixed String issue.

--- Version 1.3.3 ----
1. Fixed Cart issue.

--- Version 1.3.4 ----
1. Fixed Cart issue.

--- Version 1.3.5 ----
1. Added skip links.

--- Version 1.3.6 ----
1. Added selective refresh for site info.

--- Version 1.3.7 ----
1. Fixed styling issue.