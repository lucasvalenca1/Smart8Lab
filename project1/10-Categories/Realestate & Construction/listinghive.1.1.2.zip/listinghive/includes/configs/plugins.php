<?php
/**
 * Plugins configuration.
 *
 * @package HiveTheme\Configs
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

return [
	[
		'name'     => 'HivePress',
		'slug'     => 'hivepress',
		'required' => false,
	],
];
