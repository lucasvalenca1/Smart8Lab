<?php
/**
* Load all the modules
*/

require_once get_template_directory() . '/inc/breadcrumbs/breadcrumbs.php';