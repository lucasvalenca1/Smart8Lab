<?php 
/**
* Sidebar template
*
* @package real-estate-salient
*/
?>
<div class="col-md-3 sidebar">
<?php dynamic_sidebar( 'general-sidebar'); ?>
</div>