<?php
do_action('realest_display_testimonials');
?>