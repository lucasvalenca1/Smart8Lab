<?php 
/*
* Template Section for Properties
*/
	do_action('realest_display_search_form');

?>