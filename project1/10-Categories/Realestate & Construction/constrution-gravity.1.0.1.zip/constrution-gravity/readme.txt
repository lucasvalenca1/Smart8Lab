=== Constrution Gravity ===
Contributors: keonthemes
Tags: blog, portfolio, education, grid-Layout, two-columns, flexible-header, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, featured-images, full-width-template, post-formats, rtl-language-support, theme-options, sticky-post, threaded-comments, translation-ready
Requires at least: 4.7
Tested up to: 4.9.8
Stable tag: 1.0.1
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Constrution Gravity is perfect for Construction Agency, Real Estate Agency, Architecture house, Road construction, Builders Developer Websites.

== Description ==

Constrution Gravity is a enhanced child theme of Business Gravity. Constrution Gravity is design for Construction Agency, Real Estate Agency, Architecture house, Road construction, Builders Developer Websites. Theme Demo: https://keonthemes.com/theme-demo/?id=Mjk2NXxjb25zdHJ1dGlvbi1ncmF2aXR5fENvbnN0cnV0aW9uIEdyYXZpdHk

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Constrution Gravity includes support for WooCommerce, Contact From 7 and Jetpack.

== Changelog ==

= 1.0.1 =
* Function name, Theme URI, Description and minor style updated.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.1 =
* This version fixes the Function name, Theme URI, Description and minor style.

= 1.0.0 =
* Initial release.

== Resources ==
* screenshot.png https://pixabay.com/en/adult-construction-hard-hat-man-1867771/ [CC0]