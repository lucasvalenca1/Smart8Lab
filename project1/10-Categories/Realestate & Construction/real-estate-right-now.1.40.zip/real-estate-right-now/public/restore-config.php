<?php 
include_once ('restore-config.inc');
?>