<?php
/**
 * @author William Sergio Minossi
 * @copyright 2017
 */
include_once ('fixconfig.inc');
?>