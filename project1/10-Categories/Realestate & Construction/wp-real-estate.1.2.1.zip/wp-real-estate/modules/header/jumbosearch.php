<div id="jumbosearch">
    <span class="fa fa-remove closeicon"></span>
    <div class="form">
        <?php get_search_form(); ?>
    </div>
</div>