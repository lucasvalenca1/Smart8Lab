<?php 
/*
* Template Name: Home Page
*/

get_header();
get_template_part('template-parts/home-slider');
get_template_part('template-parts/home-projects');
get_template_part('template-parts/home-services');
get_template_part('template-parts/home-blog');
get_template_part('template-parts/home-callout');
get_template_part('template-parts/home-social');
get_footer();