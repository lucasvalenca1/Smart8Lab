<section class="container-fluid c_social_contacts">
    <div class="container">
    <div class="con-social col-md-6">
    	<?php tf_construction_get_social_block(); ?>
    </div>
    <div class="con-contact col-md-6">
   		<?php tf_construction_get_contact_block(); ?>
    </div>
</section>