<?php get_header(); ?>
<div class="container">
    	<div id="contentbx_grace_news">
			<?php woocommerce_content(); ?>
		</div><!-- contentbx_grace_news -->
</div><!-- container -->     
<?php get_footer(); ?>