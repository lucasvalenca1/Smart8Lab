=== News Box Free ===

Contributors: nalam
Requires at least: 4.0
Tested up to: 5.2.3
Tags: blog, news, education, custom-logo, one-column, two-columns, grid-layout, right-sidebar, custom-background, custom-header, custom-menu, featured-image-header, featured-images, flexible-header, full-width-template, sticky-post, threaded-comments, translation-ready, block-styles
Version: 1.0.1
Stable tag: 1.0.0
Requires PHP: 5.5
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Copyright License ==
Be 100% GPL and/or 100% GPL-compatible licensed.
Declare copyright and license explicitly. Use the license and license uri header slugs to style.css.
Declare licenses of any resources included such as fonts or images.
All code and design should be your own or legally yours. Cloning of designs is not acceptable.
Any copyright statements on the front end should display the user's copyright, not the theme author's copyright.

News Box free WordPress Theme, Copyright 2019 Noor alam
News Box free is distributed under the terms of the GNU GPL

The parent theme license
News Box WordPress Theme, Copyright 2019 Noor alam
News Box is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.



== Description ==
News Box free is an awesome masnroy grid free responsive pure WordPress blog, news and magazine theme. This is the child theme of News Box theme. News box free is very good for news, megazine and blog site with morden color touch to display your website very beautiful and good looking.  News box free is editable and super flexible new functionality. The theme has nice, beautiful and professional layouts. This theme is made for any search engine, SEO Compatible.  news box free is a totally responsive.  Html5 and css3 based coded.  It is the magazine and blog theme you case to use for the News, magazine and blog websites.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==
### Images:
License: All Images are licensed under CC0
License URI: https://creativecommons.org/publicdomain/zero/1.0/

* Screenshot image one : CC0 by free photos via pxhere (https://pxhere.com/en/photo/986709 )
* Screenshot image two: CC0 by free photos via pxhere (https://pxhere.com/en/photo/1133491 ) 

  Other images in screenshot are self created and all are under GPLv2.

    Other Images:
        screenshot.png self created GPLv2


== Brand Icons ==

* All brand icons are trademarks of their respective owners.
* The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.



== Changelog ==


= 1.0.1 ==
* Following code fixed
* global issue fixed
* Read me file updated

= 1.0.0 ==
* Released


 
	