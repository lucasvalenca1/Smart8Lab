=== Viral News ===
Contributors: hashthemes
Requires at least: 5.0
Tested up to: 5.4
Stable tag: 1.0.0
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Viral News is a magazine WordPress theme specially focused on a news portal, magazine, newspaper, blog, publishing website. The theme has a clean and minimal design that can be suited for any kind of website. The theme has a repeatable drag and drop news/magazine modules that you can play with to create the layout of your need. There are 10 beautifully designed news/magazine modules to display the various categories of news. The theme has 5 widgets that are specially built for news/magazine websites. Viral News is translation ready, SEO optimized, highly customizable and is compatible with all the major WordPress Plugin. The theme has everything needed to build a complete news, magazine, blog website. 

== Installation ==
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==
= 1.0.6 - May 01 2020 =
* Refinement in codes
* Upgrade text added

= 1.0.5 - Apr 26 2020 =
* Welcome Page and Demo Importer option added

= 1.0 - Feb 04 2020 =
* Initial release

== Resources ==
* Underscores - (C) 2012-2015 Automattic, Inc. 
* Source: http://underscores.me/
* License: GPLv2 or later 
* License Url: https://github.com/Automattic/_s/blob/master/LICENSE

* normalize.css - (C) 2012-2015 Nicolas Gallagher and Jonathan Neal 
* Source: http://necolas.github.io/normalize.css/
* License: The MIT License (MIT)
* License Url: https://github.com/necolas/normalize.css/blob/master/LICENSE.md

* jQuery OwlCarousel - Copyright 2013-2018 David Deutsch
* Source: https://owlcarousel2.github.io/OwlCarousel2/
* License: The MIT License (MIT) 
* License Url: https://github.com/OwlCarousel2/OwlCarousel2

* Font Awesome by @davegandy
* Source: http://fontawesome.io/
* License: Font - SIL OFL 1.1, CSS - MIT License
* License Url: http://opensource.org/licenses/MIT

* Theia Sticky Sidebar - Copyright 2013-2016 WeCodePixels and other contributors
* Source: https://github.com/WeCodePixels/theia-sticky-sidebar
* License: The MIT License (MIT)  
* License Url: https://github.com/WeCodePixels/theia-sticky-sidebar/blob/master/LICENSE.txt

* jQuery Superfish Menu Plugin - Copyright (c) 2013 Joel Birch
* Source: https://plugins.jquery.com/superfish/
* License: The MIT License (MIT)
* License Url: https://plugins.jquery.com/superfish/

* The Pro Upsell customizer control - Copyright (c) 2016 Justin Tadlock
* Source: https://github.com/justintadlock/trt-customizer-pro
* License: GNU GPL, version 2 or later
* License Url: https://github.com/justintadlock/trt-customizer-pro/blob/master/license.md

* Image for theme screenshot, Copyright Cristian Ungureanu
* License: Creative Commons Zero (CC0) license
* Source: https://mystock.themeisle.com/photo/protest/
* License Url: https://mystock.themeisle.com/license/

* Image for theme screenshot, Copyright Cristian Ungureanu
* License: Creative Commons Zero (CC0) license
* Source: https://mystock.themeisle.com/photo/gift-shop-in-punjim/
* License Url: https://mystock.themeisle.com/license/

* Image for theme screenshot, Copyright Andrei Stoiculescu
* License: Creative Commons Zero (CC0) license
* Source: https://mystock.themeisle.com/photo/people-taking-a-pedalo-boat-for-a-run/
* License Url: https://mystock.themeisle.com/license/

* Image for theme screenshot, Copyright Cristian Ungureanu
* License: Creative Commons Zero (CC0) license
* Source: https://mystock.themeisle.com/photo/tourists-admiring-colorful-buildings-in-copenhagen/
* License Url: https://mystock.themeisle.com/license/

* Image for theme screenshot, Copyright Cristian Ungureanu
* License: Creative Commons Zero (CC0) license
* Source: https://mystock.themeisle.com/photo/mobile-crane/
* License Url: https://mystock.themeisle.com/license/