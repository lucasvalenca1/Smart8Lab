<?php
/**
 * Deprecated functions You shouldn't use these functions and look for
 * the alternatives instead. The functions will be removed in a later version.
 * This file is loaded using 'after_setup_theme' hook at priority 10
 *
 * @package    Magazine News Byte
 * @subpackage Theme
 */

function hoot_theme_post_thumbnail() {
	_deprecated_function( __FUNCTION__, '2.7.0', 'hoot_post_thumbnail()' );
	// hoot_post_thumbnail();
}
function hoot_theme_thumbnail_size() {
	_deprecated_function( __FUNCTION__, '2.7.0', 'hoot_thumbnail_size()' );
	// hoot_thumbnail_size();
}
function hoot_theme_meta_info() {
	_deprecated_function( __FUNCTION__, '2.7.0', 'hoot_meta_info()' );
	// hoot_meta_info();
}
function hoot_theme_display_meta_info() {
	_deprecated_function( __FUNCTION__, '2.7.0', 'hoot_display_meta_info()' );
	// hoot_display_meta_info();
}