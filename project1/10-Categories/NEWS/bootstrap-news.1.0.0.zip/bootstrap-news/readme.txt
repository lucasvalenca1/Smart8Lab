=== bootstrap-news ===
Contributors: thebootstrapthemes
Tags: right-sidebar, portfolio, news, theme-options, featured-images, rtl-language-support, grid-layout, editor-style, custom-header, threaded-comments, custom-background, custom-colors, blog, footer-widgets, translation-ready

Description: Bootstrap News is a child theme of Bootstrap Blog WordPress Theme. This theme is best for making News sites, mangazines, female and feminine bloggers, newspaper, photography, news portal, news website, magazine, blog, bloggers, photographers, personal portfolio, travel bloggers, small medium and large scale businesses, corporates, lawyers, restaurants, weddings, salons, fitness, resorts, ecommerce, businesses, creative freelancers, professionals etc. and also supports woocommerce. 


Requires at least: 4.5
Tested up to: 4.9.7
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

bootstrap-news is distributed under the terms of the GNU General Public License v2


== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the bootstrap-news.zip file. Click Install Now.
3. Click Activate to use your new theme right away.
4. Create a page "home" or Select the Page Tempalate Called Front Page 
5. Select static frontpage "home" from customizer or Page Created in Step 4
6. Create categories
7. Select category needed for the homepage

Bootstrap News is a child theme of "Bootstrap Blog". Bootstrap News Theme is licensed under the GPL v2. 
Bootstrap News WordPress Theme, Copyright 2018 The Bootstrap Themes
Bootstrap News is distributed under the terms of the GNU GPL




== Changelog ==


	1.0.0 - September 17, 2018
		* Initial version released.



== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* Font-Awesome: fonts, License: SIL OFL 1.1
* Font-Awesome: css, License: MIT License
* Bootstrap: http://getbootstrap.com, License: MIT License
* Google Fonts - Apache License, version 2.0
* wp-bootstrap-navwalker – ​https://github.com/twittem/wp-bootstrap-navwalker, License: Distributed under the terms of the GPL-2.0+ @twittem

* Image licences Used in screenshot - https://unsplash.com/photos/8lUTnkZXZSA
Photo by Geoff Scott on Unsplash

* Image licences Used in screenshot - https://unsplash.com/photos/M-_EDylKDY0
Photo by Serkan Turk on Unsplash

* Image licences Used in screenshot - https://pixabay.com/en/quarterback-american-football-sport-67701/
License: Creative Commons CC0 - Free for commercial use.

* Image licences Used in screenshot - https://pixabay.com/en/auto-racing-nascar-car-sport-558089/
License: Creative Commons CC0 - Free for commercial use.

* Image licences Used in screenshot - https://pixabay.com/en/people-soccer-stadium-crowd-1284253/
License: Creative Commons CC0 - Free for commercial use.

* Image licences Used in screenshot - https://pixabay.com/en/racing-formula-1-pit-lane-ferrari-3415413/
License: Creative Commons CC0 - Free for commercial use.


* trt-customizer-pro https://github.com/justintadlock/trt-customizer-pro, (C) 2016 © Justin Tadlock,  GNU GPL version 2 or later
* Wow.js: https://github.com/matthieua/WOW , License: MIT License
* Animate.css: https://github.com/daneden/animate.css , License: MIT License
* Owl-carousel: https://owlcarousel2.github.io/OwlCarousel2, Copyright 2013-2017 David Deutsch , License : MIT
* Font-Awesome: https://github.com/FortAwesome/Font-Awesome FontAwesome 4.6.3 Copyright 2012 Dave Gandy Font License: SIL OFL 1.1 Code License: MIT License http://fontawesome.io/license/

