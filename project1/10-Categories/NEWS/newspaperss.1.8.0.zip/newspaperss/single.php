
<?php get_header();
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage newspaperss
 * @since newspaperss 1.0
 */

 ?>
<?php get_template_part( 'parts/content', 'single' ); ?>
<?php get_footer(); ?>
