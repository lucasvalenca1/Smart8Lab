=== News Portal Lite ===

Contributors:       Mystery Themes Team
Requires at least:  WordPress 4.0
Tested up to:       WordPress 5.3
Version:            1.0.1
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html
Tags:               news, grid-layout, custom-colors, one-column, two-columns, three-columns, left-sidebar, right-sidebar, footer-widgets, full-width-template, theme-options, rtl-language-support


== Description ==

News Portal Lite is child theme of News Portal ultimate magazine theme. News Portal Lite theme is best choice to create a beautiful & powerful news/magazine/blog websites with ease. Demo here: http://demo.mysterythemes.com/child-theme/news-portal-lite/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

News Portal Lite WordPress Theme is child theme of News Portal, Copyright 2017 Mystery Themes.
News Portal Lite is distributed under the terms of the GNU GPL

News Portal Lite bundles the following third-party resources:

	Screenshot Images
    Licenses: CCO Public Domain
	https://www.pexels.com/photo/architecture-buildings-city-clouds-478473/
    https://www.pexels.com/photo/men-s-white-button-up-dress-shirt-708440/
    https://www.pexels.com/photo/man-and-woman-walks-beside-green-sea-792726/
    https://www.pexels.com/photo/selective-focus-photography-of-woman-using-smartphone-beside-bookshelf-1061580/
    https://www.pexels.com/photo/drone-flying-against-blue-sky-336232/
    https://www.pexels.com/photo/brown-fish-fillet-on-white-ceramic-plate-46239/
    https://www.pexels.com/photo/man-riding-blue-snow-ski-scooter-804573/
    https://www.pexels.com/photo/a380-air-airbus-aircraft-358220/
    https://www.pexels.com/photo/business-charts-commerce-computer-265087/

== Changelog ==

= 1.0.1 =
    * Added requires php and requires at least version along with updated tested version information 
    * Removed Unwanted Space
    * Design Tweaks done on some widgets and 404 pages
    * Single post page design bug fixed
    * Toogle menu background color changed on mobile devices


= 1.0.0 =
	* Initial submit theme on wordpress.org trac.