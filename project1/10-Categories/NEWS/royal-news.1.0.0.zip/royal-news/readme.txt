=== Royal News ===

Contributors:ThemeInWP
Tags: blog, news, entertainment, one-column, two-columns, left-sidebar, right-sidebar, post-formats, custom-background, custom-menu, featured-images, full-width-template, custom-header, translation-ready, theme-options, threaded-comments

Description: Unique, Versatile, Elegant and Flexible "Royal News" is a feature-rich WordPress theme, suitable for personal, blog and magazine website about fashion, travel journey, tour, lifestyle, food blogs and others. Built with Bootstrap3 framework, Royal Magazine is Engineered for the pros and Crafted for the up-and-comers. We tried to dig further in terms of responsiveness and make it not only working in different devices but also looking like it has been specifically designed for those devices. One Click Demo Import can be done.

Requires at least: 4.5
Tested up to: 4.9.4
Stable tag: 1.0.0

== Theme License & Copyright ==
 Royal News is distributed under the terms of the GNU GPL
 Royal News Copyright 2018  Royal News,ThemeInWP

License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html


== Description ==

Child Theme of Royal Magazine. Royal News is great for magazine, blogs and lifestyle websites with simple creative features and effects to make readers feel the pleasure of reading blog posts and articles. You will get a high quality, responsive, well crafted Magazine layout out of the box, to make writers only focuses on the content of your writing. It has great typography to make your fans and followers focus on every word you write. Live preview at https://demo.themeinwp.com/royal-news/


WordPress theme "Royal News" is a child theme of "Royal Magazine".
Royal Magazine Theme is licensed under the GPL3.

License for images:
https://pixabay.com/en/woman-adult-people-indoors-house-3368245/
https://pixabay.com/en/bitcoin-currency-technology-money-3089728/
https://pixabay.com/en/business-man-newspaper-business-man-1031755/
https://pixabay.com/en/fashion-woman-adult-beauty-model-1063100/
https://pixabay.com/en/woman-profile-face-portrait-young-690118/

Released all under CC0 Creative Commons

== 1.0.0  =
* Initial release
