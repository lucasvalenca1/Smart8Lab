( function( $ ) {

	jQuery( document ).ready( function() {
		//Chosen JS
	    $( ".hs-chosen-select" ).chosen( {
	        width: "100%"
	    } );
	} );

} ) ( jQuery );