<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}
/**
 * Class bee_news_Hooks
 */
class bee_news_Hooks {
	/**
	 * bee_news_Hooks constructor.
	 */
	
}