jQuery(document).ready(function($) {


jQuery(window).load(function() {
        window.onload = function() {
            document.getElementById('shareaholic-dis-ad-col-2').style.display = 'none';
        };
    });
   


});



