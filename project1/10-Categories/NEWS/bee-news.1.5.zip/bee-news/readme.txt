===  Bee News ===
Contributors:		Beepressthemes
Tags:               custom-menu, custom-background, custom-colors, featured-images, threaded-comments, two-columns, three-columns, news, blog
Requires at least:	4.0
Tested up to:		4.9.8

Bee News
== Description ==
Bee News is a clean and modern  news websites, blogs and others.
 It is will make your website adaptable with any type of mobile devices. Your site will be adaptive when viewed on a smartphone or tablet. Fully Responsive, Customizable and Search Engine ( SEO ) Friendly Friendly WordPress Theme using Twitter Bootstrap 3, Microformats and Font Awesome icons. You can add Contact Form and Google Maps to contact page. You can also build custom front page to use 3 different block styles, post banner and slider as unlimited. The theme offers Widgetized Sidebar, four column Footer Widgets. You can add unlimted Widgets in each Sidebar and Footer Column. Theme Features: Advanced Custom Fields, Custom Front Page Settings, Custom Background Support, Custom Menu ( 3 Level on Header, 1 Level on footer ), Custom Colors, Google Fonts, Dynamic Widgets, Slider ( Responsive and Mobile Touch Friendly ), Featured Post Banner, Different Blog Page and Homepage Style, Redux Framework, Post Formats. To learn more about the theme please go to the theme uri and read the documentation.

= License =
Bee News WordPress theme, Copyright (C) 2018 Beepressthemes.com
Bee News WordPress theme is licensed under the GPL3.

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License. The exceptions to this license are as follows:

=== Scripts ===

- Bootstrap v3.3.6 (http://getbootstrap.com)
    -- Copyright 2011-2015 Twitter, Inc.
    -- Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
- Font Awesome Code
    -- Copyright Font Awesome by Dave Gandy - http://fontawesome.io
    -- License: MIT License (http://opensource.org/licenses/mit-license.html)

=== Fonts ===

- Font Awesome font licensing:
    -- SIL OFL 1.1
    -- URL: http://scripts.sil.org/OFL
- Glyphicons
    -- Released under the same license as Bootstrap ( http://glyphicons.com/license/ )
    -- Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
- Google Fonts
    -- License: SIL OFL 1.1
    -- URL: http://scripts.sil.org/OFL

-- Any other image included & distributed with the theme has been licensed under the GPL and is the creative work of Beepressthemes.com.


==== Image used in screenshot ====

  -- Slider Image:  https://www.pexels.com/photo/computer-drink-iphone-laptop-586339/
  -- First Post Thumbnail: https://www.pexels.com/photo/photo-of-a-gray-dell-laptop-displaying-pexels-webpage-811587/
  -- Second Post Thumbnail: https://www.pexels.com/photo/business-computer-desk-finance-206607/

