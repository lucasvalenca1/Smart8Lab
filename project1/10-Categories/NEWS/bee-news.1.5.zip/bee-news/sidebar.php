<!-- LEFT SLIDER OF CONTAINER -->

        <aside id="secondary" class="widget-area">
                <?php dynamic_sidebar('right-sidebar');?>
         </aside><!-- #secondary -->

            <!-- END LEFT SLIDER OF CONTAINER -->
