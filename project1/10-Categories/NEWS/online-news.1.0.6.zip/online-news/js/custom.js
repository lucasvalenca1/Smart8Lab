jQuery(document).ready(function ($) {
  jQuery(".owl-carousel").owlCarousel({
        nav: true, // Show next and prev buttons
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: true,
        items: 1,
        dots: false,
        loop: true,
        autoplay:false  
      });

  jQuery('#vertical-slide').owlCarousel({
    loop: true, 
    margin: 10, 
    nav: true, 
    responsive: {
      0: {
        items: 1
      }
      , 600: {
        items: 3
      }
      , 1000: {
        items: 5
      }
    }
  })


});

jQuery(document).ready(function($) { 

  $('.breaking-news').easyTicker({
    direction: 'up',
    easing: 'swing',
    speed: 'slow',
    interval: 3000,
    height: 'auto',
    visible: 1,
    mousePause: 1
  });
}
);



/*scroll js*/
jQuery(document).ready(function() { 

  jQuery(".resp-tabs-container, .health-content").niceScroll({
    cursorcolor:"#0c8edc",
    cursorwidth: "6px",
    cursorborder: "1px solid #0c8edc"
  });

}

);

//tab js
jQuery(document).ready(function ($) {
    //Horizontal Tab
    jQuery('#tab-wrapper').easyResponsiveTabs({
        type: 'default', //Types: default, vertical, accordion
        width: 'auto', //auto or any width like 600px
        fit: true, // 100% fit in a container
        tabidentify: 'hor_1', // The tab groups identifier
        activate: function (event) { // Callback function if tab is switched
          var $tab = $(this);
          var $info = $('#nested-tabInfo');
          var $name = $('span', $info);
          $name.text($tab.text());
          $info.show();
        }
      });
    //SPORTS Tab
    jQuery('.bg-color').easyResponsiveTabs({
        type: 'default', //Types: default, vertical, accordion
        width: 'auto', //auto or any width like 600px
        fit: true, // 100% fit in a container
        tabidentify: 'hor_1', // The tab groups identifier
        activate: function (event) { // Callback function if tab is switched
          var $tab = $(this);
          var $info = $('#nested-tabInfo');
          var $name = $('span', $info);
          $name.text($tab.text());
          $info.show();
        }
      });
  });
//video news js
jQuery(document).ready(function () {

  jQuery('#owl-news-video').owlCarousel({
        // Enable thumbnails
        thumbs: true,
        thumbsPrerendered: true, 
        video: true, 
        center: true, 
        videoWidth: 1366, // Default false; Type: Boolean/Number
        videoHeight: 600, // Default false; Type: Boolean/Number
        merge: true
        , loop: true
        , items: 1
        , // When only using images in your slide (like the demo) use this option to dynamicly create thumbnails without using the attribute data-thumb.
        thumbImage: false
        , // Enable this if you have pre-rendered thumbnails in your html instead of letting this plugin generate them. This is recommended as it will prevent FOUC
        thumbsPrerendered: true
        , // Class that will be used on the thumbnail container
        thumbContainerClass: 'owl-thumbs'
        , // Class that will be used on the thumbnail item's
        thumbItemClass: 'owl-thumb-item'
      });
});

//search js

jQuery(function($){
  var $searchlink = $('#searchtoggl i');
  var $searchbar  = $('#searchbar');
  
  jQuery('#search-bar a').on('click', function(e){
    e.preventDefault();
    
    if($(this).attr('id') == 'searchtoggl') {
      if(!$searchbar.is(":visible")) { 
        // if invisible we switch the icon to appear collapsable
        $searchlink.removeClass('fa-search').addClass('fa-times');
      } else {
        // if visible we switch the icon to appear as a toggle
        $searchlink.removeClass('fa-times').addClass('fa-search');
      }
      
      $searchbar.slideToggle(100, function(){
        // callback after search bar animation
      });
    }
  });
  
  jQuery('#search-form').submit(function(e){
    e.preventDefault(); // stop form submission
  });
});

/*overlay menu js*/
jQuery('#toggle').click(function() {
 jQuery(this).toggleClass('active');
 jQuery('#overlay').toggleClass('open');
});
jQuery(".close-btn").click(function() {
 jQuery('#overlay').removeClass('open');
});

/**  meanmenu **/
jQuery(document).ready(function () {
  jQuery('.container nav').meanmenu({
    meanScreenWidth:"992",
    meanMenuContainer: '.menu.menu-holder',
  });
});

   //Tab to top
   jQuery(window).scroll(function($) {
    if (jQuery(this).scrollTop() > 240){  
      jQuery('.scroll-top-wrapper').addClass("show");
    }
    else{
      jQuery('.scroll-top-wrapper').removeClass("show");
    }
  });
   jQuery(".scroll-top-wrapper").on("click", function($) {
     jQuery("html, body").animate({ scrollTop: 0 }, 700);
     return false;
   });




