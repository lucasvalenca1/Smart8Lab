<?php
/**
 * The template for displaying archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Online_News
 */

get_header(); ?>
	<?php 
		$layout_class ='col-9';
		$sidebar_layout = online_news_get_option('layout_options'); 

		if( is_active_sidebar('sidebar-1') && 'no-sidebar' !==  $sidebar_layout){
			$layout_class = 'col-9';
		}
		else{
			$layout_class = 'col-12';
		}		
	?>
	<div id="primary" class="content-area <?php echo esc_attr($layout_class);?> sidebar-layout">
		<main id="main" class="site-main" role="main">

				
				<section class="news-listing">
					<?php
					if ( have_posts() ) :  $i = 1;?>

					<header class="entry-header module-title">
						<?php
						the_archive_title( '<h2 class="entry-title">', '</h2>' );
						the_archive_description( '<div class="archive-description">', '</div>' );
						?>
					</header><!-- .page-header -->

					<?php
					/* Start the Loop */
					while ( have_posts() ) : the_post();
						if( $i == 1 ) { echo '<div class="row full-blog-post">'; } elseif ( $i ==2) { echo '<div class="row pull-left">'; }
						
						/*
						* Include the Post-Format-specific template for the content.
						* If you want to override this in a child theme, then include a file
						* called content-___.php (where ___ is the Post Format name) and that will be used instead.
						*/
						get_template_part( 'template-parts/content', get_post_format() );
						if( $i == 1) { echo '</div>'; } 
						$i++;				

					endwhile;
				  	if ( $i > 2) { echo '</div>'; }
				     $pagination_option =online_news_get_option('pagination_option');  
		                if('default' == $pagination_option){
		                    the_posts_navigation();
		                }
		                else{
		                    the_posts_pagination( array(
		                        'mid_size' => 0,
		                        'prev_text' => __( '<<', 'online-news' ),
		                        'next_text' => __( '>>', 'online-news' ),
		                    ) );
		                }

					else :

					get_template_part( 'template-parts/content', 'none' );

					endif; ?>	
				</section>	 	
			 	 	
			
		</main><!-- #main -->
	</div><!-- #primary -->		
<?php
do_action( 'online_news_action_sidebar' );
get_footer();
