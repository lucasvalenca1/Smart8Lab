<?php /**
 *
 *  Template Parts for displaying advertisement section
 *
 *
 */
?>
<?php if(is_active_sidebar('advertisement-section1')):?>
<section class="module advertising">
	<div class="row">
	    <div class="col-12 advertising-space">
	        <?php dynamic_sidebar('advertisement-section1');?>
	    </div><!-- .col-12 -->  
    </div><!-- .row-->  
</section><!-- .advertising -->
<?php endif;?>