<?php 
/* 
 * Template parts for showing news section 3
 *
 *
 */?>
 <section class="module">
 	<div class="row">
 		<?php 
 		$class = 'col-9';	
 		if(is_active_sidebar( 'news-section3-sidebar' )) {
 			$class = 'col-9';
 		} 
 		else{
 			$class ='col-12';
 		}
 		?>
 		<div class="<?php echo esc_attr($class);?>">
 			<?php $news_section_category =online_news_get_option('news_section3_topcategory');    	 
 			$layout_args = array(
 				'posts_per_page'  => 3,              
 				'post_type' => 'post',
 				'post_status' => 'publish',
 				'paged' => 1,
 				'ignore_sticky_posts' => 1,
 				);

 			if ( absint( $news_section_category ) > 0 ) {
 				$layout_args['cat'] = absint( $news_section_category );	       

 			}
		    // Fetch posts.
 			$the_query = new WP_Query( $layout_args );

 			if ( $the_query->have_posts() ) :  

 				$category_title = get_cat_name($news_section_category);
 			$category_link = get_category_link( $news_section_category ); ?> 

 			<header class="entry-header module-title">
 				<h2 class="entry-title"> <a href="<?php echo esc_url($category_link);?>"><?php echo esc_html($category_title);?> </a></h2>
 			</header>
 			<!-- .module-title -->

 			<div class="row pull-left">
 				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>	        

 					<article class="col-4 module-content">
 						<?php if(has_post_thumbnail()):?>
 							<figure>
 								<a href="<?php the_permalink();?>"><?php the_post_thumbnail('online-news-post-side-thumb');?></a>
 							</figure>
 						<?php endif;?>
 						<header class="entry-header">
 							<h3 class="entry-title">
 								<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
 							</h3> 
 						</header>
 						<!-- .entry-header -->

 						<?php online_news_posted_on();?>
 						<!-- .post-meta -->
 					</article>
 					<!-- .module-content -->	
 					<?php wp_reset_postdata(); ?>

 				<?php endwhile;?>
 			</div>
 		<?php endif;?> 

 		<?php 
 		$class = 'col-8';
 		if(is_active_sidebar( 'news-section3-news-section' )) {
 			$news_class = 'col-8';
 		} 
 		else{
 			$news_class ='col-12';
 		}
 		?>
 		<div class="row">
 			<div class="<?php echo esc_attr($news_class);?> news-block">
 				<?php global $layout;
 				$layout = 'news-section-3';  

 				$news_layout = online_news_get_option('news_layout3'); 

			        		 //Layout 1  
 				if('layout-1'== $news_layout):
 					get_template_part( 'template-parts/home-page/layouts/layout', '1' );
 				endif;

				        	//Layout 2
 				if('layout-2'== $news_layout):
 					get_template_part( 'template-parts/home-page/layouts/layout', '2' );
 				endif;

				        	//Layout 3
 				if('layout-3'== $news_layout):
 					get_template_part( 'template-parts/home-page/layouts/layout', '3' );
 				endif;

				        	//layout 4	        	
 				if('layout-4'== $news_layout):
 					get_template_part( 'template-parts/home-page/layouts/layout', '4' );
 				endif;
 				?>
 			</div>
 			<?php if(is_active_sidebar( 'news-section3-news-section')):?>
 				<div class="col-4 newsblock-section-three">
 					<?php dynamic_sidebar( 'news-section3-news-section');?>
 				</div>
 			<?php endif;?>
 		</div>
 	</div>
 	<!-- .col-9 -->
 	<?php if(is_active_sidebar( 'news-section3-sidebar' )) :?>
 		<div id="widget-area" class="col-3 widget sidebar" role="complementary">
 			<?php dynamic_sidebar( 'news-section3-sidebar' );?>    
 		</div>
 		<!-- #widget-area -->
 	<?php endif;?>
 </div>	
</section>
<!-- .module -->
