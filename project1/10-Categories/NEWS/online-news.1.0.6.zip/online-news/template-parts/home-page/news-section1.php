<?php
/**
 *
 * Template part for showing news section 1
 */
?>

<section class="module">
	<div class="row">
		<?php 
			$news_section_class='col-9';
			if( is_active_sidebar('news-section1-sidebar') ){
				$news_section_class='col-9';
			} 
			else{
				$news_section_class ='col-12';
			}
			
		?>
	    <div class="<?php echo esc_attr($news_section_class);?>">
		    <div class="row">
		    	<?php 
		    		$class = 'col-8';
		    		if( is_active_sidebar( 'news-section1-breaking-news' )){
		    			$class= 'col-8';
		    		}
		    		else{
		    			$class= 'col-12';
		    		}
		    	?>
		        <div class="<?php echo esc_attr($class);?> news-block">				        
		        	<?php
		        		global $layout;
		        		$layout = 'news-section-1';  

		        		 $news_layout = online_news_get_option('news_layout');

			        	//Layout 1  
			        	if('layout-1'== $news_layout):
			        		get_template_part( 'template-parts/home-page/layouts/layout', '1' );
			        	endif;

			        	//Layout 2
			        	if('layout-2'== $news_layout):
			        		get_template_part( 'template-parts/home-page/layouts/layout', '2' );
			        	endif;

			        	//Layout 3
			        	if('layout-3'== $news_layout):
			        		get_template_part( 'template-parts/home-page/layouts/layout', '3' );
			        	endif;

			        	//layout 4	        	
			        	if('layout-4'== $news_layout):
			        		get_template_part( 'template-parts/home-page/layouts/layout', '4' );
			        	endif;
		        	?>
		           
		        </div>
		        <!-- .col-8 -->
		        <?php if( is_active_sidebar( 'news-section1-breaking-news' )):?>
			        <div class="col-4 module-tab">
			           <?php dynamic_sidebar( 'news-section1-breaking-news' )?>
			        </div>
		    	<?php endif;?>
		    </div>
	    </div>
	    <?php if( is_active_sidebar( 'news-section1-sidebar' )):?>    	
		    <div class="col-3">
		    	<div id="widget-area" class="widget">
		    		<?php dynamic_sidebar( 'news-section1-sidebar' ); ?>
		    	</div>
		    </div>	    
		<?php endif;?>
	    <!-- #secondary -->
    </div>
</section>