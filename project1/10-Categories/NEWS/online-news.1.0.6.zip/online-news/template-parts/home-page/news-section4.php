<?php 
/* 
 * Template parts for showing news section 3
 *
 *
 */?>
 <section class="module featured-news">
    <div class="row">
     	<?php
     	 $featured_class = 'col-9';
     	 if(is_active_sidebar( 'news-section4-sidebar')){
     	 	$featured_class = 'col-9';
     	 } else{
     	 	$featured_class = 'col-12';
     	 }	
     	?>
        <div class="<?php echo esc_attr($featured_class);?>">
            
        	<?php global $layout;
        		$layout = 'news-section-4';  

        		$news_layout = online_news_get_option('news_layout4'); 

        		 //Layout 1  
            	if('layout-1'== $news_layout):
            		get_template_part( 'template-parts/home-page/layouts/layout', '1' );
            	endif;

            	//Layout 2
            	if('layout-2'== $news_layout):
            		get_template_part( 'template-parts/home-page/layouts/layout', '2' );
            	endif;

            	//Layout 3
            	if('layout-3'== $news_layout):
            		get_template_part( 'template-parts/home-page/layouts/layout', '3' );
            	endif;

            	//layout 4	        	
            	if('layout-4'== $news_layout):
            		get_template_part( 'template-parts/home-page/layouts/layout', '4' );
            	endif;
    		?>
            

        </div>
        <!-- .col-9 -->
        <?php if(is_active_sidebar('news-section4-sidebar')):?>
    	    <div id="widget-area" class="col-3 widget" role="complementary">
    	        <?php dynamic_sidebar('news-section4-sidebar'); ?>
    	    </div>
    	    <!-- #widget-area -->	    
    	<?php endif;?>
    </div><!-- row -->

</section>
<!-- .module -->