<?php
/*
 * Template Part to show to layout 1 in home page
 *
 *
 */?>
 <?php 
    global $layout;   

    if($layout == 'news-section-1'){ 

        $disable_news_section = online_news_get_option('disable_news_section_1');
        $news_section_category =online_news_get_option('news_section1_category');
        $news_section_number  =online_news_get_option('news_section1_number'); 
    }

    if($layout == 'news-section-2'){

        $disable_news_section = online_news_get_option('disable_news_section_2');
        $news_section_category =online_news_get_option('news_section2_category');
        $news_section_number  =online_news_get_option('news_section2_number'); 
    }

    if($layout == 'news-section-3'){

        $disable_news_section = online_news_get_option('disable_news_section_3');
        $news_section_category =online_news_get_option('news_section3_category');
        $news_section_number  =online_news_get_option('news_section3_number'); 
    }
     if($layout == 'news-section-4'){

        $disable_news_section = online_news_get_option('disable_news_section_4');
        $news_section_category =online_news_get_option('news_section4_category');
        $news_section_number  =online_news_get_option('news_section4_number'); 
    }  
?>
<?php     
    $layout_args = array(
    'posts_per_page'  => absint( $news_section_number ),              
    'post_type' => 'post',
    'post_status' => 'publish',
    'paged' => 1,
    'ignore_sticky_posts' => 1,
    );

    if ( absint( $news_section_category ) > 0 ) {
    $layout_args['cat'] = absint( $news_section_category );
    }

    // Fetch posts.
    $the_query = new WP_Query( $layout_args );     

    if ( $the_query->have_posts() ) :
        $category_title = get_cat_name($news_section_category);
         $category_link = get_category_link( $news_section_category );          
        $i = 1;?>
        <?php if(!empty($category_title)):?>
            <header class="entry-header module-title">
                <a href="<?php echo esc_url($category_link)?>"><h2 class="entry-title"> <?php echo esc_html($category_title);?></a> </h2> 
            </header>
        <?php endif;?>
       
        <?php while ( $the_query->have_posts() ) : $the_query->the_post(); 
              
            if( $i <= 3 ) { $featured = 'online-news-postthumb-medium'; } else { $featured = 'online-news-post-side-thumb'; } 
            if( $i <= 3 ) { $class = 'featured-section'; } else { $class = 'col-6'; } 
            if( $i == 1 ) { echo '<div class="row"><div class="col-12"><div id="block-module-money" class="news-slider owl-carousel owl-theme module-block-slide ">'; } elseif ( $i ==4) { echo '<div class="row pull-left no-margin-botton">'; } ?>
                <article class="<?php echo esc_attr($class);?> module-content">
                    <?php if(has_post_thumbnail()):?>
                        <figure>
                            <a href="<?php the_permalink();?>"><?php the_post_thumbnail($featured);?></a>
                        </figure>
                    <?php endif;?>
                    <div class="featured-section-contain">
                        <div class="category-link">                          
                            <?php online_news_category();?>
                        </div>
                        <header class="entry-header">
                            <h3 class="entry-title">
                                <a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
                            </h3> 
                        </header>
                        <!-- .entry-header -->
                        <?php if($i <= 3):?>
                            <div class="news-summary"> 
                            <?php
                                $excerpt = online_news_the_excerpt(10);
                                echo wp_kses_post( wpautop( $excerpt ) );
                                ?>
                            </div>
                        <?php endif;?>

                        <?php online_news_posted_on();?>
                    </div>
                </article>                
            <?php 
                if( $i == 3) { echo '</div></div></div>'; } 
                $i++; 

            ?>       
        <?php endwhile;?>
        <?php  if ( $i <=3 ) { echo '</div></div></div>'; }?>
        <?php  if ( $i > 3 ) { echo '</div>'; }?>
        <?php wp_reset_postdata(); ?>
        

    <?php endif;?>
