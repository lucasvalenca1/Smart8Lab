<?php 
/*
 * Template Parts for news  section 2
 *
 *
 */?>
 <section class="module">
    <div class="row">
     	<?php 
     	 $sectionClass = 'col-9';
     	 if(is_active_sidebar( 'news-section2-sidebar' )){
     	 	$sectionClass = 'col-9';
     	 }
     	 else{
     	 	$sectionClass ='col-12';
     	 }
     	?>
     	<?php if(is_active_sidebar( 'news-section2-sidebar' )):?>
    	    <div class="col-3">
    	        
    	            <?php dynamic_sidebar( 'news-section2-sidebar' );?>
    	            <!-- .tab-wrapper -->
    	       
    	        <!-- .bg-color -->
    	    </div>
    	<?php endif;?>
        <div class="<?php echo esc_attr($sectionClass);?> world-news-block section-layout">
           <?php      
           		global $layout;
            	$layout = 'news-section-2';    

            	 $news_layout2 = online_news_get_option('news_layout2');
            	
            	//Layout 1  
            	if('layout-1'== $news_layout2):
            		get_template_part( 'template-parts/home-page/layouts/layout', '1' );
            	endif;

            	//Layout 2
            	if('layout-2'== $news_layout2):
            		get_template_part( 'template-parts/home-page/layouts/layout', '2' );
            	endif;

            	//Layout 3
            	if('layout-3'== $news_layout2):
            		get_template_part( 'template-parts/home-page/layouts/layout', '3' );
            	endif;

            	//layout 4	        	
            	if('layout-4'== $news_layout2):
            		get_template_part( 'template-parts/home-page/layouts/layout', '4' );
            	endif;
           ?>
        </div> <!-- .col-9 -->
    </div> <!-- row -->

</section>
<!-- .module -->