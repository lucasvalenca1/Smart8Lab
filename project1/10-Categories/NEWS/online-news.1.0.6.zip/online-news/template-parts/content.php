<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Online_News
 */

?>
<div class="col-6 module-content">
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<?php if( is_sticky() ){ ?>
	    	<div class="favourite"><i class="fa fa-star"></i></div>
		<?php } ?>

		<?php if(has_post_thumbnail()):?>
			<div class="list-img"> 
			 	<?php the_post_thumbnail('online-news-feature-thumb');?>
			</div>
		<?php endif;?>	
		<div class="news-content">
			<?php if ( 'post' === get_post_type() ) : ?>
				<div class="entry-meta">
					<?php $disable_post_meta = online_news_get_option('disable_postmeta'); 
					if('false'== !$disable_post_meta): ?>
						<?php online_news_posted_on();?>
					<?php endif;?>
					 
					<?php $disable_categories = online_news_get_option('disable_categories'); 
					if('false'== !$disable_categories): ?>
						<div class="category-link">							 
					 			<?php online_news_category();?>
				 		</div>
					<?php endif;?>  
					
				</div><!-- .entry-meta -->
				
			<?php endif; ?>			 

			<header class="entry-header">
				<?php	

				if ( is_single() ) :
					the_title( '<h1 class="entry-title">', '</h1>' );
				else :
					the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h3>' );
				endif;
				 ?>	
			</header><!-- .entry-header -->
			
			<div class="entry-content">
				<?php the_excerpt();?>
	            <?php $readmore_text = online_news_get_option('readmore_text'); ?>
	            <a class="more-link" href="<?php the_permalink();?>"><?php  echo esc_html($readmore_text);?></a>
			</div><!-- .entry-content -->			
		</div>
	</article><!-- #post-## -->
</div>

