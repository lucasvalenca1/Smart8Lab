=== Online News ===

Contributors: Rigorous Theme
Tags: grid-layout, one-column, left-sidebar, right-sidebar, custom-background, custom-logo, custom-menu, theme-options, threaded-comments, translation-ready,blog,education,holiday,news
Requires at least: 5.0
Tested up to: 5.0.3
Stable tag: 1.0.6
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Online News is clean, well structured, sparkling, user-friendly, flexible, dynamic and attention-grabbing WordPress Magazine Theme with a sleek feel that's perfect for news sites, editorial websites and online magazines. It comes up with the colorful look, built with the latest design trends and highly adjustable theme customizer that lets you customize the appearance of the theme: menu, logo, background and so on. 

Besides, the theme is packed with myriad features and custom widgets that are really efficient and super user-friendly in order to focus on your job with no coding skills, are some of its strong features and make your news or magazines catch everyone�s eyes and stand out to be the best among others. Online News is fully responsive and looks good on all devices either mobile or desktop. Endless amounts of custom sliders, as well as carousels, can easily be deployed in an instant, showcasing your featured reviews or articles or keeping your pages dynamic with attractive image galleries. The theme offers several layout options for the news section.

By Default, Online News includes the social media icons you might expect such as Twitter, Facebook, Google+, Instagram and LinkedIn. This helps to keep your customers or client apprised of your recent happening and reach out to your potential customers.


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.
4. Go to Appearance, click Customize , click  Static Front Page and Choose A static page.
5. Go to Appearance, click Customize , click  Home Section Options , Select Required options.

== Copyright ==

Online News WordPress Theme, Copyright (C) 2019, Rigorous Themes
Online News is distributed under the terms of the GNU GPL


The exceptions to license are as follows:
Fonts
    Font Awesome: MIT and GPL licenses
    http://fontawesome.io/license/        
    
    Poppins
    https://fonts.google.com/specimen/Poppins

---------------------------------------------------------------------------------------------------

JS Files    
    navigation JS: MIT Licenses
    https://gist.github.com/joshmcrty/926f522766a491042be1

    owl carousel Js:  MIT Licenses
    https://github.com/OwlFonk/OwlCarousel
    
    Skip link focus fix JS: MIT Licenses
    https://github.com/cedaro/skip-link-focus

    jquery nicescroll js: MIT License
    https://github.com/inuyaksa/jquery.nicescroll

    Jquery easy ticker js: MIT Licenses
    https://github.com/vaakash/jquery-easy-ticker

    easy responsive tabs: MIT License
    https://github.com/samsono/Easy-Responsive-Tabs-to-Accordion


---------------------------------------------------------------------------------

Images
    Image used in screenshot
    
    https://pixabay.com/en/hillary-clinton-president-usa-1796201/
    https://pixabay.com/en/march-protest-society-medellin-1374386/
   https://pixabay.com/en/statue-usa-liberty-america-york-820417/
    https://pixabay.com/en/flag-patriotism-stripes-freedom-1209484/
       

        Other images in screenshot are self created and all are under GPLv2.

    Other Images: 
        screenshot.png self created GPLv2 
        layout-1.jpg self created GPLv2 
        layout-2.jpg self created GPLv2 
        layout-3.jpg self created GPLv2 
        layout-4.jpg self created GPLv2
        leftsidebar.png self created GPLv2 
        no-sidebar.png self created GPLv2 
        right-sidebar.png self created GPLv2  


== Changelog ==

= 1.0.0 =
* Initial release

= 1.0.1 =
* Minor Changes in css.

= 1.0.2 =
* Minor Changes in css
* Fix the issue of escaping.
* Fix the issue of Excerpt Function.
* Fix the design issue.

= 1.0.3 =
* Minor Changes in css.

= 1.0.4 =
* Fix the issue of Static Front Page Content Display.
*Fix the issue of characters on tags.
*Fix the issue of Lable in Customizer

= 1.0.5 =
* Added scroll to options

= 1.0.6 =
* Changed readme file according to new format.
* Tested upto 5.0.3
