/**
 * Template For backend js
 *
 */
 jQuery(document).ready(function($) {
    $('#online-news-img-container li label img').click(function(){    	
        $('#online-news-img-container li').each(function(){
            $(this).find('img').removeClass ('online-news-radio-img-selected') ;
        });
        $(this).addClass ('online-news-radio-img-selected') ;
    });                    
});
