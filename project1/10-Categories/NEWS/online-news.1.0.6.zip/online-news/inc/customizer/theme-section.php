<?php
/**
 * Header Options.
 *
 * @package Online_News
 */

$default = online_news_get_default_theme_options();

// Add Panel.
$wp_customize->add_panel( 'theme_option_panel',
	array(
	'title'      => __( 'Theme Options', 'online-news' ),
	'priority'   => 100,
	'capability' => 'edit_theme_options',
	)
);

// Header Setting Section starts
$wp_customize->add_section('section_header', 
	array(    
	'title'       => __('Header Setting', 'online-news'),
	'panel'       => 'theme_option_panel'    
	)
);
// Site Identity
$wp_customize->add_setting('theme_options[site_identity]', 
	array(
	'default' 			=> $default['site_identity'],
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control('theme_options[site_identity]', 
	array(		
	'label' 	=> __('Choose Option', 'online-news'),
	'section' 	=> 'title_tagline',
	'settings'  => 'theme_options[site_identity]',
	'type' 		=> 'radio',
	'choices' 	=>  array(
			'logo-only' 	=> __('Logo Only', 'online-news'),
			'logo-text' 	=> __('Logo + Tagline', 'online-news'),
			'title-only' 	=> __('Title Only', 'online-news'),
			'title-text' 	=> __('Title + Tagline', 'online-news')
		)
	)
);

// News Ticker title
$wp_customize->add_setting('theme_options[ticker_title]', 
	array(
	'default'           => $default['ticker_title'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',	
	'sanitize_callback' => 'sanitize_text_field'
	)
);

$wp_customize->add_control('theme_options[ticker_title]', 
	array(
	'label'       => __('News Ticker Title', 'online-news'),
	'description' => __('Change text if you want to use other than "Breaking News"', 'online-news'),
	'section'     => 'section_header',   
	'settings'    => 'theme_options[ticker_title]',		
	'type'        => 'text'
	)
);

// Left part of top navigation
$wp_customize->add_setting('theme_options[top_bar_left]', 
	array(
	'default' 			=> $default['top_bar_left'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control('theme_options[top_bar_left]', 
	array(		
	'label' 	=> __('Top Bar Left Element', 'online-news'),
	'section' 	=> 'section_header',
	'settings'  => 'theme_options[top_bar_left]',
	'type' 		=> 'radio',
	'choices' 	=> array(		
		'menu' 			=> __('Menu', 'online-news'),							
		'address' 		=> __('Address', 'online-news'),
		'news-ticker' 	=> __('News Ticker', 'online-news'),
		'social-link'	=> __('Social Links', 'online-news'),
		),	
	)
);

// Right part of top navigation
$wp_customize->add_setting('theme_options[top_bar_right]', 
	array(
	'default' 			=> $default['top_bar_right'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control('theme_options[top_bar_right]', 
	array(		
	'label' 	=> __('Top Bar Right Element', 'online-news'),
	'section' 	=> 'section_header',
	'settings'  => 'theme_options[top_bar_right]',
	'type' 		=> 'radio',
	'choices' 	=> array(		
		'menu' 			=> __('Menu', 'online-news'),							
		'address' 		=> __('Address', 'online-news'),
		'search' 		=> __('Search', 'online-news'),
		'social-link'	=> __('Social Links', 'online-news'),
		),	
	)
);

// Header Address
$wp_customize->add_setting('theme_options[top_address]', 
	array(
	'default'           =>  $default['top_address'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',	
	'sanitize_callback' => 'sanitize_text_field'
	)
);

$wp_customize->add_control('theme_options[top_address]', 
	array(
	'label'       		=> __('Address', 'online-news'),  
	'section'     		=> 'section_header',  
	'settings'    		=> 'theme_options[top_address]',		
	'type'        		=> 'text',	
	)
);

$wp_customize->add_setting('theme_options[enable_current_date]', 
	array(
	'default' 			=> $default['enable_current_date'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[enable_current_date]', 
	array(		
	'label' 	=> __('Enable Current Date', 'online-news'),
	'section' 	=> 'section_header',
	'settings'  => 'theme_options[enable_current_date]',
	'type' 		=> 'checkbox',	
	)
);

// Enable Search Form
$wp_customize->add_setting('theme_options[enable_search_form]', 
	array(
	'default' 			=> $default['enable_search_form'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[enable_search_form]', 
	array(		
	'label' 	=> __('Enable Search Form', 'online-news'),
	'section' 	=> 'section_header',
	'settings'  => 'theme_options[enable_search_form]',
	'type' 		=> 'checkbox',	
	)
);



//For Social Option
$wp_customize->add_section('section_social', array(    
'title'       => __('Social Links', 'online-news'),
'panel'       => 'theme_option_panel'    
));

//Social link text field
$social_options = array('facebook', 'twitter', 'google_plus', 'instagram', 'linkedin' );

foreach($social_options as $social) {

$social_name = ucwords(str_replace('_', ' ', $social));

$label = '';

switch ($social) {

case 'facebook':
$label = __('Facebook', 'online-news');
break;

case 'twitter':
$label = __( 'Twitter', 'online-news' );
break;

case 'google_plus':
$label = __( 'Google Plus', 'online-news' );
break;

case 'instagram':
$label = __( 'Instagram', 'online-news' );
break;

case 'linkedin':
$label = __( 'LinkedIn', 'online-news' );
break;

}

$wp_customize->add_setting( 'theme_options['.$social.']', array(
'sanitize_callback'     => 'esc_url_raw',
'sanitize_js_callback'  =>  'esc_url'
));

$wp_customize->add_control( 'theme_options['.$social.']', array(
'label'     => $label,
'type'      => 'text',
'section'   => 'section_social',
'settings'  => 'theme_options['.$social.']'
));
}

// Footer Setting Section starts
$wp_customize->add_section('section_footer', 
	array(    
	'title'       => __('Footer Setting', 'online-news'),
	'panel'       => 'theme_option_panel'    
	)
);

// Enable Top Footer Section
$wp_customize->add_setting('theme_options[enable_top_footer]', 
	array(
	'default' 			=> $default['enable_top_footer'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[enable_top_footer]', 
	array(		
	'label' 	=> __('Enable top footer section ', 'online-news'),
	'section' 	=> 'section_footer',
	'settings'  => 'theme_options[enable_top_footer]',
	'type' 		=> 'checkbox',	
	)
);

// Enable Top Footer Section
$wp_customize->add_setting('theme_options[enable_scroll_top]', 
	array(
	'default' 			=> $default['enable_scroll_top'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[enable_scroll_top]', 
	array(		
	'label' 	=> __('Enable Scroll to Top', 'online-news'),
	'section' 	=> 'section_footer',
	'settings'  => 'theme_options[enable_scroll_top]',
	'type' 		=> 'checkbox',	
	)
);

// Setting copyright_text.
$wp_customize->add_setting( 'theme_options[copyright_text]',
	array(
	'default'           => $default['copyright_text'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_textarea_content',	
	)
);
$wp_customize->add_control( 'theme_options[copyright_text]',
	array(
	'label'    => __( 'Copyright Text', 'online-news' ),
	'section'  => 'section_footer',
	'type'     => 'text',
	'priority' => 100,
	)
);

// Disable Search Footer Section
$wp_customize->add_setting('theme_options[disable_search_footer]', 
	array(
	'default' 			=> $default['disable_search_footer'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_search_footer]', 
	array(		
	'label' 	=> __('Disable search in footer section ', 'online-news'),
	'section' 	=> 'section_footer',
	'settings'  => 'theme_options[disable_search_footer]',
	'type' 		=> 'checkbox',	
	)
);

// Post Section starts
$wp_customize->add_section('section_post', 
	array(    
	'title'       => __('Post Option', 'online-news'),
	'panel'       => 'theme_option_panel'    
	)
);

// Post Read More Text
$wp_customize->add_setting('theme_options[readmore_text]', 
	array(
	'default'           =>  $default['readmore_text'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',	
	'sanitize_callback' => 'sanitize_text_field'
	)
);

$wp_customize->add_control('theme_options[readmore_text]', 
	array(
	'label'       		=> __('Read More', 'online-news'), 
	'description'		=> __('Change text if you want to use other than "Read More"', 'online-news'),  
	'section'     		=> 'section_post',  
	'settings'    		=> 'theme_options[readmore_text]',		
	'type'        		=> 'text',	
	)
);

// Disable  Categories
$wp_customize->add_setting('theme_options[disable_categories]', 
	array(
	'default' 			=> $default['disable_categories'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_categories]', 
	array(		
	'label' 	=> __('Disable categories in archive page ', 'online-news'),
	'section' 	=> 'section_post',
	'settings'  => 'theme_options[disable_categories]',
	'type' 		=> 'checkbox',	
	)
);

// Disable  Post Meta
$wp_customize->add_setting('theme_options[disable_postmeta]', 
	array(
	'default' 			=> $default['disable_postmeta'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_postmeta]', 
	array(		
	'label' 	=> __('Disable Post meta in archive page ', 'online-news'),
	'section' 	=> 'section_post',
	'settings'  => 'theme_options[disable_postmeta]',
	'type' 		=> 'checkbox',	
	)
);
// General Section starts
$wp_customize->add_section('section_general', 
	array(    
	'title'       => __('General Option', 'online-news'),
	'panel'       => 'theme_option_panel'    
	)
);

//Layout Options
$wp_customize->add_setting('theme_options[layout_options]', 
	array(
	'default' 			=> $default['layout_options'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control(new Online_News_Image_Radio_Control($wp_customize, 'theme_options[layout_options]', 
	array(		
	'label' 	=> __('Layout Options', 'online-news'),
	'section' 	=> 'section_general',
	'settings'  => 'theme_options[layout_options]',
	'type' 		=> 'radio-image',
	'choices' 	=> array(		
		'left' 			=> get_template_directory_uri() . '/images/left-sidebar.png',							
		'right' 		=> get_template_directory_uri() . '/images/right-sidebar.png',
		'no-sidebar' 	=> get_template_directory_uri() . '/images/no-sidebar.png',
		),	
	))
);

// Disable Author
$wp_customize->add_setting('theme_options[disable_author]', 
	array(
	'default' 			=> $default['disable_author'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_author]', 
	array(		
	'label' 	=> __('Disable Author ', 'online-news'),
	'description'		=> __('Change will be applied to entire page', 'online-news'),
	'section' 	=> 'section_general',
	'settings'  => 'theme_options[disable_author]',
	'type' 		=> 'checkbox',	
	)
);
// Disable Date
$wp_customize->add_setting('theme_options[disable_date]', 
	array(
	'default' 			=> $default['disable_date'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_date]', 
	array(		
	'label' 	=> __('Disable Date ', 'online-news'),
	'description'		=> __('Change will be applied to entire page', 'online-news'),
	'section' 	=> 'section_general',
	'settings'  => 'theme_options[disable_date]',
	'type' 		=> 'checkbox',	
	)
);

// Pagination Option
$wp_customize->add_setting('theme_options[pagination_option]', 
	array(
	'default' 			=> $default['pagination_option'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control('theme_options[pagination_option]', 
	array(		
	'label' 	=> __('Pagination Options', 'online-news'),
	'section' 	=> 'section_general',
	'settings'  => 'theme_options[pagination_option]',
	'type' 		=> 'radio',
	'choices' 	=> array(		
		'default' 		=> __('Default', 'online-news'),							
		'numeric' 		=> __('Numeric', 'online-news'),		
		),	
	)
);



