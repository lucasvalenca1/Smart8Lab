<?php
/**
 * Home Page Options.
 *
 * @package Online_News
 */

$default = online_news_get_default_theme_options();

// Add Panel.
$wp_customize->add_panel( 'home_page_panel',
	array(
	'title'      => __( 'Home Section Options', 'online-news' ),
	'priority'   => 100,
	'capability' => 'edit_theme_options',
	)
);
// Home Section.
$wp_customize->add_section( 'section_home_content',
	array(
		'title'      => __( 'Home Page Content', 'online-news' ),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'home_page_panel',
		)
);
// Home Content
$wp_customize->add_setting('theme_options[enable_home_section]', 
	array(
	'default' 			=> $default['enable_home_section'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[enable_home_section]', 
	array(		
	'label' 	=> __('Show home Content', 'online-news'),
	'description' => __( 'Check this to show page content in home page', 'online-news'),
	'section' 	=> 'section_home_content',
	'settings'  => 'theme_options[enable_home_section]',
	'type' 		=> 'checkbox',	
	)
);

// Slider Section.
$wp_customize->add_section( 'section_home_slider',
	array(
		'title'      => __( 'Slider Setting', 'online-news' ),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'home_page_panel',
		)
);

// Disable Slider
$wp_customize->add_setting('theme_options[disable_slider_section]', 
	array(
	'default' 			=> $default['disable_slider_section'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_slider_section]', 
	array(		
	'label' 	=> __('Enable Slider Section', 'online-news'),
	'section' 	=> 'section_home_slider',
	'settings'  => 'theme_options[disable_slider_section]',
	'type' 		=> 'checkbox',	
	)
);

// Setting slider_category.
$wp_customize->add_setting( 'theme_options[slider_category]',
	array(
	'default'           => $default['slider_category'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'absint',
	)
);
$wp_customize->add_control(
	new Online_News_Dropdown_Taxonomies_Control( $wp_customize, 'theme_options[slider_category]',
		array(
		'label'    => __( 'Select Category', 'online-news' ),
		'section'  => 'section_home_slider',
		'settings' => 'theme_options[slider_category]',
		'priority' => 100,
		)
	)
);

// Slider Number.
$wp_customize->add_setting( 'theme_options[slider_number]',
	array(
		'default'           => $default['slider_number'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'online_news_sanitize_number_range',
		)
);
$wp_customize->add_control( 'theme_options[slider_number]',
	array(
		'label'       => __( 'No of Slider', 'online-news' ),
		'section'     => 'section_home_slider',
		'type'        => 'number',
		'priority'    => 100,
		'input_attrs' => array( 'min' => 1, 'max' => 5, 'step' => 1, 'style' => 'width: 115px;' ),
		)
);

//  News Section 1.
$wp_customize->add_section( 'news_section_1',
	array(
		'title'      => __( 'Online News: News Section 1', 'online-news' ),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'home_page_panel',
		)
);

// Disable News Section 1
$wp_customize->add_setting('theme_options[disable_news_section_1]', 
	array(
	'default' 			=> $default['disable_news_section_1'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);


$wp_customize->add_control('theme_options[disable_news_section_1]', 
	array(		
	'label' 	=> __('Enable News Section 1', 'online-news'),
	'section' 	=> 'news_section_1',
	'settings'  => 'theme_options[disable_news_section_1]',
	'type' 		=> 'checkbox',	
	)
);

// Setting news section1 category.
$wp_customize->add_setting( 'theme_options[news_section1_category]',
	array(
	'default'           => $default['news_section1_category'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'absint',
	)
);
$wp_customize->add_control(
	new Online_News_Dropdown_Taxonomies_Control( $wp_customize, 'theme_options[news_section1_category]',
		array(
		'label'    => __( 'Select Category', 'online-news' ),
		'section'  => 'news_section_1',
		'settings' => 'theme_options[news_section1_category]',
		'priority' => 110,
		)
	)
);

// News Section 1  Number.
$wp_customize->add_setting( 'theme_options[news_section1_number]',
	array(
		'default'           => $default['news_section1_number'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'online_news_sanitize_number_range',
		)
);
$wp_customize->add_control( 'theme_options[news_section1_number]',
	array(
		'label'       => __( 'Number of News', 'online-news' ),
		'section'     => 'news_section_1',
		'type'        => 'number',
		'priority'    => 110,
		'input_attrs' => array( 'min' => 1, 'max' => 20, 'step' => 1, 'style' => 'width: 115px;' ),
		)
);

// Layout for news Section
$wp_customize->add_setting('theme_options[news_layout]', 
	array(
	'default' 			=> $default['news_layout'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control(new Online_News_Image_Radio_Control($wp_customize, 'theme_options[news_layout]', 
	array(		
	'label' 	=> __('News Section 1 layout', 'online-news'),
	'section' 	=> 'news_section_1',
	'settings'  => 'theme_options[news_layout]',
	'type' 		=> 'radio-image',
	'choices' 	=> array(		
		'layout-1' 	=> get_template_directory_uri() . '/images/layout-1.jpg',						
		'layout-2' 	=> get_template_directory_uri() . '/images/layout-2.jpg',
		'layout-3' 	=> get_template_directory_uri() . '/images/layout-3.jpg',
		'layout-4'	=> get_template_directory_uri() . '/images/layout-4.jpg',
		),	
	)
));

//  News Section 2.
$wp_customize->add_section( 'news_section_2',
	array(
		'title'      => __( 'Online News: News Section 2', 'online-news' ),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'home_page_panel',
		)
);

// Disable News Section 2
$wp_customize->add_setting('theme_options[disable_news_section_2]', 
	array(
	'default' 			=> $default['disable_news_section_2'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_news_section_2]', 
	array(		
	'label' 	=> __('Enable News Section 2', 'online-news'),
	'section' 	=> 'news_section_2',
	'settings'  => 'theme_options[disable_news_section_2]',
	'type' 		=> 'checkbox',	
	)
);

// Setting news section2 category.
$wp_customize->add_setting( 'theme_options[news_section2_category]',
	array(
	'default'           => $default['news_section2_category'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'absint',
	)
);
$wp_customize->add_control(
	new Online_News_Dropdown_Taxonomies_Control( $wp_customize, 'theme_options[news_section2_category]',
		array(
		'label'    => __( 'Select Category', 'online-news' ),
		'section'  => 'news_section_2',
		'settings' => 'theme_options[news_section2_category]',
		'priority' => 110,
		)
	)
);

// News Section 2  Number.
$wp_customize->add_setting( 'theme_options[news_section2_number]',
	array(
		'default'           => $default['news_section2_number'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'online_news_sanitize_number_range',
		)
);
$wp_customize->add_control( 'theme_options[news_section2_number]',
	array(
		'label'       => __( 'Number of News', 'online-news' ),
		'section'     => 'news_section_2',
		'type'        => 'number',
		'priority'    => 110,
		'input_attrs' => array( 'min' => 1, 'max' => 20, 'step' => 1, 'style' => 'width: 115px;' ),
		)
);

// Layout for news Section
$wp_customize->add_setting('theme_options[news_layout2]', 
	array(
	'default' 			=> $default['news_layout2'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control(new Online_News_Image_Radio_Control($wp_customize, 'theme_options[news_layout2]',  
	array(		
	'label' 	=> __('News Section 2 layout', 'online-news'),
	'section' 	=> 'news_section_2',
	'settings'  => 'theme_options[news_layout2]',
	'type' 		=> 'radio-image',
	'choices' 	=> array(		
		'layout-1' 	=> get_template_directory_uri() . '/images/layout-1.jpg',						
		'layout-2' 	=> get_template_directory_uri() . '/images/layout-2.jpg',
		'layout-3' 	=> get_template_directory_uri() . '/images/layout-3.jpg',
		'layout-4'	=> get_template_directory_uri() . '/images/layout-4.jpg',
		),	
	)
));

//  News Section 3.
$wp_customize->add_section( 'news_section_3',
	array(
		'title'      => __( 'Online News: News Section 3', 'online-news' ),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'home_page_panel',
		)
);

// Disable News Section 3
$wp_customize->add_setting('theme_options[disable_news_section_3]', 
	array(
	'default' 			=> $default['disable_news_section_3'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_news_section_3]', 
	array(		
	'label' 	=> __('Enable News Section 3', 'online-news'),
	'section' 	=> 'news_section_3',
	'settings'  => 'theme_options[disable_news_section_3]',
	'type' 		=> 'checkbox',	
	)
);

// Setting news section3 category.
$wp_customize->add_setting( 'theme_options[news_section3_topcategory]',
	array(
	'default'           => $default['news_section3_topcategory'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'absint',
	)
);
$wp_customize->add_control(
	new Online_News_Dropdown_Taxonomies_Control( $wp_customize, 'theme_options[news_section3_topcategory]',
		array(
		'label'    => __( 'Select  Top Category', 'online-news' ),
		'section'  => 'news_section_3',
		'settings' => 'theme_options[news_section3_topcategory]',
		'priority' => 110,
		)
	)
);

// Setting news section3 category.
$wp_customize->add_setting( 'theme_options[news_section3_category]',
	array(
	'default'           => $default['news_section3_category'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'absint',
	)
);
$wp_customize->add_control(
	new Online_News_Dropdown_Taxonomies_Control( $wp_customize, 'theme_options[news_section3_category]',
		array(
		'label'    => __( 'Select Category', 'online-news' ),
		'section'  => 'news_section_3',
		'settings' => 'theme_options[news_section3_category]',
		'priority' => 110,
		)
	)
);

// News Section 3  Number.
$wp_customize->add_setting( 'theme_options[news_section3_number]',
	array(
		'default'           => $default['news_section3_number'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'online_news_sanitize_number_range',
		)
);
$wp_customize->add_control( 'theme_options[news_section3_number]',
	array(
		'label'       => __( 'Number of News', 'online-news' ),
		'section'     => 'news_section_3',
		'type'        => 'number',
		'priority'    => 110,
		'input_attrs' => array( 'min' => 1, 'max' => 20, 'step' => 1, 'style' => 'width: 115px;' ),
		)
);

// Layout for news Section
$wp_customize->add_setting('theme_options[news_layout3]', 
	array(
	'default' 			=> $default['news_layout3'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control(new Online_News_Image_Radio_Control($wp_customize, 'theme_options[news_layout3]',  
	array(		
	'label' 	=> __('News Section 3 layout', 'online-news'),
	'section' 	=> 'news_section_3',
	'settings'  => 'theme_options[news_layout3]',
	'type' 		=> 'radio-image',
	'choices' 	=> array(		
		'layout-1' 	=> get_template_directory_uri() . '/images/layout-1.jpg',						
		'layout-2' 	=> get_template_directory_uri() . '/images/layout-2.jpg',
		'layout-3' 	=> get_template_directory_uri() . '/images/layout-3.jpg',
		'layout-4'	=> get_template_directory_uri() . '/images/layout-4.jpg',
		),	
	)
));

//  News Section 4.
$wp_customize->add_section( 'news_section_4',
	array(
		'title'      => __( 'Online News: News Section 4', 'online-news' ),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'home_page_panel',
		)
);

// Disable News Section 4
$wp_customize->add_setting('theme_options[disable_news_section_4]', 
	array(
	'default' 			=> $default['disable_news_section_4'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_checkbox'
	)
);

$wp_customize->add_control('theme_options[disable_news_section_4]', 
	array(		
	'label' 	=> __('Enable News Section 4', 'online-news'),
	'section' 	=> 'news_section_4',
	'settings'  => 'theme_options[disable_news_section_4]',
	'type' 		=> 'checkbox',	
	)
);

// Setting news section4 category.
$wp_customize->add_setting( 'theme_options[news_section4_category]',
	array(
	'default'           => $default['news_section4_category'],
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'absint',
	)
);
$wp_customize->add_control(
	new Online_News_Dropdown_Taxonomies_Control( $wp_customize, 'theme_options[news_section4_category]',
		array(
		'label'    => __( 'Select Category', 'online-news' ),
		'section'  => 'news_section_4',
		'settings' => 'theme_options[news_section4_category]',
		'priority' => 110,
		)
	)
);

// News Section 3  Number.
$wp_customize->add_setting( 'theme_options[news_section4_number]',
	array(
		'default'           => $default['news_section4_number'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'online_news_sanitize_number_range',
		)
);
$wp_customize->add_control( 'theme_options[news_section4_number]',
	array(
		'label'       => __( 'Number of News', 'online-news' ),
		'section'     => 'news_section_4',
		'type'        => 'number',
		'priority'    => 110,
		'input_attrs' => array( 'min' => 1, 'max' => 20, 'step' => 1, 'style' => 'width: 115px;' ),
		)
);

// Layout for news Section
$wp_customize->add_setting('theme_options[news_layout4]', 
	array(
	'default' 			=> $default['news_layout4'],
	'type'              => 'theme_mod',
	'capability'        => 'edit_theme_options',
	'sanitize_callback' => 'online_news_sanitize_select'
	)
);

$wp_customize->add_control(new Online_News_Image_Radio_Control($wp_customize, 'theme_options[news_layout4]', 
	array(		
	'label' 	=> __('News Section 4 layout', 'online-news'),
	'section' 	=> 'news_section_4',
	'settings'  => 'theme_options[news_layout4]',
	'type' 		=> 'radio-image',
	'choices' 	=> array(		
		'layout-1' 	=> get_template_directory_uri() . '/images/layout-1.jpg',						
		'layout-2' 	=> get_template_directory_uri() . '/images/layout-2.jpg',
		'layout-3' 	=> get_template_directory_uri() . '/images/layout-3.jpg',
		'layout-4'	=> get_template_directory_uri() . '/images/layout-4.jpg',
		),	
	)
));