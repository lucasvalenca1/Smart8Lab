<?php
/**
 * Default theme options.
 *
 * @package Online_News
 */

if ( ! function_exists( 'online_news_get_default_theme_options' ) ) :

	/**
	 * Get default theme options.
	 *
	 * @since 1.0.0
	 *
	 * @return array Default theme options.
	 */
function online_news_get_default_theme_options() {

	$defaults = array();

	$defaults['site_identity']				= 'title-text';
	$defaults['ticker_title'] 				= esc_html__( 'Breaking News:', 'online-news' );
	$defaults['top_bar_left'] 				= 'news-ticker';
	$defaults['top_address']  				= esc_html__( 'Kathmandu Nepal', 'online-news' );
	$defaults['facebook']					= '';
	$defaults['twitter']					= '';
	$defaults['google_plus']				= '';
	$defaults['instagram']					= '';
	$defaults['linkedin']					= '';
	$defaults['top_bar_right'] 				= 'address';
	$defaults['enable_current_date']		= true;
	$defaults['enable_search_form']	    	= true;	

	//Home Page Section Default
	$defaults['enable_home_section']	   	= true; 
	$defaults['slider_category']	   	 	= 0; 	
	$defaults['disable_slider_section']		= false;
	$defaults['slider_number']				= 2;	

	// Home Page News Section 1			
	$defaults['disable_news_section_1']		= false;
	$defaults['news_section1_category']		= 0; 	
	$defaults['news_section1_number']		= 4;
	$defaults['news_layout']				= 'layout-1';  

	// Home Page News Section 2		
	$defaults['disable_news_section_2']		= false;
	$defaults['news_section2_category']		= 0; 	
	$defaults['news_section2_number']		= 4;
	$defaults['news_layout2']				= 'layout-2'; 

	// Home Page News Section 3	
	$defaults['disable_news_section_3']		= false;
	$defaults['news_section3_category']		= 0; 
	$defaults['news_section3_topcategory']		= 0;	
	$defaults['news_section3_number']		= 4;
	$defaults['news_layout3']				= 'layout-3';  

	// Home Page News Section 4		
	$defaults['disable_news_section_4']		= false;
	$defaults['news_section4_category']		= 0; 	
	$defaults['news_section4_number']		= 4;
	$defaults['news_layout4']				= 'layout-4'; 

	//footer section	 		
	$defaults['enable_top_footer']			= true;
	$defaults['enable_scroll_top']			= true;
	$defaults['copyright_text']				= esc_html__( 'Copyright &copy;', 'online-news' );
	$defaults['disable_search_footer']		= false;

	//post settings
	$defaults['layout_options']				= 'right';
	$defaults['readmore_text']  			= esc_html__( 'Read More', 'online-news' );
	$defaults['disable_categories']		    = false;
	$defaults['disable_postmeta']		    = false;

	//generarl settings
	$defaults['disable_author']		   		= false;
	$defaults['disable_date']		    	= false;
	$defaults['pagination_option'] 			= 'default';
	
	// Pass through filter.
	$defaults = apply_filters( 'online_news_filter_default_theme_options', $defaults );
	return $defaults;
}

endif;

/**
*  Get theme options
*/
if ( ! function_exists( 'online_news_get_option' ) ) :

	/**
	 * Get theme option
	 *
	 * @since 1.0.0
	 *
	 * @param string $key Option key.
	 * @return mixed Option value.
	 */
	function online_news_get_option( $key ) {

		$default_options = online_news_get_default_theme_options();

		if ( empty( $key ) ) {
			return;
		}

		$theme_options = (array)get_theme_mod( 'theme_options' );
		$theme_options = wp_parse_args( $theme_options, $default_options );

		$value = null;

		if ( isset( $theme_options[ $key ] ) ) {
			$value = $theme_options[ $key ];
		}

		return $value;

	}

endif;