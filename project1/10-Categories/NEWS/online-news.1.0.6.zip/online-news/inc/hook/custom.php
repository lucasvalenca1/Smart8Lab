<?php
/**
 * Custom theme functions.
 *
 * This file contains hook functions attached to theme hooks.
 *
 * @package Online_News
 */

if( ! function_exists( 'online_news_site_branding' ) ) :
	/**
  	 * Site Branding
  	 *
  	 * @since 1.0.0
  	 */
function online_news_site_branding() { ?>
<section class="top-bar">
	<div class="container">
		<div class=" row flex-wrapper">						
			<div class="col-2">
				<?php $site_identity = online_news_get_option( 'site_identity' );
					$title = get_bloginfo( 'name', 'display' );
                    $description    = get_bloginfo( 'description', 'display' );

                	if( 'logo-only' == $site_identity){

                    if ( has_custom_logo() ) {

                            the_custom_logo();

                        }
                    } elseif( 'logo-text' == $site_identity){

                        if ( has_custom_logo() ) {

                            the_custom_logo();

                        }

                        if ( $description ) {
                            echo '<p class="site-description">'.esc_attr( $description ).'</p>';
                        }

                    } elseif( 'title-only' == $site_identity && $title ){ ?>

                        <h1 class="site-title title-only"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                        <?php 

                    }elseif( 'title-text' == $site_identity){ 
                    	echo '<div class="site-branding">';

                        if( $title ){ ?>

                            <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                            <?php 
                        }

                        if ( $description ) {

                            echo '<p class="site-description">'.esc_attr( $description ).'</p>';

                        }
                        echo '</div>';
                    } 
                ?>  
			</div>		
		
			<div class="col-7 breaking-module">			
				<?php do_action( 'online_news_action_top_left_header' );?>				
			</div>
			<!-- .breaking-module -->

			<div class="col-3 weather-city">
				<?php do_action( 'online_news_action_top_right_header');?>
			</div>
			<!-- .weather -->

		</div>
		<!-- .flex-wrapper -->
	</div>
	<!-- .container -->
</section>			
<!-- .top-bar -->
<div class="menu menu-holder">
	<div class="container">
		<div class="row flex-wrapper">
			<nav id="site-navigation" class="col-11 main-navigation" role="navigation">
				<?php
					wp_nav_menu(
					array(
						'theme_location' => 'primary',				
						'items_wrap'	 =>  '<ul>%3$s</ul>',
						'fallback_cb'    => 'online_news_primary_navigation_fallback',
					)
					);
				?>
			</nav>
			<!-- #site-navigation -->

			<?php $enable_search_form = online_news_get_option( 'enable_search_form' );
				if( 'true' == $enable_search_form):
			?>
				<div class="search-icon col-1" id="search-bar">
					<a href="#" id="searchtoggl"> <i class="fa fa-search" aria-hidden="true"></i> </a>
				</div>
				<!-- .search -->
			<?php endif;?>
		</div>
		<!-- .flex-wrapper -->
	</div>
	<!-- .container -->
</div>
<!-- .menu-item -->

<div id="searchbar">
	<div class="container">
		 <div class="row">
			<div class="col-12 search-wrapper">
				<?php get_search_form();?>
			</div>
		</div>
		<!-- .search-wrapper -->
	</div>	
	<!-- .container -->
</div>

<?php }
endif;
add_action( 'online_news_action_header', 'online_news_site_branding');

if ( ! function_exists( 'online_news_footer_top_section' ) ) :

	/**
	 * Top  Footer 
	 *
	 * @since 1.0.0
	 */
	function online_news_footer_top_section() { 
	$top_footer = online_news_get_option('enable_top_footer'); 
	$search_disable = online_news_get_option('disable_search_footer');
	$footer_class = 'col-7';
		if('false' == $search_disable){
			$footer_class = 'col-10';
		}
		else{
			$footer_class = 'col-7';
		}
		if('true' == $top_footer):?>
			 <div class="site-info">
	            <div class="container">
	                <div class="row flex-wrapper">
	                	<?php if(has_custom_logo()):?>
		                    <div class="col-2">                       
								<?php the_custom_logo();?>			
		                    </div>
	                    <?php endif;?>

	                    <?php if ( has_nav_menu( 'footer-top-menu' ) ) : ?>
	                    	<div class="<?php echo esc_attr($footer_class);?>">
		                        <?php
									wp_nav_menu( array(
										'theme_location'  => 'footer-top-menu',
										'container'       => false,	
										'items_wrap'	  => '<ul>%3$s</ul>',						
										'depth'           => 1,
										'fallback_cb'     => 'online_news_primary_navigation_fallback',
									) );
								?>
		                    </div>
		                <?php endif;?>

		                <?php if( !'false' == $search_disable) : ?>
		                    <div class="col-3">
		                      <?php get_search_form();?>
		                    </div>
	                	<?php endif;?>
	                </div><!-- flex-wrapper -->
	            </div><!-- .container -->
	        </div><!-- .site-info -->
        <?php endif;?>
		
	<?php }

endif;

add_action( 'online_news_action_footer', 'online_news_footer_top_section', 10 );

if ( ! function_exists( 'online_news_footer_section' ) ) :

	/**
	 * Footer copyright
	 *
	 * @since 1.0.0
	 */
	function online_news_footer_section() { ?>
		 <div class="copyright">
            <div class="container">
                <div class="row">
                    <?php if ( has_nav_menu( 'footer-menu' ) ) : ?>
                    	<div class="col-6">
	                        <?php
								wp_nav_menu( array(
									'theme_location'  => 'footer-menu',
									'container'       => false,	
									'items_wrap'	  => '<ul>%3$s</ul>',						
									'depth'           => 1,
									'fallback_cb'     => 'online_news_primary_navigation_fallback',
								) );
							?>
	                    </div>
	                <?php endif;?>
	                <?php 
	                	$copyright_footer = online_news_get_option('copyright_text'); 
	                	if ( ! empty( $copyright_footer ) ) {
							$copyright_footer = wp_kses_data( $copyright_footer );
						}
					?>

                    <div class="col-6"> <span><?php echo esc_html($copyright_footer);?>
                    <?php printf( esc_html__( '%1$s Theme By %2$s', 'online-news' ), 'Online News', '<a href="' . esc_url( 'https://rigorousthemes.com/' ) . '" rel="designer" target="_blank">Rigorous</a>' ); ?>
                    	
                    </span> </div>
                    <?php $enable_scroll_top = online_news_get_option('enable_scroll_top');
                    if ( true == $enable_scroll_top ):  ?>
					    <div class="scroll-top-wrapper">
							<span class="scroll-top-inner">

								<i class="fa fa-2x fa-angle-up"></i>

							</span>
						</div>
					<?php endif; ?>
                </div>
            </div><!-- .container -->
        </div><!-- .copyright -->
		
	<?php }

endif;

add_action( 'online_news_action_footer', 'online_news_footer_section', 10 );

if ( ! function_exists( 'online_news_check_home_page_content' ) ) :

	/**
	 * Check home page content status.
	 *
	 * @since 1.0.0
	 *
	 * @param bool $status Home page content status.
	 * @return bool Modified home page content status.
	 */
	function online_news_check_home_page_content( $status ) {

		if ( is_front_page() ) {
			$home_content_status = online_news_get_option( 'enable_home_section' );
			if ( false === $home_content_status ) {
				$status = false;
			}
		}
		return $status;

	}

endif;

add_filter( 'online_news_filter_home_page_content', 'online_news_check_home_page_content' );


