<?php
/**
 * Basic theme functions.
 *
 * This file contains hook functions attached to core hooks.
 *
 * @package Online_News
 */

if( ! function_exists( 'online_news_primary_navigation_fallback' ) ) :

	/**
	 * Fallback for primary navigation.
	 *
	 * @since 1.0.0
	 */
	function online_news_primary_navigation_fallback() {
		
		echo '<ul>';
			echo '<li><a href="' . esc_url( home_url( '/' ) ) . '">' .esc_html__( 'Home', 'online-news' ). '</a></li>';
			wp_list_pages( array(
			'title_li' => '',
			'depth'    => 1,
			'number'   => 5,
			) );
		echo '</ul>';

	}

endif;


if( ! function_exists( 'online_news_social_links' ) ) : 
	/**
	 *
	 * Social Links
	 *
	 */
	function online_news_social_links() {

		$facebook  		= online_news_get_option( 'facebook' );
		$twitter  		= online_news_get_option( 'twitter' );
		$google_plus  	= online_news_get_option( 'google_plus' );
		$instagram  		= online_news_get_option( 'instagram' );
		$linkedin 		= online_news_get_option( 'linkedin' );
		?>
		<ul class="social-icon">
			<?php if($facebook){?>
				<li>
					<a href="<?php echo esc_url( $facebook ); ?>" target="_blank"><i class="fa fa-facebook"></i></a>
				</li>
			<?php } ?>

			<?php if($twitter){?>
				<li>
					<a href="<?php echo esc_url( $twitter); ?>" target="_blank"><i class="fa fa-twitter"></i></a>
				</li>
			<?php } ?>

			<?php if($google_plus){?>
				<li>
					<a href="<?php echo esc_url( $google_plus); ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
				</li>
			<?php } ?>

			<?php if($instagram){?>
				<li>
					<a href="<?php echo esc_url( $instagram); ?>" target="_blank"><i class="fa fa-instagram"></i></a>
				</li>
			<?php } ?>

			<?php if($linkedin){?>
				<li>
					<a href="<?php echo esc_url( $linkedin); ?>" target="_blank"><i class="fa fa-linkedin"></i></a>
				</li>
			<?php } ?>
		</ul>
	<?php }
endif;
add_action( 'online_news_action_social_links', 'online_news_social_links');


if ( ! class_exists( 'WP_Customize_Control' ) )
  return NULL;

/**
 * Class Online_News_Dropdown_Taxonomies_Control
 */
class Online_News_Dropdown_Taxonomies_Control extends WP_Customize_Control {

    /**
     * Render the control's content.
     *
     * @since 3.4.0
     */
    public function render_content() {
        $dropdown = wp_dropdown_categories(
            array(
                'name'              => 'online-news-dropdown-categories-' . $this->id,
                'echo'              => 0,
                'show_option_none'  => __( '&mdash; Select &mdash;', 'online-news' ),
                'option_none_value' => '0',
                'selected'          => $this->value(),
                'hide_empty'        => 0,                   

            )
        ); 
        
        $dropdown = str_replace( '<select', '<select ' . $this->get_link(), $dropdown );

        printf(
            '<label class="customize-control-select"><span class="customize-control-title">%s</span> %s <span class="description customize-control-description"></span>%s </label>',
            esc_html($this->label),
            esc_html($this->description),
            $dropdown

        );
    }

}
