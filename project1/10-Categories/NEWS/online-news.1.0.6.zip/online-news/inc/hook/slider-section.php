<?php
/**
 * The slider hook for our theme.
 *
 * This is the template that displays slider of the theme
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package online_news
 */

if ( ! function_exists( 'online_news_main_slider' ) ) :

  function online_news_main_slider(){ 

		$disable_slider    		= online_news_get_option( 'disable_slider_section' ); 
		$slider_category   		= online_news_get_option( 'slider_category' );
		$slider_number	   		= online_news_get_option( 'slider_number' );
		?>
		<?php if( true == $disable_slider):?>
			<section class="banner">    
		    	<?php
					$slider_args = array(
						'posts_per_page'      => absint( $slider_number ),				
						'post_type' => 'post',
		                'post_status' => 'publish',
		                'paged' => 1,
						);

					if ( absint( $slider_category ) > 0 ) {
						$slider_args['cat'] = absint( $slider_category );
					}

					// Fetch posts.
					$the_query = new WP_Query( $slider_args );
					
				?>

				<?php if ( $the_query->have_posts() ) : ?>
					<div id="owl-demo" class="owl-carousel owl-theme">
						<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
					        <div class="item">			           
									<?php
										if( has_post_thumbnail() ):
											$post_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'online-news-slider' );
									?>
										 <div class="banner-img">
											<img src="<?php echo esc_url( $post_thumb[0] );?>" alt="<?php the_title_attribute(); ?>"> 	
										</div>						
									<?php endif; ?>		
										             	
					             
					            <!-- .banner-img -->
					            <div class="banner-content">
					                <div class="container">
					                    <div class="col-6 news-content">
					                        <div class="category-link">							 
					 							<?php online_news_category();?>
				 							</div>
					                        <!-- .category -->
					                        <header class="entry-header">
					                            <h3 class="entry-title">
					                                <a href="<?php the_permalink(); ?>"><?php the_title();?></a>
					                            </h3> </header>
					                        <!-- .entry-header -->
					                        <div class="banner-module">
					                        	<?php
													$excerpt = online_news_the_excerpt( 20 );
													echo wp_kses_post( wpautop( $excerpt ) );
												?>
					                        </div>
					                        <!-- .module-content -->
					                       	
					                        <?php online_news_posted_on();?>
					                        <!-- .post-meta -->
					                    </div>
					                    <!-- .news-content -->
					                </div>
					                <!-- .container -->
					            </div>
					            <!-- .banner-content -->
					        </div>
				        <?php endwhile; ?> 
				        <?php wp_reset_postdata(); ?>       
				    </div>
				    <!-- #owl-demo -->  
			    <?php endif;?>  
			</section>
			<!-- .banner -->
		<?php endif;
	}
endif;
add_action( 'online_news_slider', 'online_news_main_slider', 10 );