<?php
 /**
 * Cutsom Hook For Top Header
 *
 *@package Online_News
 *
 */

 if( ! function_exists( 'online_news_top_left_header' ) ):
 	/**
 	 *   Online News Top Left Header 
 	 *
 	 */
 	function online_news_top_left_header() { ?>
 		<?php $top_bar_left = online_news_get_option('top_bar_left');  		

 			if( 'news-ticker'== $top_bar_left): 
 				 $ticker_title = online_news_get_option( 'ticker_title' );							
			?> 			 

	 			<?php $get_featured_posts = new WP_Query( array(
				      'posts_per_page'        => 5,
				      'post_type'             => 'post',
				      'ignore_sticky_posts'   => true
				   ) );
				?>
				<p><strong> <?php echo ( ! empty( $ticker_title ) ) ? esc_html( $ticker_title ) : '&nbsp;'; ?></strong></p> 				
				<div class="breaking-news">									
					<ul>
						<?php while( $get_featured_posts->have_posts() ):$get_featured_posts->the_post(); ?>
							<li>
								<p><a href="<?php the_permalink(); ?>" title="<?php the_title_attribute();?>"><?php the_title(); ?></a></p> 
							</li>
						<?php endwhile; ?>
					</ul>
				</div>
				<?php wp_reset_postdata();?>
			 <?php endif;?> 	

			<?php if( 'menu'== $top_bar_left): 
				 if ( has_nav_menu( 'top-menu' ) ) { ?>
					<nav id="top-nav">
						<?php
							wp_nav_menu( array(
								'theme_location'  => 'top-menu',
								'container'       => false,								
								'depth'           => 1,
								'fallback_cb'     => 'online_news_primary_navigation_fallback',
							) );
						?>
					</nav> <!-- #top-nav --> 
				<?php }
			endif; ?>

			<?php if( 'address'== $top_bar_left):
				$left_address = online_news_get_option( 'top_address' );
				 echo ( ! empty( $left_address ) ) ? esc_html( $left_address ) : '&nbsp;';
			endif;?> 

			<?php if( 'social-link' == $top_bar_left):
				do_action( 'online_news_action_social_links');

			endif; ?>	

 	<?php }
endif;
add_action( 'online_news_action_top_left_header', 'online_news_top_left_header');

if( ! function_exists( 'online_news_right_header' ) ) :
	/**
	 * Online News Top Right Header
	 *
	 */
	function online_news_right_header() { ?>
		<?php $top_bar_right = online_news_get_option('top_bar_right'); 

			if( 'address' == $top_bar_right): 
				$right_address = online_news_get_option( 'top_address' );?>

					<p><span>
						<?php echo ( ! empty( $right_address ) ) ? esc_html( $right_address ) : '&nbsp;';?>					
					</span></p> 
				
			<?php endif;?>

			<?php if( 'search' == $top_bar_right): ?>
				<span>				
					<p><?php get_search_form();?></p>										
				</span>
			<?php endif;?>

			<?php if( 'menu' == $top_bar_right): ?>
					<span>			
						<?php if ( has_nav_menu( 'top-menu' ) ) { ?>
							<nav id="top-nav">
								<?php
									wp_nav_menu( array(
										'theme_location'  => 'top-menu',
										'container'       => false,								
										'depth'           => 1,
										'fallback_cb'     => 'online_news_primary_navigation_fallback',
									) );
								?>
							</nav> <!-- #top-nav --> 
						<?php } ?>										
					</span>
			<?php endif;?>

			<?php if( 'social-link' == $top_bar_right): ?>
					<span>				
						<?php do_action( 'online_news_action_social_links');   ?>											
					</span>
			<?php endif;?>

			<?php $enable_current_date = online_news_get_option( 'enable_current_date' );
			if( 'true' == $enable_current_date ):
			?>
				<p><span class="date">
					<?php $time = date_i18n(__('l, M j, Y','online-news'));
						echo esc_attr($time);
					?>
				</span></p>
			<?php endif;?>
	<?php }

endif;
add_action( 'online_news_action_top_right_header', 'online_news_right_header');



