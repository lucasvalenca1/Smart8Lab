<?php
/**
 * Widget that display breaking news and trending news
 *
 * @package Online_News
 */

/**
 *  Widget For tab section
 */
class online_news_news_tab extends WP_Widget {

	function __construct() {

		global $control_ops;

		$widget_ops = array(						
			'classname' 	=> 'online-news-tab-section', 
			'description' 	=> __( 'A widget that displays posts in tab section', 'online-news') 
			);

		parent::__construct('online-news-news-tab', __('Online News: Categories Tab', 'online-news'), $widget_ops);

		$this->alt_option_name = 'widget_blif';		
	}

	function form($instance) {
		$category_frist = !empty($instance['category_frist']) ? $instance['category_frist'] : '';	
		$category_second = !empty($instance['category_second']) ? $instance['category_second'] : '';
		$number = !empty($instance['number']) ? $instance['number'] : 4;		
		?>		

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('category_frist')); ?>"><?php esc_html_e('Select the frist category :', 'online-news'); ?>
				<?php
				wp_dropdown_categories(array(
					'show_option_none' => ' ',
					'name' => $this->get_field_name('category_frist'),
					'selected' => $category_frist
					));
					?>
				</label>
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('category_second')); ?>"><?php esc_html_e('Select the second category :', 'online-news'); ?>
					<?php
					wp_dropdown_categories(array(
						'show_option_none' => ' ',
						'name' => $this->get_field_name('category_second'),
						'selected' => $category_second
						));
						?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts:', 'online-news'); ?></label>
					<input id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" value="<?php echo absint($number); ?>" size="3">
				</p>
				<?php
			}

			function update($new_instance, $old_instance) {
				$instance = array();
				$instance['number'] = !empty($new_instance['number']) ? absint($new_instance['number']) : 4;
				$instance['category_frist'] = absint($new_instance['category_frist']);		
				$instance['category_second'] = absint($new_instance['category_second']);

				return $instance;
			}

			function widget($args, $instance) {	
				$number = !empty($instance['number']) ? $instance['number'] : 4;		
				$category_frist = isset($instance['category_frist']) ? $instance['category_frist'] : '';
				$category_second = isset($instance['category_second']) ? $instance['category_second'] : '';
				$category_frist_title = get_cat_name($category_frist);
				$category_second_title = get_cat_name($category_second);?>

				<div class="bg-color">
					<div id="tab-wrapper">
						<ul class="resp-tabs-list hor_1">
							<li><?php echo esc_html($category_frist_title); ?> </li>
							<li> <?php echo esc_html($category_second_title); ?> </li>
						</ul>
						<div class="resp-tabs-container hor_1">
							<?php  $online_news_cat_post_args = array(
								'posts_per_page'      => $number,
								'no_found_rows'       => true,
								'post_status'         => 'publish',
								'cat'				  => $category_frist,		
								'ignore_sticky_posts' => true
								); 
							$online_news_tab_query = new WP_Query($online_news_cat_post_args);
							if ($online_news_tab_query->have_posts()) :?>
							<div class="tab-content">
								<?php  while ( $online_news_tab_query->have_posts() ) :$online_news_tab_query->the_post();  ?> 
									<article class="module-content">
										<header class="entry-header">
											<h3 class="entry-title">
												<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
											</h3> 
										</header>
										<!-- .entry-header -->
										<?php online_news_posted_on();?>
										<!-- .post-meta -->
									</article>
									<!-- .module-content -->
								<?php endwhile;?>
							</div>
							<!-- .tab-content -->
							<?php wp_reset_postdata();?>	
						<?php endif;?>
						

						<?php  $online_news_cat_post_args = array(
							'posts_per_page'      => $number,
							'no_found_rows'       => true,
							'post_status'         => 'publish',
							'cat'				  => $category_second,		
							'ignore_sticky_posts' => true
							); 
						$online_news_tab_query = new WP_Query($online_news_cat_post_args);
						if ($online_news_tab_query->have_posts()) :?>
						<div class="tab-content">
							<?php  while ( $online_news_tab_query->have_posts() ) :$online_news_tab_query->the_post();  ?> 
								<article class="module-content">
									<header class="entry-header">
										<h3 class="entry-title">
											<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
										</h3> 
									</header>
									<!-- .entry-header -->
									<?php online_news_posted_on();?>
									<!-- .post-meta -->
								</article>
								<!-- .module-content -->
							<?php endwhile;?>
						</div>
						<!-- .tab-content -->
					<?php endif;?>
					<!-- .tab-content -->
					<?php wp_reset_postdata();?>
				</div>
				<!-- .resp-tabs-container -->
			</div>
			<!-- .tab-wrapper -->
		</div>
		<?php }

	}

	add_action( 'widgets_init', 'register_news_tab_section_widget' );
	function register_news_tab_section_widget() {

		register_widget( 'online_news_news_tab' );
		
	}

/**
 *  Widget For  news section
 */
class online_news_news_section extends WP_Widget {

	function __construct() {

		global $control_ops;

		$widget_ops = array(						
			'classname' 	=> 'online-news-section', 
			'description' 	=> __( 'A widget that displays posts.', 'online-news') 
			);

		parent::__construct('online-news-news-section', __('Online News: News Section', 'online-news'), $widget_ops);

		$this->alt_option_name = 'widget_blif';		
	}

	function form($instance) {
		$category = !empty($instance['category']) ? $instance['category'] : '';		
		$number = !empty($instance['number']) ? $instance['number'] : 4;			
		$radio_buttons = !empty($instance['radio_buttons']) ? $instance['radio_buttons'] : 'radio_option_1';	
		?>		

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php esc_html_e('Select the category :', 'online-news'); ?>
				<?php
				wp_dropdown_categories(array(
					'show_option_none' => ' ',
					'name' => $this->get_field_name('category'),
					'selected' => $category
					));
					?>
				</label>
			</p>	

			<p>
				<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts:', 'online-news'); ?></label>
				<input id="<?php echo esc_attr(($this->get_field_id('number'))); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" value="<?php echo absint($number); ?>" size="3">
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('text_area'); ?>">
					<?php echo esc_html__('Online News Layouts','online-news'); ?>
				</label><br>
				<label for="<?php echo $this->get_field_id('radio_buttons'); ?>">
					
					<input class="" id="<?php echo $this->get_field_id('radio_option_1'); ?>" name="<?php echo $this->get_field_name('radio_buttons'); ?>" type="radio" value="radio_option_1" <?php if($radio_buttons === 'radio_option_1'){ echo 'checked="checked"'; } ?> />
					<img src="<?php echo get_template_directory_uri();?>/images/layout-03.jpg">
				</label>
				<label for="<?php echo $this->get_field_id('radio_buttons'); ?>">
					
					<input class="" id="<?php echo $this->get_field_id('radio_option_2'); ?>" name="<?php echo $this->get_field_name('radio_buttons'); ?>" type="radio" value="radio_option_2" <?php if($radio_buttons === 'radio_option_2'){ echo 'checked="checked"'; } ?> />
					<img src="<?php echo get_template_directory_uri();?>/images/layout-01.jpg">
				</label>
				<label for="<?php echo $this->get_field_id('radio_buttons'); ?>">
					
					<input class="" id="<?php echo $this->get_field_id('radio_option_3'); ?>" name="<?php echo $this->get_field_name('radio_buttons'); ?>" type="radio" value="radio_option_3" <?php if($radio_buttons === 'radio_option_3'){ echo 'checked="checked"'; } ?> />
					<img src="<?php echo get_template_directory_uri();?>/images/layout-02.jpg">
				</label>
			</p>
			<?php
		}

		function update($new_instance, $old_instance) {
			$instance = array();
			$instance['number'] = !empty($new_instance['number']) ? absint($new_instance['number']) : 4;
			$instance['category'] = absint($new_instance['category']);
			$instance['radio_buttons'] = strip_tags($new_instance['radio_buttons']);		
			
			return $instance;
		}
		function widget($args, $instance) {	
			$number = !empty($instance['number']) ? $instance['number'] : 4;		
			$category = isset($instance['category']) ? $instance['category'] : '';	
			$radio_buttons = isset($instance['radio_buttons']) ? $instance['radio_buttons'] : '';	
			$category_title = get_cat_name($category);
			
			?>
			<?php if($radio_buttons == 'radio_option_3'):?>		
				<div class="health widget">
					<?php  $online_news_cat_post_args = array(
						'posts_per_page'      => $number,
						'no_found_rows'       => true,
						'post_status'         => 'publish',
						'cat'				  => $category,		
						'ignore_sticky_posts' => true
						); 
					$online_news_tab_query = new WP_Query($online_news_cat_post_args);
					if ($online_news_tab_query->have_posts()) :?>
					<header class="entry-header module-title">
						<h2 class="entry-title"> <?php echo esc_html($category_title); ?> </h2> 
					</header>
					<div class="health-content">	                		
						<?php  while ( $online_news_tab_query->have_posts() ) :$online_news_tab_query->the_post();  ?> 
							<article class="small-module">
								<?php if(has_post_thumbnail()):?>
									<figure class="small-image">
										<a href="<?php the_permalink();?>"><?php the_post_thumbnail('online-news-postthumb-thumb');?></a>
									</figure>
								<?php endif;?>		                    
								<div class="small-info"> 
									<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
								</h3> 
							</div>
							<!-- .entry-header -->
							<?php online_news_posted_on();?>
							<!-- .post-meta -->
						</article>
						<!-- .module-content -->
					<?php endwhile;?>
				</div>
				<!-- .tab-content -->
				<?php wp_reset_postdata();?>
			<?php endif;?>        	
			
		</div>
		
	<?php endif; ?>
	<?php if($radio_buttons == 'radio_option_2'):?>
		<div class="news-widget">
			<?php  $online_news_cat_post_args = array(
				'posts_per_page'      => $number,
				'no_found_rows'       => true,
				'post_status'         => 'publish',
				'cat'				  => $category,		
				'ignore_sticky_posts' => true
				); 
			$online_news_tab_query = new WP_Query($online_news_cat_post_args);
			if ($online_news_tab_query->have_posts()) :?>                
			<header class="widget-header module-title">
				<h2 class="entry-title"> <?php echo esc_html($category_title); ?> </h2> 
			</header>                       
			<?php  while ( $online_news_tab_query->have_posts() ) :$online_news_tab_query->the_post();  ?>		                	
				<aside class="module-post">
					<?php if( has_post_thumbnail() ):?>
						<figure>
							<a href="<?php the_permalink();?>"><?php the_post_thumbnail('online-news-sidebar-thumb');?></a>
						</figure>
					<?php endif;?>
					<header class="entry-header">
						<h3 class="entry-title">
							<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
						</h3> 
					</header>
					<!-- .entry-header -->
					<div class="news-summary"> 
						<?php
						$excerpt = online_news_the_excerpt(12);
						echo wp_kses_post( wpautop( $excerpt ) );
						?>
					</div>                               
				</aside> 			                    
				<!-- .module-content -->	                    
			<?php endwhile;?>
			<?php wp_reset_postdata();?>               
		<?php endif;?>        	
		
	</div>
<?php endif;?>	

<?php if($radio_buttons == 'radio_option_1'): ?>
	<div class="news-widget">
		<?php  $online_news_cat_post_args = array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'cat'				  => $category,		
			'ignore_sticky_posts' => true
			); 
		$online_news_tab_query = new WP_Query($online_news_cat_post_args);
		if ($online_news_tab_query->have_posts()) :?>                
		<header class="widget-header module-title">
			<h2 class="entry-title"> <?php echo esc_html($category_title); ?> </h2> 
		</header>
		<aside class="col-12 module-post feature-list">
			<ul class="article-post">
				<?php $i= 0;?>                       
				<?php  while ( $online_news_tab_query->have_posts() ) :$online_news_tab_query->the_post(); $i++; ?>
					<li>			                			
						<article class="module-content">
							<?php if($i==1):?>
								<?php if( has_post_thumbnail() ):?>
									<figure>
										<a href="<?php the_permalink();?>"><?php the_post_thumbnail('online-news-post-thumb');?></a>
									</figure>
								<?php endif;?>
							<?php endif;?>
							<div class="category-link">							 
								<?php online_news_category();?>
							</div>
							<!-- .module-category -->
							
							<header class="entry-header">
								<h3 class="entry-title">
									<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
								</h3> 
							</header>
							<!-- .entry-header --> 
							<?php if($i==1):?>
								<div class="news-summary"> 
									<?php
									$excerpt = online_news_the_excerpt(12);
									echo wp_kses_post( wpautop( $excerpt ) );
									?>
								</div>
							<?php endif;?>                               
						</article>			                    
						<!-- .module-content -->			
					</li>               
				<?php endwhile;?>
			</ul>
		</aside>
		<?php wp_reset_postdata();?>               
	<?php endif;?>        	
	
</div>
<?php endif;?>

<?php }

}
add_action( 'widgets_init', 'register_news_news_section_widget' );
function register_news_news_section_widget() {

	register_widget( 'online_news_news_section' );
	
}

/**
 *  Widget For Article section 
 */
add_action( 'widgets_init', 'register_news_article_section_widget' );
function register_news_article_section_widget() {

	register_widget( 'online_news_article_section' );
	
}

class online_news_article_section extends WP_Widget {

	function __construct() {

		global $control_ops;

		$widget_ops = array(						
			'classname' 	=> 'online-news-article-section', 
			'description' 	=> __( 'A widget that displays article.', 'online-news') 
			);

		parent::__construct('online-news-article-section', __('Online News: Article  Section', 'online-news'), $widget_ops);

		$this->alt_option_name = 'widget_blif';		
	}

	function form($instance) {
		$category = !empty($instance['category']) ? $instance['category'] : '';		
		$number = !empty($instance['number']) ? $instance['number'] : 4;		
		?>		

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php esc_html_e('Select the category :', 'online-news'); ?>
				<?php
				wp_dropdown_categories(array(
					'show_option_none' => ' ',
					'name' => $this->get_field_name('category'),
					'selected' => $category
					));
					?>
				</label>
			</p>	

			<p>
				<label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php esc_html_e('Number of posts:', 'online-news'); ?></label>
				<input id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="number" value="<?php echo absint($number); ?>" size="3">
			</p>
			<?php
		}

		function update($new_instance, $old_instance) {
			$instance = array();
			$instance['number'] = !empty($new_instance['number']) ? absint($new_instance['number']) : 4;
			$instance['category'] = absint($new_instance['category']);		
			
			return $instance;
		}

		function widget($args, $instance) {	
			$number = !empty($instance['number']) ? $instance['number'] : 4;		
			$category = isset($instance['category']) ? $instance['category'] : '';		
			$category_title = get_cat_name($category);		
			?>		
			<div class="news-widget author-info">
				<?php  $online_news_cat_post_args = array(
					'posts_per_page'      => $number,
					'no_found_rows'       => true,
					'post_status'         => 'publish',
					'cat'				  => $category,		
					'ignore_sticky_posts' => true
					); 
				$online_news_tab_query = new WP_Query($online_news_cat_post_args);
				if ($online_news_tab_query->have_posts()) :?>                
				<header class="widget-header module-title">
					<h2 class="entry-title"> <?php echo esc_html($category_title); ?> </h2> 
				</header>
				<ul class="article-post">
					<?php  while ( $online_news_tab_query->have_posts() ) :$online_news_tab_query->the_post();  ?>
						<li>
							<aside class="module-post">
								<div class="author-img">
									<?php online_news_posted_on();?>	                                    
									<!-- .post-meta -->
									<?php if( has_post_thumbnail() ) :
									$post_thumb = wp_get_attachment_image_src( get_post_thumbnail_id(), 'online-news-article-thumb' );
									?>
									<a href="<?php the_permalink();?>">
										<img src="<?php echo esc_url( $post_thumb[0] );?>" class="news-author" alt="<?php the_title_attribute(); ?>"> 
									</a>
								<?php endif;?>	                                    
							</div>

							<header class="entry-header">
								<h3 class="entry-title">
									<a href="<?php the_permalink();?>"><?php echo wp_trim_words( get_the_title(), 8 ); ?></a>
								</h3> 
							</header>
							<!-- .entry-header -->                                
						</aside> 			                    
						<!-- .module-content -->
					</li>
				<?php endwhile;?>
			</ul>
			<?php wp_reset_postdata();?>	               
		<?php endif;?>        	
		
	</div>
	<!-- .latest -->
	
	<?php }
}