<?php
/**
 * The template for displaying home page.
 * @package Online_News
 */

get_header(); ?>
<?php if ( 'posts' != get_option( 'show_on_front' ) ){?>
            
    <?php 
         $enable_home_section     = online_news_get_option('enable_home_section');   
         $disable_section1_layout = online_news_get_option('disable_news_section_1');
         $disable_section2_layout = online_news_get_option('disable_news_section_2');
         $disable_section3_layout = online_news_get_option('disable_news_section_3');
         $disable_section4_layout = online_news_get_option('disable_news_section_4');   
                 
    ?>
    <?php 
        if( 'true' == $disable_section1_layout):
             get_template_part( 'template-parts/home-page/news', 'section1' );
        endif;

        get_template_part( 'template-parts/home-page/news', 'advertisement' ); 
        
        if(  'true' == $disable_section2_layout):
            get_template_part( 'template-parts/home-page/news', 'section2' );
        endif;  

        get_template_part( 'template-parts/home-page/news', 'advertisement1' ); 

        if(  'true' == $disable_section3_layout):
             get_template_part( 'template-parts/home-page/news', 'section3' );
        endif;

        get_template_part( 'template-parts/home-page/news', 'advertisement2' );   

        if(  'true' == $disable_section4_layout ):
             get_template_part( 'template-parts/home-page/news', 'section4' );
        endif; 

        if(  'true' == $enable_home_section ):
             get_template_part( 'page' );
        endif; 


    ?>
  
<?php } else{ ?>  

    <?php 
        $layout_class ='col-9';
        $sidebar_layout = online_news_get_option('layout_options'); 

        if( is_active_sidebar('sidebar-1') && 'no-sidebar' !==  $sidebar_layout){
            $layout_class = 'col-9';
        }
        else{
            $layout_class = 'col-12';
        }       
    ?>
    <div class="row">
        <div class="<?php echo esc_attr($layout_class);?> sidebar-layout">
            <section class="news-listing">
                <?php
                if ( have_posts() ) :
                    $i = 0;
                    if ( is_home() && ! is_front_page() ) : ?>
                        <header>
                            <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
                        </header>

                    <?php
                    endif;

                    /* Start the Loop */
                    while ( have_posts() ) : the_post();
                        if($i%2==0):
                            echo '<div class="row">';
                        endif;
                        /*
                         * Include the Post-Format-specific template for the content.
                         * If you want to override this in a child theme, then include a file
                         * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                         */
                        get_template_part( 'template-parts/content', get_post_format() );

                        $i++;
                        if($i%2==0):
                            echo '</div>';
                        endif;

                    endwhile;

                        $pagination_option =online_news_get_option('pagination_option');  
                        if('default' == $pagination_option){
                            the_posts_navigation();
                        }
                        else{
                            the_posts_pagination( array(
                                'mid_size' => 2,
                                'prev_text' => __( '<<', 'online-news' ),
                                'next_text' => __( '>>', 'online-news' ),
                            ) );
                        }
                    else :

                    get_template_part( 'template-parts/content', 'none' );

                endif; ?>
            </section>
        </div>
        <?php do_action( 'online_news_action_sidebar' );?>  
    </div>


<?php }?>
<?php get_footer();?>