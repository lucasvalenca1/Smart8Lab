<?php
/**
* The header for our theme
*
* This is the template that displays all of the <head> section and everything up until <div id="content">
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package Online_News
*/

?>
<?php
	/**
	* Hook - online_news_action_doctype.
	*
	* @hooked online_news_doctype -  10
	*/
	do_action( 'online_news_action_doctype' );
	?>
	<head>
	<?php
	/**
	* Hook - online_news_action_head.
	*
	* @hooked online_news_head -  10
	*/
	do_action( 'online_news_action_head' );
	?>

	<?php wp_head(); ?>
	</head>

<body <?php body_class(); ?>>
	<?php
		/**
		* Hook - online_news_action_before.
		*
		* @hooked online_news_page_start - 10
		* @hooked online_news_skip_to_content - 15
		*/
		do_action( 'online_news_action_before' );
		?>

		<?php
		/**
		* Hook - online_news_action_before_header.
		*
		* @hooked online_news_header_start - 10
		*/
		do_action( 'online_news_action_before_header' );
		?>

		<?php 
		/**
		 *Hook - online_news_action_head.
		 *
		 *@hooked online_news_site_branding
		 */
		do_action( 'online_news_action_header' ); 
		?>		

		<?php
		/**
		* Hook - online_news_action_after_header.
		*
		* @hooked online_news_header_end - 10
		*/
		do_action( 'online_news_action_after_header' );
		?>

		<?php
		/**
		* Hook - online_news_action_before_content.
		*
		* @hooked online_news_content - 10
		*/
		do_action( 'online_news_action_before_content' );
		?>		

