var $ = jQuery;
$(document).ready(function () {
    'use strict';
    // Tabbed widget
    if (typeof jQuery.fn.easytabs !== 'undefined') {

        jQuery('.tab-widget').easytabs();
    }
});
