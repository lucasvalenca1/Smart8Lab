----------------------------------
NewsPress Lite
----------------------------------
Version: 	2.7
Developer: 	D5 Creation
Author URI: 	https://d5creation.com

Donation Link: 	https://d5creation.com/donate/

Copyright: 	D5 Creation
License: 		GNU General Public License v2 or later
License URI: 	http://www.gnu.org/licenses/gpl-2.0.html

This Product is provided "as is" with no waranty or liabilities of D5 Creation. All the PHP Code, Images and other particulars included with this product are licensed under the same License (GPL) of the Theme or Compatible  Licenses.


1. Some Part of screenshot.png, License: Public Domain CC0, https://pixabay.com/en/woman-hat-the-elegance-jewelry-1028398/, https://pixabay.com/en/girl-snow-dress-red-life-blonde-1163269/, https://pixabay.com/en/girl-portrait-beauty-long-hair-755864/

2. jQuery Fraction Slider, License: MIT, Author: Mario J�ckle, Source: http://fractionslider.jacksbox.de

3. Genericons Fonts, License: GPL, Author: AUTOMATTIC, Source: http://genericons.com/

All other images are Lincenced Under GNU GPL and Copyrighted to D5 Creation

NB: No Sub Menus will be shown in the Top Menu

Version 2.5
--------------------
- Style Update

Version 2.3
--------------------
- Narrow Width Template Added

Version 1.9
--------------------
- Code Cleanup

Version 1.7
--------------------
- Code Cleanup
- Some Tags Added


Version 1.5
--------------------
The 1.5 Version is a Major Version
- Added Customize for Theme Options
- Removed Options Framework
- Translation Ready
