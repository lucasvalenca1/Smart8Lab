<?php
/* 	News Press's Footer
	Copyright: 2014-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since NewsPress 1.0
*/
?>

</div><!-- container -->
<div class="clear"> </div>
<div id="footer">

<div id="footer-content">
<?php
   	get_sidebar( 'footer' );
?>
</div> <!-- footer-content -->
<div id="creditline"><span class=".alignleft"><?php newspress_creditline(); ?></span></span></div><a href="#" class="go-top"> </a>
</div> <!-- footer -->
</div><!-- site-container -->
<?php wp_footer(); ?>
</body>
</html>