===  Newsliner ===

Contributors: Thememattic
Tags: blog, news, entertainment, one-column, two-columns, left-sidebar, right-sidebar, post-formats, custom-background, custom-menu, featured-images, full-width-template, custom-header, translation-ready, theme-options, threaded-comments


Requires at least: 4.5
Tested up to: 4.9.4
Stable tag: 1.0.0

== Theme License & Copyright ==
Newsliner is distributed under the terms of the GNU GPL
Newsliner Copyright 2018 Newsliner,Thememattic

License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html


== Description ==
Child Theme of Perfect Magazine, Newsliner is a powerful and stylish WordPress magazine theme suitable for news, newspaper, magazine, sports, technology, food, travel, blogs, publishing, business and any kind of sites.


WordPress theme "Newsliner" is a child theme of "Perfect Magazine".
Perfect Magazine Theme is licensed under the GPL3.


== Google Fonts ==
Source Sans Pro
Source: https://fonts.google.com/specimen/Source+Sans+Pro
License: Open Font License


Playfair Display
Source: https://fonts.google.com/specimen/Playfair+Display
License: Open Font License

License for images:
https://pixabay.com/en/beautiful-woman-beauty-bright-3116587/ by jonas-svidras and is licensed under CC0 Creative Commons
https://pixabay.com/en/beautiful-bright-beauty-fashion-2768032/ by jonas-svidras and is licensed under CC0 Creative Commons
https://pixabay.com/en/beautiful-bright-beauty-fashion-2819394/ by jonas-svidras and is licensed under CC0 Creative Commons
https://pixabay.com/en/wedding-beach-love-couple-1770860/ by adamkontor and is licensed under CC0 Creative Commons
https://pixabay.com/en/car-race-ferrari-racing-car-pirelli-438467/ byUp-Free  and is licensed under CC0 Creative Commons



Released all under CC0 Creative Commons

== 1.0.0  =
* Initial release
