		<div class="entry-meta">
			<?php cleanews_posted_on(); ?> <span class="grey-text">by</span> <?php echo get_the_author(); ?>
		</div><!-- .entry-meta -->