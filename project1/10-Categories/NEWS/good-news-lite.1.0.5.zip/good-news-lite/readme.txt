== Good News Lite ==
Theme URI: https://electrathemes.com/wordpress-themes/good-news-lite/
Author: ElectraThemes
Author URI: http://electathemes.com/
Requires at least: 4.0
Tested up to: 4.9.5
Stable tag: 1.0.5
Tags: two-columns, right-sidebar,left-sidebar,full-width-template, flexible-header, custom-colors, custom-menu, custom-logo, featured-images, footer-widgets, featured-image-header, theme-options, threaded-comments, translation-ready, blog
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Text Domain: good-news-lite

== Theme Description ==

Good News Lite is a WordPress theme for news, affiliate blog and magazine websites. It is a mobile responsive WordPress theme and home page is driven by widgets section of WordPress customizer. Good News Lite is a very newbie friendly WordPress theme as website like the demo can be launched easily with the help of step by step documentation and tutorial which is available for free is here: https://electrathemes.com/documentation/good-news-lite/

== Copyright ==
Good News Lite WordPress Theme, Copyright 2017 ElectraThemes
Good News Lite is distributed under the terms of the GNU GPL

== Installation ==

1. Primary:
 = Login to your wp-admin account and go to Appearance -> Themes.
 = Select "Install" tab and click on the "Upload" link.
 = Select "good-news-lite.zip" and click on "Install Now" button.
 = In case of errors, use an alternate method.
 
2. Alternate:
 = Unzip the template file (good-news-lite.zip) that you have downloaded.
 = Upload the entire folder (good-news-lite) to your server via FTP and place it in the /wp-content/themes/ folder.
 = Do not change the directory name.
 = The template files should be there now: /wp-content/themes/good-news-lite/index.php (example).
 
3. Log into your WP admin panel and click on "Appearance". Go to "Themes" tab.

4. Now click on 'good-news-lite' to activate the theme.

5. Complete all of the required inputs in the Appearance => Custimize option and click "Save & Publish" to make the changes LIVE.
 

=========== Change-log ===========
= 1.0.0 (10th April 2018) 
* Theme submitted to WordPress.org for review.

= 1.0.1 (12th April 2018) 
* Misc Changes.

= 1.0.2 (13th April 2018) 
* Misc Changes.

= 1.0.3 (27th April 2018) 
* Customize file update sanitization.
* Misc changes.

= 1.0.4 (28th April 2018) 
* Pro link added.

= 1.0.5 (5th July 2018) 
* Misc Changes.

---------------------------------------------------------
License and Copyrights for Resources used in this theme
---------------------------------------------------------

Fontawesome
===========
License URI:  http://fontawesome.io/license/
Resource Name: fontawesome
License Name: Open Font License (OFL) Version 4.6.1	
	
Fonts
===========
PT Sans - http://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i
Oswald - http:////fonts.googleapis.com/css?family=Oswald:500,300,600,700
They are under SIL Open Font.
	
Bootstrap files
===========
Bootstrap - http://getbootstrap.com v3.3.7 
Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)


Owl carousel files
===========
Owl carousel - v2.2.1 David Deutsch
Licensed under MIT (https://github.com/OwlCarousel2/OwlCarousel2/blob/develop/LICENSE)

 
TGM Plugin Activation files
=======================
TGM Plugin Activation
Version 2.6.1
Licensed under GNU GPL - https://github.com/TGMPA/TGM-Plugin-Activation

== Resources ==

https://www.pexels.com/photo/woman-holding-card-while-operating-silver-laptop-919436/ © bruce mars ,CC0
https://www.pexels.com/photo/red-people-outside-sport-2207/ ©  Pixabay ,CC0
https://www.pexels.com/photo/brunette-woman-blonde-long-hair-in-white-off-shoulder-sleeve-at-daytime-90754/ © Pixabay  ,CC0
https://www.pexels.com/photo/portrait-of-young-woman-with-umbrella-247199/ ©  Pixabay ,CC0
https://www.pexels.com/photo/photo-of-women-wearing-eye-mask-787968/ © bruce mars  ,CC0
https://www.pexels.com/photo/woman-using-hair-brush-39250/ © Pixabay  ,CC0
https://www.pexels.com/photo/woman-waving-her-hair-874576/ © Rakicevic Nenad  ,CC0
https://www.pexels.com/photo/bride-decoration-fashion-flowers-265705/ ©  Pixabay ,CC0
