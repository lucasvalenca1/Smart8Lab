<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Good News Lite
 */

get_header(); ?>
<section id="blog">
	<div class="contain blog">
		<!-- latest post -->
		<div class="container">
			<div class="latest-post">
				<div class="row">
					<div class="active_page">						
						<div class="clearfix"></div>
					</div> <!-- //active_page -->
					<?php if(get_theme_mod('blogsidebar',2) == 1) : 
							get_sidebar();
						endif;
					?>
					<?php $col_class = (get_theme_mod('blogsidebar',2) == 3)?'12':'8'; ?>
					<div class="col-lg-<?php echo esc_attr($col_class); ?> col-md-<?php echo esc_attr($col_class); ?> col-sm-12 col-xs-12">
						<h2><?php esc_html_e('404 Page Not Found','good-news-lite'); ?></h2>
						<p><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'good-news-lite' ); ?></p>
						<?php get_search_form(); ?>
					</div><!-- .page-content -->
					<?php if(get_theme_mod('blogsidebar',2) == 2) : 
							get_sidebar();
						endif;
					?>
				</div>
			</div>
		</div>
	</div>
<section>
<?php
get_footer();
