<?php
/**
 * Template Name: Home Page
 *
 *@link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 *@package Good News Lite
 */
get_header();
if ( 'posts' == get_option( 'show_on_front' ) ) { ?>
   <section id="blog-post-<?php the_ID(); ?>" <?php post_class(); ?>> 
    <div class="contain blog">
        <?php get_template_part( 'template-parts/content', get_post_format() );?>   
    </div>
</section>
<?php } else {   ?>
<section id="blog">
    <div class="contain blog">
        <!-- latest post -->
        <div class="container">
            <div class="latest-post">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <?php 
                            if (is_active_sidebar('home-page-main-slider')){
                                dynamic_sidebar('home-page-main-slider');
                           } ?>
                        </div>
                        <div class="row">
                            <?php
                            if (is_active_sidebar('home-page-video-section')){
                                dynamic_sidebar('home-page-video-section');
                            } ?>
                        </div>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <?php
                                if (is_active_sidebar('home-page-category-section')){
                                    dynamic_sidebar('home-page-category-section');
                                } ?>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <?php
                            if (is_active_sidebar('home-page-category-section2')){
                                dynamic_sidebar('home-page-category-section2');
                            } ?>
                            </div>
                        </div>                        
                        <div class="row">
                            <?php
                            if(is_active_sidebar('home-page-news-gallery')){
                                dynamic_sidebar('home-page-news-gallery');
                            }
                            ?>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php } get_footer();