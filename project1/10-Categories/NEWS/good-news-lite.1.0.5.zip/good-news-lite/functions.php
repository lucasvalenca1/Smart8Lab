<?php
if ( ! function_exists( 'good_news_lite_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function good_news_lite_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Good News Lite, use a find and replace
		 * to change 'good-news-lite' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'good-news-lite', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );		

		add_theme_support( 'title-tag' );

		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary', 'good-news-lite' ),
			'header-menu' => esc_html__( 'Top Header Menu', 'good-news-lite' ),
			'footer-menu' => esc_html__( 'Footer Menu', 'good-news-lite' ),
		) );

		add_image_size('good_news_lite_thumbnail_image', 840, 560, true);
        add_image_size('good_news_lite_PostThumbnailImage', 565, 355, true);
        add_image_size('good_news_lite_SliderPostThumbnailImage', 278, 173, true);
		add_image_size('good_news_lite_ThumbnailSmallImage', 110, 75, true);
		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array('comment-form','comment-list',) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'good_news_lite_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
			'priority' => 11,
            'header-text' => array('img-responsive-logo', 'site-description-logo'),
		) );
		function good_news_lite_active_widgets($active) {            

            //Bundled Widgets
            $active['tabs'] = true;
            $active['accordion'] = true;
            $active['video'] = true;
            $active['testimonial'] = true;
            $active['taxonomy'] = true;
            $active['social-media-buttons'] = true;
            $active['simple-masonry'] = true;
            $active['slider'] = true;
            $active['cta'] = true;
            $active['contact'] = true;
            $active['features'] = true;
            $active['headline'] = true;
            $active['hero'] = true;
            $active['icon'] = true;
            $active['image-grid'] = true;
            $active['price-table'] = true;
            $active['layout-slider'] = true;

            return $active;
        }
        add_filter('siteorigin_widgets_active_widgets', 'good_news_lite_active_widgets');
        
        $user = wp_get_current_user();
        update_user_option($user->ID, 'managenav-menuscolumnshidden',
            array( 0 => 'link-target',  1 => 'xfn', 2 => 'description', 3 => 'title-attribute', ),
            true);
	}
endif;
add_action( 'after_setup_theme', 'good_news_lite_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function good_news_lite_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'good_news_lite_content_width', 640 );
}
add_action( 'after_setup_theme', 'good_news_lite_content_width', 0 );


add_filter( 'nav_menu_css_class', 'good_news_lite_nav_menu_css_class' );
add_filter( 'walker_nav_menu_start_el', 'good_news_lite_walker_nav_menu_start_el', 10, 4 );

function good_news_lite_nav_menu_css_class( $classes ){
        if( is_array( $classes ) ){
            $tmp_classes = preg_grep( '/^(fa)(-\S+)?$/i', $classes );
            if( !empty( $tmp_classes ) ){
                $classes = array_values( array_diff( $classes, $tmp_classes ) );
            }
        }
        return $classes;
}
function good_news_lite_walker_nav_menu_start_el( $item_output, $item, $depth, $args ){
        if( is_array( $item->classes ) ){
            $classes = preg_grep( '/^(fa)(-\S+)?$/i', $item->classes );
            if( !empty( $classes ) ){
                $item_output = good_news_lite_replace_item( $item_output, $classes );
            }
        }
        return $item_output;
}
function good_news_lite_replace_item( $item_output, $classes ){       
       $spacer = ' ';
        if( !in_array( 'fa', $classes ) ){
            array_unshift( $classes, 'fa' );
        }

        $before = true;
        if( in_array( 'fa-after', $classes ) ){
            $classes = array_values( array_diff( $classes, array( 'fa-after' ) ) );
            $before = false;
        }

        $icon = '<i class="' . implode( ' ', $classes ) . '"></i>';

        preg_match( '/(<a.+>)(.+)(<\/a>)/i', $item_output, $matches );
        if( 4 === count( $matches ) ){
            $item_output = $matches[1];
            if( $before ){
                $item_output .= $icon . '<span class="fontawesome-text">' . $spacer . $matches[2] . '</span>';
            } else {
                $item_output .= '<span class="fontawesome-text">' . $matches[2] . $spacer . '</span>' . $icon;
            }
            $item_output .= $matches[3];
        }
        return $item_output;
    }


add_filter('get_custom_logo','good_news_lite_change_logo_class');
function good_news_lite_change_logo_class($html)
{
	$html = str_replace('class="custom-logo"', 'class="img-responsive logo-fixed"', $html);
	$html = str_replace('width=', 'original-width=', $html);
	$html = str_replace('height=', 'original-height=', $html);
	$html = str_replace('class="custom-logo-link"', 'class="img-responsive logo-fixed"', $html);
	return $html;
}

function good_news_lite_filter_front_page_template( $template ) {
    return is_home() ? '' : $template;
}
add_filter( 'front_page_template', 'good_news_lite_filter_front_page_template' );

add_action( 'admin_menu', 'good_news_admin_menu');
function good_news_admin_menu( ) {
    add_theme_page( __('Pro Feature','good-news-lite'), __('Good News Plus','good-news-lite'), 'manage_options', 'good-news-plus-buynow', 'good_news_plus_buy_now', 300 );   
}
function good_news_plus_buy_now(){ ?>
<div class="good_news_plus_version">
  <a href="<?php echo esc_url('https://electrathemes.com/wordpress-themes/good-news-plus-wordpress-theme/'); ?>" target="_blank">
    <img src ="<?php echo esc_url('https://d34y2auxjtk0r3.cloudfront.net/featured-images/good-news-plus-features.png') ?>" width="100%" height="auto" />
  </a>
</div>
<?php
}

require get_template_directory() . '/inc/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/theme-default-setup.php';
require get_template_directory() . '/inc/breadcumbs.php';
require get_template_directory() . '/inc/enqueue-files.php';
require get_template_directory() . '/inc/customizer.php';

require get_template_directory() . '/inc/widgets/slider-post-widget/slider-post-widget.php';
require get_template_directory() . '/inc/widgets/news-slides-widget/news-slides-widget.php';
require get_template_directory() . '/inc/widgets/top-and-bottom-post-widget/top-and-bottom-post-widget.php';
require get_template_directory() . '/inc/widgets/below-slider-widget/below-slider-widget.php';
require get_template_directory() . '/inc/widgets/news-showcase-widget/news-showcase-widget.php';