<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Good News Lite
 */

get_header(); ?>
<section id="blog post-<?php the_ID(); ?>" <?php post_class(); ?>> <div >
	<div class="contain blog">		
		<!-- latest post -->
		<div class="container">
			<div class="latest-post">
				<div class="row">					
					<div class="active_page">
						<?php echo good_news_lite_custom_breadcrumbs(); ?>
						<div class="clearfix"></div>
					</div> <!-- //active_page -->
					<?php if(get_theme_mod('singlepost_sidebar',2) == 1) : 
							get_sidebar();
						endif;
					?>
					<?php $col_class = (get_theme_mod('singlepost_sidebar',2) == 3)?'12':'8'; ?>
					<div class="col-lg-<?php echo esc_attr($col_class); ?> col-md-<?php echo esc_attr($col_class); ?> col-sm-12 col-xs-12">
						<?php while ( have_posts() ) : the_post(); ?>
								<div class="grid-post">
									<div class="single-post-image">
										<div class="col-4">
											<?php if ( has_post_thumbnail() ) : ?>
			                                    <?php the_post_thumbnail( 'good_news_lite_thumbnail_image', array( 'alt' => the_title_attribute(array('echo' => false,)), 'class' => 'img-responsive') ); ?>
			                                    <?php else: ?>		                                    	
		                                    		<div class="no-post-thumbnail"><i class="fa fa-image"></i> </div>
		                                    <?php endif; ?>
										</div>
										<div class="text">
											<h2 class="t-small"><?php the_title(); ?></h2>								<div class="meta-loop">
												<div class="pull-left">
												<?php if(get_theme_mod('blogSingleMetaTag',1) == 1) : ?>
													<span class="author"><i class="fa fa-user" aria-hidden="true"></i> <a href="<?php the_permalink(); ?>" title="" rel="author"><?php the_author(); ?></a></span> &nbsp;
													<span class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo esc_html(get_the_date( 'd M Y')); ?></span>
													<?php if(!empty(get_the_tag_list('', ', ' ))): ?>&nbsp;
													<span class="hashtag"><i class="fa fa-hashtag" aria-hidden="true"></i> <?php echo wp_kses_post(get_the_tag_list('', ', ' )); ?></span>
												<?php endif; endif; ?>
												</div>												
												<div class="clearfix"></div>
											</div>
											<div class="meta-loop">
												<p><?php the_content(); ?></p>
											</div>
										</div>
									</div>

								</div>
								<div class="pagelink"><?php wp_link_pages(); ?></div>
							<?php							
 		                    if ( comments_open() || get_comments_number() ) {
                            	comments_template();
                        	}  ?>
							<?php 
	                        endwhile;
		                    // Previous/next page navigation.		                   
	                      ?>
							<div class="clearfix"></div>
					</div> <!-- //col-lg-8 -->
					<?php if(get_theme_mod('singlepost_sidebar',2) == 2) : 
							get_sidebar();
						endif;
					?>
				</div> <!-- //row -->
			</div> <!-- //latest post -->
		</div> <!-- //container -->
	</div>
</section>
<?php get_footer();