<!-- footer -->
<?php $footer_array = array( 2 =>array(6,6) ,3 =>array(4,4,4),4 =>array(4,4,4,12) );
$footer_widget_style = get_theme_mod('footerWidgetStyle',3);
$hide_footer_widget_bar = get_theme_mod('hideFooterWidgetBar',1); ?>
<section id="footer">
<?php if(($hide_footer_widget_bar == 1) || ($hide_footer_widget_bar == '')) : 
     $footer_widget_style = $footer_widget_style+1;
     $footer_column_value = floor(12/($footer_widget_style)); ?>
	<div class="footer-wrap">
		<div class="container">
			<div class="row">
				<div class="footer-box">
		            <div class="container">
		                <div class="row">
		                    <?php $k = 1; ?>
		                    <?php for( $i=0; $i<$footer_widget_style; $i++) { ?>
		                        <?php if (is_active_sidebar('footer-'.$k)) { ?>
		                            <div class="col-md-<?php echo esc_attr($footer_array[$footer_widget_style][$i]); ?> col-sm-6 col-xs-12"><?php dynamic_sidebar('footer-'.$k); ?></div>
		                        <?php }
		                        $k++;
		                    } ?>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
    </div>
	<?php endif;?>
	<div class="footer">
		<div class="container">
			<div class="row">
				<div class="footer_inner">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
					<p><?php
						if(get_theme_mod('CopyrightAreaText') != '') :
							 echo wp_kses_post(get_theme_mod('CopyrightAreaText')); 
						endif; 
					 	esc_html_e('Theme : ','good-news-lite'); ?> <a href="<?php echo esc_url('https://electrathemes.com/wordpress-themes/good-news-lite/'); ?>"><?php esc_html_e('Good News Lite','good-news-lite'); ?></a></p>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<div class="footer_right">
							<?php if(get_theme_mod('hideFooterMenu',false) != true) : ?>
	
								<?php
		                        if (has_nav_menu('footer-menu')) {
		                            $good_news_lite_defaults = array(
		                                'theme_location' => 'footer-menu',
		                                'container'      => false, 
		                                'menu_class'    => 'menu',
		                            );
		                            wp_nav_menu($good_news_lite_defaults);                                        
		                        } ?>
							
							<?php endif; ?>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>		
<!-- //footer -->
<?php wp_footer(); ?>
</body>
</html>