<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Good News Lite
 */

get_header(); ?>
<section id="search-page" <?php post_class(); ?>> 
	<div class="contain blog">
		<?php if (have_posts()) : ?>
		    <?php get_template_part('template-parts/content'); ?>
		<?php else : 
		 get_template_part('template-parts/content-none');  
		endif; ?>
	</div>
</section>
<?php get_footer();