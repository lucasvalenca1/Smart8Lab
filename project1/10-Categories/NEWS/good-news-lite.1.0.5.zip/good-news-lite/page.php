<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Good News Lite
 */

get_header(); ?>
<section id="blog">
	<div class="contain blog">
		<!-- latest post -->
		<div class="container">
			<div class="latest-post">
				<div class="row">	
					<div class="active_page">
						<?php echo good_news_lite_custom_breadcrumbs(); ?>
						<div class="clearfix"></div>
					</div> <!-- //active_page -->
					<?php if(get_theme_mod('page_sidebar',2) == 1) : 
							get_sidebar();
						endif;
					?>
					<?php $col_class = (get_theme_mod('page_sidebar',2) == 3)?'12':'8'; ?>
					<div class="col-lg-<?php echo esc_attr($col_class); ?> col-md-<?php echo esc_attr($col_class); ?> col-sm-12 col-xs-12">
						<?php
						while ( have_posts() ) : the_post();
						the_content();
                        wp_link_pages( array(
                                'before' => '<div class="page-links">' . esc_html__( 'Page:', 'good-news-lite' ),
                                'after'  => '</div>',
                            ) );
						endwhile; // End of the loop.
						?>
					</div>
					<?php if(get_theme_mod('page_sidebar',2) == 2) : 
						get_sidebar();
					endif;		 ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php get_footer();