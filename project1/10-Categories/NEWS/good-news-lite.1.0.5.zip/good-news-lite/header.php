<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Good News Lite
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php if(get_theme_mod('preloader') != 2) :
        if(get_theme_mod('customPreloader') == '') { ?>
            <div class="preloader">
                <?php  get_template_part('template-parts/svg-loader/default'); ?>
            </div>
        <?php } else{ ?>
            <div class="preloader"><span class="preloader-gif" style="background: url(<?php echo esc_url(get_theme_mod('customPreloader')); ?>) no-repeat;"></span></div>
    <?php } endif; ?>
	<section id="header-section">
    <div class="header ">
		<div class="top_bar">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">						
						<?php
						if (has_nav_menu('header-menu')) {
                            $good_news_lite_defaults = array(
                                'theme_location' => 'header-menu',
                                'container'      => false, 
                                'menu_class'    => 'top_menu menu list-inline',
                            );
                            wp_nav_menu($good_news_lite_defaults);
                        } ?>						
					</div>
					
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
						<nav class="social-links">
							<?php for($i=1; $i<=6; $i++) : ?>
	                            <?php if(get_theme_mod('TopHeaderSocialIcon'.$i) != '' && get_theme_mod('TopHeaderSocialIconLink'.$i) != '' ): ?>
                                   <a href="<?php echo esc_url(get_theme_mod('TopHeaderSocialIconLink'.$i)); ?>" class="icon" title="" target="_blank">
                                        <i class="fa <?php echo esc_attr(get_theme_mod('TopHeaderSocialIcon'.$i)); ?>"></i>
                                    </a>
	                            <?php endif; ?>
                            <?php endfor; ?>
						</nav>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div><!--//top_bar-->
        <div class="container" id="header-top">
			<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-4 col-xs-8">
					<div class="logo">
						<?php $logo = '';
                 			
	                 			if(has_custom_logo()){
	                        		the_custom_logo();
	                    		} 		                	
			                	$good_news_lite_dark_logo_id=get_theme_mod('good_news_lite_dark_logo');
			                	$good_news_lite_dark_logo=wp_get_attachment_url($good_news_lite_dark_logo_id);
			                	if($good_news_lite_dark_logo != ''){ ?>
				                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="custom-logo-link" rel="home" itemprop="url">
				                        <img class="img-responsive logo-dark" src="<?php echo esc_url($good_news_lite_dark_logo); ?>" alt="<?php esc_attr_e('Logo','good-news-lite'); ?>">
			                    	</a>
			                <?php }
			                if(get_theme_mod('header_text',true)){
	                    			echo '<div class="logo-light "><a href="'.esc_url( home_url('/')).'" rel="home" class="site-title"><h4 class="custom-logo ">'.esc_html(get_bloginfo('name')).'</h4></a><h6 class="custom-logo site-description">'.esc_html(get_bloginfo('description')).'</h6></div>';
	                    	} ?>			                
					</div>
				</div>
				
				<div class="col-lg-9 col-md-9 col-sm-8 col-xs-4">
					

				<div class="main-menu">
                            <!-- Responsive Menu -->
                            <nav id='cssmenu'>
                                <div id="box-top-mobile"></div>
                                <div class="button"></div>
                                <?php
			                        $good_news_lite_defaults = array(
			                            'theme_location' => 'primary',
			                            'container'      => false, 
			                            'menu_class'    => 'offside',
			                        );
			                        wp_nav_menu($good_news_lite_defaults);
			                    ?>                                
                            </nav>
                            <!-- Responsive Menu End -->
                        </div>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>
</section>