<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Good News Lite
 */
?>
		<!-- latest post -->
		<div class="container">
			<div class="latest-post">
				<div class="row">
					<div class="active_page">
						<?php echo good_news_lite_custom_breadcrumbs(); ?>
						<div class="clearfix"></div>
					</div>
					<?php if(get_theme_mod('blogsidebar',2) == 1) : 
							get_sidebar();
						endif;
					$col_class = (get_theme_mod('blogsidebar',2) == 3)?'12':'8'; ?>
					<div class="col-lg-<?php echo esc_attr($col_class); ?> col-md-<?php echo esc_attr($col_class); ?> col-sm-12 col-xs-12">
						<div class="row">
						<?php while ( have_posts() ) : the_post(); ?>
							<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
								<div class="grid-post">
									<div class="blog-main">
										<div class="blog-post-image">
											<?php if ( has_post_thumbnail() ) : ?>
												<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'good_news_lite_thumbnail_image', array( 'alt' => the_title_attribute(array('echo' => false,)), 'class' => 'img-responsive') ); ?></a>
											<?php else: ?>
												<a href="<?php the_permalink(); ?>">
													<div class="no-post-thumbnail"><i class="fa fa-image"></i> </div>
												</a>
											<?php endif; ?>
										</div>
										<div class="text">
											<h2 class="t-small"><a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a></h2>
											<div class="meta-loop">
												<div class="pull-left">
												<?php if(get_theme_mod('blogMetaTag',1) == 1) : ?>
													<span class="author"><i class="fa fa-user" aria-hidden="true"></i> <a href="<?php the_permalink(); ?>" title="" rel="author"><?php the_author(); ?></a></span> &nbsp;
													<span class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i>&nbsp;&nbsp;<?php echo esc_html(get_the_date( 'd M Y')); ?></span> 
													<?php endif; ?>
												</div>
												<div class="clearfix"></div>
											</div>
											<div class="meta-loop">
												<?php if(get_theme_mod('blogPostExcerpt',1) == 1) : ?>
												<p><?php  echo esc_html(good_news_lite_excerpt(absint(get_theme_mod('blogPostExcerptTextLimit',15)))); ?></p>
											<?php endif; ?>
											</div>
										</div>
										<div class="clearfix"></div>
									</div>
								</div>
							</div>
							<?php endwhile; ?>
							<div class="clearfix"></div>
						</div>	
						<div class="blog_pages">
							<?php the_posts_pagination( array(
								'Previous' => __( 'Back', 'good-news-lite' ),
								'Next' => __( 'Onward', 'good-news-lite' ),
							) ); ?>
						</div>
					</div>
					<?php if(get_theme_mod('blogsidebar',2) == 2) : 
							get_sidebar();
						endif;
					?>
				</div>
			</div>
		</div>