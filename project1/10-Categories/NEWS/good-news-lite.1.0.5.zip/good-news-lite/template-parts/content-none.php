<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Good News Lite
 */
?>
		<!-- latest post -->
		<div class="container">
			<div class="latest-post">
				<div class="row">
					<div class="active_page">						
						<div class="clearfix"></div>
					</div> <!-- //active_page -->
					<?php $col_class = (get_theme_mod('blogsidebar',2) == 3)?'12':'8'; ?>
					<div class="col-lg-<?php echo esc_attr($col_class); ?> col-md-<?php echo esc_attr($col_class); ?> col-sm-12 col-xs-12">
						<h2><?php esc_html_e( 'Nothing Found', 'good-news-lite' ); ?></h2>
						<?php if ( is_search() ) : ?>
						<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'good-news-lite' ); ?></p>
						<?php
							get_search_form();
						 else : ?>
						<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'good-news-lite' ); ?></p>
						<?php
							get_search_form();
						endif; ?>
						<div class="clearfix"></div>
					</div>
					<?php get_sidebar(); ?><!-- //col-lg-4 -->
				</div>
			</div>
		</div>	