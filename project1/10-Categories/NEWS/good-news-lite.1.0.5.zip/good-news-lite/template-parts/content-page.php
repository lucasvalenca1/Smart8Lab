<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Good News Lite
 */
?>
<section id="single-page">
    <div class="contain blog">
        <!-- latest post -->
        <div class="container">
            <div class="latest-post">
                <div class="row">
                    <?php $col_class = (get_theme_mod('page_sidebar',2) == 3)?'12':'8'; ?>
                    <div class="col-lg-<?php echo esc_attr($col_class); ?> col-md-<?php echo esc_attr($col_class); ?> col-sm-12 col-xs-12">
                        <?php the_content();

                        wp_link_pages( array(
                                'before' => '<div class="page-links">' . esc_html__( 'Page:', 'good-news-lite' ),
                                'after'  => '</div>',
                            ) );
                        // If comments are open or we have at least one comment, load up the comment template.
                        if ( comments_open() || get_comments_number() ) {
                            comments_template();
                        } ?>
                    </div> <!-- //col-lg-8 -->   
                                
                </div> <!-- //row -->
            </div> <!-- //latest post -->
        </div> <!-- //container -->
    </div>
</section>
