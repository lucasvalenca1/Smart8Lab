<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Good News Lite
 */
get_header(); ?>
<section id="blog-archive" <?php post_class(); ?>> 
	<div class="contain blog">
		<?php get_template_part( 'template-parts/content', get_post_format() );?>	
	</div>
</section>
<?php get_footer();