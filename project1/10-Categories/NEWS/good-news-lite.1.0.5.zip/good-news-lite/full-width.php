<?php
/**
 * Template Name: Full Width
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Good News Lite
 */
get_header(); ?>
<section id="blog">
    <div class="contain blog">
        <!-- latest post -->
        <div class="container">
            <div class="latest-post">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <?php the_content();
                        wp_link_pages( array(
                            'before' => '<div class="page-links">' . esc_html__( 'Page:', 'good-news-lite' ),
                            'after'  => '</div>',
                        ) );
                        // If comments are open or we have at least one comment, load up the comment template.
                        if ( comments_open() || get_comments_number() ) {
                            comments_template();
                        } ?>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer();