<?php
/**
* Good News Lite Customization options
**/

function good_news_lite_sanitize_checkbox( $checked ) {
  return ( ( isset( $checked ) && true == $checked ) ? true : false );
}

function good_news_lite_field_sanitize_input_choice( $input, $setting ) {

  // Ensure input is a slug.
  $input = sanitize_key( $input );

  // Get list of choices from the control associated with the setting.
  $choices = $setting->manager->get_control( $setting->id )->choices;

  // If the input is a valid key, return it; otherwise, return the default.
  return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
}

/**
   * Image control by radio button
*/
if ( class_exists( 'WP_Customize_Control' ) ) {
  class good_news_lite_Image_Radio_Control extends WP_Customize_Control {

    public function render_content() {

      if ( empty( $this->choices ) ) {
        return;
      }

      $name = '_customize-radio-' . $this->id;

      ?>
      <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
      <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
      <ul class="controls" id="good-news-lite-img-container">
        <?php
        foreach ( $this->choices as $value => $label ) :
          $class = ( $this->value() == $value ) ? 'good-news-lite-radio-img-selected good-news-lite-radio-img-img' : 'travel-radio-img-img';
          ?>
          <li style="display: inline;">
            <label>
              <input <?php $this->link(); ?>style='display:none' type="radio"
                     value="<?php echo esc_attr( $value ); ?>"
                     name="<?php echo esc_attr( $name ); ?>" <?php $this->link();
              checked( $this->value(), $value ); ?> />
              <img src='<?php echo esc_url( $label ); ?>' class='<?php echo esc_attr( $class ); ?>'/>
            </label>
          </li>
          <?php
        endforeach;
        ?>
      </ul>
      <?php
    }
  }
}


//Post/Page sidebar layout
function good_news_lite_page_layout_sanitize( $input ) {
  $valid_keys = array(
    '1'     => get_template_directory_uri() . '/assets/images/widgets/left-sidebar.png',
    '2'     => get_template_directory_uri() . '/assets/images/widgets/right-sidebar.png',
    '3'     => get_template_directory_uri() . '/assets/images/widgets/no-sidebar.png',   
  );
  if ( array_key_exists( $input, $valid_keys ) ) {
    return $input;
  } else {
    return '';
  }
}

function good_news_lite_customize_register( $wp_customize ) {
  $wp_customize->add_panel(
    'general',
    array(
        'title' => __( 'General', 'good-news-lite' ),
        'description' => __('styling options','good-news-lite'),
        'priority' => 20, 
    )
  );
  
   //All our sections, settings, and controls will be added here
  $wp_customize->add_section(
    'TopHeaderSocialLinks',
    array(
      'title' => __('Top Header Social Accounts', 'good-news-lite'),
      'priority' => 120,
      'description' => __( 'In first input box, you need to add FONT AWESOME shortcode which you can find ' ,  'good-news-lite').'<a target="_blank" href="'.esc_url('https://fortawesome.github.io/Font-Awesome/icons/').'">'.__('here' ,  'good-news-lite').'</a>'.__(' and in second input box, you need to add your social media profile URL.', 'good-news-lite').'<br />'.__(' Enter the URL of your social accounts. Leave it empty to hide the icon.' ,  'good-news-lite'),
      'panel' => 'general'
    )
  );

$TopHeaderSocialIcon = array();
  for($i=1;$i <= 5;$i++):  
    $TopHeaderSocialIcon[] =  array( 'slug'=>sprintf('TopHeaderSocialIcon%d',$i),   
      'default' => '',   
      'label' => esc_html__( 'Social Account ', 'good-news-lite') .$i,   
      'priority' => sprintf('%d',$i) );  
  endfor;
  foreach($TopHeaderSocialIcon as $TopHeaderSocialIcons){
    $wp_customize->add_setting(
      $TopHeaderSocialIcons['slug'],
      array(
        'default' => '',
        'capability'     => 'edit_theme_options',
        'type' => 'theme_mod',
        'sanitize_callback' => 'sanitize_text_field',
      )
    );
    $wp_customize->add_control(
      $TopHeaderSocialIcons['slug'],
      array(
        'type'  => 'text',
        'section' => 'TopHeaderSocialLinks',
        'input_attrs' => array( 'placeholder' => esc_attr__('Enter Icon','good-news-lite') ),
        'label'      =>   $TopHeaderSocialIcons['label'],
        'priority' => $TopHeaderSocialIcons['priority']
      )
    );
  }
  $TopHeaderSocialIconLink = array();
  for($i=1;$i <= 5;$i++):  
    $TopHeaderSocialIconLink[] =  array( 'slug'=>sprintf('TopHeaderSocialIconLink%d',$i),   
      'default' => '',   
      'label' => esc_html__( 'Social Link ', 'good-news-lite' ) .$i,
      'priority' => sprintf('%d',$i) );  
  endfor;
  foreach($TopHeaderSocialIconLink as $TopHeaderSocialIconLinks){
    $wp_customize->add_setting(
      $TopHeaderSocialIconLinks['slug'],
      array(
        'default' => '',
        'capability'     => 'edit_theme_options',
        'type' => 'theme_mod',
        'sanitize_callback' => 'esc_url_raw',
      )
    );
    $wp_customize->add_control(
      $TopHeaderSocialIconLinks['slug'],
      array(
        'type'  => 'text',
        'section' => 'TopHeaderSocialLinks',
        'priority' => $TopHeaderSocialIconLinks['priority'],
        'input_attrs' => array( 'placeholder' => esc_html__('Enter URL','good-news-lite')),
      )
    );
  }
  
  $wp_customize->get_section('title_tagline')->panel = 'general';
  $wp_customize->get_section('static_front_page')->panel = 'general';
  $wp_customize->get_section('header_image')->panel = 'general';
  $wp_customize->get_section('title_tagline')->title = __('Header & Logo','good-news-lite');

$wp_customize->add_section(
  'headerNlogo',
  array(
    'title' => __('Header & Logo','good-news-lite'),
    'panel' => 'general'
  )
);

/*
*Multiple logo upload code
*/
$wp_customize->add_setting(
    'good_news_lite_dark_logo',
    array(
        'default' => '',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control( new WP_Customize_Cropped_Image_Control( $wp_customize, 'good_news_lite_dark_logo', array(
    'section'     => 'title_tagline',
    'label'       => __( 'Upload Dark Logo' ,'good-news-lite'),
    'flex_width'  => true,
    'flex_height' => true,
    'width'       => 120,
    'height'      => 50,
    'priority'    => 48,
    'default-image' => '',
) ) );

$wp_customize->add_setting('theme_header_fix', array(
        'default' => false,  
        'sanitize_callback' => 'good_news_lite_sanitize_checkbox',
));
$wp_customize->add_control('theme_header_fix', array(
    'label'   => esc_html__('Header Fix','good-news-lite'),
    'section' => 'title_tagline',
    'type'    => 'checkbox',
    'priority' => 49
));

$wp_customize->add_setting(
  'theme_logo_height',
  array(
    'default' => '',
    'capability'     => 'edit_theme_options',
    'sanitize_callback' => 'absint',
    )
  );
$wp_customize->add_control(
  'theme_logo_height',
  array(
    'section' => 'title_tagline',
    'label'      => __('Enter Logo Size', 'good-news-lite'),
    'description' => __("Use if you want to increase or decrease logo size (optional) Don't include `px` in the string. e.g. 20 (default: 10px)",'good-news-lite'),
    'type'       => 'text',
    'priority'    => 50,
    )
  );

$wp_customize->add_setting(
    'preloader',
    array(
        'default' => '1',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'good_news_lite_field_sanitize_input_choice',
        'priority' => 20, 
    )
);
$wp_customize->add_section( 'preloaderSection' , array(
    'title'       => __( 'Preloader', 'good-news-lite' ),
    'priority'    => 32,
    'capability'     => 'edit_theme_options',
    'panel' => 'general'
) );
$wp_customize->add_control(
    'preloader',
    array(
        'section' => 'preloaderSection',                
        'label'   => __('Preloader','good-news-lite'),
        'type'    => 'radio',
        'choices'        => array(
            "1"   => esc_html__( "On ", 'good-news-lite' ),
            "2"   => esc_html__( "Off", 'good-news-lite' ),
        ),
    )
);

$wp_customize->add_setting( 'customPreloader', array(
    'sanitize_callback' => 'absint',
    'capability'     => 'edit_theme_options',
    'priority' => 40,
));

$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'customPreloader', array(
    'label'    => __( 'Upload Custom Preloader', 'good-news-lite' ),
    'section'  => 'preloaderSection',
    'settings' => 'customPreloader',
) ) );

//Colors section
$wp_customize->add_setting(
    'themeColor',
    array(
        'default' => '#f00',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'themeColor',
    array(
        'label'      => __('Theme Color ', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 10
    )
  )
);
$wp_customize->add_setting(
  'secondaryColor',
  array(
      'default' => '#000000',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'secondaryColor',
    array(
        'label'      => __('Secondary Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 11
    )
  )
);
//Menu Background Color
$wp_customize->add_setting(
  'menuBackgroundColor',
  array(
      'default' => '',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'menuBackgroundColor',
    array(
        'label'      => __('Menu Background Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 11
    )
  )
);
//Menu Background Color (Scroll)
$wp_customize->add_setting(
  'menuBackgroundColorScroll',
  array(
      'default' => '#fff',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'menuBackgroundColorScroll',
    array(
        'label'      => __('Menu Background Color (after scroll)', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 11
    )
  )
);
//Menu Text Color
$wp_customize->add_setting(
  'menuTextColor',
  array(
      'default' => '#9f9f9f',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'menuTextColor',
    array(
        'label'      => __('Menu Text Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 11
    )
  )
);
//Menu Text Color
$wp_customize->add_setting(
  'menuTextColorScroll',
  array(
      'default' => '#9f9f9f',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'menuTextColorScroll',
    array(
        'label'      => __('Menu Text Color(after scroll)', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 11
    )
  )
);
//Body Background Color
$wp_customize->add_setting(
  'bodyBackgroundColor',
  array(
      'default' => '#ffffff',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'bodyBackgroundColor',
    array(
        'label'      => __('Body Background Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 11
    )
  )
);

//Footer Background Color
$wp_customize->add_setting(
  'footerBackgroundColor',
  array(
      'default' => '#efefef',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'footerBackgroundColor',
    array(
        'label'      => __('Footer Background Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 14
    )
  )
);
$wp_customize->add_setting(
  'footerTextColor',
  array(
      'default' => '#9f9f9f',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'footerTextColor',
    array(
        'label'      => __('Footer Text Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 14
    )
  )
);
$wp_customize->add_setting(
  'footerLinkColor',
  array(
      'default' => '#9f9f9f',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'footerLinkColor',
    array(
        'label'      => __('Footer Link Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 14
    )
  )
);
$wp_customize->add_setting(
  'footerLinkHoverColor',
  array(
      'default' => '#000000',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control(
  new WP_Customize_Color_Control(
    $wp_customize,
    'footerLinkHoverColor',
    array(
        'label'      => __('Footer Link Hover Color', 'good-news-lite'),
        'section' => 'colors',
        'priority' => 14
    )
  )
);

/* Color Section Ends */

/*-------------------- BLog Page Option --------------------------*/
$wp_customize->add_section(
    'blogThemeOption',
    array(
        'title' => __( 'Blog Page Options', 'good-news-lite' ),
        'description' => __('Blog page option settings. ','good-news-lite'),
        'priority' => 124,
       
    )
);

// Blog page sidebar
  $wp_customize->add_setting(
    'blogsidebar',
    array(
      'default'           => '2',
      'capability'        => 'edit_theme_options',
      'sanitize_callback' => 'good_news_lite_page_layout_sanitize',
    )
  );

  $wp_customize->add_control( new good_news_lite_Image_Radio_Control(
      $wp_customize,
      'blogsidebar',
      array(
        'type'        => 'radio',
        'label'       => esc_html__( 'Available Sidebars Blog Page', 'good-news-lite' ),
        'description' => esc_html__( 'Select Sidebar For Blog Page ', 'good-news-lite' ),
        'section'     => 'blogThemeOption',
        'priority'    => 3,
        'choices'     => array(
          '1'     => get_template_directory_uri() . '/assets/images/widgets/left-sidebar.png',
          '2'     => get_template_directory_uri() . '/assets/images/widgets/right-sidebar.png',
          '3'     => get_template_directory_uri() . '/assets/images/widgets/no-sidebar.png'

        )
      )
    )
  );

// Single page sidebar
  $wp_customize->add_setting(
    'singlepost_sidebar',
    array(
      'default'           => '2',
      'capability'        => 'edit_theme_options',
      'sanitize_callback' => 'good_news_lite_page_layout_sanitize',
    )
  );

  $wp_customize->add_control( new good_news_lite_Image_Radio_Control(
      $wp_customize,
      'singlepost_sidebar',
      array(
        'type'        => 'radio',
        'label'       => esc_html__( 'Available Sidebars For Single Post', 'good-news-lite' ),
        'description' => esc_html__( 'Select Sidebar For Single Post', 'good-news-lite' ),
        'section'     => 'blogThemeOption',
        'priority'    => 4,
        'choices'     => array(
          '1'     => get_template_directory_uri() . '/assets/images/widgets/left-sidebar.png',
          '2'     => get_template_directory_uri() . '/assets/images/widgets/right-sidebar.png',
          '3'     => get_template_directory_uri() . '/assets/images/widgets/no-sidebar.png'

        )
      )
    )
  );

  // Theme page sidebar
  $wp_customize->add_setting(
    'page_sidebar',
    array(
      'default'           => '2',
      'capability'        => 'edit_theme_options',
      'sanitize_callback' => 'good_news_lite_page_layout_sanitize',
    )
  );

  $wp_customize->add_control( new good_news_lite_Image_Radio_Control(
      $wp_customize,
      'page_sidebar',
      array(
        'type'        => 'radio',
        'label'       => esc_html__( 'Available Sidebars For Single Page', 'good-news-lite' ),
        'description' => esc_html__( 'Select Sidebar For Site Pages', 'good-news-lite' ),
        'section'     => 'blogThemeOption',
        'priority'    => 4,
        'choices'     => array(
          '1'     => get_template_directory_uri() . '/assets/images/widgets/left-sidebar.png',
          '2'     => get_template_directory_uri() . '/assets/images/widgets/right-sidebar.png',
          '3'     => get_template_directory_uri() . '/assets/images/widgets/no-sidebar.png'

        )
      )
    )
  );

$wp_customize->add_setting(
    'blogMetaTag',
    array(
        'default' => '1',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'good_news_lite_field_sanitize_input_choice',
    )
);
$wp_customize->add_control(
    'blogMetaTag',
    array(
        'section' => 'blogThemeOption',
        'label'      => __('Select Blog Post Meta Tag Option', 'good-news-lite'),
        'type'       => 'select',
        'choices' => array(
          "1"   => esc_html__( "Show", 'good-news-lite' ),
          "2"   => esc_html__( "Hide", 'good-news-lite' ),      
        ),
    )
);
$wp_customize->add_setting(
    'blogSingleMetaTag',
    array(
        'default' => '1',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'good_news_lite_field_sanitize_input_choice',
    )
);
$wp_customize->add_control(
    'blogSingleMetaTag',
    array(
        'section' => 'blogThemeOption',
        'label'      => __('Select Single Post Meta Tag Option', 'good-news-lite'),
        'type'       => 'select',
        'choices' => array(
          "1"   => esc_html__( "Show", 'good-news-lite' ),
          "2"   => esc_html__( "Hide", 'good-news-lite' ),      
        ),
    )
);

$wp_customize->add_setting(
    'blogPostExcerpt',
    array(
        'default' => '1',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'good_news_lite_field_sanitize_input_choice',
    )
);
$wp_customize->add_control(
    'blogPostExcerpt',
    array(
        'section' => 'blogThemeOption',
        'label'      => __('Select Blog Post Excerpt Option', 'good-news-lite'),
        'type'       => 'select',
        'choices' => array(
          "1"   => esc_html__( "Show", 'good-news-lite' ),
          "2"   => esc_html__( "Hide", 'good-news-lite' ),      
        ),
    )
);
$wp_customize->add_setting(
    'blogPostExcerptTextLimit',
    array(
        'default' => '150',
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control(
    'blogPostExcerptTextLimit',
    array(
        'section' => 'blogThemeOption',
        'label'      => __('Blog Post Excerpt String Limit Option', 'good-news-lite'),
        'type'       => 'text',        
    )
);

/*------------------------ Blog  Page option End ----------------------------*/

//Footer Section
$wp_customize->add_section( 'footerCopyright' , array(
    'title'       => __( 'Footer', 'good-news-lite' ),
    'priority'    => 100,
    'capability'     => 'edit_theme_options',
  ) );
$wp_customize->add_setting(
    'hideFooterMenu',
    array(
        'default' => false,
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
        'priority' => 20, 
    )
);
$wp_customize->add_control(
    'hideFooterMenu',
    array(
        'section' => 'footerCopyright',                
        'label'   => __('Hide Footer Menu (In Menu Footer Menu location.)','good-news-lite'),
        'type'    => 'checkbox',
    )
);

$wp_customize->add_setting(
    'CopyrightAreaText',
    array(
        'capability'     => 'edit_theme_options',
        'sanitize_callback' => 'wp_kses_post',
        'priority' => 20, 
    )
);
$wp_customize->add_control(
    'CopyrightAreaText',
    array(
        'section' => 'footerCopyright',                
        'label'   => __('Enter Copyright Text','good-news-lite'),
        'type'    => 'textarea',
    )
);

$wp_customize->add_setting(
  'hideFooterWidgetBar',
  array(
      'default' => '2',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'good_news_lite_field_sanitize_input_choice',
      'priority' => 20, 
  )
);
$wp_customize->add_control(
  'hideFooterWidgetBar',
  array(
    'section' => 'footerCopyright',                
    'label'   => __('Hide Widget Area','good-news-lite'),
    'type'    => 'select',
    'choices' => array(
        "1"   => esc_html__( "Show", 'good-news-lite' ),
        "2"   => esc_html__( "Hide", 'good-news-lite' ),
    ),
  )
);
$wp_customize->add_setting(
  'footerWidgetStyle',
  array(
      'default' => '3',
      'capability'     => 'edit_theme_options',
      'sanitize_callback' => 'good_news_lite_field_sanitize_input_choice',
      'priority' => 20, 
  )
);
$wp_customize->add_control(
  'footerWidgetStyle',
  array(
      'section' => 'footerCopyright',                
      'label'   => __('Select Widget Area','good-news-lite'),
      'type'    => 'select',
      'choices'        => array(
          "1"   => esc_html__( "2 column", 'good-news-lite' ),
          "2"   => esc_html__( "3 column", 'good-news-lite' ),
          "3"   => esc_html__( "4 column", 'good-news-lite' )
      ),
  )
);
// Text Panel Starts Here 

}
add_action( 'customize_register', 'good_news_lite_customize_register' );

function good_news_lite_custom_css(){
 
  wp_enqueue_style( 'good_news_lite_style', get_stylesheet_uri() );
  $custom_css='';

  $custom_css.="#news-slider-carousel-widget .content_inner .cat_title, .contain .post_title h4, .contain .news_gallery #news-gallery-carousel-widget .owl-nav .owl-prev, .contain .news_gallery #news-gallery-carousel-widget .owl-nav .owl-next, .contain .quate_day .quate_day_contain .more_button, #blog .contain .sidebar .sidebar_contain .tags_list a:hover, .search-submit,.comment-list .comment .comment-metadata .edit-link a:hover,.comment-list .reply a:hover,.comments-area .comment-respond .comment-reply-title,.comments-area .comment-respond form.comment-form .form-submit input,.nav-links span.current,.nav-links a:hover, #cssmenu > ul > li:after, #cssmenu ul ul li:hover, .button:before, .footer-widget .calendar_wrap table#wp-calendar caption{background:".get_theme_mod('themeColor','#f00')."}

  .contain ol.breadcrumb li a, #cssmenu > ul > li:hover > a,
#cssmenu > ul > li.active > a, .footer-widget h4, .active_page ol.arrows li a:hover, .contain .featured-big .featured-text h2.t-title a:hover{color:".get_theme_mod('themeColor','#f00')."}

  	.contain .featured-big .featured-text .meta-loop a:hover, .contain .vedio_post_list .vedio_post_right .vedio_post_title a:hover, .contain .grid-post .t-small a:hover, contain .news_gallery #news-gallery-carousel-widget .news_gallery_list .head:hover, #blog .contain .sidebar .sidebar_contain .post_lists li a:hover, logo site-title h4, logo site-description,.comment-list .comment .comment-author a,.widget li a:hover{ color: ".get_theme_mod('themeColor','#f00')."}
    .nav-links a,.nav-links span{border: 2px solid ".get_theme_mod('themeColor','#f00')."}

    .button:after{border-color: ".get_theme_mod('themeColor','#f00')."}

    .comment-list .comment .comment-metadata .edit-link a,.comment-list .reply a{color: ".get_theme_mod('themeColor','#f00')."; border:1px solid ".get_theme_mod('themeColor','#f00').";}
    .comment-list .reply a:hover{border:1px solid ".get_theme_mod('themeColor','#f00').";}

  	#blog .contain .pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover{
  		border: 4px solid ".get_theme_mod('themeColor','#f00')." !important;
  	}
  	#blog .contain .pagination>li>a, .pagination>li>span{border: 2px solid ".get_theme_mod('themeColor','#f00').";} input[type='search'].search-field:focus{border-color: ".get_theme_mod('themeColor','#f00').";}

    .contain .grid-post .text .meta-loop .comment a, .contain .post_review .post_image_info .review, .contain .news_gallery #news-gallery-carousel-widget .news_gallery_list .meta-loop .comment a, #blog .contain .sidebar .sidebar_contain .post_bottom_img_contain .comment a, .search-submit:hover,
    .search-submit:focus,.comments-area .comment-respond form.comment-form .form-submit input:hover, .footer-wrap{
      background: ".get_theme_mod('secondaryColor','#000').";
    }
    .contain .grid-post .text .meta-loop .comment a:after, .contain .news_gallery #news-gallery-carousel-widget .news_gallery_list .meta-loop .comment a:after, #blog .contain .sidebar .sidebar_contain .post_bottom_img_contain .comment a:after { border-color: ".get_theme_mod('secondaryColor','#000')." transparent transparent transparent;
    }
    #cssmenu > ul > li > a, .contain ol.breadcrumb li, #cssmenu ul ul li a { color: ".get_theme_mod('secondaryColor','#000').";}
    #header-top{background: ".get_theme_mod('menuBackgroundColor','').";}
    .ace-responsive-menu > li > a{color:".get_theme_mod('menuTextColor','#9f9f9f').";}
    body{background: ".get_theme_mod('bodyBackgroundColor','#fff').";}
    
    .footer{background: ".get_theme_mod('footerBackgroundColor','#efefef')."}
    .footer p{color: ".get_theme_mod('footerTextColor','#5d5d5d')."}
    .footer a{color: ".get_theme_mod('footerLinkColor','#5d5d5d')."}
    .footer a:hover{color: ".get_theme_mod('footerLinkHoverColor','#000')."}
    .header.fixed-header{background: ".get_theme_mod('menuBackgroundColorScroll','#fff')."}
    .header.fixed-header .ace-responsive-menu > li > a{color: ".get_theme_mod('menuTextColorScroll','#9f9f9f')."}

    @media (max-width:1024px){
      #cssmenu > ul > li > a:hover, #cssmenu ul ul li:hover > a, #cssmenu ul ul li a:hover, #cssmenu > ul > li:hover > a{color: ".get_theme_mod('themeColor','#f00').";}

      #cssmenu .submenu-button:before, #cssmenu .submenu-button:after{background-color: ".get_theme_mod('themeColor','#f00').";}
      
      #cssmenu .submenu-button.submenu-opened:after, .button.menu-opened:before, .button.menu-opened:after{background-color: ".get_theme_mod('secondaryColor','#000').";}
    }

  ";

    /*Main logo height*/
    $theme_logo_height = (get_theme_mod('theme_logo_height'))?(get_theme_mod('theme_logo_height')):50;
    $custom_css.= ".logo img{ max-height: ".esc_attr($theme_logo_height)."px;   }";

    $theme_logo_width = (get_theme_mod('theme_logo_width'))?(get_theme_mod('theme_logo_width')):160;
    $custom_css.= ".logo img{ max-width: ".esc_attr($theme_logo_width)."px;   }";

    if(get_theme_mod('theme_header_fix',0)){
      $custom_css.= "#header-section .fixed-header.fixed { position :fixed; } ";
    }    

  if(has_header_image()){
     
      $url = get_header_image();
      $custom_css .= ".blog-heading-wrap {background-image:url(".esc_url_raw($url).");}";
  }
  $custom_css .= esc_html(get_theme_mod('customCss'));
  wp_add_inline_style( 'good_news_lite_style', $custom_css ); 

  $script_js = '';  
  
  if( get_theme_mod('theme_header_fix',false))
  {
    $script_js .="
      jQuery('.logo-dark').hide();
      jQuery(window).scroll(function () {
        if (jQuery(window).scrollTop() > 200) {
            jQuery('.header').addClass('fixed-header');
            jQuery('.logo-dark').show();
            jQuery('.logo-fixed').hide();
        } else {           
            jQuery('.header').removeClass('fixed-header');
            jQuery('.logo-dark').hide();
            jQuery('.logo-fixed').show();
        }
      });
    ";
  }

if(get_theme_mod('good_news_lite_dark_logo')==''){
  $script_js.="
    jQuery(window).scroll(function () {
      if(jQuery(window).scrollTop() > 200) {
        jQuery('.logo-fixed').show();
      }else {           
        jQuery('.logo-dark').show();
      }
    });
    ";
}
  wp_add_inline_script( 'good-news-lite-custom-script', $script_js );
 }