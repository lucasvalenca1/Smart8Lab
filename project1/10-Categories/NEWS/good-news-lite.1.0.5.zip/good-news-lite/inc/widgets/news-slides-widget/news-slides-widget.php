<?php // Register and load the widget
	function good_news_lite_gallery_load_widget() {
    	register_widget( 'good_news_lite_gallery_news_widget' );
	}
	add_action( 'widgets_init', 'good_news_lite_gallery_load_widget' );
 
	// Creating the widget 
	class good_news_lite_gallery_news_widget extends WP_Widget {
 		function __construct() {
			$widget_ops = array('classname' => 'good-news-lite-gallery-news-widget', 'description' => esc_html__( "The Widget Can Display The News Gallery In Slider", 'good-news-lite') );
	        parent::__construct('good-news-lite-gallery-widget_1', esc_html__('GN : News slides Widget', 'good-news-lite'), $widget_ops);
			
			$this->alt_option_name = 'good_news_lite_gallery_flush_widget_template1';
	        add_action( 'save_post', array($this, 'good_news_lite_gallery_flush_widget_cache_template') );
	        add_action( 'deleted_post', array($this, 'good_news_lite_gallery_flush_widget_cache_template') );
	        add_action( 'switch_theme', array($this, 'good_news_lite_gallery_flush_widget_cache_template') );
		}
	// Creating widget front-end
	public function widget( $args, $instance ) {

		$good_news_lite_gallery_cache = wp_cache_get('good_news_lite_gallery_news_widget', 'widget');
        if ( !is_array($good_news_lite_gallery_cache) )
            $good_news_lite_gallery_cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $good_news_lite_gallery_cache[ $args['widget_id'] ] ) ) {
            echo esc_attr($good_news_lite_gallery_cache[ $args['widget_id'] ]);
            return;
        }
        ob_start();
        extract($args);

		$title =(isset($instance['title']))? apply_filters( 'widget_title', $instance['title'] ):__('Title Gallery','good-news-lite');
		$num = ! empty( $instance['num'] ) ? $instance['num'] : '-1';
		$category = isset( $instance['category'])?$instance['category']:'';
		$arg = 	array('post_type'=>'post', 'posts_per_page'=>$num );
 		($category>0)?$arg['category__in']=$category:'';
 		$good_news_lite_gallery = new WP_Query($arg);
 		?>

		<div class="news_gallery">
			<div class="col-md-12">
				<div class="post_title">
					<h4><?php echo esc_html($title); ?></h4>
				</div>
				<div class="gallery">
					<div id="news-gallery-carousel-widget" class="owl-carousel owl-theme">
						<?php if($good_news_lite_gallery->have_posts()):
							while($good_news_lite_gallery->have_posts()): $good_news_lite_gallery->the_post();
						?>
					  	<div class="news_gallery_list">
					  		<?php if ( has_post_thumbnail() ) : ?>
				                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('good_news_lite_SliderPostThumbnailImage',array( 'alt' => the_title_attribute(array('echo' => false,)), 'class' => 'img-responsive') ); ?></a>
				            <?php else: ?>
				                <a href="<?php the_permalink(); ?>">
					                <div class="no-post-thumbnail"><i class="fa fa-image"></i> </div>
				                </a>
				            <?php endif; ?>
					  		<a class="head" href="<?php the_permalink();?>"><p class=""><?php the_title(); ?></p></a>
					  		<div class="meta-loop">
								<div class="pull-left">
									<span class="author"><i class="fa fa-user" aria-hidden="true"></i> <a href="<?php the_permalink();?>" title="" rel="author"><?php the_author(); ?></a></span> &nbsp; 
									<span class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo esc_html(get_the_date('d M Y'));?></span> 
								</div>
								<div class="clearfix"></div>
							</div>
					  	</div>	
					  	<?php endwhile; wp_reset_postdata(); endif; ?>
					</div>
				</div>
			</div>
		</div>
		
	<?php 
	$good_news_lite_gallery_cache[$args['widget_id']] = ob_get_flush();
    wp_cache_set('good_news_lite_gallery_flush_widget_cache_template2', $good_news_lite_gallery_cache, 'widget');
}
         
	// Widget Backend 
	public function form( $instance ) {
		$category = isset($instance['category'])?$instance['category']:'';		
		$title = (isset($instance['title'])) ? $instance['title'] : __('Title Gallery','good-news-lite');	
		$num    = isset( $instance['num'] ) ? $instance['num']  : 3;
		// Widget admin form
		?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:','good-news-lite'); ?></label> 
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('num')); ?>">
                <?php esc_html_e( 'Number Of Posts To show:', 'good-news-lite' ); ?>
            </label>
            <input class="widefat select-numpost" id="<?php echo esc_attr($this->get_field_id('num')); ?>" name="<?php echo esc_attr($this->get_field_name('num')); ?>" type="text" value="<?php echo esc_attr($num); ?>">
        </p>
        <p>
			<label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php esc_html_e('Select category','good-news-lite'); ?>:</label>
			<?php wp_dropdown_categories( array( 'show_option_none' => '-Select-', 'name' => $this->get_field_name('category'), 'selected' => $category ) ); ?>
		</p>
	<?php 
	}     
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;        
		$instance['title'] = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['num'] = ! empty( $new_instance['num'] ) ? absint( $new_instance['num'] ) : 3;
		$instance['category'] = ( !empty( $new_instance['category']) && $new_instance['category'] > 0 ) ? absint($new_instance['category']):'';

        $this->good_news_lite_gallery_flush_widget_cache_template();
        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['good_news_lite_gallery_flush_widget_cache_template2']) )
            delete_option('good_news_lite_gallery_flush_widget_cache_template2');
        return $instance;
    }
    function good_news_lite_gallery_flush_widget_cache_template() {
        wp_cache_delete('good_news_lite_gallery_flush_widget_cache_template2', 'widget');
    }
	
} // Class wpb_widget ends here