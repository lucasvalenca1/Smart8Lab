<?php // Register and load the widget
	function good_news_lite_slider_load_widget() {
		register_widget( 'good_news_lite_slider_widget' );
	}
	add_action( 'widgets_init', 'good_news_lite_slider_load_widget' );
 
 // enqueue widget style
	function good_news_lite_slider_enqueue_styles(){
		wp_enqueue_style('slider-custom-css', get_template_directory_uri().'/inc/widgets/slider-post-widget/css/widget-default.css');
	}
	add_action('wp_enqueue_scripts', 'good_news_lite_slider_enqueue_styles' );	
	// Creating the widget 
	class good_news_lite_slider_widget extends WP_Widget {
 		function __construct() {
			$widget_ops = array('classname' => 'good-news-lite-slider-widget', 'description' => esc_html__( "The widget can display the news slider", 'good-news-lite') );
	        parent::__construct('good-news-lite-slider-widget_1', esc_html__('GN : Slider Post Widget', 'good-news-lite'), $widget_ops);
			
			$this->alt_option_name = 'good_news_lite_slider_flush_widget_template1';
	        add_action( 'save_post', array($this, 'good_news_lite_slider_flush_widget_cache_template') );
	        add_action( 'deleted_post', array($this, 'good_news_lite_slider_flush_widget_cache_template') );
	        add_action( 'switch_theme', array($this, 'good_news_lite_slider_flush_widget_cache_template') );

		}

	// Creating widget front-end
 
	public function widget( $args, $instance ) {
		$good_news_lite_slider_cache = wp_cache_get('good_news_lite_slider_news_widget', 'widget');
        if ( !is_array($good_news_lite_slider_cache) )
            $good_news_lite_slider_cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $good_news_lite_slider_cache[ $args['widget_id'] ] ) ) {
            echo esc_attr($good_news_lite_slider_cache[ $args['widget_id'] ]);
            return;
        }
        ob_start();
        extract($args);

		$num = !empty($instance['num'])?$instance['num']:'-1';
 		$category = isset($instance['category'])?$instance['category']:''; 	
 		$arg = array('post_type'=>'post', 'posts_per_page'=>$num );
 		($category>0)?$arg['category__in']=$category:'';
 		$good_news_lite_slider = new WP_Query($arg);

 		?>
 		<section id="news_slider">
			<div class="news_slider">
				<div class="container">					
					<div class="row">
						<div class="col-md-12">
							<div id="news-slider-carousel-widget" class=" news-slider-carousel-widget owl-carousel owl-theme">
								<?php if($good_news_lite_slider->have_posts()):
									while($good_news_lite_slider->have_posts()): $good_news_lite_slider->the_post();
								?>
								<div>
									<?php if ( has_post_thumbnail() ) : ?>
						                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'good_news_lite_PostThumbnailImage', array( 'alt' => the_title_attribute(array('echo' => false,)), 'class' => 'img-responsive') ); ?></a>
						            <?php else: ?>
						                <a href="<?php the_permalink(); ?>">
						                	<div class="no-post-thumbnail"><i class="fa fa-image"></i> </div>
						                </a>
						                <div></div>
						            <?php endif; ?>
									<div class="content_over">
										<div class="content_inner">
											<div class="cat_title"><?php echo get_the_category_list(wp_kses_post(' - ','good-news-lite')); ?></div>

											<h2 class="cat_cont"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
											<div class="cat_date"><a href="<?php the_permalink();?>"><i class="fa fa-user" aria-hidden="true"></i> <?php the_author();?></a> &nbsp; <i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo esc_html(get_the_date('d M Y')); ?></div> 
										</div>
									</div>
								</div>
							<?php endwhile; wp_reset_postdata(); endif; ?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	<?php 
	$good_news_lite_slider_cache[$args['widget_id']] = ob_get_flush();
    wp_cache_set('good_news_lite_slider_flush_widget_cache_template2', $good_news_lite_slider_cache, 'widget');
}
         
	// Widget Backend 
	public function form( $instance ) {

		$category = !empty($instance['category'])?$instance['category']:'';		
		$num = (isset($instance['num'])) ? $instance['num']:4; 	
		// Widget admin form
		?>		
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('num')); ?>">
                <?php esc_html_e('Number Of Posts To show:','good-news-lite'); ?>
            </label>
            <input class="widefat select-numpost" id="<?php echo esc_attr($this->get_field_id('num')); ?>" name="<?php echo esc_attr($this->get_field_name('num')); ?>" type="number" value="<?php echo esc_attr($num); ?>">
        </p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php esc_html_e('Select category:','good-news-lite'); ?></label> 
			<?php wp_dropdown_categories(array('show_option_none'=>'-Select-', 'name'=> $this->get_field_name('category'),'selected'=> $category)); ?>
		</p>
	<?php 
	}
     
	// Updating widget replacing old instances with new	
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;        
		$instance['num'] = ! empty( $new_instance['num'] ) ? absint( $new_instance['num'] ) : 4;
		$instance['category'] = ( !empty( $new_instance['category']) && $new_instance['category'] > 0 ) ? absint($new_instance['category']):'';

        $this->good_news_lite_slider_flush_widget_cache_template();
        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['good_news_lite_slider_flush_widget_cache_template2']) )
            delete_option('good_news_lite_slider_flush_widget_cache_template2');
        return $instance;
    }
    function good_news_lite_slider_flush_widget_cache_template() {
        wp_cache_delete('good_news_lite_slider_flush_widget_cache_template2', 'widget');
    }
} // Class wpb_widget ends here