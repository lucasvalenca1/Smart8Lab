<?php // Register and load the widget
	function good_news_lite_showcase_news_load_widget() {
    	register_widget( 'good_news_lite_showcase_news_widget' );
	}
	add_action( 'widgets_init', 'good_news_lite_showcase_news_load_widget' );
 
	// Creating the widget 
	class good_news_lite_showcase_news_widget extends WP_Widget {
 		function __construct() {		

			$widget_ops = array('classname' => 'good-news-lite-showcase-news-widget', 'description' => esc_html__( "The widget can display the news showcase", 'good-news-lite') );
	        parent::__construct('good-news-lite-showcase-widget_1', esc_html__('GN : News Showcase Widget', 'good-news-lite'), $widget_ops);
			
			$this->alt_option_name = 'good_news_lite_showcase_flush_widget_template1';
	        add_action( 'save_post', array($this, 'good_news_lite_showcase_flush_widget_cache_template') );
	        add_action( 'deleted_post', array($this, 'good_news_lite_showcase_flush_widget_cache_template') );
	        add_action( 'switch_theme', array($this, 'good_news_lite_showcase_flush_widget_cache_template') );
		}
	// Creating widget front-end
 
	public function widget( $args, $instance ) {
		wp_enqueue_style('news-showcase-widget-css', get_template_directory_uri().'/inc/widgets/news-showcase-widget/showcase.css');

		$good_news_lite_showcase_cache = wp_cache_get('good_news_lite_showcase_news_widget', 'widget');
        if ( !is_array($good_news_lite_showcase_cache) )
            $good_news_lite_showcase_cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $good_news_lite_showcase_cache[ $args['widget_id'] ] ) ) {
            echo esc_attr($good_news_lite_showcase_cache[ $args['widget_id'] ]);
            return;
        }
        ob_start();
        extract($args);

		$title =(isset($instance['title']))? apply_filters( 'widget_title', $instance['title'] ):__('Title Showcase','good-news-lite');
		$num = !empty($instance['num'])?$instance['num']:'-1'; 
		$category = !empty($instance['category'])?$instance['category']:'';
		$arg = 	array('post_type'=>'post', 'posts_per_page'=>$num );
 		($category>0)?$arg['category__in']=$category:'';
 		$good_news_lite_showcase = new WP_Query($arg);
 		?>
 		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="post_title">
						<h4><?php echo esc_html($title); ?></h4>
					</div>
				</div>				
				<div class="grid">
				<?php if($good_news_lite_showcase->have_posts()):
					while($good_news_lite_showcase->have_posts()): $good_news_lite_showcase->the_post();
					?>
					<figure class="effect-layla">
						<?php if ( has_post_thumbnail() ) :
							$featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'good_news_lite_thumbnail_image');  ?>
							<div class="img-post-thumbnail" style='background-image: url("<?php echo esc_url($featured_img_url);?>");'> </div>							
						<?php else: ?>
			                <div class="no-post-thumbnail"> </div>
			            <?php endif; ?>						
						<figcaption>
							<h2><?php echo get_the_category_list(wp_kses_post(' - ','good-news-lite')); ?></h2>
							<p><?php the_title(); ?></p>
							<a href="<?php echo the_permalink(); ?>"><?php esc_html_e('View more:','good-news-lite'); ?></a>
						</figcaption>			
					</figure>
					<?php endwhile; wp_reset_query(); endif; ?>					
				</div>				
				<div class="clearfix"></div>
			</div>
		</div>		
	<?php 
	$good_news_lite_showcase_cache[$args['widget_id']] = ob_get_flush();
	wp_cache_set('good_news_lite_showcase_flush_widget_cache_template2', $good_news_lite_showcase_cache, 'widget');
}
         
	// Widget Backend 
	public function form( $instance ) {
		$category = !empty($instance['category'])?$instance['category']:'';
		$title = (isset($instance['title'])) ? $instance['title'] : __('News title','good-news-lite');	

		$num = (isset($instance['num'])) ? $instance['num']: 2; ?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:','good-news-lite'); ?></label> 
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('num')); ?>">
                <?php esc_html_e('Number Of Posts To show:','good-news-lite'); ?>
            </label>	
			<input class="widefat select-numpost" id="<?php echo esc_attr($this->get_field_id('num')); ?>" name="<?php echo esc_attr($this->get_field_name('num')); ?>" type="number" value="<?php echo esc_attr($num); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('category')); ?>">
                <?php esc_html_e('Select Category:','good-news-lite'); ?>
            </label>
            <?php wp_dropdown_categories(array('show_option_none'=>'-Select-', 'class'=> 'widefat select-numpost','name' => $this->get_field_name('category'),'selected'=>$category)); ?>
			
		</p>
	<?php 
	}
    
	// Updating widget replacing old instances with new	
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['num'] = ! empty( $new_instance['num'] ) ? absint( $new_instance['num'] ) : 2;
		$instance['category'] = ( !empty( $new_instance['category']) && $new_instance['category'] > 0 ) ? absint($new_instance['category']):'';


        $this->good_news_lite_showcase_flush_widget_cache_template();
        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['good_news_lite_showcase_flush_widget_cache_template2']) )
            delete_option('good_news_lite_showcase_flush_widget_cache_template2');
        return $instance;
    }
    function good_news_lite_showcase_flush_widget_cache_template() {
        wp_cache_delete('good_news_lite_showcase_flush_widget_cache_template2', 'widget');
    }
} // Class wpb_widget ends here