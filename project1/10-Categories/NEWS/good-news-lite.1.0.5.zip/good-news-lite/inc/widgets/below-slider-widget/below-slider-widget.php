<?php
function good_news_lite_video_post_load_widget(){
	register_widget('good_news_lite_video_post_widget');
}
add_action('widgets_init','good_news_lite_video_post_load_widget');

class good_news_lite_video_post_widget extends WP_Widget{
	function __construct(){
		$widget_ops = array('classname' => 'good-video-post-widget', 'description' => esc_html__( "The widget can display video post", 'good-news-lite') );
        parent::__construct('good-video-post-widget_1', esc_html__('GN : Below Slider widget', 'good-news-lite'), $widget_ops);
		
		$this->alt_option_name = 'good_news_lite_post_flush_widget_template1';
        add_action( 'save_post', array($this, 'good_news_lite_post_flush_widget_cache_temlate') );
        add_action( 'deleted_post', array($this, 'good_news_lite_post_flush_widget_cache_temlate') );
        add_action( 'switch_theme', array($this, 'good_news_lite_post_flush_widget_cache_temlate') );
	}

	public function widget($args, $instance){	
	 	$good_news_lite_post_cache = wp_cache_get('good_news_lite_video_post_widget', 'widget');
        if ( !is_array($good_news_lite_post_cache) )
            $good_news_lite_post_cache = array();

        if ( ! isset( $args['widget_id'] ) )
            $args['widget_id'] = $this->id;

        if ( isset( $good_news_lite_post_cache[ $args['widget_id'] ] ) ) {
            echo esc_attr($good_news_lite_post_cache[ $args['widget_id'] ]);
            return;
        }
        ob_start();
        extract($args);
		$title =(isset($instance['title']))? apply_filters( 'widget_title', $instance['title'] ):__('Title Video','good-news-lite');
		$num = !empty($instance['num'])?$instance['num']:'-1';
		$category = isset($instance['category'])?$instance['category']:'';
		$arg = 	array('post_type'=>'post', 'posts_per_page'=>$num );
 		($category>0)?$arg['category__in']=$category:'';
 		$good_news_lite_posts = new WP_Query($arg);		
		?>
		<div class="gn-video-post-section">			
			<div class="col-md-12">
				<div class="post_title">
					<h4><?php echo esc_html($title); ?></h4>
				</div>
			</div>		
			<?php $counter=1; if($good_news_lite_posts->have_posts()):
				while($good_news_lite_posts->have_posts()) : $counter = ($counter>$num)?1:$counter; $good_news_lite_posts->the_post();
				if($counter==1){
			?>
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 featured-big mb-3">
                <div class="inner-post">
					<div class="position-relative c-meta l-white">
						<div class="lazyload bg bg-49 color">
							<?php if ( has_post_thumbnail() ) : ?>
			                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('good_news_lite_thumbnail_image',array( 'alt' => the_title_attribute(array('echo' => false,)), 'class' => 'img-responsive') ); ?></a>
			                <?php else: ?>
			                    <a href="<?php the_permalink(); ?>">
			                    	<div class="no-post-thumbnail"><i class="fa fa-image"></i> </div>
			                    </a>
			                <?php endif; ?>
						</div>
						<a href="#" class="cover"></a>
						<div class="featured-text p-3">
							<h2 class="t-title f-title"><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
							<div class="meta-loop small c-meta f-text">								
								<span class="author"><i class="fa fa-user" aria-hidden="true"></i> <a href="<?php the_permalink();?>" title="" rel="author"><?php the_author();?></a></span>&nbsp;
								<span class="date"><i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo get_the_date('d M Y'); ?></span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php } else { ?>
			<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 featured-small">
				<div class="video_post_list">
					<div class="video_post_left">
						<?php if ( has_post_thumbnail() ) : ?>
		                    <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('good_news_lite_PostThumbnailImage',array( 'alt' => the_title_attribute(array('echo' => false,)), 'class' => 'img-responsive') ); ?></a>
		                <?php else: ?>
		                    <a href="<?php the_permalink(); ?>">
		                    	<div class="no-post-thumbnail"><i class="fa fa-image"></i> </div>
		                    </a>
		                <?php endif; ?>
					</div>
					<div class="video_post_right">
						<div class="video_post_title">
							<a href="<?php the_permalink();?>"><?php the_title(); ?></a>
						</div>	
						<div class="video_post_detail">	
							<span class="author"><i class="fa fa-user" aria-hidden="true"></i> <a href="<?php the_permalink();?>" title="" rel="author"><?php the_author();?></a></span>&nbsp;	
							<span> <i class="fa fa-calendar-o" aria-hidden="true"></i> <?php echo get_the_date('d M Y'); ?></span> 
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
				<div class="clearfix"></div>
			</div>
			<?php } $counter++; endwhile; wp_reset_postdata(); endif; ?>
			<div class="clearfix"></div>
		</div>
			
<?php  $good_news_lite_post_cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('good_news_lite_post_flush_widget_cache_temlate2', $good_news_lite_post_cache, 'widget');
    }
		public function form($instance){
			$title  = isset( $instance['title'] ) ? $instance['title']  :  __('News title','good-news-lite'); 
        	$num    = isset( $instance['num'] ) ? $instance['num'] : 3;
			$category = isset($instance['category'])?$instance['category']:''; ?>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title','good-news-lite');?></label>
				<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" type="text" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>">
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('num')); ?>">
                <?php esc_html_e('Number Of Posts To show:', 'good-news-lite'); ?>
            	</label>
				
				<input class="widefat select-numpost" id="<?php echo esc_attr($this->get_field_id('num')); ?>" name="<?php echo esc_attr($this->get_field_name('num')); ?>" type="number" value="<?php echo esc_attr($num); ?>">
			</p>
			<p>
				<label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php esc_html_e('Select category:','good-news-lite'); ?></label> 
				<?php wp_dropdown_categories(array('show_option_none'=>'-Select-', 'name'=> $this->get_field_name('category'),'selected'=> $category)); ?>
			</p>
<?php 	}
	function update( $new_instance, $old_instance ) {
        $instance = $old_instance;        
        $instance['title'] = ! empty( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '';
        $instance['num'] = ! empty( $new_instance['num'] ) ? absint( $new_instance['num'] ) : 3;
		$instance['category'] = ( !empty( $new_instance['category']) && $new_instance['category'] > 0 ) ? absint($new_instance['category']):'';

        $this->good_news_lite_post_flush_widget_cache_temlate();
        $alloptions = wp_cache_get( 'alloptions', 'options' );
        if ( isset($alloptions['good_news_lite_post_flush_widget_cache_temlate2']) )
            delete_option('good_news_lite_post_flush_widget_cache_temlate2');
        return $instance;
    }
    function good_news_lite_post_flush_widget_cache_temlate() {
        wp_cache_delete('good_news_lite_post_flush_widget_cache_temlate2', 'widget');
    }
}