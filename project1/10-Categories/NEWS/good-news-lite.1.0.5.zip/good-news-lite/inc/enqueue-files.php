<?php

/*
 * Good News Lite Enqueue css and js files
 */

function good_news_lite_admin_scripts_style( $hook ) {

    if ( 'widgets.php' != $hook && 'customize.php' != $hook ) {
        return;
    }

    if ( function_exists( 'wp_enqueue_media' ) ) {
        wp_enqueue_media();
    }

    wp_register_script( 'good-news-lite-media-uploader', get_template_directory_uri() . '/assets/js/media-uploader.js', array( 'jquery' ) );
    wp_enqueue_script( 'good-news-lite-media-uploader' );
    wp_localize_script( 'good-news-lite-media-uploader', 'good_news_lite_l10n', array(
        'upload' => esc_html__( 'Upload', 'good-news-lite' ),
        'remove' => esc_html__( 'Remove', 'good-news-lite' )
    ) );

    wp_enqueue_script( 'good-news-lite-admin-script', get_template_directory_uri() . '/assets/js/admin-script.js', array( 'jquery' ), null, true );

    wp_enqueue_style( 'good-news-lite-admin-style', get_template_directory_uri() . '/assets/css/admin-style.css', array(), null );
}

add_action( 'admin_enqueue_scripts', 'good_news_lite_admin_scripts_style' );

function good_news_lite_enqueue() {
    wp_enqueue_style('googlefont-oswald', '//fonts.googleapis.com/css?family=Oswald:500,300,600,700', array(),null);
    wp_enqueue_style('googlefont-pt-sans', '//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i', array(),null);

    wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.css', array(),null);
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.css', array(),null);
    wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.css', array(),null);
    wp_enqueue_style('good-news-lite-responsive-menu', get_template_directory_uri() . '/assets/css/menu.css', array(),null);
    wp_enqueue_style('good-news-lite-main-style', get_template_directory_uri() . '/assets/css/default.css', array(),null);      

    wp_enqueue_script("comment-reply");
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.js', array('jquery'),false, true );
    wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.js', array('jquery'),false, true);
    wp_enqueue_script('good-news-lite-responsive-menu', get_template_directory_uri() . '/assets/js/menu.js', array('jquery'),false, true);
    wp_enqueue_script('good-news-lite-custom-script', get_template_directory_uri() . '/assets/js/custom.js',array('jquery'),false, true);
  
    good_news_lite_custom_css();
}

add_action('wp_enqueue_scripts', 'good_news_lite_enqueue');