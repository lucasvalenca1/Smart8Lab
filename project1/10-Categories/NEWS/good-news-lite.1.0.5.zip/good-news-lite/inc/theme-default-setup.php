<?php
/*
 * Good News Lite Main Sidebar
 */
function good_news_lite_widgets_init() {
    register_sidebar(array(
        'name' => esc_html__('Home Page Main Slider', 'good-news-lite'),
        'id' => 'home-page-main-slider',
        'description' => esc_html__('Main slider.', 'good-news-lite'),
        'before_widget' => '<div id="%1$s" class="widget sidebar_contain home-page-main-slider %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="post_title"><h4>',
        'after_title' => '</h4></div>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Home Page Section Below slider', 'good-news-lite'),
        'id' => 'home-page-video-section',
        'description' => esc_html__('Below slider widgets.', 'good-news-lite'),
        'before_widget' => '<div id="%1$s" class="widget sidebar_contain home-page-video-section %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="post_title"><h4>',
        'after_title' => '</h4></div>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Left Section of 2 Column Section', 'good-news-lite'),
        'id' => 'home-page-category-section',
        'description' => esc_html__('Top and bottom post widget.', 'good-news-lite'),
        'before_widget' => '<div id="%1$s" class="widget sidebar_contain home-page-category-section %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="post_title"><h4>',
        'after_title' => '</h4></div>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Right Section of 2 Column Section', 'good-news-lite'),
        'id' => 'home-page-category-section2',
        'description' => esc_html__('Top and bottom post widget.', 'good-news-lite'),
        'before_widget' => '<div id="%1$s" class="widget sidebar_contain home-page-category-section2 %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="post_title"><h4>',
        'after_title' => '</h4></div>',
    ));
    
    register_sidebar(array(
      'name'  => esc_html__('Home Page News slides','good-news-lite'),
      'id'  => 'home-page-news-gallery',
      'description' => esc_html__('Home Page News slides','good-news-lite'),
      'before_widget' => '<div id="%1$s" class="widget sidebar_contain home-page-news-gallery %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="post_title"><h4>',
        'after_title' => '</h4></div>',
    ));
    register_sidebar(array(
        'name' => esc_html__('Main Sidebar', 'good-news-lite'),
        'id' => 'sidebar-1',
        'description' => esc_html__('Main sidebar that appears on the right.', 'good-news-lite'),
        'before_widget' => '<div id="%1$s" class="widget sidebar_contain %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<div class="post_title"><h4>',
        'after_title' => '</h4></div>',
    ));    

    register_sidebar(array(
        'name' => __('Footer 1', 'good-news-lite'),
        'id' => 'footer-1',
        'description' => __('Footer that appears on the down.', 'good-news-lite'),
        'before_widget' => '<aside id="%1$s" class="footer-widget widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h4>',
        'after_title' => '</h4>',
    ));
    register_sidebar(array(
        'name' => __('Footer 2', 'good-news-lite'),
        'id' => 'footer-2',
        'description' => __('Footer that appears on the down.', 'good-news-lite'),
        'before_widget' => '<aside id="%1$s" class="footer-widget widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h4>',
        'after_title' => '</h4>',
    ));
    register_sidebar(array(
        'name' => __('Footer 3', 'good-news-lite'),
        'id' => 'footer-3',
        'description' => __('Footer that appears on the down.', 'good-news-lite'),
        'before_widget' => '<aside id="%1$s" class="footer-widget widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h4>',
        'after_title' => '</h4>',
    ));
    register_sidebar(array(
        'name' => __('Footer 4', 'good-news-lite'),
        'id' => 'footer-4',
        'description' => __('Footer that appears on the down.', 'good-news-lite'),
        'before_widget' => '<aside id="%1$s" class="footer-widget widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h4>',
        'after_title' => '</h4>',
    ));
}
add_action('widgets_init', 'good_news_lite_widgets_init');
/**
 * Set up post entry meta.    
 * Meta information for current post: categories, tags, permalink, author, and date.    
 * */
function good_news_lite_excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  } 
  $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
  return $excerpt;
} 

function good_news_lite_entry_meta() {	
	$good_news_lite_taglist = get_the_tag_list('', ', ' );	?>	
    <p><?php esc_html_e('By : ', 'good-news-lite'); ?><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="tag"><?php echo esc_html(ucfirst(get_the_author())); ?></a> - <?php echo sprintf('<time datetime="%1$s">%2$s</time>', esc_attr(get_the_date('c')), esc_html(get_the_date('F d , Y'))); ?></p>
<?php 	
}


/*
* TGM plugin activation register hook 
*/
add_action( 'tgmpa_register', 'good_news_lite_action_tgm_plugin_active_register_required_plugins' );
function good_news_lite_action_tgm_plugin_active_register_required_plugins() {
    if(class_exists('TGM_Plugin_Activation')){
      $plugins = array(
        array(
           'name'      => __('Page Builder by SiteOrigin','good-news-lite'),
           'slug'      => 'siteorigin-panels',
           'required'  => false,
        ),
        array(
           'name'      => __('SiteOrigin Widgets Bundle','good-news-lite'),
           'slug'      => 'so-widgets-bundle',
           'required'  => false,
        ),
        array(
           'name'      => __('Contact Form 7','good-news-lite'),
           'slug'      => 'contact-form-7',
           'required'  => false,
        ),
      );
      $config = array(
        'default_path' => '',
        'menu'         => 'good-news-lite-install-plugins',
        'has_notices'  => true,
        'dismissable'  => true,
        'dismiss_msg'  => '',
        'is_automatic' => false,
        'message'      => '',
        'strings'      => array(
           'page_title'                      => __( 'Install Recommended Plugins', 'good-news-lite' ),
           'menu_title'                      => __( 'Install Plugins', 'good-news-lite' ),           
           'nag_type'                        => 'updated'
        )
      );
      tgmpa( $plugins, $config );
    }
}