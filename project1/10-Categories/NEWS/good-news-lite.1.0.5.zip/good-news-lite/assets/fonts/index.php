<?php 
/*
*	@package    Good News Lite WordPress Theme
*   @author     ElectraThemes
*/