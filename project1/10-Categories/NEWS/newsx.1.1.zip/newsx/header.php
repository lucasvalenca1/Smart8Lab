<!DOCTYPE html>
<!--[if lt IE 7]>
    <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
    <!--[if IE 7]>
    <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
    <!--[if IE 8]>
    <html class="no-js lt-ie9"> <![endif]-->
    <!--[if gt IE 8]><!-->
<html <?php language_attributes(); ?>><!--<![endif]-->
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <meta charset="<?php bloginfo('charset'); ?>" />	
<?php wp_head(); ?>
</head>
<body id="style-switcher" <?php body_class(get_theme_mod('layout_selector')); ?> >
<div class="row">
	<header>
	<div class=" newsblog-top" style="background-image: url('<?php echo esc_url(get_header_image()); ?>')">
		
			<div class="container">
			<div class="col-lg-6 col-md-4 col-sm-12 col-xs-12 head-top animated zoomIn" align="" >
				<div class="logo">
				<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				  <?php if (has_custom_logo()) {
					  the_custom_logo();
				 } else { ?>
				 <h1><?php echo esc_attr(get_bloginfo('name')); } ?></h1>
				  <?php if( get_theme_mod( 'sitedescription' ) == '') { ?>  
					<p><?php echo esc_attr(get_bloginfo('description', 'display')); ?></p>
				  <?php }  ?>
			   </a>
			   </div>
			</div>
			<div class="col-md-6 col-sm-12 col-xs-12 top-social">
				 <?php $newsera_theme_options = newsera_get_options(); 
				if(get_theme_mod('newsera_theme_options_wp_news_social_media')!=""){ ?>
				<ul class="social">
					<?php if(get_theme_mod('newsera_options_facbook_link')!=''){ ?>
					<li class="facebook"><a href="<?php echo esc_url(get_theme_mod('newsera_options_facbook_link')); ?>" class="fb"><i class="fa fa-facebook"></i></a>						 </li>
					<?php }
					if(get_theme_mod('newsera_options_twitter_link')!=''){ ?>
					<li class="twitter"><a href="<?php echo esc_url(get_theme_mod('newsera_options_twitter_link')); ?>" class="tw"><i class="fa fa-twitter"></i></a>							</li>
					<?php } 
					if(get_theme_mod('newsera_options_youtube_link')!=''){ ?>
					<li class="youtube"><a href="<?php echo esc_url(get_theme_mod('newsera_options_youtube_link')); ?>" class="yu"><i class="fa fa-youtube"></i></a>							</li>
					<?php } 
					if(get_theme_mod('newsera_options_linkdin_link')!=''){ ?>
					<li class="linkedin"><a href="<?php echo esc_url(get_theme_mod('newsera_options_linkdin_link')); ?>" class="lin"><i class="fa fa-linkedin"></i></a>						  </li>
					<?php } 
					if(get_theme_mod('newsera_options_goglpls_link')!=''){ ?>
					<li class="google"><a href="<?php echo esc_url(get_theme_mod('newsera_options_goglpls_link')); ?>" class="gp"><i class="fa fa-google-plus"></i></a>						  </li>
					<?php } ?>
				</ul>
				<?php } ?>				
			</div>
			<?php if(get_theme_mod('date')!='') { ?>
			<div class="col-md-12 date">
				<i class="fa fa-calendar"></i> <span class="date-side"><?php echo esc_attr(date_i18n( get_option( 'date_format' ), strtotime( 'l, M j, Y' ) )); ?></span>
			</div>
			<?php } ?>
			<div class="clearfix"></div>
		</div><!--container-->
	</div><!--row-->
	<div class="container-fluid black-box">
		<div class="navigation_menu" id="bs-example-navbar-collapse-1" data-spy="affix" data-offset-top="95">
			<div class=" navbar-container container" >
				<nav role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#menu">
						  <span class="sr-only"><?php esc_html_e('Toggle navigation','newsX');?></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						  <span class="icon-bar"></span>
						</button>
					</div>
					<div id="menu" class="collapse navbar-collapse ">    
						<?php wp_nav_menu( array(
						'theme_location' => 'primary',
						'menu_class' => 'nav navbar-nav',
						'fallback_cb' => 'newsera_fallback_page_menu',
						'walker' => new newsera_nav_walker(),
						));    ?>        
					</div>    
				</nav>
			</div>
		</div>
	</div>
	</header>
</div>