<?php //Template Name: HOME
get_header(); 
$newsera_theme_options = newsera_get_options(); ?>
<div class="container">
	<div class="col-md-9 col-xs-12 left-post"> 		
		<!-- breaking news -->
		<?php if ( esc_attr( get_theme_mod('breaking_news', 1 ))){ ?>
		<div class="col-md-12 hot-news">
                <div class="row">
                    <div class="col-md-12">
					<?php if(get_theme_mod("breaking_news_title")!='') { ?>
                    <span class="pull-left bre-latest"><i class="fa fa-bullhorn"></i> <?php echo esc_attr(get_theme_mod("breaking_news_title")); ?> </span> 
					<?php }
							$get_featured_posts = new WP_Query( array(
								'posts_per_page' => 10,
								'post_type'      => 'post'
							) ); ?>
						<ul id="js-news" class="js-hidden">
							<?php if( $get_featured_posts->have_posts() ) : while( $get_featured_posts->have_posts() ) : 		$get_featured_posts->the_post(); ?>
								<li class="news-item">
									<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
									<?php the_title(); ?>
									</a>
								</li>
							<?php endwhile; endif; wp_reset_postdata(); ?>
						  </ul>
					</div>
				</div><!-- row -->
		</div>
		<?php } ?> <!-- breaking news --> 
		
		<?php if(do_shortcode(get_theme_mod('newsera_options_wp_news_slider')!="")){ ?>
		<div class="col-md-12 w_slider"> 
			<?php echo do_shortcode(get_theme_mod('newsera_options_wp_news_slider_shortcode')); ?>
		</div><?php } ?> <!-- slider code close -->
		
		<?php if(get_theme_mod('newsera_options_second_blog')!=""){ ?>
		<div class="col-md-12 post2 second_post">			
			<?php if(get_theme_mod('newsera_options_wp_news_blog2_showtitle') !='') { ?>
			<div class="col-md-12 col-xs-12 c_heading">
				<h3 class="heading animated" id="blog_heading"><?php echo esc_attr(get_theme_mod('wp_news_blog_slider1')); ?></h3>
			</div>
			<?php } ?>
			<div class="col-md-12 col-sm-12 col-xs-12 newsblog-section-bigblock divider-1 blogs blog-second">
				<div id="myCarousel" class="carousel slide" data-ride="carousel">
					<!-- Wrapper for slides -->
					<div class="carousel-inner">
					<?php if ( have_posts()) : 			
						$newsera_args = array( 'post_type' => 'post', 'category_name' =>get_theme_mod('wp_news_blog_slider1'));						
						$newsera_post_type_data = new WP_Query( $newsera_args );
						$i=1;
						while($newsera_post_type_data->have_posts()):
						$newsera_post_type_data->the_post();  ?>
						<?php if(has_post_thumbnail()): ?>
						  <div class="item <?php if($i==1) echo "active"; ?>">
							<?php $data= array('class' =>'img-responsive'); 
								the_post_thumbnail('newsera-post-thumb', $data); ?>
							<div class="carousel-caption">
								<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
								<p><?php echo substr(get_the_excerpt(),0,150); ?></p>
							</div>
						  </div>
						<?php endif; ?>
						<?php $i++; endwhile; ?>
					</div>					
					<!-- Left and right controls -->
					<a class="left carousel-control" href="#myCarousel" data-slide="prev">
						<i class="fa fa-arrow-left" aria-hidden="true"></i>
					</a>
					<a class="right carousel-control" href="#myCarousel" data-slide="next">
						<i class="fa fa-arrow-right" aria-hidden="true"></i>
					</a>
				<?php endif; ?>	
				</div>
			</div>
		</div>
		<?php } ?> <!-- home blog slider code close -->
		<div class="col-md-12 post2">
		<?php if(get_theme_mod('newsera_options_wp_news_third_blog')!=""){ ?>
			<div class="col-md-6 third_post"> <!-- third blog area -->
			<?php if(get_theme_mod('newsera_options_wp_news_blog3_showtitle') !='') { ?>
			<div class="col-md-12 col-xs-12 c_heading">
				<?php if(get_theme_mod('newsera_options_wp_news_blog3_title') !='') { ?>
				<h3 class="heading animated" id="blog_heading"><?php echo esc_attr(get_theme_mod('wp_news_blog_slider3')); ?></h3>
				<?php } ?>
			</div>
			<?php } ?>
			<div class="col-md-12 col-sm-12 col-xs-12 newsblog-section-bigblock divider-1 blogs blog-second">
				<div class="row" id="wp_news_blog_section1">
					<?php if ( have_posts()) : 			
						$newsera_args = array( 'post_type' => 'post','posts_per_page' => 1,'category_name' =>get_theme_mod('wp_news_blog_slider3'));	
						$newsera_post_type_data = new WP_Query( $newsera_args );
					while($newsera_post_type_data->have_posts()):
					$newsera_post_type_data->the_post();  ?>
					<div class="col-md-12 col-sm-12 col-xs-12 blog-details">
					<?php if(has_post_thumbnail()): ?>
						<div class="img-thumbnail">
							<?php $data= array('class' =>'img-responsive'); 
								  the_post_thumbnail('newsera-post-thumb', $data); ?>
							   <a class="pull-left" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>"></a>
						</div>
						<?php endif; ?>
						<div class="col-md-12 media newsblog-slider-auth-inner">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<span><?php if(get_the_date() !='') { ?>
								<i class="fa fa-calendar"></i> <a href="<?php the_permalink(); ?>"> <?php echo get_the_date();?> </a>
								<?php } ?>
							</span>
						</div>
						<div class="col-md-12 w_blog_detail">
							<p><?php echo substr(get_the_excerpt(),0,150); ?></p>
						</div>
					</div><!--post-1-->
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</div>
				<?php endif;  ?>
				<div class="col-md-12 post2-start">
					<?php if ( have_posts()) : 			
						$newsera_args = array( 'post_type' => 'post','posts_per_page' => 4,'category_name' =>get_theme_mod('wp_news_blog_slider3'));	
						$newsera_post_type_data = new WP_Query( $newsera_args );
					while($newsera_post_type_data->have_posts()):
					$newsera_post_type_data->the_post();  ?>
					<div class="col-md-12 col-sm-12 col-xs-12 blog-details">
						<div class="side-image">
							<?php if(has_post_thumbnail()): ?>
							<?php $data= array('class' =>'img-responsive'); 
								  the_post_thumbnail('newsera-post-thumb', $data); ?>
							   <a class="pull-left" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>"></a>
							<?php endif; ?>
						</div>
						<div class="sidebar-blog-details">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<span><?php if(get_the_date() !='') { ?>
								<i class="fa fa-calendar"></i> <a href="<?php the_permalink(); ?>"> <?php echo get_the_date();?> </a>
								<?php } ?>
							</span>
						</div>
					</div><!--post-1-->
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</div>
			</div>
		</div>
		<?php endif; } ?>		
		<!-- third blog area close -->
		
		<div class="col-md-6 fourth_post"> <!-- fourth blog area -->
			<?php if(get_theme_mod('newsera_options_fourth_blog')!=""){ ?>
			<?php if(get_theme_mod('newsera_options_wp_news_blog4_showtitle') !='') { ?>
			<div class="col-md-12 col-xs-12 c_heading">
				<?php if(get_theme_mod('newsera_options_wp_news_blog4_title') !='') { ?>
				<h3 class="heading animated" id="blog_heading"><?php echo esc_attr(get_theme_mod('wp_news_blog_slider4')); ?></h3>
				<?php } ?>
			</div>
			<?php } ?>
			<div class="col-md-12 col-sm-12 col-xs-12 newsblog-section-bigblock divider-1 blogs blog-second">
				<div class="row" id="wp_news_blog_section1">
					<?php if ( have_posts()) : 			
						$newsera_args = array( 'post_type' => 'post','posts_per_page' => 1,'category_name' =>get_theme_mod('wp_news_blog_slider4'));	
						$newsera_post_type_data = new WP_Query( $newsera_args );
					while($newsera_post_type_data->have_posts()):
					$newsera_post_type_data->the_post();  ?>
					<div class="col-md-12 col-sm-12 col-xs-12 blog-details">
					<?php if(has_post_thumbnail()): ?>
						<div class="img-thumbnail">
							<?php $data= array('class' =>'img-responsive'); 
								  the_post_thumbnail('newsera-post-thumb', $data); ?>
							   <a class="pull-left" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>"></a>
						</div>
						<?php endif; ?>
						<div class="col-md-12 media newsblog-slider-auth-inner">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<span><?php if(get_the_date() !='') { ?>
								<i class="fa fa-calendar"></i> <a href="<?php the_permalink(); ?>"> <?php echo get_the_date();?> </a>
								<?php } ?>
							</span>
						</div>
						<div class="col-md-12 w_blog_detail">
							<p><?php echo substr(get_the_excerpt(),0,150); ?></p>
						</div>
					</div><!--post-1-->
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</div>
				<?php endif;  ?>
				<div class="col-md-12 post2-start">
					<?php if ( have_posts()) : 			
						$newsera_args = array( 'post_type' => 'post','posts_per_page' => 4,'category_name' =>get_theme_mod('wp_news_blog_slider4'));	
						$newsera_post_type_data = new WP_Query( $newsera_args );
					while($newsera_post_type_data->have_posts()):
					$newsera_post_type_data->the_post();  ?>
					<div class="col-md-12 col-sm-12 col-xs-12 blog-details">
						<div class="side-image">
							<?php if(has_post_thumbnail()): ?>
							<?php $data= array('class' =>'img-responsive'); 
								  the_post_thumbnail('newsera-post-thumb', $data); ?>
							   <a class="pull-left" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>"></a>
							<?php endif; ?>
						</div>
						<div class="sidebar-blog-details">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<span><?php if(get_the_date() !='') { ?>
								<i class="fa fa-calendar"></i> <a href="<?php the_permalink(); ?>"> <?php echo get_the_date();?> </a>
								<?php } ?>
							</span>
						</div>
					</div><!--post-1-->
					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</div>
			</div>
			<?php endif; } ?>
		</div> <!-- fourth blog area close -->
	</div>
	<div class="col-md-12 post2 fifth_post"> <!-- fifth blog area -->
			<?php if(get_theme_mod('newsera_options_fifth_blog','1')!=""){ ?>
			<?php if(get_theme_mod('newsera_options_wp_news_blog5_showtitle') !='') { ?>
			<div class="col-md-12 col-xs-12 c_heading">
				<?php if(get_theme_mod('newsera_options_wp_news_blog5_title') !='') { ?>
				<h3 class="heading animated" id="blog_heading"><?php echo esc_attr(get_theme_mod('newsera_options_wp_news_blog5_title')); ?></h3>
				<?php } ?>
			</div>
			<?php } ?>
			<div class="col-md-12 col-xs-12 post2-start">
				<?php if ( have_posts()) : 			
					$newsera_args = array( 'post_type' => 'post','posts_per_page' => 4,'category_name' =>get_theme_mod('wp_news_blog_slider1'));	
					$newsera_post_type_data = new WP_Query( $newsera_args );
				while($newsera_post_type_data->have_posts()):
				$newsera_post_type_data->the_post();  ?>
				<div class="col-md-12 col-sm-12 col-xs-12 blog-details">
				<?php if(has_post_thumbnail()): ?>
					<div class="col-sm-4 col-xs-12 side-image ">
						<?php $data= array('class' =>'img-responsive'); 
							  the_post_thumbnail('newsera-post-thumb', $data); ?>
						   <a class="pull-left" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>"></a>
					</div>
					<?php endif; ?>
				<div class="col-sm-8 col-xs-12 sidebar-blog-details">
					<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					<span><?php if(get_the_date() !='') { ?>
						<i class="fa fa-calendar"></i> <a href="<?php the_permalink(); ?>"> <?php echo get_the_date();?> </a>
						<?php } ?>
					</span>
					<p><?php echo substr(get_the_excerpt(),0,150); ?></p>
				</div>
				</div>
				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
			</div>
			<?php endif; } ?>
	</div> <!-- fifth blog area close -->
</div>
<div class="col-md-3 col-xs-12"><!-- sidebar blogs -->
	<div class="col-md-12 post2 widget home-sidebar">
		<?php if( is_active_sidebar( 'sidebar-secondary' ) ) {
            dynamic_sidebar( 'sidebar-secondary' );
        } else {
		   the_widget( 'WP_Widget_Search');
		   the_widget( 'WP_Widget_Recent_Posts');		   
		} ?>
	</div>		
</div><!-- sidebar blogs close -->
</div>
<?php get_footer(); ?>