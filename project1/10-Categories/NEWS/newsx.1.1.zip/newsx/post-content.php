<div class="row">
	<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	 <?php if(has_post_thumbnail()): ?>
		<div class="img-thumbnail">
			<?php $newsera_defalt_arg= array('class' =>'img-responsive'); 
			the_post_thumbnail('newsera-post-thumb', $newsera_defalt_arg); ?>
		</div>
		<?php endif; ?>
		<div class="col-md-12 auth_box">
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<?php if(get_the_tag_list() != '') { ?>
			<p class="news_tags"><?php the_tags( esc_html__('Tags : ','newsX'), '', '<br />'); ?></p>
			<?php } ?>
			<span><i class="fa fa-calendar"></i><?php echo get_option( 'date_format' ); ?> </span>
			<?php the_content(); ?>
			<?php if(!is_single() && !is_page()){ ?>
			<a href="<?php the_permalink(); ?>" class="w_edit"><?php esc_html_e('Read More','newsX'); ?></a>
			<?php } ?>
		</div>
	</div>
</div>