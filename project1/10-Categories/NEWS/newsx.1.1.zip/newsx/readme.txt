== RESOURCES ==

* Image in the screenshot is from http://pixabay.com/:
	https://pixabay.com/en/new-york-brooklyn-bridge-3414128/
	
	
== Changelog ==

= Version 1.1 =
* Minor css issue fixed

= Version 1.0 =
* home post Blog sider issue fixed
* Screenshto image chanegs
* Other minor issue fixed.


