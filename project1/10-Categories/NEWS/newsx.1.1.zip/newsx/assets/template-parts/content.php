<div class=" post-2 clearfix">
	<div  id="post-<?php the_ID(); ?>" <?php post_class(); ?>>		
		 <?php if(has_post_thumbnail()): ?>
		 <div class="img-thumbnail col-md-6" >
			<a href="<?php the_permalink(); ?>"><?php $newsera_defalt_arg= array('class' =>'img-responsive '); the_post_thumbnail('news_post_thumb', $newsera_defalt_arg); ?></a>						
		 </div><?php endif;?>
		 <div class=" auth_box auth_box-2">
			<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<?php if(is_home()) { ?>
			<span><i class="fa fa-calendar"></i><b><?php echo get_the_date();?></b> </span>
			<span><i class="fa fa-comment-o icon"></i><b><?php comments_number('no Comments','1 Comments','% Comments');?></b></span>
			<span><i class="fa fa-user icon"></i><b><a href="<?php echo esc_url(get_author_posts_url( get_the_author_meta( 'ID' ) )); ?>"><?php echo get_the_author(); ?></a></b></span> <?php } ?>
			<div class="post-content"><?php the_content(); ?></div>
			<?php if(!is_single() && is_page()){ ?>
			<a href="<?php the_permalink(); ?>" class="w_edit"><?php esc_html_e('Read More','newsX'); ?></a>
			<?php } ?>
		</div>
	</div>
</div>