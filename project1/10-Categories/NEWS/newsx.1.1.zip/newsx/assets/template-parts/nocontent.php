<div class="row error-page">
	<h3><?php esc_html_e('No Posts Found','newsX'); ?></h3>
	<a class="btn" href="<?php echo esc_url(home_url( '/' )); ?>"><?php esc_html_e('Go back to homepage','newsX'); ?></a>
	<?php get_search_form(); ?>
</div>