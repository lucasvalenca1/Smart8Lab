 <?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package newsera
 */

get_header(); 
?>
<div class="container-fluid newsera-bredcum">
	<div class="container">
		<h1><?php esc_html_e('Home','newsera'); ?></h1>
    </div>
</div>
<!-- Blog  With Right Side bar Start -->
<div class="conatainer-fluid space w_blog">
	<div class="container">
		<div class="col-md-8 right-side blog_gallery">
			<?php if ( have_posts()){ 
				while ( have_posts() ): the_post();
					get_template_part('/assets/template-parts/content');
				endwhile;
				}else{
					get_template_part('/assets/template-parts/nocontent');
				} ?>
				<div class="newsera_blog_pagination1">
				<?php the_posts_pagination( array( 'mid_size' => 2 ) ); ?>
			</div>
		</div>
		<?php get_sidebar(); ?>
	</div>
</div>
<!-- Blog  End -->
<?php get_footer(); ?>