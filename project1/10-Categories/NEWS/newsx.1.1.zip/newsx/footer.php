<!--footer-->
<?php $newsera_theme_options = newsera_get_options(); ?>
<footer>
<?php if ( is_active_sidebar( 'footer-widget-area' ) ) { ?>
<div class="row black-box news_blog_footer">
	<div class="row">
		<?php dynamic_sidebar( 'footer-widget-area' ); ?>
	</div>
	<?php } ?>
</div>
</footer>
<div class="row orange-box">
	<div class="container  text-color-white text-left">
		<div class="col-md-8">
		<p class="p-copy-right">
		<?php if(get_theme_mod('newsera_options_footer_copyright')){  echo esc_attr(get_theme_mod('newsera_options_footer_copyright','Proudly Powered By WordPress')); } ?>
		 <a href="<?php if(get_theme_mod('newsera_options_developed_by_link')){  echo esc_url(get_theme_mod('newsera_options_developed_by_link' , 'http://www.woow-themes.com')); } ?>" class="footer-color">
		<?php if(get_theme_mod('newsera_options_developed_by_text')){  echo esc_attr(get_theme_mod('newsera_options_developed_by_text','Developed By woow-themes.com')); } ?></a>  
		</p>
		</div>
		<div class="col-md-4 col-sm-12 col-xs-12 top-social">
			 <?php $newsera_theme_options = newsera_get_options(); 
			if(get_theme_mod('newsera_theme_options_wp_news_social_media')!=""){ ?>
			<ul class="social">
				<?php if(get_theme_mod('newsera_options_facbook_link')!=''){ ?>
				<li class="facebook"><a href="<?php echo esc_url(get_theme_mod('newsera_options_facbook_link')); ?>" class="fb"><i class="fa fa-facebook"></i></a>						 </li>
				<?php }
				if(get_theme_mod('newsera_options_twitter_link')!=''){ ?>
				<li class="twitter"><a href="<?php echo esc_url(get_theme_mod('newsera_options_twitter_link')); ?>" class="tw"><i class="fa fa-twitter"></i></a>							</li>
				<?php } 
				if(get_theme_mod('newsera_options_youtube_link')!=''){ ?>
				<li class="youtube"><a href="<?php echo esc_url(get_theme_mod('newsera_options_youtube_link')); ?>" class="yu"><i class="fa fa-youtube"></i></a>							</li>
				<?php } 
				if(get_theme_mod('newsera_options_linkdin_link')!=''){ ?>
				<li class="linkedin"><a href="<?php echo esc_url(get_theme_mod('newsera_options_linkdin_link')); ?>" class="lin"><i class="fa fa-linkedin"></i></a>						  </li>
				<?php } 
				if(get_theme_mod('newsera_options_goglpls_link')!=''){ ?>
				<li class="google"><a href="<?php echo esc_url(get_theme_mod('newsera_options_goglpls_link')); ?>" class="gp"><i class="fa fa-google-plus"></i></a>						  </li>
				<?php } ?>
			</ul>
			<?php } ?>
			
		</div>
	</div>
</div>
<?php if(get_theme_mod('newsera_options_slide_up')){?>
<a href="#" class="back-to-top"><i class="fa fa-arrow-up bounce"></i></a>
<?php } ?>	
<?php wp_footer(); ?>
</body>
</html>