<?php
/**
 * Template Name: Front page
 */

get_header('home');

get_template_part( 'content', 'featured' );

get_footer();
