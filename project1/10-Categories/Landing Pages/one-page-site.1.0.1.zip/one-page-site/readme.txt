=== Theme: One Page Site ===
Contributors: ThemeHunk
Tags: one-column, two-columns, grid-layout, right-sidebar, custom-colors, custom-menu, theme-options, sticky-post, translation-ready, footer-widgets, blog 
Requires at least: 4.0
Tested up to: 5.1.1
Stable tag: 1.0.2
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"One Page Site a onepage WordPress Theme" By ThemeHunk.

== Description ==
Onepagesite is a child theme of novellite theme, it is loaded with total customization option.

== Frequently Asked Questions ==

= Does your theme works with latest WordPress version. =
Yes, our theme works with latest WordPress version.

= Does your theme support third party plugin =
Yes, we have created our theme in such a way that it can support almost all plugin available in a market. However, It is very difficult to test each and every plugin. So if you get any issues either you can contact to our support forum. They will help you in every possible manner to make plugin compatible with the theme. Or you can use any alternate plugin.

= Does your theme works on multisite. =
Yes, all our theme works on multisite.

== Resources ==

WordPress theme "Onepagesite " is a child theme of "novellite".
Novellite Theme is licensed under the GPL3.

License for images:
1. Image Name: main.jpeg 
Resource link: https://www.pexels.com/photo/bird-s-eye-view-of-city-buildings-during-sunset-681336/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Changelog ==
== 1.0.1 ==
* compatible with latest wordpress.

== 1.0.0 ==
* Initial release

== Upgrade Notice ==

= 1.0.1  =
* compatible with latest wordpress.

Once again, thank you so much for trying the Onepagesite WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.