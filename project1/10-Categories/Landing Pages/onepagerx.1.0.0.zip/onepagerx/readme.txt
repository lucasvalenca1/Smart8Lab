=== Theme: onepagerx ===
Contributors: ThemeHunk
Tags: one-column, two-columns, grid-layout, right-sidebar, custom-colors, custom-menu, theme-options, sticky-post, translation-ready, footer-widgets, blog 
Requires at least: 5.6
Tested up to: 5.2.2
Stable tag: 1.0.0
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"onepagerx a onepage WordPress Theme" By ThemeHunk.

== Description ==
 onepagerx is a child theme of novellite theme, It's good for local business site, portfolio site, agency site, music site, construction site, lawyer site. It is loaded with total customization option and contain usefule sections(#slider, #service, #team, #testimonial,#pricing, #ecommerce, #blog, #contact). It is a light weight theme  and you can make onepage as well as multipage site by using it.

== Frequently Asked Questions ==

= Does your theme works with latest WordPress version. =
Yes, our theme works with latest WordPress version.

= Does your theme support third party plugin =
Yes, we have created our theme in such a way that it can support almost all plugin available in a market. However, It is very difficult to test each and every plugin. So if you get any issues either you can contact to our support forum. They will help you in every possible manner to make plugin compatible with the theme. Or you can use any alternate plugin.

= Does your theme works on multisite. =
Yes, all our theme works on multisite.

== Resources ==

WordPress theme "onepagerx " is a child theme of "novellite".
Novellite Theme is licensed under the GPL3.

Image License:
Screenshot.png
Resource link: https://stocksnap.io/photo/VP98M357OV
Licensed under the CCO license.


== Changelog ==
== 1.0.0 ==
* Initial release

Once again, thank you so much for trying the onepagerx WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.