<div class="post">
    <p><?php _e('Nothing Found', 'variant-landing-page-four'); ?></p>
</div>