=== One Page Boxed===
Contributors: evidisha
 Tags: right-sidebar, custom-menu, custom-logo, editor-style, featured-images, translation-ready, flexible-header, sticky-post, theme-options, portfolio
Requires at least: 4.0.5
Tested up to: 5.1.1
Stable tag: 1.0.1
License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html


"One Page Boxed One Page Business WordPress Theme" By evidisha.


== Description ==
One Page Boxed is a boxed layout child theme of Oneline lite, It is loaded with total customization option.

== Resources ==
WordPress theme "One Page Boxed" is a child theme of "oneline-lite".
Oneline-lite Theme is licensed under the GPL3.

License for images:
1. Image Name: main.jpeg 
Resource link: https://www.pexels.com/photo/abstract-art-background-blur-735812/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Changelog ==
== 1.0.1  =
* Compatible with updated wordpress.

== 1.0.0  =
* Initial release

== Upgrade Notice ==

= 1.0.1  =
* Compatible with updated wordpress.

== Theme License & Copyright ==
One Page Boxed is distributed under the terms of the GNU GPL
One Page Boxed-Copyright 2018 One Page Boxed, evidisha.com
Once again, thank you so much for trying the One Page Boxed WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on evidisha, we would recommend you to visit the evidisha Support Forum and ask your queries there.