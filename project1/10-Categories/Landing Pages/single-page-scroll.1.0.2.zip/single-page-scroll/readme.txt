=== Single Page Scroll ===

Contributors: Blogwings
Tags: right-sidebar, custom-menu, custom-logo, editor-style, featured-images, translation-ready, flexible-header, sticky-post, theme-options, portfolio
Requires at least: 4.0.5
Tested up to: 5.1.1
Stable tag: 1.0.2
License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"Single Page Scroll theme One Page Business WordPress Theme" By Blogwings.

== Description ==
Single page Scroll theme is specially designed for corporate/business websites. Theme is user friendly and its instant set up process help you to create professional website for Business (Agency, Interior, Florist, Transport, Construction etc), Shop / eCommerce, Personal, Blog, Photography. This responsive theme comes with live customizer, Full body background slider and background image option, Translation ready, Header layouts (Default, Center and Split), Widget based home page sections with unlimited items capability, Unlimited color option, Advance Section styling, Professionally designed sections (Ribbon, Services, About Us, Call to action, Team, Shop (WooCommerce), Testimonial, Latest News, Contact Us (With call to, Mail to, Address and Map). Theme contain seven widget area (Four for footer, Two for sidebar (default pages) and one for shop page). Theme is compatible with WooCommerce, bbPress, Lead form builder, Contactform7 and with many other WP plugin.

== Resources ==

Single page scroll WordPress Theme is child theme of featuredlite WordPress Theme, 
Featured Lite WordPress theme, copyright (c) 2017 themehunk.com
Featured Lite Theme is distributed under the terms of the GNU GPL3

License for images:
1. Image Name: main.jpeg 
Resource link: https://www.pexels.com/photo/sky-adventure-outdoors-parachute-122829/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Frequently Asked Questions ==
= Do you provide support to free user? =
Yes, we provide support to free user. Just mail us at "infoblogwings@gmail.com"

= Can i modify your theme =
Yes sure, theme comes with GPL license you are free to modify theme as per your need.

== Change Log ==

= 1.0.2  =
* compatible with latest wordpress.

== 1.0.1  =
* Styling improved.

== 1.0.0  =
* Initial release

== Upgrade Notice ==
= 1.0.2=
* compatible with latest wordpress.

Once again, thank you so much for trying the Single page scroll WordPress Theme. 
As we said at the beginning, we will be glad to help you. 
If you have any questions related to this theme then do let us know & we will try our best to assist. 
If you have any general questions related to the themes on blogwings, we would recommend you to visit the blogwings site and mail us to ask your queries.