=== One Page Agency ===

Contributors: Blogwings, niteshraghu
Tags: right-sidebar, custom-menu, custom-logo, editor-style, featured-images, translation-ready, flexible-header, sticky-post, theme-options, portfolio
Requires at least: 4.0.5
Tested up to: 5.1.1
Stable tag: 1.0.2
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"One Page Agency theme One Page Business WordPress Theme" By Blogwings.

== Description ==
One page agency is a child theme of oneline lite, It is clean and unique design to create onepage plus multipage site.

== Frequently Asked Questions ==
= Do you provide support to free user? =
Yes, we provide support to free user. Just mail us at "infoblogwings@gmail.com"

= Can i modify your theme =
Yes sure, theme comes with GPL license you are free to modify theme as per your need.

== Changelog ==

= 1.0.2=
* compatible with latest wordpress.

= 1.0.1 =
* Readme.txt file updated.

= 1.0.0  =
* Initial release

== Upgrade Notice ==
= 1.0.2=
* compatible with latest wordpress.

== Resources ==

License for Screenshot:
1.Screenshot
Resource link:https://pixabay.com/en/woman-business-fashion-young-3060784/ 
Licensed under the CCO license.
License link : https://pixabay.com/en/service/terms/#usage

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
