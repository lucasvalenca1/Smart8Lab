=== realonepage ===

Contributors: themehunk
Tags: right-sidebar, custom-menu, custom-logo, editor-style, featured-images, translation-ready, flexible-header, sticky-post, theme-options, portfolio
Requires at least: 4.0.5
Tested up to: 5.2.1
Stable tag: 1.0.0
License: GPLv3 or later
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"realonepage is a multipurpose WordPress Theme" By themehunk.

== Description ==
Realonepage is a child theme of oneline lite, it provide a new skin to oneline lite theme with unique look and elegant style.

== Frequently Asked Questions ==
= Do you provide support to free user? =
Yes, we provide support to free user. Just mail us at "info@themehunk.com"

= Can i modify your theme =
Yes sure, theme comes with GPL license you are free to modify theme as per your need.

== Changelog ==

= 1.0.0  =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
* theme release

== Resources ==

License for Screenshot:
1.Screenshot
Resource link:https://burst.shopify.com/photos/beach-sunset-thailand?c=nature
Licensed under the CCO license.
License link : https://burst.shopify.com/licenses/creative-commons