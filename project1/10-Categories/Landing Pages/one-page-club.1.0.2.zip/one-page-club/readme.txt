=== One Page Club ===

Contributors: evidisha
Tags: right-sidebar, custom-menu, custom-logo, editor-style, featured-images, translation-ready, flexible-header, sticky-post, theme-options, portfolio
Requires at least: 4.0.5
Tested up to: 5.1.1
Stable tag: 1.0.2
License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

"One Page Club One Page Business WordPress Theme" By evidisha.


== Description ==
One Page Club is a versatile one page theme for creating beautiful websites. This theme comes with powerful features which will help you in designing a wonderful website for any type of niche (Business, Landing page, E-commerce, Local business, Personal website). It is the most advanced free WordPress theme available on the web with live customizer. This theme comes with fully responsive slider with clean and elegant design. Theme supports drag & drop widget for section content, Woocommerce section to feature your product at home page and use your site as an online store. Contact section with lead generation functionality. These all section is supported by our plugin ThemeHunk customizer. 

== Resources ==
WordPress theme "One Page Club" is a child theme of "oneline-lite".
Oneline-lite Theme is licensed under the GPL3.

License for images:
1. Image Name: main.jpeg 
Resource link: https://www.pexels.com/photo/rock-formation-with-passage-way-leading-towards-vast-ocean-508156/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Changelog ==
== 1.0.2 ==
* Compatible with updated wordpress.
== 1.0.1 ==
* Image license added.
== 1.0.0 ==
* Initial release.

== Upgrade Notice ==

= 1.0.2  =
* Compatible with updated wordpress.

== Theme License & Copyright ==
One Page Club is distributed under the terms of the GNU GPL
One Page Club -Copyright 2017 One Page Club, evidisha.com
Once again, thank you so much for trying the One Page Club WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on evidisha, we would recommend you to visit the evidisha Support Forum and ask your queries there.