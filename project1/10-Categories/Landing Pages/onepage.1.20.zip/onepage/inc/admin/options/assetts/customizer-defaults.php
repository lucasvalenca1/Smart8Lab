<?php
//add settings default value
$background_color = '#f6f6f6';

$header_background_color = '#d44d5c';
$header_text_color = '#faedee';
$header_link_normal = '#faedee';
$header_link_hover = '#ffffff';

$body_text_color = '#666666';
$body_headings_color = '#444444';
$body_link_normal = '#444444';
$body_link_hover = '#d44d5c';

$footer_background_color =  '#d44d5c';
$footer_text_color = '#faedee';
$footer_headings_color = '#ffffff';
$footer_link_normal = '#faedee';
$footer_link_hover = '#ffffff';

$button_background_normal = '#d44d5c';
$button_background_hover = '#c53e4d';
$button_text_normal =  '#ffffff';
$button_text_hover = '#ffffff';