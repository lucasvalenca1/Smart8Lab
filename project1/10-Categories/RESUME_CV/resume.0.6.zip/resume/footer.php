<?php
/**
 * footer - Template for displaying the footer
 * Contains all wp_footer after.
 *
 * theme ResuMe
 */
?>
<footer role="separator">
</footer>
<?php wp_footer(); ?>
</body>
</html>

