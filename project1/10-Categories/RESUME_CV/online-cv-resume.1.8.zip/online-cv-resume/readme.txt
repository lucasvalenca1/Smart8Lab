﻿=== Online CV Resume ===

Contributors: eDataStyle
Requires at least: 4.0
Tested up to: 5.2.0
Stable tag: 1.8
Requires PHP: 7.0
License: GPLv3 
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Online CV Resume is a Modern, Minimal & Creative  WordPress theme for online resume, cv, or a personal website. This beautiful online resume template comes with a built-in portfolio type . Online-CV-Resume is suitable for designer, developer, freelancer, photographer, architects, Artists and many more individual who want to showcase his/her work. It is a high performance template it’s help to load your website fast and it’s fully optimize and clean code help search engine to optimize website. It comes with pre-defined sections for skills, education, work experience, etc. All theme options can be easily set up using live theme customizer. 

It’s 100% responsive that’s why it will work nicely on all smart devices( smart phones, tablet, PCs and desktops ). It’s also well documented and clean coded that’s why anyone can change it easily.


== Copyright ==
Online CV Resume WordPress Theme, Copyright (C) 2019 eDataStyle.com
Online CV Resume is distributed under the terms of the GNU GPL

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.
4. For Home Section or hero widget , please install plugins piklist plguins from wordpress.org then you will find a widgets for home page..

== Credits ==

Underscores:
Author: 2012-2015 Automattic
Source: http://underscores.me
License: GPLv3 or later](https://www.gnu.org/licenses/gpl-3.0.html)

Bootstrap:
Author: Twitter
Source: http://getbootstrap.com
License: Licensed under the MIT license

Fontawesome :
Author: fontawesome
Source: http://fontawesome.io/
License: [MIT/SIL OFL Licensed](http://fontawesome.io/license/)

Customizer:
Author: https://github.com/justintadlock
Source: https://github.com/justintadlock/trt-customizer-pro
License: GNU GPL

Owl Carousel 2:
Author: David Deutsch
Source: https://github.com/OwlCarousel2/OwlCarousel2
License: [MIT License.]

FancyBox:
Author: fancyApps 
Source:  http://fancyapps.com/fancybox/
License: GPLv3

Tgmpluginactivation:
Source: http://tgmpluginactivation.com/
License: GPL-2.0 or later license.

AOS-next:
Source: https://github.com/michalsnik/aos/blob/v2/LICENSE
License: MIT License.


== Google Fonts ==
Roboto
Source: https://fonts.google.com/specimen/Roboto?selection.family=Roboto
License: Open Font License 

K2D
Source: https://fonts.google.com/specimen/K2D
License: Open Font License  

== Image Used ==
https://pxhere.com/en/photo/710493
CC0 Public Domain

screenshot profile pic:
https://pxhere.com/en/photo/946992
CC0 Public Domain

== Changelog ==

= 1.8 =
* css active link add add recommend elementor page builder

= 1.7 =
* Theme Reviewer feedback

= 1.6 =
* Theme Reviewer feedback

= 1.5 =
* user feedback updated

= 1.4 =
* Screenshoot updated

= 1.3 =
* Review Team bug fixed

= 1.2 =
* License for AOS & sreenshoot

= 1.1 =
* Text update

= 1.0 =
* Initial release
