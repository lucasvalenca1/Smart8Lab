Images asphatthemes:
-------------------------------
Resumee WordPress Theme, Copyright 2017 Ashiquzzaman Kiron
Resumee is distributed under the terms of the GNU GPL


All other images are from pixabay.com, Unplash.com and WordPress dummy contents released under GPL v2
Tested up to: 5.4
Minimum Required Version: 4.5

1. site-logo - https://pixabay.com/en/parking-signs-symbols-black-circle-39771/
2. Face - https://pixabay.com/en/business-man-businessman-corporate-1042709/


== Changelog ==

##### = 0.4.6 -  March 12 , 2020  =
- Fix: Intro widget one error (create function)


##### = 0.4.5 -  February 24 , 2020  =
- Compatibility: Tested up to 5.4


##### = 0.4.4 -  October 17 , 2019  =
- Compatibility: Tested up to 5.2.2



##### = 0.4.3 -  July 9 , 2019  =
- Compatibility: Tested up to 5.2.2



##### = 0.4.2 - June 8 , 2019  =
- Fix: Skill section HTML accept issue
- Add: WP Compatibility 5.2.1



##### = 0.4.1 - April 22 , 2019  =
- Add: Tested upto WordPress 5.2



##### = 0.4.0 - December 22 , 2018  =
- Add: Gutenberg full bleed image CSS
- Fix: Gutenberg default button block issue
- Fix: Full bleed image container issue


= 0.3.9 -  November 12 , 2018  =
- Add: Gutenberg default theme opt in options



= 0.3.8 -  November 1 , 2018  =
- Add: Xing social icon in Intro widget



= 0.3.7 -  September 17 , 2018  =
- Update: Tested upto 4.9.8
- Add: Minimum required version



= 0.3.6 - August 24, 2018  = 
- Update: WordPress latest version compatibility
- Version Bump




= 0.3.5 - June 12, 2018  = 
- Update: WordPress latest version compatibility



= 0.3.4 - May 28, 2018  = 
- Tweak: Footer widget margin issue
- Fix: Default footer & sidebar issue



= 0.3.3 - April 13, 2018  = 
- Change: Google UTM tag URL in upsell dashboard



= 0.3.2 - March 12, 2018  = 
- Add: Google UTM tag URL in upsell dashboard
- Fix: Theme info


= 0.3.1 - February 09, 2018  = 
- Add: Intro widget social icon option "none"


= 0.3.0 - January 04, 2018  = 
- Add: Demo data dashboard upsell



= 0.2.9 - December 06, 2017  = 
- Fix: Footer Text customizer setting



= 0.2.8 - November 11, 2017  = 
- Fixed posts page input[submit] btn style
- Fixed posts page input[reset] btn style
- Corrected Dashboard refund day 
- Changed theme desription



= 0.2.7 - October 29 , 2017  = 
- Fixed dashboard theme option panel


= 0.2.6 - October 4 , 2017  = 
- Changed theme description
- Added default fallback style for input field & submit button



= 0.2.5 - September 11 , 2017  = 
- Changed theme description



= 0.2.4 - August 28 , 2017  = 
- Added intro widget icon hide



= 0.2.3 - August 20 , 2017  = 
- removed dashboard discount code




= 0.2.2 - August 20 , 2017  = 
- Added dashboard discount code




= 0.2.1 - August 14 , 2017  = 
- Removed dashboard discount code




= 0.2.0 - August 14 , 2017  = 
- Added dashboard discount code





= 0.1.9 - July 22 , 2017  = 

- Fixed blog sidebar issue on mobile
- Fixed blog template tag issue





= 0.1.8 - June 30 , 2017  = 

- Changed theme description
- Removed discount code




= 0.1.7 - June 22 , 2017  = 

- Added theme redirection on dashboard page
- Added discount code




= 0.1.6 - June 9 , 2017  = 

- Created new resumee.pot file




= 0.1.5 - June 7 , 2017  = 

- Fixed NS Theme Check "Missing singular placeholder" issue



= 0.1.4 - June 2 , 2017  = 

- Fixed issue, using text field
- Removed commented code from landing-page.php and also removed commented codes from other files.
- Removed wp_enqueue_script( 'jquery' ) from function.php file
- Removed the commented the_content code and also removed unnecessary codes
- Removed layouts folder
- Fixed the issue, created own theme pot file.
- Declared theme copyright format as asked





= 0.1.3 - June 1 , 2017  = 

- Fixed page level table styling issue



= 0.1.2 - May 24 , 2017  = 

- Fixed upsell console error
- Fixed header image problem



= 0.1.1 - May 18 , 2017  =

- Improved Widgets customizer UX
- Changed Intro Image
- Improved Front page widget styling
- Appended Pro widget customizer preview 
- Changed screenshot




= 0.1.0 - May 10, 2017  =

- Fixed "Template Comments" post page comment section UI issue 




= 0.0.9 - May 8, 2017  =

- Removed home widget sidebar
- Added widget description
- Fixed Page & post comment button UI issue
- Fixed inside single post table issue
- Fixed ul, li & spacing & link issues in Footer widget



= 0.0.8 - May 7, 2017  =

- Fixed single post table styling
- Fixed Search page styling issue
- Fixed other styling issues
- Fixed frontpage widget error after adding
- Fixed icon fontawesome Icon problems
- Deleted site link color and site text color options from customizer



= 0.0.7 - May 5, 2017  =

- Added placeholder for widgets
- Deleted sass files



= 0.0.6 - May 4, 2017  =

- Deleted navigation.js file
- Deleted bootstrap.js file
- Changed documentation link
- Added fontawesome icon select on Intro widget





= 0.0.5 - May 1, 2017  =

- Changed description
- Added blog sidebar
- Added search page & 404 page styling
- Made frontpage widgets
- Made translation ready
- Added theme tags
- Removed readme.md
- Other styling changes
- Fixed sidr first click not working
- Updated sidr version to  v2.2.1 
- Long word content overflow fixed
- Fixed comment numbering 
- Fixed sidr menu close hover cursor
- Changed frontpage.php to landing-page.php
- Fixed other CSS issues
- Added partial refresh in widgets
- Added conditional block on widgets




= 0.0.4 - February 26, 2017  =

- Changed descriptions




= 0.0.3 - February 26, 2017  =

- Styling changes
- Removing frontpage extra blocks




= 0.0.2 - February 26, 2017  =

- Theme release





-------------------------------------------------------
Credits:
-------------------------------------------------------


* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)


1. Underscores starter theme - Copyright: Automattic, automattic.com 
    - URL                   http://underscores.me/
    - Licence               Licensed under GPLv2 or later    
    - Licence URL           http://www.gnu.org/licenses/gpl.html

2. Font Awesome
    - URL                   http://fortawesome.github.io/Font-Awesome/#license
    - License               SIL Open Font & MIT
    - License URL (MIT)     http://opensource.org/licenses/MIT
    - License URL (OFL)     http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

3. Google Fonts - Open Sans
    - URL                   https://www.google.com/fonts/specimen/Open+Sans
    - License               SIL Open Font
    - License URL           http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL


5. Google Fonts - Lato
    - URL                   https://www.google.com/fonts/specimen/lato
    - License               SIL Open Font
    - License URL           http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL


6. Sidr 
    - URL - https://github.com/artberri/sidr
    - License - License -jquery.matchHeight.js is licensed under The MIT License (MIT)
    - License - Released under the MIT License


7. Normalize CSS
    - Author - Nicolas Gallagher and Jonathan Neal 
    - License - The MIT License (MIT)   
    - URL - https://github.com/necolas/normalize.css/blob/master/LICENSE.md
    - Source - http://necolas.github.com/normalize.css/


8. Bootstrap 3.3.7
    - Author - Mark Otto, Jacob Thornton
    - URL - https://github.com/twbs/bootstrap
    - License -  Code released under the MIT License. Docs released under Creative Commons
    - License URL - https://github.com/twbs/bootstrap/blob/master/LICENSE