<?php

$oziz_resume_title = get_theme_mod('resume_title','RESUME');
$oziz_resume_title_sub = get_theme_mod('resume_title_sub','A LITTLE JOURNEY OF MY LIFE');
oziz_ch_block_teaser($oziz_resume_title, $oziz_resume_title_sub);

