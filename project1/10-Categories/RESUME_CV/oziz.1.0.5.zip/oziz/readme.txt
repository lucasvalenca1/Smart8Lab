=== Oziz ===
Contributors: WPAmaNuke
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 4.9
Tested up to: 5.2
Requires PHP: 5.6.4
Stable tag: 1.0.5
License: GNU General Public License v2 or later
License URI: LICENSE

Oziz One Page Landing Page WordPress Theme for resume , skill and portfolio

== Description ==

Oziz is a one page WordPress theme for resumes / cv. It's responsive, and based on bootstrap. It has a Custom HomePage which you can use to put video, education, experience, biography, skills, testimonials, a pricing table, and contact info. This theme is suitable as a landing page or for those of you looking for jobs by showing your skill and resume portfolio. Demo : http://reviews.wpamanuke.com/homepage/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

oziz includes support for Infinite Scroll in Jetpack.

= How To Setup Menu For Landing Page ( Custom HomePage )
For each section , you need create anchor link like this :
	- http://yourdomain.com/#oz-id-about
	- http://yourdomain.com/#oz-id-resume
	- http://yourdomain.com/#oz-id-pricing
	- http://yourdomain.com/#oz-id-portfolio
	- http://yourdomain.com/#oz-id-testimonial	
	- http://yourdomain.com/#oz-id-team
	- http://yourdomain.com/#oz-id-contact
	
== Changelog ==

= 1.0 - March 12 2019 =
* Initial release
= 1.0.1 - April 03 2019 =
* Fix Color, Gallery, Default Menu Spacing
= 1.0.2 - May 17 2019 =
* Fix CSS
* Add Full Width Options
= 1.0.3 - May 30 2019 =
* Edit readme.txt
= 1.0.4 - June 6 2019 =
* Change Screenshot
= 1.0.5 - June 12 2019 =
* jquery.tcycle.js enable for all pages

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* Bootstrap v4.0 http://getbootstrap.com, Copyright 2011-2018 Twitter, Inc. , [MIT License](https://github.com/twbs/bootstrap/blob/v4-dev/LICENSE)
* Google Webfonts  Raleway | SIL Open Font License / OFL , Source: https://www.google.com/fonts , [License OFL](http://scripts.sil.org/OFL)
* Customizer Based on OnePress WordPress Theme , (C) 2019 FameThemes , https://wordpress.org/themes/onepress/ [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* mb.YTPlayer , (C) 2019 by Pupunzi , https://github.com/pupunzi/jquery.mb.YTPlayer ,  [MIT](https://opensource.org/licenses/MIT)
* tCycle , (C) 2013 by malsup , http://malsup.github.io/jquery.tcycle.js , [MIT](https://opensource.org/licenses/MIT)
* Font Awesome 4.7.0 ,Created by @davegandy, http://fontawesome.io - @fontawesome , [MIT License](http://fontawesome.io/license) Font: SIL OFL 1.1, CSS: MIT License
* Images for theme Screenshot | Source: https://stocksnap.io/ , License: CC0 1.0 Universal / Public Domain Dedication / GPL Compatible , [CC0 1.0 Universal] (https://creativecommons.org/publicdomain/zero/1.0/)
    - https://stocksnap.io/photo/DEQF28Z7U9
* Dummy Images for profil/team | Source : Own Made , GPL