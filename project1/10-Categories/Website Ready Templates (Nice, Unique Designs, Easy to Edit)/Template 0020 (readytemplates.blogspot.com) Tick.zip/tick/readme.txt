Tick 2.0 Read Me 
------------------------------------------------------------------------------------------------------------
Design By: Ethan Neuenswander 
[http://www.ethanneuen.com]
------------------------------------------------------------------------------------------------------------
 

Thank You for downloading Tick 2.0 a Minimalist Open Source web template designed to prove that content and design can both look great.
------------------------------------------------------------------------------------------------------------
Tick is currently being ported in to Wordpress check [http://www.ethanneuen.com] to see the progress on the template.
It is also being worked on in Java to make the Navigation bars open and close.