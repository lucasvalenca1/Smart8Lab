=== Professional Education Consultancy ===

Contributors: cyclonetheme
Tags: custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, left-sidebar , right-sidebar,grid-layout,theme-options,blog ,news ,portfolio
Requires at least: 4.0
Tested up to: 5.2.2
Stable tag: 0.4
Requires PHP: 5.2
Author URI: https://cyclonethemes.com/
Theme URI: https://cyclonethemes.com/downloads/professional-education-consultancy-lite/
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Professional Education Consultancy is child theme of Bizberg WordPress Theme. Theme is a clean & modern Education WordPress Theme. Professional Education Consultancy is suitable for any tuition, marketing, book selling, university, workshop, college, school, course hub, training center, blogging or any kind of educational institution.  Also Professional Education Consultancy theme is a perfect solution for your educational websites. This Free WordPress theme is fully responsive, cross-browser compatible, translation ready & SEO friendly. if you run into any problem while using our theme, you can refer to extensive documentation or contact our friendly support team. It fully supports Gutenberg, all the sections are made from Gutenberg.

== License ==

Bizberg WordPress Theme, Copyright 2019 CycloneTheme
Bizberg is distributed under the terms of the GNU General Public License v2

Professional Education Consultancy WordPress Theme is child theme of Bizberg WordPress Theme, Copyright 2019 CycloneTheme
Professional Education Consultancy WordPress Theme is distributed under the terms of the GNU GPL

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Professional Education Consultancy includes support for Infinite Scroll in Jetpack.

== Changelog ==

= 0.1 =
* Initial release

== Screenshots ==

**** Screenshot image CCO by pxhere *****/

1. https://pxhere.com/en/photo/74935
2. https://pxhere.com/en/photo/764632