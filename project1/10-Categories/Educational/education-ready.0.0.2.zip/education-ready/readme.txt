 === Education Ready ===

 Contributors: amplethemes
 Tags: custom-logo, one-column, two-columns, right-sidebar, left-sidebar, full-width-template, custom-background, custom-colors, custom-menu, featured-images, theme-options, threaded-comments, translation-ready, blog, portfolio, e-commerce, footer-widgets
 Requires at least: WordPress 3.6
 Tested up to: WordPress 5.0.3
 Stable tag: 1.0.0
 Requires PHP: 5.2.4
 License: GPLv3
 License URI: http://www.gnu.org/licenses/gpl-2.0.html

 == Description ==

 Education Ready is child theme of Education Method.  Education Ready is a clean, simple and professional business theme with attractive elements and ample of features for business and corporate websites. It is well suited theme for business, corporate, informative, agencies, travel, design, art, personal ,woocommerce shop  and any other creative websites and blogs. It features multiple sections on the front page including favicon, logo, widgets, multiple navigations, address bar, social menus, and customizer to customize theme easily.

== License ==

Education Ready WordPress Theme is child theme of Education Method WordPress Theme, Copyright (C) 2017, Ample Themes
Education Ready  is distributed under the terms of the GNU GPL


Education Method  WordPress Theme, Copyright (C) 2017, Ample Themes
Education Method is distributed under the terms of the GNU GPL



 == Frequently Asked Questions ==

 == Installation ==
 1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.



 == Changelog ==

 ===V-0.0.1===
 * initial version


 == Upgrade Notice ==

 = 0.0.1 =
 * Initial version


 * This version fixes a security related bug.  Upgrade immediately.

 == Resources ==

== Images Used in Screenshot ==
   All the images are CCO license, https://pxhere.com/en/license
 * https://pxhere.com/en/photo/1190563


 * https://pxhere.com/en/photo/1129489
 * https://pxhere.com/en/photo/1446751
 * https://pxhere.com/en/photo/723072

 All other resources are used from parent theme which is GPL compatible.




