<?php
/**
 * Template for Front page
 *
 * Template name: Frontpage
 *
 * @package Education_Soul
 */

get_header();

get_footer();
