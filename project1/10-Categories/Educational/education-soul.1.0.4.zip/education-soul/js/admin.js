( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#education-soul-settings-metabox-container' ).tabs();

	});

} )( jQuery );
