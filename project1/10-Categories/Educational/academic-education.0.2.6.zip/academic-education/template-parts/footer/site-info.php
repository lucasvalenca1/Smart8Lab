<?php
/**
 * Displays Site info
 */
?>

<div class="copyright-wrapper">
	<div class="inner">
       	<div class="copyright">
       		<p><?php echo esc_html(get_theme_mod('academic_education_footer_copy',__('Copyright 2017 -','academic-education'))); ?> <?php academic_education_credit(); ?></p>
       	</div>
       	<div class="clear"></div>
	</div>
</div>
