=== Academic Education ===
Contributors: LogicalThemes
Tags: left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, sticky-post, post-formats, full-width-template, theme-options, threaded-comments, translation-ready, rtl-language-support, blog, education, e-commerce
Requires at least: 5.0
Tested up to: 5.3.2
Stable tag: 0.2.6
Requires PHP: 7.2.14
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Academic Education theme is suitable for college, School, university, LMS, Training Center, Academy, Primary School, High School and Kindergarten and various educational websites. and hey you can even put it use for tuition classes, coaching classes, personal, blogging and any small business, we are not leaving anything behind. A highly flexible, versatile yet multipurpose theme that can be used to build business and corporate websites.

== Description ==

Academic Education theme is suitable for college, School, university, LMS, Training Center, Academy, Primary School, High School and Kindergarten and various educational websites. and hey you can even put it use for tuition classes, coaching classes, personal, blogging and any small business, we are not leaving anything behind. A highly flexible, versatile yet multipurpose theme that can be used to build business and corporate websites. This theme comprises of news, added filter feature, personalization options with a clean professional design that is user friendly. Not only that you can also find useful sections such as testimonial section, Banner with Call to Action Button (CTA),social media links and so on. An excellent option for the educational institutions and businesses. The SEO optimization with unique and secure coding ensures safety of your data along with the SEO activities, web crawlers will love it. A lovely theme for your lovely university. lastly , we would like to talk about the insane customization viability in regards to add on features tools and short codes that we provide.

== Changelog ==

= 0.1 =
  *  Initial version Released.

= 0.2 =
  *  Reolved Error.
  *  Done responsive menu css.
  *  Resolved the translation error in footer.
  *  Added image tag in page template.

= 0.2.1 =
  *  Added the License information of image url with given format.
  *  Resolved the console error of customizer.js 
  *  Added the theme url.

= 0.2.2 =
  *  Changed esc_attr_x to esc_html_x in searchform.php.
  *  Done the text capital of class.
  *  include post format tag.
  *  Added updated bootstrap file. 

= 0.2.3 =
  *  Added Typography.
  *  Added Potfile.

= 0.2.4 =
  *  Added woocommerce.
  *  Changed slider.
  *  Updated pot file.
  *  Resolved theme errors.
  *  Changed theme screenshot.
  *  Changed image urls.

= 0.2.5 =
  * Added skip to content in the theme.
  * Code of navigation updated.
  * Resolved css errors.
  * Changed single post layout.
  * Done Keyboard navigation.
  * Pot file updated.

= 0.2.6 =
  * Added sticky header option.
  * Changed some theme code.
  * Updated POT file.

== Resources ==

Academic Education WordPress Theme, Copyright 2017 LogicalThemes
Academic Education is distributed under the terms of the GNU GPL

Theme is Built using the following resource bundles.

  Bootstrap
  - Mark Otto and Jacob Thornton
  - copyright 2011-2018, Mark Otto and Jacob Thornton
  - https://github.com/twbs/bootstrap/releases/download/v4.0.0/bootstrap-4.0.0-dist.zip 
  - License: MIT License (MIT) 
  - https://github.com/twbs/bootstrap/blob/master/LICENSE

  Font Awesome 
  - Dave Gandy
  - Copyright July 12, 2018, Dave Gandy 
  - https://github.com/FortAwesome/Font-Awesome.git
  - License: Font Awesome Free 5.0.6
  - http://fontawesome.com/license

  Superfish 
  - Joeldbirch 
  - Copyright 2013, Justin Tadlock 
  - https://github.com/joeldbirch/superfish.git 
  - License: Free to use and abuse under the MIT license. v1.7.9 
  - https://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

  Customizer Pro
  - Justin Tadlock 
  - Copyright 2016, Justin Tadlock.
  - License: All code, unless otherwise noted, is licensed under the GNU GPL, version 2 or later.
  - https://github.com/justintadlock/trt-customizer-pro

  Pexels Images
  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://www.pexels.com/photo-license/

  Screenshot banner image: Copyright Tookapic
  License: CC0 1.0 Universal (CC0 1.0)
  Source: https://www.pexels.com/photo/brown-building-near-grass-field-83133/