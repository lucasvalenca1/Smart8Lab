=== Education Xpert ===
Contributors: sparklewpthemes
Tags: left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, custom-logo, featured-images, footer-widgets, full-width-template, theme-options, threaded-comments, translation-ready, e-commerce, education
Requires at least: 4.7
Tested up to: 5.3
Requires PHP: 5.2.4
Stable tag: 1.0.0
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Education Xpert simple clean and awesome fully customizable responsive Free Education WordPress Themes, Education Xpert specially design for all type of educational institutions websites. Education Xpert is one of the most accessible Free Education WordPress Themes which can easily accommodate all type of users with no coding skills to advanced or normal web developers. Education Xpert Free Education WordPress Themes includes excellent features for educational website and practices of all type of educational business, themes have included more advanced features like one-click demo data import, primary theme color, list courses section, about section, call to action, services list section display team member, success store counter, testimonial section, blog section and footer section with more individual page &  post layout options, fully customizer based theme options. Education Xpert is very easy to use for all types of educational institutions website like online courses, colleges, universities, schools, and different other education-based websites. also, Education Xpert Free Education WordPress Themes is fully translation ready, a powerful options panel, child theme support, quality code, reorder all sections, site speed optimized, responsive, cross-browser compatible, good documentation, SEO friendly and supports WooCommerce and some other external plugins like element page builder, Page Builder by SiteOrigin, Jetpack, Contact Form 7 and many more plugins.

== Description ==

Education Xpert simple clean and awesome fully customizable responsive Free Education WordPress Themes, Education Xpert specially design for all type of educational institutions websites. Education Xpert is one of the most accessible Free Education WordPress Themes which can easily accommodate all type of users with no coding skills to advanced or normal web developers. Education Xpert Free Education WordPress Themes includes excellent features for educational website and practices of all type of educational business, themes have included more advanced features like one-click demo data import, primary theme color, list courses section, about section, call to action, services list section display team member, success store counter, testimonial section, blog section and footer section with more individual page &  post layout options, fully customizer based theme options. Education Xpert is very easy to use for all types of educational institutions website like online courses, colleges, universities, schools, and different other education-based websites. also, Education Xpert Free Education WordPress Themes is fully translation ready, a powerful options panel, child theme support, quality code, reorder all sections, site speed optimized, responsive, cross-browser compatible, good documentation, SEO friendly and supports WooCommerce and some other external plugins like element page builder, Page Builder by SiteOrigin, Jetpack, Contact Form 7 and many more plugins. If you face any problem or issue related to our education theme, you can refer to our theme documentation or contact our friendly support team. Check demo at http://demo.sparklewpthemes.com/educationxpert and theme details at https://sparklewpthemes.com/wordpress-themes/educationxpert and get free support forum at https://sparklewpthemes.com/support/



== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Theme supports WooCommerce and some other external plugins like elementor page builder, Jetpack, Contact Form 7 and many more plugins.

= Where can I find theme all features ? =

You can check our Theme features at http://demo.sparklewpthemes.com/educationxpert/

= Where can I find theme demo? =

You can check our Theme Demo at http://sparklewpthemes.com/wordpress-themes/educationxpert/


== Translation ==

Education Xpert theme is translation ready.


== Copyright ==

Education Xpert WordPress Theme is child theme of Educenter, Copyright 2019 Sparkle Themes.
Education Xpert is distributed under the terms of the GNU GPL

Educenter WordPress Theme, Copyright (C) 2018 Sparkle Themes.
Educenter is distributed under the terms of the GNU GPL


== Credits ==

	Images used in screenshot

	* Slider Image - https://pxhere.com/en/photo/441465 License: CCO (https://pxhere.com/en/license)


== Changelog ==

= 1.1.1 12th December 2019  =

** Make theme fully compatible with RTL(Right to left) languages compatible.
** Make theme fully translation ready with compatible polylang & WPML plugins.
** Add click event section to scroll related section in customizer HomePage Block Section.
** Make theme fully compatible with latest version FontAwesome icon.
** Fixed Schema Structure error on the breadcrumb.
** Fixed major responsive and normal design issue.
** .Pot file updates with recent change.
** Add documentation link in customizer.
** Fixed dynamic design issue.
** Recommended plugin added (Polylang, Elementor, Loco Translate).
** Check blank condition for course price read circle issue.
** Make theme compatible with must popular element or page builder plugins.
** Add new blog template for list all posts.
** Add new blank page template "Blank Template (For Page Builders)".


= 1.0.0 22nd May 2019 =

 ** Initial submit theme on wordpress.org trac.