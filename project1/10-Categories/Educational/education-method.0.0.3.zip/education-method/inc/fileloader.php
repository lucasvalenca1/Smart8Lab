<?php
require get_template_directory() . '/inc/repeater-class.php';
require get_template_directory() . '/inc/golbal-theme-mod.php';
require get_template_directory() . '/inc/default.php';
require get_template_directory() . '/inc/ample-themes/customizer/slider-sections/slider-field-sanitization.php';
require get_template_directory() . '/inc/ample-themes/customizer/slider-sections/slider-function.php';
require get_template_directory() . '/inc/customizer-function-category.php';
require get_template_directory() . '/inc/ample-themes/customizer/top-header-customizer/sanitize-checkbox.php';
require get_template_directory() . '/inc/ample-themes/metabox/metabox-icon.php';
require get_template_directory() . '/inc/ample-themes/widgets/service-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/quote-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/team-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/testimonials-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/latest-blog-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/gallery-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/about-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/top-info-widgets.php';
require get_template_directory() . '/inc/ample-themes/widgets/events.php';
require get_template_directory() . '/inc/ample-themes/widgets/noticed.php';
require get_template_directory() . '/inc/ample-themes/widgets/courses.php';


require get_template_directory() . '/inc/ample-themes/metabox/metabox-page-post-sidebar.php';
require get_template_directory() . '/inc/ample-themes/customizer/layout-design/layout-functions.php';
require get_template_directory() . '/inc/ample-themes/customizer/theme-options-customizer/theme-options-functions.php';
require get_template_directory() . '/inc/hook/dynamic-style-css.php';
require get_template_directory() . '/inc/hook/resets-color.php';













