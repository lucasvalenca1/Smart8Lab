<?php
/**
 * Template name: Front Page
 *
 * @package Education_Mind
 */

get_header();

get_footer();
