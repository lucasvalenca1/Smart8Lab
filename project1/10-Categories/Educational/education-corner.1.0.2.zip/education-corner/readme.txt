=== Education Corner ===

Tags: e-commerce, grid-layout, footer-widgets, blog, one-column, two-columns, full-width-template, threaded-comments, left-sidebar, flexible-header,  custom-colors,  custom-header, custom-menu, featured-images, theme-options, custom-logo, translation-ready
Requires at least: 4.0
Tested up to: 4.7.4
Education Corner WordPress Theme, Copyright 2017 by Themescorners (https://themescorners.com/)
Education Corner is distributed under the terms of the GNU GPL

License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Education Corner this is a child theme of Store Corner and is based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc.

=== Parent Theme ===

Business Corner
License: GNU General Public License v2+
License URI: http://www.gnu.org/licenses/gpl-2.0.html

============================================
Version 2.0.6
============================================
* Released: June 11, 2018
* Updates in degines
* Add new links

===========
ABOUT THEME
Education Corner is multipurpose responsive, clean and uniqe WordPress Theme for any Store purpose. Education Corner have easy navigate customizer by this you can easily customize theme in just few clicks. This theme gives you awesome looking website just put you contents and its ready to go. Education Corner is a awesome eCommerce theme to be make the shop site. Education Corner is an aesthetically pure and clean and highly customizable, professionally composed and very lightweight and fast loading, responsive WordPress e-commerce theme. Store Theme smoothly integrates WooCommerce, one of the best e-commerce plugin, to make professional and stunning stores. Corner Theme comes with an Awesome layout design that will instantly draw the attention of anyone who visits your website. It is designed with strong focus on usability and overall excellent user experience. It exists so that you can speedily and efficiently craft powerful e-Commerce websites across all niches and markets in a matter of minutes, without having to write a line of code. Check the demo :- http://themescorners.in/education-corner/

For free themes support, please contact us https://themescorners.com/

Education Corner ScreenShot Licence :
https://pixabay.com/en/books-stack-book-store-1163695/

Extra Images Licence :
https://pixabay.com/en/men-employees-suit-work-greeting-1979261/
https://pixabay.com/en/wood-desktop-paper-leaves-glasses-3240764/
https://pixabay.com/en/laptop-woman-education-study-young-3087585/

============================================
Version 1.0.0
============================================
* First public release

============================================
Version 1.0.1
============================================
* Fixed the issue
* Update new code
* Update New Screeen Shot 

============================================
Version 1.0.2
============================================
* Fixed the issue
* Update new code
