=== Shark Education ===

Contributors: sharkthemes
Requires at least: 4.7
Tested up to: 4.9.8
Stable tag: 1.0.0

professional and elegant blue schemed child theme

== Description ==

Shark Education is a clean and elegant dark - purple yellow schemed child theme of Uni Education. Theme Demo: http://demo.sharkthemes.com/shark-education/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0.0 - Aug 29 2018 =
* Initial release

== Credits ==

== Images Screenshot ==
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pixabay.com/en/library-books-reading-school-study-2616960/