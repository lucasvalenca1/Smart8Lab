/** Main js */
(function( $ ) {
    'use strict';
	
	// Variables and DOM Caching.
	var $body = $( 'body' );
		
	/**
	 * Test if an iOS device.
	 */
	function checkiOS() {
		return /iPad|iPhone|iPod/.test(navigator.userAgent) && ! window.MSStream;
	}
	
	/**
	 * Test if background-attachment: fixed is supported.
	 * @link http://stackoverflow.com/questions/14115080/detect-support-for-background-attachment-fixed
	 */
	function supportsFixedBackground() {
		var el = document.createElement('div'),
			isSupported;

		try {
			if ( ! ( 'backgroundAttachment' in el.style ) || checkiOS() ) {
				return false;
			}
			el.style.backgroundAttachment = 'fixed';
			isSupported = ( 'fixed' === el.style.backgroundAttachment );
			return isSupported;
		}
		catch (e) {
			return false;
		}
	}
	
	/**
	 * Test if inline SVGs are supported.
	 * @link https://github.com/Modernizr/Modernizr/
	 */
	function supportsInlineSVG() {
		var div = document.createElement( 'div' );
		div.innerHTML = '<svg/>';
		return 'http://www.w3.org/2000/svg' === ( 'undefined' !== typeof SVGRect && div.firstChild && div.firstChild.namespaceURI );
	}
	
	// Fire on document ready.
	$( document ).ready( function() {
		if ( true === supportsFixedBackground() ) {
			document.documentElement.className += ' background-fixed-supported';
		}
		if ( true === supportsInlineSVG() ) {
			document.documentElement.className = document.documentElement.className.replace( /(\s*)no-svg(\s*)/, '$1svg$2' );
		}
	});
	
	// Add header video class after the video is loaded.
	$( document ).on( 'wp-custom-header-video-loaded', function() {
		$body.addClass( 'has-header-video' );
	});


	/**
	 * Slide In plugin
	 * @author Sam Sehnert
	 * Licensed under the MIT license
	 *
	 * @desc A small plugin that checks whether elements
	 * are within the user visible viewport of a web browser.
	 */
	function imagery_slide_in() {
		$.fn.visible = function(partial) {
		    
	      var $t            = $(this),
	          $w            = $(window),
	          viewTop       = $w.scrollTop(),
	          viewBottom    = viewTop + $w.height(),
	          _top          = $t.offset().top,
	          _bottom       = _top + $t.height(),
	          compareTop    = partial === true ? _bottom : _top,
	          compareBottom = partial === true ? _top : _bottom;
		    
		  return ((compareBottom <= viewBottom) && (compareTop >= viewTop));

		};

		var win = $(window);

		var allMods = $(".post-preview");

		allMods.each(function(i, el) {
		  var el = $(el);
		  if (el.visible(true)) {
		    el.addClass("already-visible"); 
		  } 
		});

		win.scroll(function(event) {
		  
		  allMods.each(function(i, el) {
		    var el = $(el);
		    if (el.visible(true)) {
		      el.addClass("come-in"); 
		    } 
		  });
		  
		});
	} // END Slide In plugin

	/**
	 * Masonry Layout + Slide In + Jetpack Infinite Scroll.
	 */
	var $container;

	function imagery_trigger_masonry() {
		// don't proceed if $grid has not been selected
		if ( !$container ) {
			return;
		}
		// init Masonry
		$container.imagesLoaded(function(){
			$container.masonry({
				// options
				itemSelector: '.post-preview',
				columnWidth: '.post-preview',
				percentPosition: true,
				gutter: 0
			});
            $container.animate({ opacity: 1.0 }, 500 );
            //$container.addClass('loaded');
            imagery_slide_in();
		});
	}

	$(window).load(function(){
		$container = $('.post-grid'); // this is the grid container

		imagery_trigger_masonry();

		// Triggers re-layout on infinite scroll
		$( document.body ).on( 'post-load', function () {
        
			// I removed the infinite_count code
			var $selector = $('.infinite-wrap');
			var $elements = $selector.find('.post-preview');
			
			if( $selector.children().length > 0 ) {
				$container.append( $elements ).masonry( 'appended', $elements, true );
				imagery_trigger_masonry();
			}
 
		});
	});

	/**
	 * Toggled.
	 */	
    $(".search-btn").on("click", function() {
        $(this).toggleClass('active');
        $(".site-search").slideToggle("fast");
    });
	
})( jQuery );