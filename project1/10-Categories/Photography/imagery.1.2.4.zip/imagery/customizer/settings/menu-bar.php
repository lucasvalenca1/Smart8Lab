<?php
/**
 * @package Imagery
 */
function imagery_customizer_menu_bar( $options ) {
	/**
	 *	Add section.
	 *--------------------------------------------------------------*/
	$options[] = array(
		  'slug'        => 'menu_bar',
		  'opt_type'    => 'section',
		  'name'        => esc_html__( 'Menu Bar Settings', 'imagery' ),
		  'priority'    => 101,
	);

	/**
	 *	Options.
	 *--------------------------------------------------------------*/
	# Search icon.
	$options[] = array(
		  'slug'        => 'search_display',
		  'opt_type'    => 'toogle_switch',
		  'name'        => esc_html__( 'Add search icon', 'imagery' ),
		  'default'     => 0,
		  'section'     => 'menu_bar',
		  'transport'   => 'refresh',
	);


	# Background-color of submenu.
	$options[] = array(
		  'slug'        => 'submenu_bg_color',
		  'opt_type'    => 'color',
		  'name'        => esc_html__( 'Background-color of submenu', 'imagery' ),
		  'description' => esc_html__( 'This option applies to the background of the submenu when displayed on large screens.', 'imagery' ),
		  'default'     => '#ffffff',
		  'section'     => 'menu_bar',
		  'transport'   => 'refresh',
		  'js_mod'      => 'css_output',
		  'css_output'  => array(
			array(
				  'class' => '.main-navigation ul ul li',
				  'style' => 'background-color'
			)
		)
	);

	# Submenu color.
	$options[] = array(
		  'slug'        => 'submenu_color',
		  'opt_type'    => 'color',
		  'name'        => esc_html__( 'Submenu color', 'imagery' ),
		  'default'     => '#2c2c2c',
		  'section'     => 'menu_bar',
		  'transport'   => 'refresh',
		  'js_mod'      => 'css_output',
		  'css_output'  => array(
			array(
				  'class' => '.main-navigation .sub-menu a, .main-navigation .sub-menu li:hover > a',
				  'style' => 'color'
			)
		)
	);

	# Submenu color.
	$options[] = array(
		  'slug'        => 'menu_border_color',
		  'opt_type'    => 'color',
		  'name'        => esc_html__( 'Border color', 'imagery' ),
		  'default'     => '#ffffff',
		  'section'     => 'menu_bar',
		  'transport'   => 'refresh',
		  'js_mod'      => 'css_output',
		  'css_output'  => array(
			array(
				  'class' => '.main-navigation ul ul, .main-navigation ul ul li, .main-navigation li, .dropdown-toggle:after, .main-navigation .primary-menu',
				  'style' => 'border-color'
			),
			array(
				'class' => '.main-navigation ul ul:before',
				'style' => 'border-bottom-color'
			)
		)
	);

	return $options;
}
add_filter( 'imagery_settings_input', 'imagery_customizer_menu_bar' );