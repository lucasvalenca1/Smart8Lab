## Copyright and License

All code, unless otherwise noted, is licensed under the [GNU GPL](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html), version 2 or later.

2016 &copy; [Justin Tadlock](http://justintadlock.com).
