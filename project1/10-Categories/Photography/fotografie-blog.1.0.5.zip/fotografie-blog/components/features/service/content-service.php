<?php
/**
 * The template used for displaying service
 *
 * @package Fotografie Blog Pro
 */
?>

<?php
/**
 * fotografie_blog_service hook
 * @hooked fotografie_blog_service_display - 10
 */
do_action( 'fotografie_blog_service' );
