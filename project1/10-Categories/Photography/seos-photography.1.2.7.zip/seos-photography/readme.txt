=== Seos Photography ===
Contributors: SEOS - Tsvetomir Tsvetanov
Tags: photography, one-column, two-columns, left-sidebar, grid-layout, flexible-header, custom-background, custom-header, custom-menu, custom-colors, editor-style, featured-image-header, featured-images, rtl-language-support, threaded-comments, translation-ready, blog, e-commerce
Requires at least: 5.3.2
Tested up to: 5.3.2
Stable tag: 1.2.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Seos Photography is a modern responsive WordPress theme.

== Description ==
Description: Seos Photography is a modern responsive WordPress theme. The Seos Photography theme is excellent for a photography, photographer, newspaper, images, photos, publishing or other editorial websites. To learn more about the theme please go to the theme uri and read the documentation.

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= A question that someone might have =

== Changelog ==

= Version 1.2.7 January 22 2020 =
* ADDED: Tested up to: 5.3.2
* DELETE: Demo

= Version 1.2.6 August 17 2019 =
* ADDED: Menu Accessibilit
* DELETE: changelog.txt file


= Version 1.2.5 May 25 2017 =
* ADDED: HTTPS Premium Link
* ADDED: Kirki 3.0.33

= Version 1.2.4 February 14 2017 =
* FIXED: Remove Tags

= Version 1.2.3 November 17 2017 =
* FIXED: Button 2 Issue
* FIXED: Customize Issues

= Version 1.2.2 November 17 2017 =
* FIXED: KIRKI Issue

= Version 1.01 =
* Initial release

== Upgrade Notice ==

== Resources ==
* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)


* Animate.css -http://daneden.me/animate - http://opensource.org/licenses/MIT - Licensed under the MIT license
* jQuery-viewport-checker - https://github.com/dirkgroenen/jQuery-viewport-checker/blob/master/LICENSE- Licensed under the MIT license
* Fonts - https://www.google.com/fonts/specimen/Oswald - SIL Open Font License, 1.1
* Genericons - https://github.com/Automattic/Genericons/blob/master/LICENSE.txt - GNU General Public License v2.0
 
 Images used in Screenshot are licensed under Creative Commons Zero License:


 * Michal Jarmoluk - https://pixabay.com/en/photo-lens-lenses-photographer-old-256888/ - CC0 1.0 License
 * Font Awesome - http://opensource.org/licenses/mit-license.html - MIT License
   
 Unless otherwise specified, all the theme files, scripts and images
 are licensed under GNU General Public License version 2.