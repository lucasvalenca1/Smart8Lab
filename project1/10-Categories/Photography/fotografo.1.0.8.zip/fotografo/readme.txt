Fotografo WordPress Theme, Copyright 2016 Cvasnii Evghenii
Fotografo is distributed under the terms of the GNU GPL (http://www.gnu.org/licenses/gpl-3.0.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/> .

Fotografo WordPress Theme is derived from Underscores WordPress Theme, Copyright 2012-2016 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

Fotografo WordPress Theme bundles the following third-party resources:

Elegant icons font, Copyright 2017 Elegant Themes
Elegant icons are dual licensed under the GPL 2.0(https://www.gnu.org/licenses/gpl-2.0.html) and MIT (http://opensource.org/licenses/MIT)
Source: https://www.elegantthemes.com/blog/resources/elegant-icon-font

   
Twiiter Bootstrap 4, Copyright 2017 Twiiter Bootstrap
Twiiter Bootstrap 4 is licensed under MIT License. https://github.com/twbs/bootstrap/blob/master/LICENSE 
Source: http://v4-alpha.getbootstrap.com, 


Photos used in screenshot.png, Copyright (c) 2016 Michael Durana (https://unsplash.com/@basedxmichael), 
Photo licensed under Creative Commons Zero(http://creativecommons.org/publicdomain/zero/1.0/)
Source: 
https://unsplash.com/photos/mIivHg60BxM
https://unsplash.com/photos/sYegwYtIqJg


Changelog
v.1.0.7 (Feb 09, 2017) 
1. Form elements appearance improved 

v.1.0.6 (Feb 04, 2017) 
1. Post Meta appearance improved 

v.1.0.5 (Feb 04, 2017) 
1. Sidebar widgets appearance improved 

v.1.0.4 (Feb 02, 2017) 
1. Migration from Gumby Framework to Twitter Bootstrap 4 

