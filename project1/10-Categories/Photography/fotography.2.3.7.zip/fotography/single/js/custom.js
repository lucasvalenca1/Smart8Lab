jQuery(document).ready(function($) {
   	$('#light-gallery').lightGallery({
        showThumbByDefault:true,
        addClass:'showThumbByDefault'
    });
});