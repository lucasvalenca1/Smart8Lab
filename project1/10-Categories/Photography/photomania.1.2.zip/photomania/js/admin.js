( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#photomania-settings-metabox-container' ).tabs();

	});

} )( jQuery );
