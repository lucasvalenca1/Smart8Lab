=== kai === 

Contributors: Afrothemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, portfolio, blog
Requires at least: 4.7
Tested up to: 5.3
Requires PHP: 5.3.1
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

kai is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

kai is a simple WordPress theme for photographers & bloggers, use it for a travel, food or photography bloging & portfolio. kai can also be use be used for creative agency or photo studio. Try it out for free today.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

kai includes support for Infinite Scroll in Jetpack.


== Credits ==
Images used in screenshot:
License(for all of them): https://pixabay.com/en/service/terms/#usage
summer palm vacation
https://pixabay.com/illustrations/summer-palm-vacation-glases-sun-3172634/
https://pixabay.com/photos/nature-fog-landscape-sky-mountain-2466927/#
https://pixabay.com/photos/nova-scotia-duck-tolling-retriever-4259013/
https://pixabay.com/photos/gallo-farm-animal-domestic-4262773/
https://pixabay.com/photos/beach-beverage-caribbean-cocktail-84533/
https://pixabay.com/photos/rose-flower-love-romance-beautiful-729509/
https://pixabay.com/photos/van-vintage-beach-cool-wallpaper-336606/
https://pixabay.com/photos/elephant-animals-asia-large-1822636/
https://pixabay.com/photos/fitness-couple-model-sport-strong-2498657/
https://pixabay.com/photos/art-watercolor-color-colorful-2681039/
https://pixabay.com/photos/van-vintage-beach-cool-wallpaper-336606/
https://pixabay.com/photos/girl-model-fashion-woman-hair-4247592/


== Changelog ==
= 1.0.3 - 13 June 2019 =
* Mobile view
= 1.0 - 8 June 2019 =
* Menu border issue fixed
* Initial release