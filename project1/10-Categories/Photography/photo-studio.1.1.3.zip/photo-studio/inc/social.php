<?php if( ! defined( 'ABSPATH' ) ) exit;

	function photo_studio_social_section () { ?>
		
			<div <?php if(get_theme_mod( 'social_media_activate' )){ ?> style="float: none;"<?php } ?> class="fa-icons">
			

				<?php if (get_theme_mod( 'photo_studio_facebook' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'photo_studio_social_link_type' )) == "_blank"){echo esc_attr(get_theme_mod( 'photo_studio_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'photo_studio_facebook' )); ?>"><i class="fa fa-facebook-f"></i></a>
				<?php endif; ?>
							
				<?php if (get_theme_mod( 'photo_studio_twitter' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'photo_studio_social_link_type' ))){echo esc_attr(get_theme_mod( 'photo_studio_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'photo_studio_twitter' )) ?>"><i class="fa fa-twitter"></i></a>
				<?php endif; ?>
											
				<?php if (get_theme_mod( 'photo_studio_google' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'photo_studio_social_link_type' ))){echo esc_attr(get_theme_mod( 'photo_studio_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'photo_studio_google' )); ?>"><i class="fa fa-google-plus"></i></a>
				<?php endif; ?>
															
				<?php if (get_theme_mod( 'photo_studio_youtube' )) : ?>
					<a target="<?php if(esc_attr(get_theme_mod( 'photo_studio_social_link_type' ))){echo esc_attr(get_theme_mod( 'photo_studio_social_link_type' )); } else {echo "_self"; } ?>" href="<?php echo esc_url(get_theme_mod( 'photo_studio_youtube' )); ?>"><i class="fa fa-youtube"></i></a>
				<?php endif; ?>
				
			</div>
		
<?php } 


function photo_studio_social_customize_register( $wp_customize ) {  		
/***********************************************************************************
 * Social media option
***********************************************************************************/
 
		$wp_customize->add_section( 'photo_studio_social_section' , array(
			'title'       => __( 'Social Media', 'photo-studio' ),
			'description' => __( 'Social media buttons', 'photo-studio' ),
			'priority'   => 64,
		) );
		
		$wp_customize->add_setting( 'social_media_activate_header', array (
			'sanitize_callback' => 'photo_studio_sanitize_checkbox',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_activate_header', array(
			'label'    => __( 'Activate Social Icons in Header:', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'social_media_activate_header',
			'type' => 'checkbox',
		) ) );
		
		$wp_customize->add_setting( 'social_media_activate', array (
			'sanitize_callback' => 'photo_studio_sanitize_checkbox',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'social_media_activate', array(
			'label'    => __( 'Activate Social Icons in Footer:', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'social_media_activate',
			'type' => 'checkbox',
		) ) );
		
		$wp_customize->add_setting( 'photo_studio_social_link_type', array (
			'sanitize_callback' => 'photo_studio_sanitize_social',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_social_link_type', array(
			'label'    => __( 'Link Type', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'photo_studio_social_link_type',
			'type'     =>  'select',
            'choices'  => array(
				'' => esc_attr__( ' ', 'photo-studio' ),
				'_self' => esc_attr__( '_self', 'photo-studio' ),
				'_blank' => esc_attr__( '_blank', 'photo-studio' ),
            ),			
		) ) );
		
		$wp_customize->add_setting( 'social_media_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'social_media_color', array(
			'label'    => __( 'Social Icons Color:', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'social_media_color',
		) ) );
				
		$wp_customize->add_setting( 'social_media_hover_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'social_media_hover_color', array(
			'label'    => __( 'Social Icons Hover Color:', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'social_media_hover_color',
		) ) );

		$wp_customize->add_setting( 'social_media_background_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'social_media_background_color', array(
			'label'    => __( 'Social Section Background Color:', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'social_media_background_color',
		) ) );

		$wp_customize->add_setting( 'social_media_border_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'social_media_border_color', array(
			'label'    => __( 'Social Section Border Bottom Color:', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'social_media_border_color',
		) ) );
		
		$wp_customize->add_setting( 'photo_studio_facebook', array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_facebook', array(
			'label'    => __( 'Enter Facebook url', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'photo_studio_facebook',
		) ) );
	
		$wp_customize->add_setting( 'photo_studio_twitter', array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_twitter', array(
			'label'    => __( 'Enter Twitter url', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'photo_studio_twitter',
		) ) );

		$wp_customize->add_setting( 'photo_studio_google', array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_google', array(
			'label'    => __( 'Enter Google+ url', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'photo_studio_google',
		) ) );
		$wp_customize->add_setting( 'photo_studio_linkedin', array (
			'sanitize_callback' => 'esc_url_raw',
		) );

				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_youtube', array(
			'label'    => __( 'Enter Youtube url', 'photo-studio' ),
			'section'  => 'photo_studio_social_section',
			'settings' => 'photo_studio_youtube',
		) ) );
					
		$wp_customize->add_setting( 'photo_studio_vimeo', array (
			'sanitize_callback' => 'esc_url_raw',
		) );

}
add_action( 'customize_register', 'photo_studio_social_customize_register' );


/***********************************************************************************
 * Social Styles
***********************************************************************************/
	function photo_studio_social_all_css() {
    ?>
		<style type="text/css">
			<?php if(get_theme_mod('social_media_color')) { ?> .social .fa-icons i {color:<?php echo esc_attr (get_theme_mod('social_media_color')); ?> !important;} <?php } ?> 
			<?php if(get_theme_mod('social_media_hover_color')) { ?> .social .fa-icons i:hover {color:<?php echo esc_attr (get_theme_mod('social_media_hover_color')); ?> !important;} <?php } ?>
			<?php if(get_theme_mod('social_media_background_color')) { ?> .social {background:<?php echo esc_attr (get_theme_mod('social_media_background_color')); ?> !important;} <?php } ?>
			<?php if(get_theme_mod('social_media_border_color')) { ?> .social {border-bottom: 1px solid <?php echo esc_attr (get_theme_mod('social_media_border_color')); ?> !important;} <?php } ?>
			
					</style>
		
    <?php	
}
		add_action('wp_head', 'photo_studio_social_all_css');