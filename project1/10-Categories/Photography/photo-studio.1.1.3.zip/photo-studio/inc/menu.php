<?php if( ! defined( 'ABSPATH' ) ) exit;

function photo_studio_menu_customize_register( $wp_customize ) {

/***********************************************************************************
 * Menu Colors
***********************************************************************************/
 
		$wp_customize->add_section( 'photo_studio_premium_menu_options' , array(
			'title'       => __( 'Top Menu Colors', 'photo-studio' ),
			'description' => __( 'Top Menu Colors', 'photo-studio' ),
			'priority'   => 64,
		) );

/********************************************
* Menu Text Color
*********************************************/ 

		$wp_customize->add_setting('photo_studio_premium_nav_text_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_nav_text_color', array(
		'label' => __('Menu Text Color', 'photo-studio'),        
		'section' => 'photo_studio_premium_menu_options',
		'settings' => 'photo_studio_premium_nav_text_color'
		)));

		
/********************************************
* Menu Hover Color
*********************************************/ 

		$wp_customize->add_setting('photo_studio_premium_nav_hover_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_nav_hover_color', array(
		'label' => __('Menu Hover Color', 'photo-studio'),        
		'section' => 'photo_studio_premium_menu_options',
		'settings' => 'photo_studio_premium_nav_hover_color'
		)));
		

/********************************************
* Menu Background Hover
*********************************************/ 
 

		$wp_customize->add_setting('photo_studio_premium_menu_background_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_menu_background_color', array(
		'label' => __('Menu Background Color', 'photo-studio'),        
		'section' => 'photo_studio_premium_menu_options',
		'settings' => 'photo_studio_premium_menu_background_color'
		)));
					

/********************************************
* Submenu Background Hover
*********************************************/

		$wp_customize->add_setting('photo_studio_premium_sub_background_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_sub_background_color', array(
		'label' => __('Submenu Background Color', 'photo-studio'),        
		'section' => 'photo_studio_premium_menu_options',
		'settings' => 'photo_studio_premium_sub_background_color'
		)));

/********************************************
* Menu Background Hover Color
*********************************************/ 

		$wp_customize->add_setting('photo_studio_premium_menu_background_hover_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_menu_background_hover_color', array(
		'label' => __('Menu Background Hover Color', 'photo-studio'),        
		'section' => 'photo_studio_premium_menu_options',
		'settings' => 'photo_studio_premium_menu_background_hover_color'
		)));
		

/********************************************
* Submenu Border
*********************************************/ 

		$wp_customize->add_setting('photo_studio_premium_menu_border_left_color', array(         
		'default'     => '',
		'sanitize_callback' => 'sanitize_hex_color'
		)); 	

		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_menu_border_left_color', array(
		'label' => __('Border Left Color', 'photo-studio'),        
		'section' => 'photo_studio_premium_menu_options',
		'settings' => 'photo_studio_premium_menu_border_left_color'
		)));
		
}
add_action( 'customize_register', 'photo_studio_menu_customize_register' );




	function photo_studio_customize_menu_css() { ?>
		<style type="text/css">
			<?php if(get_theme_mod('photo_studio_premium_nav_text_color')) { ?>.main-navigation a,  .main-navigation li > a:after, .cart-contents .fa, #site-navigation .cart-contents .fa, .cart-contents-count, .cart-contents .amount, .cart-contents  {color:<?php echo esc_html(get_theme_mod('photo_studio_premium_nav_text_color')); ?> !important;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_premium_nav_hover_color')) { ?>.main-navigation ul li a:hover, .main-navigation li > a:hover:after {color:<?php echo esc_html(get_theme_mod('photo_studio_premium_nav_hover_color')); ?>  !important;} <?php } ?>    
			<?php if(get_theme_mod('photo_studio_premium_sub_background_color')) { ?>.main-navigation ul ul li a, .cart-contents:hover .cart-contents-count, .cart-contents:hover .amount  {background:<?php echo esc_html(get_theme_mod('photo_studio_premium_sub_background_color')); ?> !important;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_premium_menu_background_color')) { ?>.nav-center, #site-navigation, .main-navigation ul li {background-color:<?php echo esc_html(get_theme_mod('photo_studio_premium_menu_background_color')); ?> !important;} <?php } ?> 			
			<?php if(get_theme_mod('photo_studio_premium_menu_border_left_color')) { ?>.main-navigation ul ul li {border-left: 3px solid <?php echo esc_html(get_theme_mod('photo_studio_premium_menu_border_left_color')); ?> !important;} <?php } ?>
			<?php if(get_theme_mod('photo_studio_premium_menu_background_hover_color')) { ?>.main-navigation ul li:hover, .main-navigation ul ul li a:hover {background: <?php echo esc_html(get_theme_mod('photo_studio_premium_menu_background_hover_color')); ?> !important;} <?php } ?>	
		</style>
		
    <?php
}
		add_action('wp_head', 'photo_studio_customize_menu_css');