<?php
/**
 * Theme Customizer
 *
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function photo_studio_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	

/***********************************************************************************
 * Sanitize Functions
***********************************************************************************/
					
		function photo_studio_sanitize_checkbox( $input ) {
			if ( $input ) {
				return 1;
			}
			return 0;
		}
/***********************************************************************************/
		
		function photo_studio_sanitize_social( $input ) {
			$valid = array(
				'' => esc_attr__( ' ', 'photo-studio' ),
				'_self' => esc_attr__( '_self', 'photo-studio' ),
				'_blank' => esc_attr__( '_blank', 'photo-studio' ),
			);

			if ( array_key_exists( $input, $valid ) ) {
				return $input;
			} else {
				return '';
			}
		}	

/********************************************
* Search Button on Header
*********************************************/ 
		
		$wp_customize->add_section( 'photo_studio_premium_search' , array(
			'title'       => __( 'Search Button', 'photo-studio' ),
			'priority'		=> 70,
		) );
				
		$wp_customize->add_setting( 'photo_studio_home_activate_search', array (
			'sanitize_callback'	=> 'photo_studio_sanitize_checkbox',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_home_activate_search', array(
			'label'    => __( 'Search Button on Header', 'photo-studio' ),
			'section'  => 'photo_studio_premium_search',
			'settings' => 'photo_studio_home_activate_search',
			'type'     =>  'checkbox',
		) ) );		
		
/***********************************************************************************
 * Colors
***********************************************************************************/
	
		$wp_customize->add_setting( 'photo_studio_link_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'photo_studio_link_color', array(
			'label'    => __( 'Link Color:', 'photo-studio' ),
			'section'  => 'colors',
			'settings' => 'photo_studio_link_color',
		) ) );
				
	
		$wp_customize->add_setting( 'photo_studio_link_hover_color', array (
			'sanitize_callback' => 'sanitize_hex_color',
		) );
				
		$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'photo_studio_link_hover_color', array(
			'label'    => __( 'Link Hover Color:', 'photo-studio' ),
			'section'  => 'colors',
			'settings' => 'photo_studio_link_hover_color',
		) ) );
		
/***********************************************************************************
 * Contacts
***********************************************************************************/
 
		$wp_customize->add_section( 'photo_studio_contacts_header' , array(
			'title'       => __( 'Header Contacts', 'photo-studio' ),
			'priority'   => 45,
		) );
		
		$wp_customize->add_setting( 'photo_studio_contacts_header_phone', array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_contacts_header_phone', array(
			'label'    => __( 'Phone Number', 'photo-studio' ),
		'description' => __('  Add content and activate the phone.', 'photo-studio'),        
			
			'section'  => 'photo_studio_contacts_header',
			'settings' => 'photo_studio_contacts_header_phone',
			'type'     =>  'text'		
		) ) );

		
		$wp_customize->add_setting( 'photo_studio_contacts_header_address', array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_contacts_header_address', array(
			'label'    => __( 'Address', 'photo-studio' ),
		'description' => __(' Add content and activate the address.', 'photo-studio'),        
			
			'section'  => 'photo_studio_contacts_header',
			'settings' => 'photo_studio_contacts_header_address',
			'type'     =>  'text'		
		) ) );
			
		$wp_customize->add_setting( 'photo_studio_contacts_header_email', array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_contacts_header_email', array(
			'label'    => __( 'Email', 'photo-studio' ),
		'description' => __(' Add content and activate the email.', 'photo-studio'),        
			
			'section'  => 'photo_studio_contacts_header',
			'settings' => 'photo_studio_contacts_header_email',
			'type'     =>  'text'		
		) ) );
		
/********************************************
* Footer Copyright
*********************************************/ 

		$wp_customize->add_section( 'photo_studio_footer_copyright' , array(
			'title'       => __( 'Footer Copyright', 'photo-studio' ),
			'priority'		=> 99,
		) );
				
/******************************************** Footer Deactivat *********************************************/ 

		$wp_customize->add_setting( 'photo_studio_premium_copyright1', array(
			'default'			=> '',
			'sanitize_callback' => 'wp_kses'
		));
		$wp_customize->add_control(
			new WP_Customize_Control(
				$wp_customize, 'photo_studio_premium_copyright1', array(
					'label'		=> __( 'Custom Copyright Text', 'photo-studio' ),
					'section'	=> 'photo_studio_footer_copyright',
					'settings'	=> 'photo_studio_premium_copyright1',
					'type'		=> 'textarea'
				)
			)
		);			
}
add_action( 'customize_register', 'photo_studio_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function photo_studio_customize_preview_js() {
	wp_enqueue_script( 'photo_studio_customizer', get_template_directory_uri() . '/framework/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'photo_studio_customize_preview_js' );


		function photo_studio_customize_all_css() {
    ?>
		<style>
			<?php if ( (!is_front_page() or !is_home()) and get_theme_mod('custom_header_position') == "home") { ?> .site-header { display: none;} <?php } ?> 
			<?php if ( get_theme_mod('custom_header_position') == "deactivate") { ?> .site-header { display: none;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_aside_background_color')) { ?>#content aside h2 {background:<?php echo esc_attr (get_theme_mod('photo_studio_aside_background_color')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_aside_background_color1')) { ?>#content aside ul, #content .widget {background:<?php echo esc_attr (get_theme_mod('photo_studio_aside_background_color1')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_aside_title_color')) { ?>#content aside h2 {color:<?php echo esc_attr (get_theme_mod('photo_studio_aside_title_color')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_aside_link_color')) { ?>#content aside a {color:<?php echo esc_attr (get_theme_mod('photo_studio_aside_link_color')); ?>;} <?php } ?> 
			<?php if(get_theme_mod('photo_studio_aside_link_hover_color')) { ?>#content aside a:hover {color:<?php echo esc_attr (get_theme_mod('photo_studio_aside_link_hover_color')); ?>;} <?php } ?> 
			

			<?php if(get_theme_mod('photo_studio_link_color')) { ?> a { color: <?php echo get_theme_mod('photo_studio_link_color'); ?>;} <?php } ?>
			<?php if(get_theme_mod('photo_studio_link_hover_color')) { ?> a:hover { color: <?php echo get_theme_mod('photo_studio_link_hover_color'); ?>;} <?php } ?>
			
			<?php if(get_theme_mod('photo_studio_titles_setting_1')) { ?> .single-title, .sr-no-sidebar .entry-title, .full-p .entry-title { display: none !important;} <?php } ?>

		</style>
		
    <?php	
}
		add_action('wp_head', 'photo_studio_customize_all_css');
		
/**************************************
Sidebar Options
**************************************/


	function photo_studio_sidebar_width () {
		if(get_theme_mod('photo_studio_sidebar_width')) {
	
	$photo_studio_content_width = 96;
	$photo_studio_sidebar_width = esc_attr(get_theme_mod('photo_studio_sidebar_width'));
	$photo_studio_sidebar_sum = $photo_studio_content_width - $photo_studio_sidebar_width;

	?>
		<style>
			#content aside {width: <?php echo esc_attr(get_theme_mod('photo_studio_sidebar_width')); ?>% !important;}
			#content main {width: <?php echo esc_attr($photo_studio_sidebar_sum); ?>%  !important;}
		</style>
		
	<?php }
}
	add_action('wp_head','photo_studio_sidebar_width');
	

	
/*********************************************************************************************************
* Sidebar Position
**********************************************************************************************************/

	function photo_studio_sidebar(){
	$option_sidebar = get_theme_mod( 'photo_studio_sidebar_position');		
	if($option_sidebar == '2') { 
			wp_enqueue_style( 'photo-seos-right-sidebar', get_template_directory_uri() . '/css/right-sidebar.css');
		}

	$option_sidebar = get_theme_mod( 'photo_studio_sidebar_position');			
		if($option_sidebar == '3') { 
			wp_enqueue_style( 'photo-seos-no-sidebar', get_template_directory_uri() . '/css/no-sidebar.css');
		}
	}
	add_action( 'wp_enqueue_scripts', 'photo_studio_sidebar' );
	
		
		
