<?php

function photo_studio_read_more_customize_register( $wp_customize ) {					
/***********************************************************************************
 * Read More Button
***********************************************************************************/
 
		$wp_customize->add_section( 'photo_studio_premium_read_more' , array(
			'title'       => __( 'Read More Button Options', 'photo-studio' ),
			'priority'   => 94,
		) );

		
		$wp_customize->add_setting( 'photo_studio_premium_read_more_activate', array (
			'sanitize_callback' => 'photo_studio_sanitize_checkbox',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_premium_read_more_activate', array(
			'label'    => __( 'Activate Read More Button:', 'photo-studio' ),
			'section'  => 'photo_studio_premium_read_more',
			'settings' => 'photo_studio_premium_read_more_activate',
			'type' => 'checkbox',
		) ) );
		
		$wp_customize->add_setting( 'photo_studio_premium_read_more_setting', array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
				
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'photo_studio_premium_read_more_setting', array(
			'label'    => __( 'Read More Button Text:', 'photo-studio' ),
			'section'  => 'photo_studio_premium_read_more',
			'settings' => 'photo_studio_premium_read_more_setting',
			'type' => 'text',
		) ) );
		
		$wp_customize->add_setting( 'photo_studio_premium_read_more_length', array (
			'sanitize_callback' => 'absint',
		) );
				
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_premium_read_more_length', array(
			'label'    => __( 'Read More Button Length:', 'photo-studio' ),
			'section'  => 'photo_studio_premium_read_more',
			'settings' => 'photo_studio_premium_read_more_length',
			'type' => 'number',
			'input_attrs'     => array(
				'min'  => 8,
				'max'  => 200,
				'step' => 1,
				),					
		) ) );

		$wp_customize->add_setting('photo_studio_premium_read_more_color', array(        
  	      'default' => ' ',
		  'sanitize_callback' => 'sanitize_hex_color'
		));  
	
		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_read_more_color', array(
		'label' => __('Read More Button Color', 'photo-studio'),       
  	      'section' => 'photo_studio_premium_read_more',
  	      'settings' => 'photo_studio_premium_read_more_color'
		)));
		
		$wp_customize->add_setting('photo_studio_premium_read_more_hover_color', array(        
  	      'default' => ' ',
		  'sanitize_callback' => 'sanitize_hex_color'
		));  
	
		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_read_more_hover_color', array(
		'label' => __('Read More Button Hover Color', 'photo-studio'),       
  	      'section' => 'photo_studio_premium_read_more',
  	      'settings' => 'photo_studio_premium_read_more_hover_color'
		)));
				
		$wp_customize->add_setting('photo_studio_premium_read_more_background_color', array(        
  	      'default' => '#dd3333',
		  'sanitize_callback' => 'sanitize_hex_color'
		));  
	
		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_read_more_background_color', array(
		'label' => __('Read More Button Background Color', 'photo-studio'),       
  	      'section' => 'photo_studio_premium_read_more',
  	      'settings' => 'photo_studio_premium_read_more_background_color'
		)));
						
		$wp_customize->add_setting('photo_studio_premium_read_more_background_hover_color', array(        
  	      'default' => '#333333',
		  'sanitize_callback' => 'sanitize_hex_color'
		));  
	
		$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'photo_studio_premium_read_more_background_hover_color', array(
		'label' => __('Read More Button Background Hover Color', 'photo-studio'),       
  	      'section' => 'photo_studio_premium_read_more',
  	      'settings' => 'photo_studio_premium_read_more_background_hover_color'
		)));
		
}
add_action( 'customize_register', 'photo_studio_read_more_customize_register' );


/*********************************************************************************************************
* Excerpt
**********************************************************************************************************/

	function photo_studio_premium_excerpt_more( $more ) {
		if (get_theme_mod('photo_studio_premium_read_more_activate')) { 

			return '<p class="link-more"><a class="read-more" href="'. get_permalink( get_the_ID() ) . '">' . photo_studio_premium_return_read_more_text (). '</a></p>';
		}
	}
	add_filter( 'excerpt_more', 'photo_studio_premium_excerpt_more' );	
	
		
	function customize_premium_custom_excerpt_length( $length ) {
		if (get_theme_mod('photo_studio_premium_read_more_length')) {
			return get_theme_mod('photo_studio_premium_read_more_length');
		}
		else return 42;
	}
	
	add_filter( 'excerpt_length', 'customize_premium_custom_excerpt_length', 999 );
	
	
	function photo_studio_premium_return_read_more_text () {
		if (get_theme_mod('photo_studio_premium_read_more_setting')) {	 
			return get_theme_mod('photo_studio_premium_read_more_setting');
		} 
		return "Read More";
	}	
	
/***********************************************************************************
 * Read More Styles
***********************************************************************************/

		function photo_studio_read_more_all_css() {
    ?>
		<style type="text/css">
			<?php if(!get_theme_mod('pagination_slider')) { ?> .camera_thumbs {display: none !important;} <?php } ?>
			
			<?php if(get_theme_mod('photo_studio_premium_read_more_color')) { ?> .read-more, .read-slide, .link-more a { color: <?php echo get_theme_mod('photo_studio_premium_read_more_color'); ?> !important;} <?php } ?>		<?php if(get_theme_mod('photo_studio_premium_read_more_hover_color')) { ?> .read-more:hover, .read-slide:hover, .link-more a:hover { color: <?php echo get_theme_mod('photo_studio_premium_read_more_hover_color'); ?> !important;} <?php } ?>
			<?php if(get_theme_mod('photo_studio_premium_read_more_background_color')) { ?> .read-more { background: <?php echo get_theme_mod('photo_studio_premium_read_more_background_color'); ?> !important;} <?php } ?>
			<?php if(get_theme_mod('photo_studio_premium_read_more_background_hover_color')) { ?> .read-more:hover { background: <?php echo get_theme_mod('photo_studio_premium_read_more_background_hover_color'); ?> !important;} <?php } ?>	
		</style>
		
    <?php	
}
		add_action('wp_head', 'photo_studio_read_more_all_css');		