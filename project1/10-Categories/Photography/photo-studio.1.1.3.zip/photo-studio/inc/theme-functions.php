<?php if( ! defined( 'ABSPATH' ) ) exit;
/**
 * Functions and definitions
 */
/*******************************
Basic
********************************/

if ( ! function_exists( 'photo_studio_setup' ) ) :

function photo_studio_setup() {

	load_theme_textdomain( 'photo-studio', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'woocommerce' );
	
	add_theme_support( 'custom-logo', array(
		'height'      => 50,
		'width'       => 300,
		'flex-height' => true,
		'flex-width'  => true,
		'header-text' => array( 'site-title', 'site-description' ),
	) );
	
	register_nav_menu('primary', esc_html__( 'Primary', 'photo-studio' ) );
	register_nav_menu('left', esc_html__( 'Left', 'photo-studio' ) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'photo_studio_custom_background_args', array(
		'default-color' => '#ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'photo_studio_setup' );

/*******************************
$content_width
********************************/

function photo_studio_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'photo_studio_content_width', 840 );
}
add_action( 'after_setup_theme', 'photo_studio_content_width', 0 );


/*******************************
* Register widget area.
********************************/


	function photo_studio_widgets_init() {
		register_sidebar( array(
			'name'          => esc_html__( 'Sidebar', 'photo-studio' ),
			'id'            => 'sidebar-1',
			'description'   => esc_html__( 'Add widgets here.', 'photo-studio' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		) );		
}
add_action( 'widgets_init', 'photo_studio_widgets_init' );
	
/*******************************
* Enqueue scripts and styles.
********************************/
 
function photo_studio_scripts() {

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'photo-style', get_stylesheet_uri());
		wp_enqueue_style( 'animate', get_template_directory_uri() . '/framework/css/animate.css');
		wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/css/font-awesome.css', array(), '4.7.0'  );
		wp_enqueue_style( 'genericons', get_template_directory_uri() . '/framework/genericons/genericons.css', array(), '3.4.1' );	
		wp_enqueue_style( 'photo-woocommerce', get_template_directory_uri() . '/inc/woocommerce/woo-css.css' );
		wp_enqueue_style( 'photo-font', '//fonts.googleapis.com/css?family=Oswald' );
		wp_enqueue_style( 'photo-font', '//fonts.googleapis.com/css?family=Roboto' );

		wp_enqueue_script( 'photo-navigation', get_template_directory_uri() . '/framework/js/navigation.js', array(), '20120206', true );
		wp_enqueue_script( 'photo-skip-link-focus-fix', get_template_directory_uri() . '/framework/js/skip-link-focus-fix.js', array(), '20130115', true );
		wp_enqueue_script( 'photo-left-menu', get_template_directory_uri() . '/framework/js/left-menu.js', array(), '20130116', true );
		//wp_enqueue_script( 'photo-aniview', get_template_directory_uri() . '/framework/js/jquery.aniview.js', array(), '2014416', true );

		if ( is_singular() && wp_attachment_is_image() ) {
			wp_enqueue_script( 'photo-keyboard-image-navigation', get_template_directory_uri() . '/framework/js/keyboard-image-navigation.js', array( 'jquery' ), '20141104' );
		}
		
		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}
}

add_action( 'wp_enqueue_scripts', 'photo_studio_scripts' );


function photo_studio_admin_scripts() {
	
		wp_enqueue_style( 'photo-seos-admin', get_template_directory_uri() . '/inc/css/admin.css');
}		
add_action( 'admin_enqueue_scripts', 'photo_studio_admin_scripts' );


/*******************************
* Includes.
*******************************/

	require get_template_directory() . '/inc/template-tags.php';
	require get_template_directory() . '/inc/extras.php';
	require get_template_directory() . '/inc/customizer.php';
	require get_template_directory() . '/inc/jetpack.php';
	require get_template_directory() . '/inc/custom-header.php';
	require get_template_directory() . '/inc/woocommerce/woo-functions.php';
	require get_template_directory() . '/inc/social.php';
	require get_template_directory() . '/framework/js/viewportchecker.php';
	require get_template_directory() . '/inc/menu.php';
	require get_template_directory() . '/inc/read-more.php';
	require get_template_directory() . '/inc/home-images/images-home-page.php';
	require get_template_directory() . '/inc/pro/pro.php';

	
		
/* ----------------------------------------------------------------------
Hide the Sidebar
---------------------------------------------------------------------- */

	function photo_studio_active_sidebar () { 
	if ( ! is_active_sidebar('sidebar-1') and !get_theme_mod('photo_studio_home_activate_recent')  ) { ?>
		<style> #content main{float: none; width: 100%; padding: 0;}</style>
	<?php }
	}
	
	add_action('wp_head','photo_studio_active_sidebar');
