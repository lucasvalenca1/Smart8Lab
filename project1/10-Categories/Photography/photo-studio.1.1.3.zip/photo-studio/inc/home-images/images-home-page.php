<?php if( ! defined( 'ABSPATH' ) ) exit;

/*******************************
* Enqueue scripts and styles.
********************************/
 
function photo_studio_home_images_scripts() {
		wp_enqueue_style( 'photo-home-images', get_template_directory_uri() . '/inc/home-images/home-page-images.css', array(), '4.7.0'  );
}

add_action( 'wp_enqueue_scripts', 'photo_studio_home_images_scripts' );


function photo_studio_home_images_customize_register( $wp_customize ) {
	
/************************** Home Page Images ******************************/

	$wp_customize->add_panel( 'photo_studio_home_images_panel' , array(
		'title'       => __( 'Home Page Images', 'photo-studio' ),
		'priority'		=> 2,
	) );

	for($photo=1;$photo<=2;$photo++) {		
		$wp_customize->add_section( 'photo_studio_home_images'.$photo , array(
			'title'       => __( 'Image'.$photo , 'photo-studio' ),
			'priority'		=> 2,
			'panel'		=> 'photo_studio_home_images_panel',
		) );
		
		$wp_customize->add_setting( 'photo_studio_home_images_image'.$photo, array (
			'sanitize_callback' => 'esc_url_raw',
		) );
			
		$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'photo_studio_home_images_image'.$photo, array(
			'label'    => __( 'Image ', 'photo-studio' ),
			'section'  => 'photo_studio_home_images'.$photo,
			'settings' => 'photo_studio_home_images_image'.$photo,
		) ) );

		$wp_customize->add_setting( 'photo_studio_home_images_title'.$photo, array (
			'sanitize_callback' => 'sanitize_text_field',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_home_images_title'.$photo, array(
			'label'    => __( 'Image Title', 'photo-studio' ),
			'section'  => 'photo_studio_home_images'.$photo,
			'settings' => 'photo_studio_home_images_title'.$photo,
			'type' => 'text',
		) ) );
		
		$wp_customize->add_setting( 'photo_studio_home_images_url'.$photo, array (
			'sanitize_callback' => 'esc_url_raw',
		) );
		
		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'photo_studio_home_images_url'.$photo, array(
			'label'    => __( 'Image URL', 'photo-studio' ),
			'section'  => 'photo_studio_home_images'.$photo,
			'settings' => 'photo_studio_home_images_url'.$photo,
			'type' => 'url',
		) ) );			
	}
}
add_action( 'customize_register', 'photo_studio_home_images_customize_register' );	
	
function photo_studio_home_page () { ?>

	<div class="my-home-photos">

		<?php for($photo=1;$photo<=2;$photo++) { 

			if(get_theme_mod('photo_studio_home_images_image'.$photo)) { ?>

				<a href="<?php echo get_theme_mod('photo_studio_home_images_url'.$photo); ?>">
					<div class="photos-img" style="background-image: url('<?php echo get_theme_mod('photo_studio_home_images_image'.$photo); ?>')" alt="photo"></div>
						<div class="my-photos-title"><?php echo get_theme_mod('photo_studio_home_images_title'.$photo);?></div>
					<div class="my-photo-background"></div>
				</a>

			<?php } 
		} ?>

	</div>

<?php }
