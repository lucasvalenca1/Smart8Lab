<?php
/**
 * The Header template
 */ 
 ?>
<!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) & !(IE 8)]><!-->
<html itemscope itemtype="http://schema.org/WebPage" <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width" />
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">	
	<?php endif; ?>
	<?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'photo-studio' ); ?></a>

		<?php if (get_theme_mod( 'social_media_activate_header' ) or get_theme_mod('photo_studio_contacts_header_address') or get_theme_mod('photo_studio_contacts_header_phone') or get_theme_mod('photo_studio_contacts_header_email')) { ?>
		
		<div class="social">
				<div class="fa-icons">
					<?php if (esc_attr(get_theme_mod( 'social_media_activate_header' ))) {echo photo_studio_social_section ();} ?>		

				</div>
				<div class="soc-right">
						<?php if (esc_attr(get_theme_mod('photo_studio_contacts_header_address'))) { ?><span itemprop="address" itemscope itemtype="http://schema.org/PostalAddress"><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo esc_attr(get_theme_mod('photo_studio_contacts_header_address')); ?></span><?php } ?>
						<?php if (esc_attr(get_theme_mod('photo_studio_contacts_header_phone'))) { ?><span itemprop="telephone"><i class="fa fa-volume-control-phone" aria-hidden="true"></i> <?php echo esc_attr(get_theme_mod('photo_studio_contacts_header_phone')); ?></span><?php } ?>
						<?php if (esc_attr(get_theme_mod('photo_studio_contacts_header_email'))) { ?>
						<span>
							<i class="fa fa-envelope" aria-hidden="true"></i> 
							<a itemprop="email" href="mailto:<?php echo esc_attr(get_theme_mod('photo_studio_contacts_header_email')); ?>"><?php echo esc_attr(get_theme_mod('photo_studio_contacts_header_email')); ?></a>
						</span><?php } ?>
				</div>
				<div class="clear"></div>
		</div>	 
		<?php } ?>

	<div class="nav-center">
		<span class="photo-logo" itemprop="logo" itemscope itemtype="http://schema.org/ImageObject"><?php the_custom_logo(); ?></span><div class="clear"></div>
		<nav id="site-navigation" class="main-navigation">
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">	
				<a href="#" id="menu-icon">	
					<span class="menu-button"> </span>
					<span class="menu-button"> </span>
					<span class="menu-button"> </span>
				</a>
			</button>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
		</nav><!-- #site-navigation -->
	
		
	</div>		
	<?php if(get_theme_mod('photo_studio_home_activate_breadcrumb')and ( !is_front_page() || !is_home())) { ?>
		<div class="breadcrumb" itemprop="breadcrumb"> <!-- breadcrumb -->
			<ul itemscope="" itemtype="http://schema.org/BreadcrumbList">
				<meta name="numberOfItems" content="2">
				<meta name="itemListOrder" content="Ascending">
				<li class="trail-item trail-begin" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
						<span itemprop="name">
							<span class="dashicons dashicons-admin-home"></span>
							<span style=" display: none;"><?php echo get_bloginfo( 'name' ); ?></span>
						</span>
					</a>
					<meta content="1" itemprop="position">
				</li>
				<li class="trail-item trail-end" itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
					<span itemprop="name"><?php the_title(); ?></span>
					<meta content="2" itemprop="position">
				</li>
			</ul>
		</div> <!-- breadcrumb -->	
	<?php } ?>	
	<?php if ( has_nav_menu( 'left' ) ) { ?>
	<div class="left-menu">
		<div id="mySidenav" class="sidenav">
		  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<?php wp_nav_menu( array( 'theme_location' => 'left', 'menu_id' => 'left-menu' ) ); ?>
		</div>
		<span style="font-size: 30px; background: none; cursor:pointer; display: inline-block;padding: 0 10px 2px 10px;" onclick="openNav()">&#9776;</span>
	</div>	
	<?php } ?>
	
	<header id="masthead" class="site-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader">
	
<?php // Deactivate Header Image ?>
		
		<?php if (get_theme_mod('custom_header_position') != "deactivate") { ?>
		
	
<?php // All Pages Header Image  ?>	
		<?php if ( get_theme_mod('custom_header_position') == "all" ) : ?>

	
		<?php if (has_header_image() !=""){ ?><img alt="Header Image" class="header-img" src="<?php header_image(); ?>" /><?php } ?>
	
			<div class="site-branding">
				<div class="dotted">
					
						<?php if ( is_front_page() && is_home() ) : ?>
							<h1 class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</h1>
						<?php else : ?>
							<p class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</p>
						<?php endif;

						$ap_description = esc_html (get_bloginfo( 'description', 'display' ));
						if ( $ap_description || is_customize_preview() ) : ?>
						<p class="site-description aniview" data-av-animation="bounceInRight" <?php if ( is_front_page() or is_home() ) { ?>itemprop="headline" <?php } ?>>
							<span class="ml2"><?php echo $ap_description; ?></span>
						</p>
						<?php if(get_theme_mod('photo_studio_home_activate_search')) { get_search_form(); } ?>					
				<?php endif;  ?>			
				
				</div><!-- .site-branding -->
			</div>	
		
		
		<?php endif;  ?>

		<?php // All Pages Without Home Page  ?>		
	
		<?php if ( get_theme_mod('custom_header_position') == "without" ) : ?>
		
		<?php if (!is_front_page() or !is_home()) { ?>

	
		<?php if (has_header_image() !=""){ ?><img alt="Header Image" class="header-img" src="<?php header_image(); ?>" /><?php } ?>
	
			<div class="site-branding">
				<div class="dotted">
					
						<?php if ( is_front_page() && is_home() ) : ?>
							<h1 class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</h1>
						<?php else : ?>
							<p class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</p>
						<?php endif;

						$ap_description = esc_html (get_bloginfo( 'description', 'display' ));
						if ( $ap_description || is_customize_preview() ) : ?>
						<p class="site-description aniview" data-av-animation="bounceInRight" <?php if ( is_front_page() or is_home() ) { ?>itemprop="headline" <?php } ?>>
							<span class="ml2"><?php echo $ap_description; ?></span>
						</p>
						<?php if(get_theme_mod('photo_studio_home_activate_search')) { get_search_form(); } ?>					
				<?php endif; ?>			
				
				</div><!-- .site-branding -->
			</div>	
		
		
		<?php } endif;  ?>
		
		<?php // Home Page Header Image  ?>			
		<?php if ( ( is_front_page() || is_home() ) and get_theme_mod('custom_header_position') == "home" ) { ?>

		<?php if (has_header_image() !=""){ ?><img alt="Header Image" class="header-img" src="<?php header_image(); ?>" /><?php } ?>
		
					
			<div class="site-branding">
				<div class="dotted">

						<?php if ( is_front_page() && is_home() ) : ?>
							<h1 class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</h1>
						<?php else : ?>
							<p class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</p>
						<?php endif;

						$ap_description = esc_html (get_bloginfo( 'description', 'display' ));
						if ( $ap_description || is_customize_preview() ) : ?>
						<p class="site-description aniview" data-av-animation="bounceInRight" <?php if ( is_front_page() or is_home() ) { ?>itemprop="headline" <?php } ?>>
							<span class="ml2"><?php echo $ap_description; ?></span>
						</p>
						<?php if(get_theme_mod('photo_studio_home_activate_search')) { get_search_form(); } ?>
				</div>
				<?php endif; ?>		
				</div>
			</div><!-- .site-branding -->
		
	<?php } 

	} ?>
	
		<?php // Default Header Image ?>
		
		<?php if (  has_header_image() !="") { ?>
		
		<?php if ( get_theme_mod('custom_header_position') != "all") { ?>

		<?php if ( get_theme_mod('custom_header_position') != "home" ) { ?>
		
		<?php if ( get_theme_mod('custom_header_position') != "without" ) { ?>
		
			<?php if (has_header_image() !=""){ ?><img alt="Header Image" class="header-img" src="<?php echo esc_url(get_template_directory_uri()). "/framework/images/header.jpg"; ?>" /><?php } ?>
			<div class="site-branding">
				<div class="dotted">
					
						<?php if ( is_front_page() && is_home() ) : ?>
							<h1 class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</h1>
						<?php else : ?>
							<p class="site-title aniview" itemscope itemtype="http://schema.org/Brand">
								<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><span class="ml2"><?php bloginfo( 'name' ); ?></span></a>
							</p>
						<?php endif;

						$ap_description = esc_html (get_bloginfo( 'description', 'display' ));
						if ( $ap_description || is_customize_preview() ) : ?>
						<p class="site-description aniview" data-av-animation="bounceInRight" <?php if ( is_front_page() or is_home() ) { ?>itemprop="headline" <?php } ?>>
							<span class="ml2"><?php echo $ap_description; ?></span>
						</p>
						<?php if(get_theme_mod('photo_studio_home_activate_search')) { get_search_form(); } ?>
						<?php if(get_theme_mod('photo_studio_home_face_title')) { ?><div class="photo-autor"><?php echo get_theme_mod('photo_studio_home_face_title'); ?></div><?php } ?>
						<?php if(get_theme_mod('photo_studio_home_face')) { ?><img class="header-face" src="<?php echo get_theme_mod('photo_studio_home_face'); ?>" /><?php } ?>							
				<?php endif; ?>			
				</div>
			</div><!-- .site-branding -->

		<?php } } } } ?>

	</header><!-- #masthead -->
	<div class="clear"></div>
		<?php if  ( is_home() or is_front_page() ) {  echo photo_studio_home_page (); } ?>
	<div class="clear"></div>
	<div id="content" class="site-content">