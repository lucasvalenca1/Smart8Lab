<?php if( ! defined( 'ABSPATH' ) ) exit;

function photo_studio_premium_animation_classes () { ?>
	<script type="text/javascript">
		
		jQuery(document).ready(function() {
				jQuery('.my-photos-title').addClass("hidden").viewportChecker({
					classToAdd: 'animated zoomIn',
					offset: 0  
				   }); 
		});
	
	</script>
<?php } 

add_action('wp_footer', 'photo_studio_premium_animation_classes');				   
				   
		
		