<?php
/**
 * The template used for displaying credits
 *
 * @package Shutter_Up
 */
?>

<?php
/**
 * shutter_up_credits hook
 * @hooked shutter_up_footer_content - 10
 */
do_action( 'shutter_up_credits' );
