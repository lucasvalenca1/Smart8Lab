<div class="no-content">
	<div class="post-inside">
	<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for.', 'tography-lite' ); ?></p>
	</div>
</div>