<div id="container" class="container">
	<section id="main" role="main" class="row">
		<div class="col-md-12">
			<div class="page_title_wrap">
				<h1 class="page_title"><?php single_post_title(); ?></h1>
			</div><!-- /page_title_wrap -->
		</div><!-- /col-md-12 -->
		
		<div id="content" class="col-md-9">

