        	</div><!-- /content -->

        	<?php get_sidebar(); ?>

        	<div class="clearfix"></div>
        </section><!--/row -->

        <div class="clearfix"></div>
    </div><!-- /#container -->