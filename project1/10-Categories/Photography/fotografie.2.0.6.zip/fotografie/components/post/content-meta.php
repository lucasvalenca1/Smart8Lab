<?php
/**
 * Entry meta display
 *
 * @package Fotografie
 */

?>

<footer class="entry-meta">
	<?php fotografie_posted_on(); ?>
</footer><!-- .entry-meta -->
