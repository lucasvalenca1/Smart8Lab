;(function($){ 
	$('.instagram-size-thumbnail').addClass('instagram-photo');
})(jQuery);
