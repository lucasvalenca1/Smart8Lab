<?php
/**
 * The keenshot sidebar section
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage keenshot
 * @since 1.0.0
 */

  /**
   * Keenshot after single content hook
   */

do_action('keenshot_sidebar');
