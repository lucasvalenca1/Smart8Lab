<?php
/**
 * Keenshot functions and definitions
 *
 * @link 
 *
 * @package Keenshot
 * 
 * @hoocked Keenshot Banner Section
 */

 do_action( 'keenshot_comment_navigation' ); 
