<?php
/**
 * Keenshot functions and definitions
 *
 * @link 
 *
 * @package Keenshot
 * 
 * @hoocked Keenshot Custom Media Content Section
 */

do_action('keenshot_taxonomy_content'); 