=== Fotocover ===

Contributors:       mysterythemes
Requires at least:  WordPress 4.0
Tested up to:       WordPress 4.9
Requires PHP:       5.6
Stable tag:         1.0.0
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html
Tags:               photography, blog, portfolio, grid-layout, one-column, two-columns, right-sidebar, left-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, footer-widgets, theme-options, translation-ready


== Description ==

Fotocover is child theme of Fotogenic Free WordPress Theme crafted for your blog, gallery or photography collection. It has a unique, modern, light and clean design which will make your website look awesome. It is completely built on Customizer which allows you to customize most of the theme settings easily with live previews. This theme comes with 3 different archive layouts and other exciting features that allow you to customize the theme easily without coding knowledge.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Fotogenic is distributed under the terms of the GNU GPL

Fotocover WordPress Theme is child theme of Fotogenic Theme, Copyright 2019 Mystery Theme.
Fotocover is distributed under the terms of the GNU GPL

Fotocover bundles the following third-party resources:

	Screenshot Images
    Licenses: CCO Public Domain
    https://pxhere.com/en/photo/103316

== Changelog ==

= 1.0.0 =
	* Submit on wp.org trac.