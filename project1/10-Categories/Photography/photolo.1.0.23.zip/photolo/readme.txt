=== photolo ===

Contributors: softnweb.com
Tags: photography, custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready

Requires at least: 4.5
Tested up to: 4.8
Stable tag: 1.0.0
License: GNU General Public License GPLv3 or later
License URI: LICENSE

A starter theme called photolo.

== Description ==

An elegant & fully featured Photography theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== License ==
- All images and bundled resources included in this theme are GPL3.
- The Theme itself is GPL3.

== Copyright ==

photolo WordPress Theme, Copyright 2018 softnweb
It is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.


== Frequently Asked Questions ==

= Does this theme support any plugins? =


== Changelog ==

= 1.0.19 - May 1 2018 =
* Add new Blog Post Layout
* Limit text for blog Heading 
* remove default blog image
* Add Instagram widget area

= 1.0.20 - May 9 2018 =
* bug fix for fancybox link
* Spelling mistake Mesonry to Masonry

= 1.0.21 - May 17 2018 =
* fancybox add next, pre arrow and caption for each gallery
* Add new optopn Blogs Page Columns

= 1.0.22 - DEC 27 2019 =
* Disable hove in mobile
* Change blog page column to 1 in Mobile view

= 1.0.23 - JAN 8 2020 =
* Add custom option for Display Title and Category in Customizing > Blogs Page Layout Settings

* Initial release

== photolo bundles the following third-party resources:==

Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc.
Licenses: [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
Source: https://underscores.me/

normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal
License: MIT
Source: https://necolas.github.io/normalize.css/

Bootstrap v4.0.0-beta.3 
License: MIT
Source: https://getbootstrap.com

Masonry PACKAGED v4.2.1
License: MIT
Source: https://masonry.desandro.com

Packery PACKAGED v2.1.1
License: MIT
Source: http://packery.metafizzy.co

imagesLoaded PACKAGED v4.1.4 
License: MIT
Source: http://packery.metafizzy.co

bxSlider v4.2.12
License: MIT
Source: http://bxslider.com

bxSlider v4.2.12
License: MIT
Source: http://bxslider.com

fancyBox
License: GPLv3 for open source use
Source: http://fancyapps.com/fancybox/

IcoMoon
License: CC BY 4.0 or GPL
Source: https://icomoon.io/


