<?php
/**
 * @package clickpic
 */
?>
<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>
         <?php dynamic_sidebar('sidebar-1');?>
<?php endif; ?>	
