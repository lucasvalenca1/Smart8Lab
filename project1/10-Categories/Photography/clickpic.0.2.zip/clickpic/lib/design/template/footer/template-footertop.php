<footer class="footer"> 
    <div class="container">
      <div class="row"><!-- row -->
            
                <div class="col-lg-4 col-md-4"><!-- widgets column left -->
                  <?php if ( ! dynamic_sidebar( 'footer-1' ) ) : ?>
                    <?php endif; // end footer widget area ?>  
                </div><!-- widgets column left end -->
                
                
                
                <div class="col-lg-4 col-md-4"><!-- widgets column left -->
                  <?php if ( ! dynamic_sidebar( 'footer-2' ) ) : ?>
                    <?php endif; // end footer widget area ?>  
              </div><!-- widgets column left end -->
                
                
                
                <div class="col-lg-4 col-md-4"><!-- widgets column left -->
                  <?php if ( ! dynamic_sidebar( 'footer-3' ) ) : ?>
                    <?php endif; // end footer widget area ?>  
              </div><!-- widgets column left end -->
          </div>
    </div>
</footer>