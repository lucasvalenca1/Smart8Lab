<?php   
/**
 * @package clickpic
 */
?>
<?php
if ( ! isset( $content_width ) ) $content_width = 900;
add_image_size( 'clickpic-home-banner-size', 1600, 750,true );
add_image_size( 'clickpic-home-box-size', 400, 250,true );
add_image_size( 'clickpic-inner-page-banner', 1600, 550,true );
add_image_size( 'clickpic-welcomehome-banner', 583, "",true ); 
?>