<?php   
/**
 * @package clickpic
 */
?>
<?php
require_once get_template_directory()."/lib/require/customizer/clickpic_customizer.php";
require_once get_template_directory()."/lib/clickpic_custom_jsstyle.php";
require_once get_template_directory()."/lib/clickpic_custom_themesupport.php";
require_once get_template_directory()."/lib/clickpic_custom_banners.php";
require_once get_template_directory()."/lib/clickpic_custom_widgets.php";
require_once get_template_directory()."/lib/clickpic_custom_content_excerpt.php";