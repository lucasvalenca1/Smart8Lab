<?php
/**
 * The SVG arrow for the projects grid - mobile devices.
 *
 * @see        https://pixelgrade.com
 * @author     Pixelgrade
 * @package    Noah Lite
 * @version    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?><svg width="19px" height="17px" viewBox="0 0 19 17" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <g id="group" stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd">
        <rect id="line1" transform="translate(12.703301, 5.303301) scale(-1, 1) rotate(-315.000000) translate(-12.703301, -5.303301) " x="6.70330095" y="3.80330086" width="12" height="3"></rect>
        <rect id="line2" transform="translate(6.353301, 5.303301) rotate(-315.000000) translate(-6.353301, -5.303301) " x="0.353300811" y="3.80330086" width="12" height="3"></rect>
        <rect id="line3" x="0" y="14" width="19" height="3"></rect>
    </g>
</svg>
