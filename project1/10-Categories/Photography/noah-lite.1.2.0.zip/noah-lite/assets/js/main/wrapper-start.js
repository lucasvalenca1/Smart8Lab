(function( $, window, document, undefined ) {
