<?php

defined( 'ABSPATH' ) || exit;

require get_parent_theme_file_path() . '/inc/widget/recent_post.php';
