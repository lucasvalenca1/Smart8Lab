jQuery(document).ready(function(){jQuery("#catch-store-ui-tabs").tabs()});
