<?php
/**
 * The template used for displaying credits
 *
 * @package Catch_Store
 */
?>

<?php
/**
 * catch_store_credits hook
 * @hooked catch_store_footer_content - 10
 */
do_action( 'catch_store_credits' );
