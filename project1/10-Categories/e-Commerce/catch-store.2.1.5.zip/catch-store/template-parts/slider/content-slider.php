<?php
/**
 * The template used for displaying slider
 *
 * @package Catch_Store
 */
?>

<?php
/**
 * catch_store_slider hook
 * @hooked catch_store_featured_slider - 10
 */
do_action( 'catch_store_slider' );
