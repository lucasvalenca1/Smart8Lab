<?php
/**
 *
 * @author      CodeGearThemes
 * @category    WordPress
 * @package     Acoustics
 * @version     1.0.0
 *
 * @see  acoustics_footer_social()
 */
if ( function_exists( 'acoustics_footer_social' ) ):
	add_action( 'footer_social', 'acoustics_footer_social', 10 );
endif;
