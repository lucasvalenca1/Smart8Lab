<?php
/**
 * Template part for topbar
 *
 * @package yith-proteo
 */
?>
<div id="topbar">
	<div class="container">
		<?php dynamic_sidebar( 'topbar-sidebar' ); ?>
	</div>
</div>
