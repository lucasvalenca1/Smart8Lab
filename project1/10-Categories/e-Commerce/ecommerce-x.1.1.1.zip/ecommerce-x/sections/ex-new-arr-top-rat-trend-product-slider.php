  <?php $ecommerce_x_frontpage_new_arrival_top_rated_trending_product_option = get_theme_mod( 'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_option', 'show' );
  if( $ecommerce_x_frontpage_new_arrival_top_rated_trending_product_option == 'show' ) :?>
  	<section class="new-arrival b-new-arrival">
  		<div class="container">
  			<div class="row">
  				<?php  get_template_part('template-parts/frontNewTopTrendProductSlider/slider','new-arrivals');   
  				get_template_part('template-parts/frontNewTopTrendProductSlider/slider','top-rated-products');   
  				get_template_part('template-parts/frontNewTopTrendProductSlider/slider','trending-products');   
  				?>
  			</div>
  		</div>
  	</section>
  	<?php endif;?>