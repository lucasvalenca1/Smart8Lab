 <?php $ecommerce_x_frontpage_service_option = get_theme_mod( 'ecommerce_x_frontpage_service_option', 'show' );
 if( $ecommerce_x_frontpage_service_option == 'show' ) :?>
   <section class="services">
    <div class="container-fluid">
      <div class="row justify-content-center">
       <?php
       $service_catId = get_theme_mod( 'ecommerce_x_frontpage_service_category');
       $service_number = get_theme_mod( 'ecommerce_x_frontpage_service_items_number');

       $args = array(
        'post_type' => 'post',
        'posts_per_page' => $service_number,
        'post_status' => 'publish',
        'paged' => 1,
        'cat' => $service_catId,

      );
       $serviceloop = new WP_Query($args);
       if ( $serviceloop->have_posts() ) :
        while ($serviceloop->have_posts()) : $serviceloop->the_post(); 
          ?>
          <div class="col-lg-4 col-sm-6">
            <div class="service-holder">
              <?php if(has_post_thumbnail()): ?>
                <div class="icon-holder">
                 <?php the_post_thumbnail('ecommerce-x-service-33-*-28'); ?>
               </div>
             <?php endif;?>
             <div class="text-holder">
              <h6><?php the_title();?></h6>
              <?php the_content();?>
            </div>
          </div>
        </div>
      <?php endwhile;
      wp_reset_postdata();
    endif;
    ?>
  </div>
</div>
</section>
<?php endif;?>