 <?php $ecommerce_x_frontpage_slider_option = get_theme_mod( 'ecommerce_x_frontpage_slider_option', 'show' );
 if( $ecommerce_x_frontpage_slider_option == 'show' ) :?>
   <section class="banner">
     <?php $k=1; 
     for($i=1;$i<6;$i++){
      $slider_page[$k]=get_theme_mod('ecommerce_x_slider_title_'.$i);
      $slider_button_title[$k]=get_theme_mod('ecommerce_x_slider_button_title_'.$i);
      $slider_button_url[$k]=get_theme_mod('ecommerce_x_slider_button_url_'.$i);
      $k=$k+1;
    }
    $args = array (
      'post_type' => 'page',
      'post_per_page' => $k,
      'posts_per_page'=>6,
      'post__in'         => ($slider_page) ? ($slider_page) : '',
      'orderby'           =>'post__in',
    );

    $sliderloop = new WP_Query($args);
    $j=1;
    if ($sliderloop->have_posts()) :  while ($sliderloop->have_posts()) : $sliderloop->the_post();?>
      <div class="banner-slide">
        <?php 
        if(has_post_thumbnail()): ?>
          <?php the_post_thumbnail('ecommerce-x-banner-1343-*-613');
        endif; ?>
        <div class="caption">
          <h1><?php the_title();?></h1>
          <?php the_excerpt();?>
          <?php if($slider_button_title[$j]): ?>
            <a href="<?php echo esc_url($slider_button_url[$j]); ?>" class="btn"><?php echo esc_attr($slider_button_title[$j]); ?><span class="fa fa-angle-right icon" aria-hidden="true"></span></a>
          <?php endif;?>
        </div>
      </div>
      <?php $j=$j+1; endwhile;
      wp_reset_postdata();  
    endif; ?>
  </section>
  <?php  endif;?>