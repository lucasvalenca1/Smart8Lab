 <?php $ecommerce_x_frontpage_trending_product_option = get_theme_mod( 'ecommerce_x_frontpage_trending_product_option', 'show' );
 if( $ecommerce_x_frontpage_trending_product_option == 'show' ) :?>
  <section class="trending-product">
    <div class="container">
      <div class="main-title">
        <h2><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_trending_product_text'));?></h2>
      </div>
      <div class="row">
        <?php
        $trending_product_item_catId = get_theme_mod( 'ecommerce_x_frontpage_trending_product_items');
        $trending_product_item_number = get_theme_mod( 'ecommerce_x_frontpage_trending_product_items_number' );
        $args = array(
          'post_type'      => 'product',
          'posts_per_page' => $trending_product_item_number,
          'tax_query'      => array(
            array(
              'taxonomy'   => 'product_cat',
              'field'   => 'term_id',
              'terms'   => $trending_product_item_catId
            )
          )
        );
        $trending_productloop = new WP_Query($args);     
        if ( $trending_productloop->have_posts() ) :
          while ($trending_productloop->have_posts()) : $trending_productloop->the_post(); 
            ?>
            <div class="col-lg-3 col-sm-6">
              <div class="product-holder">
                <div class="img-holder">
                  <?php if(has_post_thumbnail()):
                   the_post_thumbnail('ecommerce-x-trending-product-255-*-325');
                 endif; ?>
                 <?php global $product;?>
                 <?php if ( $product->is_on_sale() ) : ?>
                   <div class="tag">
                    <span><?php echo esc_html__('Sale','ecommerce-x');?></span>
                  </div>
                <?php endif;?>
                <ul class="option">
                  <li>
                    <a href="<?php the_permalink();?>" data-toggle="tooltip" data-placement="top" title="View">
                      <span class="fa fa-search" aria-hidden="true"></span>
                    </a>
                  </li>
                </ul>
              </div>
              <a href="<?php the_permalink();?>" class="p-title"><h6><?php the_title();?></h6></a>

              <div class="price-tag">
                <div class="tag-holder">
                 <?php
                 global $woocommerce;
                 $currency = get_woocommerce_currency_symbol();
                 $sale = get_post_meta( get_the_ID(), '_sale_price', true);
                 ?>
                 <span><?php echo esc_html($currency);?> <?php echo esc_html($sale);?></span>
                 
                 <div class="cart-btn">
                  <a href="<?php echo esc_url( $product->add_to_cart_url() );?>" class="add-cart"><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php   endwhile;
      wp_reset_postdata();
    endif;?>
  </div>
</div>
</section>
<?php endif;?> 