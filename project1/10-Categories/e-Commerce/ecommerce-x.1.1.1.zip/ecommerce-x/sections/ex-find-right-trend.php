 <?php $ecommerce_x_frontpage_find_right_trend_option = get_theme_mod( 'ecommerce_x_frontpage_find_right_trend_option', 'show' );
 if( $ecommerce_x_frontpage_find_right_trend_option == 'show' ) :
  $trend_name =  get_theme_mod('ecommerce_x_find_right_trend_page_title');
  $query_post = get_post($trend_name);
  $post_image_url = get_the_post_thumbnail_url(  $trend_name )
  ?>
  <section class="trend" style="background: url(<?php echo esc_url(  $post_image_url );?>) no-repeat;">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <div class="main-title">
            <h2><?php echo esc_html($query_post->post_title);?></h2>
            <?php wp_reset_postdata(); ?>
          </div>
          <div class="row">
            <?php
            $find_right_trend_item_catId = get_theme_mod( 'ecommerce_x_frontpage_find_right_trend_items');
            $find_right_trend_item_number = get_theme_mod( 'ecommerce_x_frontpage_find_right_trend_items_number' );
            $args = array(
              'post_type'      => 'product',
              'posts_per_page' => $find_right_trend_item_number,
              'tax_query'      => array(
                array(
                  'taxonomy'   => 'product_cat',
                  'field'   => 'term_id', 
                  'terms'   => $find_right_trend_item_catId
                )
              )
            );
            $product_category_loop = new WP_Query($args);     
            if ( $product_category_loop->have_posts() ) :
              while ($product_category_loop->have_posts()) : $product_category_loop->the_post(); 
                ?>
                <div class="col-lg-6 col-md-6">
                  <div class="other-p-style media">
                    <a href="<?php the_permalink();?>"><?php if(has_post_thumbnail()):?>
                    <?php 
                    the_post_thumbnail('ecommerce-x-new-arrival-108-*-119',array('class'=>'mr-3'));
                    endif;?></a>
                    <div class="media-body">
                      <a href="<?php the_permalink();?>" class="p-title"><h6 class="mt-0"><?php the_title();?></h6></a>
                      <div class="price-tag">
                        <div class="tag-holder">
                         <?php
                         global $woocommerce;
                         global $product;
                         $currency = get_woocommerce_currency_symbol();
                         $sale = get_post_meta( get_the_ID(), '_sale_price', true);
                         ?>
                         <span><?php echo esc_html($currency);?> <?php echo esc_html($sale);?></span>
                         <div class="cart-btn">
                          <a href="<?php echo esc_url( $product->add_to_cart_url() );?>" class="add-cart"><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <?php
            endwhile;
            wp_reset_postdata();
          endif;?>
        </div>
      </div>
    </div>
  </div>
</section>
<?php endif;?>  