  <section class="leather-product">
    <div class="row">
      
      <?php ecommerce_x_advertisement_items();?>
     
    
    </div>
  </section>