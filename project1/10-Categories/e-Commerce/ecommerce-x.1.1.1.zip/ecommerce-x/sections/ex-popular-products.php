 <?php $ecommerce_x_frontpage_popular_product_option = get_theme_mod( 'ecommerce_x_frontpage_popular_product_option', 'show' );
 if( $ecommerce_x_frontpage_popular_product_option == 'show' ) :?>
  <section class="popular-product">
    <div class="container">
      <div class="title-content">
        <div class="main-title">
          <h2><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_popular_product_text'));?></h2>
        </div>
      </div>
      <div class="row">
        <?php if ( is_active_sidebar( 'popular-product' ) ) : 
          dynamic_sidebar('popular-product'); 
        endif;
        ?>  
      </div>
    </div>
  </section>
  <?php endif;?>