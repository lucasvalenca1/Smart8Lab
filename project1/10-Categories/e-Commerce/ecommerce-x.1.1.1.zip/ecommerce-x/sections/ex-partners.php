<?php $ecommerce_x_frontpage_partner_option = get_theme_mod( 'ecommerce_x_frontpage_partner_option', 'show' );
if( $ecommerce_x_frontpage_partner_option == 'show' ) :?> 
	<section class="partners">
		<div class="container">
			<div class="row">
				<?php
				$partnernumber = get_theme_mod( 'ecommerce_x_frontpage_partner_items_number');
				$partnerCategoryId = get_theme_mod('ecommerce_x_frontpage_partner_category');
				$args = array(
					'post_type' => 'post',
					'posts_per_page' => $partnernumber,
					'post_status' => 'publish',
					'paged' => 1,
					'cat' => $partnerCategoryId
				);
				$partnerloop = new WP_Query($args);
				if ( $partnerloop->have_posts() ) :
					while ($partnerloop->have_posts()) : $partnerloop->the_post();?>
						<div class="col-md-2">
							<?php if(has_post_thumbnail()): ?>
								<div class="img-holder">
									<?php the_post_thumbnail('ecommerce-x-partner-logo-215-*-156'); ?>
								</div>
							<?php endif;?>
						</div>
						<?php 
					endwhile;
					wp_reset_postdata();
				endif;?>
			</div>
		</div>
	</section>
	<?php endif?>