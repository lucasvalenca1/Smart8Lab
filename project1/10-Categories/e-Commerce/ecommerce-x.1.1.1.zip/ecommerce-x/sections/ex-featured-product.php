<?php
/**
 * ex-featured-product.php.
 *
 * @version 1.1.0
 */
?>
<?php $ecommerce_x_frontpage_feature_product_option = get_theme_mod( 'ecommerce_x_frontpage_feature_product_option', 'show' );
if( $ecommerce_x_frontpage_feature_product_option == 'show' ) :?>
   <section class="categories">
    <div class="container">
      <div class="row">
        <?php for($i=1;$i<=3;$i++){
          $featured_image_cat_id[$i] = get_theme_mod( 'ecommerce_x_featured_image_category_id_'.$i );

          if($featured_image_cat_id[$i]){
            $featured_image_info[$i] = get_term( $featured_image_cat_id[$i], 'product_cat' );
            if(!empty($featured_image_info[$i]->term_id)):
              $thumbnail_id[$i] = get_term_meta( $featured_image_info[$i]->term_id, 'thumbnail_id', true );
              $image[$i] = wp_get_attachment_image_src( $thumbnail_id[$i], 'ecommerce-x-featured-product-289-*-174' );

              ?>

              <div class="col-lg-4">
                <div class="cat-holder">
                  <a href="<?php echo esc_url(get_category_link($featured_image_cat_id[$i]));?>">  <?php
                  if($image[$i]): ?>
                    <img src="<?php echo esc_url($image[$i][0]);?>" alt="">
                    <?php endif; ?></a>
                    <div class="caption">
                      <h6><?php echo esc_html($featured_image_info[$i]->description);?></h6>
                      <a href="<?php echo esc_url(get_category_link($featured_image_cat_id[$i]));?>"><?php echo esc_html__('Discover Now','ecommerce-x');?></a>
                    </div>
                  </div>
                </div>
              <?php endif;
            }
          }?>
        </div>
      </div>
    </section>
<?php endif;
