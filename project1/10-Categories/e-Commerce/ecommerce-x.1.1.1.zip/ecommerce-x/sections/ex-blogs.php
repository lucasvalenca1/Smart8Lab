<?php $wp_commerce_frontpage_latest_news_option = get_theme_mod( 'wp_commerce_frontpage_latest_news_option', 'show' );
if( $wp_commerce_frontpage_latest_news_option == 'show' ) :?>
  <section class="blogs">
    <div class="container">
      <div class="main-title">
        <h2><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_latest_news_text'));?></h2>
      </div>
      <div class="row">
        <div class="col-xl-6 col-lg-5">
         <?php
         $latestnewsnumber = get_theme_mod( 'ecommerce_x_frontpage_latest_news_items_number');
         $latestnewsCategoryId = get_theme_mod('ecommerce_x_frontpage_latest_news_category');
         $args = array(
          'post_type' => 'post',
          'posts_per_page' => $latestnewsnumber,
          'post_status' => 'publish',
          'paged' => 1,
          'cat' => $latestnewsCategoryId
        );
         $latestnewsloop = new WP_Query($args);
         if ( $latestnewsloop->have_posts() ) :
          $i=1;
          while ($latestnewsloop->have_posts()) : $latestnewsloop->the_post(); 
            if($i==1):
              ?>
              <div class="left-blog">
                <a href="<?php the_permalink();?>" class="img-holder">
                  <?php if(has_post_thumbnail()): ?>
                   <?php the_post_thumbnail('ecommerce-x-blog-featured-image-540-*-495'); ?>
                 <?php endif;?>
                 <div class="text-holder">
                  <span class="date"><?php echo get_the_date( 'F d, Y'); ?></span>
                  <h4><?php the_title();?></h4>
                </div>
              </a>
            </div>
            <?php 
          endif;
           $i =$i+1;
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
    </div>
    <div class="col-xl-6 col-lg-7">
      <?php
      if ( $latestnewsloop->have_posts() ) :
        $i=1;
        while ($latestnewsloop->have_posts()) : $latestnewsloop->the_post(); 
          if($i>1):?>
            <div class="media">
              <a href="<?php the_permalink();?>">
               <?php if(has_post_thumbnail()): ?>
                 <?php the_post_thumbnail('ecommerce-x-blog-image-257-*-232'); ?>
               <?php endif;?>
             </a>
             <div class="media-body">
              <span class="date"><?php echo get_the_date( 'F d, Y'); ?></span>
              <h4 class="mt-0"><?php the_title();?></h4>
              <a href="<?php the_permalink();?>" class="btn"><?php echo esc_html__('Read More','ecommerce-x');?></a>
            </div>
          </div>
          <?php
        endif;
        $i =$i+1;
      endwhile;
      wp_reset_postdata();
    endif;?>
  </div>
</div>
</div>
</section>
<?php endif;?>