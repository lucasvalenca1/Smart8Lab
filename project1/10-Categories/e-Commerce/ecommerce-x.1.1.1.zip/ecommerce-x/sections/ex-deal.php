 <?php $ecommerce_x_frontpage_deal_of_the_week_option = get_theme_mod( 'ecommerce_x_frontpage_deal_of_the_week_option', 'show' );
 if( $ecommerce_x_frontpage_deal_of_the_week_option == 'show' ) :?>
  <section class="deal">
    <div class="container">
      <div class="main-title">
        <h2><?php echo esc_html(get_theme_mod( 'ecommerce_x_frontpage_deal_of_the_week_text'));?></h2>
      </div>
      <div class="row justify-content-center">
        <?php 
        $productId = get_theme_mod( 'ecommerce_x_frontpage_deal_of_the_week_product' );
        $productName = wc_get_product( $productId );
        if(!empty($productName)):?>
          <div class="deal-slider">
            <div class="col-lg-5 col">
              <div class="product-holder">
                <div class="img-holder">
                  <?php 
                  $lunch_date  = get_theme_mod('ecommerce_x_frontpage_deal_of_the_week_lunch_date');
                  echo get_the_post_thumbnail($productId,'ecommerce-x-deal-of-the-week-445-*-568');?>
                  <?php
                  global $woocommerce;
                  $currency = get_woocommerce_currency_symbol();
                  $price = get_post_meta( $productId, '_regular_price', true);
                  $sale = get_post_meta( $productId, '_sale_price', true);
                  if($price && $sale):
                    $discount_percentage = ($sale/$price)*100;
                    ?>
                    <div class="tag">
                      <span>
                        <?php 
                        echo absint( $discount_percentage ) ?><?php echo esc_html__('% off','ecommerce-x');?></span>
                      </div>
                    <?php endif;?>
                  </div>

                </div>
              </div>
              <div class="col-lg-6 col">
                <div class="deal-content">
                  <div class="countdown" id="countdown" data="<?php echo esc_attr($lunch_date);?>"></div>
                  <a href="<?php echo esc_url( get_permalink($productId) );?>" class="p-title"><h2><?php echo esc_html($productName->get_title());?></h2></a>
                  <?php $productShortDescription = get_post( $productId );
                  echo esc_html($productShortDescription->post_excerpt);?>
                  <div class="price-tag">
                    <span>><?php echo esc_html($currency); echo esc_html($price); ?> <span class="discount-tag"><?php echo esc_html($currency); echo esc_html($sale); ?></span></span>
                  </div>
                  <a href="<?php echo esc_url( '?add-to-cart='.$productId );?>" class="add-cart"><span class="fa fa-shopping-basket" aria-hidden="true"></span><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
                </div>
              </div>
            </div>
          <?php endif;?>
        </div>
      </div>
    </section>
    <?php endif;?>  