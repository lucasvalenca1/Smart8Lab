 <?php $ecommerce_x_frontpage_deal_of_the_week_option = get_theme_mod( 'ecommerce_x_frontpage_deal_of_the_week_option', 'show' );
 if( $ecommerce_x_frontpage_deal_of_the_week_option == 'show' ) :?>
  <section class="subscribe">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <div class="other-title">
            <?php $subscribe_name =  get_theme_mod('ecommerce_x_subscribe_page_title');
            $query_post = get_post($subscribe_name);?>
            <h2><?php echo esc_html($query_post->post_title);?></h2>
            <p><?php echo esc_html($query_post->post_content);?></p>
          </div>
          <?php if (get_theme_mod('ecommerce_x_news_letter_form_code')):
            echo do_shortcode(get_theme_mod('ecommerce_x_news_letter_form_code')); 
          endif; ?>
        </div>
      </div>
    </div>
  </section>
  <?php endif;?> 