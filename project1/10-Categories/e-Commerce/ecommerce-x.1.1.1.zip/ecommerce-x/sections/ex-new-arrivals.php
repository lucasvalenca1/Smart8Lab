   <section class="new-arrival">
    <div class="container">
      <div class="main-title">
        <h2><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_new_arrival_text'));?></h2>
      </div>
      <div class="row">
        <!-- Loop start -->
        <?php $ecommerce_x_product_count  = get_theme_mod('ecommerce_x_frontpage_new_arrival_items_number');
        $new_arrival_args = array(
          'post_type' => 'product',
          'posts_per_page' => absint( $ecommerce_x_product_count ),
          'stock' => 1,
          'orderby' =>'date',
          'order' => 'DESC' 
        );        
        $new_arrival_query = new WP_Query( $new_arrival_args );
        ?>     
        <?php
        if ( $new_arrival_query->have_posts() ) {
          while ( $new_arrival_query->have_posts() ) {
            $new_arrival_query->the_post();?>
            <div class="col-lg-4 col-sm-6">
              <div class="other-p-style media">
                <a href="<?php the_permalink();?>"> 
                 <?php if(has_post_thumbnail()):?>
                  <?php the_post_thumbnail( 'ecommerce-x-new-arrival-108-*-119',array('class'=>'mr-3') );?>
                <?php endif;?>
              </a>
              <div class="media-body">
                <a href="<?php the_permalink();?>" class="p-title"><h6 class="mt-0"><?php the_title();?></h6></a>
                <div class="price-tag">
                  <div class="tag-holder">
                   <?php
                   global $woocommerce;
                   $currency = get_woocommerce_currency_symbol();
                   $price = get_post_meta( get_the_ID(), '_regular_price', true);
                   $sale = get_post_meta( get_the_ID(), '_sale_price', true);
                   ?>
                   <span><span class="discount-tag"><?php echo esc_html($currency); echo esc_html($price); ?></span><?php echo esc_html($currency); echo esc_html($sale); ?>
                 </span>
                 <div class="cart-btn">
                   <?php global $product;?>
                   <a href="<?php echo esc_url( $product->add_to_cart_url() );?>" class="add-cart"><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </div>
     <?php  }
   }?>
 </div>
</div>
</section>