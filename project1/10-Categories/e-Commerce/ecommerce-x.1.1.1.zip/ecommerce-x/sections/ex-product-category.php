<?php $ecommerce_x_frontpage_product_category_option = get_theme_mod( 'ecommerce_x_frontpage_product_category_option', 'show' );
if( $ecommerce_x_frontpage_product_category_option == 'show' ) :?>
 <section class="product-category">
  <div class="container">
    <div class="main-title">
      <h2><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_product_category_text'));?></h2>
    </div>
    <div class="row">
      <?php 
      $product_id_1 = get_theme_mod( 'ecommerce_x_frontpage_product_category_1' );
      $product_id_2 = get_theme_mod( 'ecommerce_x_frontpage_product_category_2' );
      $product_id_3 = get_theme_mod( 'ecommerce_x_frontpage_product_category_3' );
      $product_id_4 = get_theme_mod( 'ecommerce_x_frontpage_product_category_4' );
      $product_catid_1 = get_theme_mod( 'ecommerce_x_frontpage_product_category_id_1' );
      $product_catid_2 = get_theme_mod( 'ecommerce_x_frontpage_product_category_id_2' );

      ecommerce_x_get_woocommerce_product_by_id($product_id_1);
      ecommerce_x_get_woocommerce_product_by_id($product_id_2);
      ecommerce_x_get_woocommerce_category_by_id($product_catid_1);
      ecommerce_x_get_woocommerce_category_by_id($product_catid_2);
      ecommerce_x_get_woocommerce_product_by_id($product_id_3);
      ecommerce_x_get_woocommerce_product_by_id($product_id_4);

      ?>
    </div>
  </div>
</section>

<?php endif;?>  