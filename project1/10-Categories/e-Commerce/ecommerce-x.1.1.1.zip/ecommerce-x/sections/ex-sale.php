<?php $ecommerce_x_frontpage_sale_advertisement_option = get_theme_mod( 'ecommerce_x_frontpage_sale_advertisement_option', 'show' );
if( $ecommerce_x_frontpage_sale_advertisement_option == 'show' ) :?>
	<section class="sale">
		<div class="container">
			<?php $ad_banner_url =  get_theme_mod('ecommerce_x_frontpage_sale_advertisement_banner');?>
			<a href="#"><img src="<?php echo esc_url($ad_banner_url);?>" alt=""></a>
		</div>
	</section>
<?php endif;?>	