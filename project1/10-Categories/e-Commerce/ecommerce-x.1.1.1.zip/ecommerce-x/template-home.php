<?php
/*
*	Template Name: FrontPage
*
*/	
get_header();

get_template_part( 'sections/ex', 'banner' );
get_template_part( 'sections/ex', 'featured-product' );
get_template_part( 'sections/ex', 'trending-product' );
get_template_part( 'sections/ex', 'product-ad' );
get_template_part( 'sections/ex', 'product-category' );
get_template_part( 'sections/ex', 'new-arrivals' );
get_template_part( 'sections/ex', 'deal' );
get_template_part( 'sections/ex', 'popular-products' );
get_template_part( 'sections/ex', 'sale' );
get_template_part( 'sections/ex', 'find-right-trend' );
get_template_part( 'sections/ex', 'new-arr-top-rat-trend-product-slider' );
get_template_part( 'sections/ex', 'subscribe' );
get_template_part( 'sections/ex', 'service' );
get_template_part( 'sections/ex', 'blogs' );
get_template_part( 'sections/ex', 'partners' );

get_footer(); ?>
