<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ecommerce_X
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<header class="header">
		<?php
		$ecommerce_x_header_option = get_theme_mod( 'ecommerce_x_top_header_option', 'show' );
		if( $ecommerce_x_header_option == 'show' ) :?>
			<?php get_template_part( 'template-parts/header/header', 'top' );?>
		<?php endif;?>	
		<?php	
		get_template_part( 'template-parts/header/header', 'middle' );?>
		<?php
		get_template_part( 'template-parts/header/header', 'bottom' );	
		?>
	</header>
	
	<?php if( is_home() || (!is_front_page()) ):
	if(class_exists('WooCommerce')):
		if(!is_shop() && !is_product_category()):
	endif;	
	?>
	<nav aria-label="breadcrumb">
		<div class="container">
			<?php ecommerce_x_inner_breadcrumb();?>
		</div>
	</nav>
	<?php
	if(class_exists('WooCommerce')):
		endif;
	endif;
	endif;?>

