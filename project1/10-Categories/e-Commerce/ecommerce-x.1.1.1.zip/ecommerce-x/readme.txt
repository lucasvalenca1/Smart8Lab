=== Ecommerce X ===
Contributors: wpcodethemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, blog, e-commerce
Requires at least: 4.5
Tested up to: 5.1
Stable tag: 1.1.1
License: GNU General Public License v2 or later
License URI: LICENSE

A starter theme called Ecommerce X.

== Description ==

Ecommerce X is beautifully design e-commerce theme fully compatible with most popular WooCommerce plugin. The theme comes with clean and elegant design and developer friendly. It is fully responsive, translation ready, SEO friendly and compatible with WooCommerce.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Ecommerce X includes support for Infinite Scroll in Jetpack.

== Copyright ==

Ecommerce X WordPress Theme, Copyright 2019 wpcodethemes.com
Ecommerce X is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Changelog ==

= 1.1.1 - May 04 2019 =
* Fix - Search text fixed in header.

= 1.1.0 - May 03 2019 =
* Fix - `content-product.php` - Price HTML fixed.
* Fix - `content-product.php` - Add to cart button text fixed.
* Fix - `content-single-product.php` - Price HTML fixed.
* Fix - `content-single-product.php` - Variable add to cart template fixed.
* Fix - `content-single-product.php` - Thumbnails (gallery) fixed.
* Fix - `content-single-product.php` - Categories links fixed.
* Fix - `slider-trending-products.php` - Price HTML fixed.
* Fix - `slider-trending-products.php` - Add to cart button text fixed.
* Fix - "`get_woocommerce_term_meta` is deprecated..." notice fixed (using `get_term_meta` instead).
* Fix - "Posted on" removed from cart, checkout and my account pages.
* Dev - `content-single-product.php` and `content-product.php` - Templates version updated.
* Dev - General clean up.

= 1.0.7 - Sep 23 2018 =
* change color of title, title hover, comment number of blogs
* remove post thumbnails width height

= 1.0.6 - Sep 23 2018 =
* change color of title
* bug fixes

= 1.0.5 - Sep 19 2018 =
* rename Invalid function name and add prefix ecommerce_x

= 1.0.4 - Sep 16 2018 =
* tgm remove
* tags added in styles.css
* screenshot changed and minor bug fixes

= 1.0.3 - Sep 12 2018 =
* remove customizer-css file
* changes css
* frontpage bug fixes

= 1.0.2 - Sep 11 2018 =
* remove tgm
* add one click demo
* changes in frontpage section on slider, featured section, product category section and find right trend section

= 1.0.1 - Aug 27 2018 =
* screenshot chages and bug fixes

= 1.0.0 - July 22 2018 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* Copyright (C) Federico Zivolo 2018, Distributed under the MIT License (license terms are at http://opensource.org/licenses/MIT).

* Bootstrap v4.1.0 (https://getbootstrap.com/), Copyright 2011-2018 The Bootstrap Authors, Copyright 2011-2018 Twitter, Inc. Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* Version: 1.9.0, Author: Ken Wheeler, Website: http://kenwheeler.github.io, Docs: http://kenwheeler.github.io/slick, Repo:, http://github.com/kenwheeler/slick, Issues: http://github.com/kenwheeler/slick/issues

* Zoom 1.7.21, license: MIT, http://www.jacklmoore.com/zoom

* jQuery v3.3.1 -ajax,-ajax/jsonp,-ajax/load,-ajax/parseXML,-ajax/script,-ajax/var/location,-ajax/var/nonce,-ajax/var/rquery,-ajax/xhr,-manipulation/_evalUrl,-event/ajax,-effects,-effects/Tween,-effects/animatedSelector | (c) JS Foundation and other contributors | jquery.org/license

* jQuery JavaScript Library v1.12.4, http://jquery.com/, Includes Sizzle.js, http://sizzlejs.com/, Copyright jQuery Foundation and other contributors, Released under the MIT license, http://jquery.org/license, Date: 2016-05-20T17:17Z

* SmartMenus jQuery Plugin - v1.1.0 - September 17, 2017, http://www.smartmenus.org/, Copyright Vasil Dinkov, Vadikom Web Ltd., http://vadikom.com, Licensed MIT

* SmartMenus jQuery Plugin Bootstrap 4 Addon - v0.1.0 - September 17, 2017, http://www.smartmenus.org/, Copyright Vasil Dinkov, Vadikom Web Ltd., http://vadikom.com, Licensed MIT

* Bootstrap Navwalker, https://github.com/twittem/wp-bootstrap-navwalker, Version: 2.0.4,  Author: Edward McIntyre - @twittem,  License: GPL-2.0+,  License URI: http://www.gnu.org/licenses/gpl-2.0.txt

== Images ==

All images used in the theme under GPL License

https://pixabay.com/en/adult-beautiful-beauty-face-1867889/
https://pixabay.com/en/shirt-man-white-fashion-2017-2947548/
https://pixabay.com/en/girl-bedroom-female-fashion-style-1733342/
https://pixabay.com/en/bag-chair-computer-indoors-laptop-1866582/
