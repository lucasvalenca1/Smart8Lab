<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ecommerce_X
 */

?>

<footer class="footer">
	<div class="container">
		<?php
		if ( has_nav_menu( 'footer-top' ) ) {
			wp_nav_menu( array(
				'theme_location'    => 'footer-top',
				'depth'             => 0,
				'container'   =>'ul',
				'menu_class'  =>'top-link'
			));
		}
		?>
		
		<div class="btm-link">
			<div class="row">
				<?php if ( is_active_sidebar( 'footer-widget' ) ) : ?>
					<?php dynamic_sidebar( 'footer-widget' ); ?>
				<?php endif;?>
			</div>
		</div>
		<div class="copyright">
			<div class="copyright-holder">
				<span><?php echo esc_html(get_theme_mod('ecommerce_x_footer_copyright_text'));?></span>
			</div>
			<?php $ecommerce_x_footer_payment_method_option = get_theme_mod( 'ecommerce_x_footer_payment_method_option', 'show' );
			if( $ecommerce_x_footer_payment_method_option == 'show' ) :?>
				<ul class="cards">
					<?php 
					$payment_method_arrays = array(
						'fa fa-cc-amex'=>'american-express',
						'fa fa-cc-mastercard'=>'master-card',
						'fa fa-cc-paypal'=>'paypal',
						'fa fa-cc-discover'=>'discover',
						'fa fa-cc-visa'=>'visa-card',
					);
					?>
					<?php foreach($payment_method_arrays as $key=>$payment_method):
						if(get_theme_mod( 'ecommerce_x_footer_payment_method_url_'.$payment_method)):                
							?>
							<li><a href="<?php echo esc_url(get_theme_mod('ecommerce_x_footer_payment_method_url_'.$payment_method));?>"><i class="<?php echo esc_attr($key);?>"></i></a></li>
						<?php endif;
					endforeach;?>
				</ul>
			<?php endif;?>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>

</body>
</html>
