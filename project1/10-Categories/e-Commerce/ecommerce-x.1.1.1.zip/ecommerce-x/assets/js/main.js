(function ($) {
  "use strict";
  $(document).ready(function(){
    $('.banner').slick({
      dots: false,
      infinite: true,
      arrows:true,
      speed: 500,
      slidesToShow: 1,
      autoplay:true,
      slidesToScroll: 1
    });
  });

  $(document).ready(function(){
    $('.deal .row').slick({
      dots: false,
      infinite: false,
      arrows:true,
      speed: 500,
      slidesToShow: 1,
      autoplay:false,
      slidesToScroll: 1
    });
  });

  $(document).ready(function(){
    $('.other-new-arrival .tab-pane .row').slick({
      dots: true,
      infinite: false,
      speed: 300,
      slidesToShow: 4,
      arrows: false,
      autoplay:true,
      slidesToScroll: 1,
      responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
      ]
    });
  });

  $(document).ready(function(){
    $('.partners .row').slick({
      dots: false,
      infinite: true,
      speed: 300,
      slidesToShow: 6,
      arrows: false,
      autoplay:true,
      slidesToScroll: 1,
      responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
      ]
    });
  });

  $(document).ready(function(){
    $('.b-new-arrival .b-new-slider').slick({
      dots: false,
      infinite: true,
      speed: 300,
      autoplay:true,
      slidesToShow: 1,
      arrows: true,
      slidesToScroll: 1
    });
  });


  $(function () {
    $('[data-toggle="tooltip"]').tooltip()
  })

  $(document).ready(function(){
    $('.b-header .navbar-toggler').click(function(){
      $('.b-header .navbar-toggler #nav-icon3').toggleClass('open');
    });
  });


  $(document).ready(function(){
    $(".more-cat").click(function(){
      $(".more-cat-item").slideToggle("slow");
      $(this).toggleClass("active");
    });
  });

  $(document).ready(function(){
    if ( $('.more-cat').hasClass('active') ) {
      $('.more-cat a').addClass('woodwork');
    }
  });

  $(document).ready(function(){
   $('.product__slider-main').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    autoplay: false,
    lazyLoad: 'ondemand',
    autoplaySpeed: 3000,
    adaptiveHeight: true,
    asNavFor: '.product__slider-thmb'
  });

   $('.product__slider-thmb').slick({
    slidesToShow: 4,
    slidesToScroll: 1,
    infinite: true,
    arrows: false,
    lazyLoad: 'ondemand',
    asNavFor: '.product__slider-main',
    dots: false,
    centerMode: false,
    centerPadding: '50px',
    focusOnSelect: true,
    swipeToSlide: true,
    responsive: [
    {
      breakpoint: 992,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1
      }
    },
    {
      breakpoint: 576,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1
      }
    }
    ]
  });
 });


  $(document).ready(function(){
    $('.product__slider-main .slide').zoom();
  });

  jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up"><span class="fa fa-angle-up" aria-hidden="true"></span></div><div class="quantity-button quantity-down"><span class="fa fa-angle-down" aria-hidden="true"></span></div></div>').insertAfter('.quantity input');
  jQuery('.quantity').each(function() {
    var spinner = jQuery(this),
    input = spinner.find('input[type="number"]'),
    btnUp = spinner.find('.quantity-up'),
    btnDown = spinner.find('.quantity-down'),
    min = input.attr('min'),
    max = input.attr('max');

    btnUp.click(function() {
      var oldValue = parseFloat(input.val());
      if (oldValue >= max) {
        var newVal = oldValue;
      } else {
        var newVal = oldValue + 1;
      }
      spinner.find("input").val(newVal);
      spinner.find("input").trigger("change");
    });

    btnDown.click(function() {
      var oldValue = parseFloat(input.val());
      if (oldValue <= min) {
        var newVal = oldValue;
      } else {
        var newVal = oldValue - 1;
      }
      spinner.find("input").val(newVal);
      spinner.find("input").trigger("change");
    });

  });

  $(".product-categories .cat-parent a").addClass("parent");
  $(".product-categories .cat-parent .children").removeClass("parent");

  $(".product-categories .cat-parent").click(function (e) {
      e.preventDefault();
      $(this).siblings(".product-categories .cat-parent").removeClass("active").end().addClass("active");
      $(".product-categories .cat-parent.active .children").slideToggle("slow");
    });
})(jQuery);

