/**
 * Customizer custom js
 */

jQuery(document).ready(function() {
   jQuery('.wp-full-overlay-sidebar-content').prepend('<div class="ecommerce-x-ads"> <a href="https://wpfactory.com/item/ecommerce-x-theme-for-woocommerce/" class="button" target="_blank">{pro}</a></div>'.replace('{pro}',ecommerce_x_customizer_js_obj.pro));
});