<?php
/**
 * Ecommerce X Theme Customizer
 *
 * @package Ecommerce_X
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function ecommerce_x_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'blogname', array(
			'selector'        => '.site-title a',
			'render_callback' => 'ecommerce_x_customize_partial_blogname',
		) );
		$wp_customize->selective_refresh->add_partial( 'blogdescription', array(
			'selector'        => '.site-description',
			'render_callback' => 'ecommerce_x_customize_partial_blogdescription',
		) );
	}
}
add_action( 'customize_register', 'ecommerce_x_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function ecommerce_x_customize_partial_blogname() {
	bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function ecommerce_x_customize_partial_blogdescription() {
	bloginfo( 'description' );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function ecommerce_x_customize_preview_js() {
	wp_enqueue_script( 'ecommerce-x-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), '20151215', true );
}
add_action( 'customize_preview_init', 'ecommerce_x_customize_preview_js' );


/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Enqueue required scripts/styles for customizer panel
 *
 * @since 1.0.0
 */
function ecommerce_x_customize_backend_scripts() {
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), '4.7.0' );

	wp_enqueue_style( 'ecommerce_x_admin_customizer_style', get_template_directory_uri() . '/assets/customizer/ex-customizer-style.css', array(), '1.0.0' );

	wp_enqueue_script( 'ecommerce_x_admin_customizer', get_template_directory_uri() . '/assets/customizer/ex-customizer-controls.js', array( 'jquery', 'customize-controls' ), '1.0.0', true );

	wp_enqueue_script('ecommerce-x-customizer', get_template_directory_uri() . '/inc/upgrade-to-pro/pro.js', array('jquery'), '1.3.0', true);

	wp_localize_script( 'ecommerce-x-customizer', 'ecommerce_x_customizer_js_obj', array(
		'pro' => __('Upgrade To Ecommerce Pro','ecommerce-x')
	) );
	wp_enqueue_style( 'ecommerce-x-customizer', get_template_directory_uri() . '/inc/upgrade-to-pro/pro.css');
}
add_action( 'customize_controls_enqueue_scripts', 'ecommerce_x_customize_backend_scripts', 10 );



/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Load customizer required panels.
 */

require get_template_directory() . '/inc/customizer/ex-general-panel.php';
require get_template_directory() . '/inc/customizer/ex-header-panel.php';
require get_template_directory() . '/inc/customizer/ex-frontpage-panel.php';
require get_template_directory() . '/inc/customizer/ex-footer-panel.php';
require get_template_directory() . '/inc/customizer/ex-customizer-classes.php';
require get_template_directory() . '/inc/customizer/ex-customizer-sanitize.php';