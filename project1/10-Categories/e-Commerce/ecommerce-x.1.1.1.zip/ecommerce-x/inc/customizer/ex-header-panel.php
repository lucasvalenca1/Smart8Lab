<?php
/**
 * WP Commerce Header Settings panel at Theme Customizer
 *
 * @package Excommerce X
 * @since 1.0.0
 */

add_action( 'customize_register', 'ecommerce_x_header_settings_register' );

function ecommerce_x_header_settings_register( $wp_customize ) {

    $wp_customize->get_section( 'header_image' )->priority = '20';
    $wp_customize->get_section( 'header_image' )->title    = __( 'Header Image', 'ecommerce-x' );
    $wp_customize->get_section( 'header_image' )->panel    = 'ecommerce_x_header_settings_panel';

	/**
     * Add Header Settings Panel
     *
     * @since 1.0.0
     */
    $wp_customize->add_panel(
     'ecommerce_x_header_settings_panel',
     array(
         'priority'       => 10,
         'capability'     => 'edit_theme_options',
         'theme_supports' => '',
         'title'          => __( 'Header Settings', 'ecommerce-x' ),
     )
 );

    /*----------------------------------------------------------------------------------------------------------------------------------------*/
	/**
     * Top Header section
     *
     * @since 1.0.0
     */
    $wp_customize->add_section(
        'ecommerce_x_header_section',
        array(
        	'priority'       => 5,
        	'panel'          => 'ecommerce_x_header_settings_panel',
        	'capability'     => 'edit_theme_options',
        	'theme_supports' => '',
            'title'          => __( 'Header Section', 'ecommerce-x' ),
            'description'    => __( 'Managed the content display at Header section.', 'ecommerce-x' ),
        )
    );

    /**
     * Switch option for Top Header
     *
     * @since 1.0.0
     */
    $wp_customize->add_setting(
        'ecommerce_x_top_header_option',
        array(
        	'capability'     	=> 'edit_theme_options',
            'default' 			=> 'show',
            'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
        )
    );
    $wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
        $wp_customize,
        'ecommerce_x_top_header_option',
        array(
            'label'     	=> __( 'Header Top Option', 'ecommerce-x' ),
            'description'   => __( 'Show/Hide option for Header Top section.', 'ecommerce-x' ),
            'section'   	=> 'ecommerce_x_header_section',
            'settings'		=> 'ecommerce_x_top_header_option',
            'type'      	=> 'switch',
            'priority'  	=> 5,
            'choices'   	=> array(
                'show'  		=> __( 'Show', 'ecommerce-x' ),
                'hide'  		=> __( 'Hide', 'ecommerce-x' )
            )
        )
    )
);

/**
* Switch option for search options
*
* @since 1.0.0
*/
$wp_customize->add_setting(
    'ecommerce_x_header_search_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'hide',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_header_search_option',
    array(
        'label'         => __( 'Header Search Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for search form at header section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_header_section',
        'settings'      => 'ecommerce_x_header_search_option',
        'type'          => 'switch',
        'priority'      => 5,
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);

/**
* Switch option for shopping cart icon
*
* @since 1.0.0
*/
$wp_customize->add_setting(
    'ecommerce_x_header_cart_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_header_cart_option',
    array(
        'label'         => __( 'Header Cart Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for shopping cart at header section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_header_section',
        'settings'      => 'ecommerce_x_header_cart_option',
        'type'          => 'switch',
        'priority'      => 6,
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);
}