<?php
/**
 * WP Commerce Footer Settings panel.
 *
 * @package Excommerce X
 * @since 1.0.0
 */

add_action( 'customize_register', 'ecommerce_x_footer_settings_register' );

function ecommerce_x_footer_settings_register( $wp_customize ) {
/**
     * Add Footer Settings Panel
     *
     * @since 1.0.0
     */
$wp_customize->add_panel(
 'ecommerce_x_footer_settings_panel',
 array(
     'priority'       => 25,
     'capability'     => 'edit_theme_options',
     'theme_supports' => '',
     'title'          => __( 'Footer Settings', 'ecommerce-x' ),
 )
);

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Footer Payment method Settings
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_payment_method_footer_section',
    array(
        'priority'       => 2,
        'panel'          => 'ecommerce_x_footer_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Payment method links', 'ecommerce-x' )
    )
);

/**
 * Switch option for Payment methods Links
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_footer_payment_method_option',
    array(
    	'capability'     	=> 'edit_theme_options',
        'default' 			=> 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_footer_payment_method_option',
    array(
        'label'     	=> __( 'Payment method options', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Payment method Links', 'ecommerce-x' ),
        'section'   	=> 'ecommerce_x_payment_method_footer_section',
        'settings'		=> 'ecommerce_x_footer_payment_method_option',
        'type'      	=> 'switch',
        'choices'   	=> array(
            'show'  		=> __( 'Show', 'ecommerce-x' ),
            'hide'  		=> __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

// Payment method Links
$payment_method_arrays = array('american-express'=>'American Express','master-card'=>'Master Card','paypal'=>'Paypal','discover'=>'Discover','visa-card'=>'Visa Card');
foreach ($payment_method_arrays as  $key=>$payment_method) {
   $wp_customize->add_setting( 'ecommerce_x_footer_payment_method_url_'.$key, array(
     'capability'            => 'edit_theme_options',
     'default'               => '',
     'sanitize_callback'     => 'esc_url_raw'
 ) );

   $wp_customize->add_control( 'ecommerce_x_footer_payment_method_url_'.$key, array(
     /* translators: %s: Label */ 
     'label'                 =>  sprintf( __( '%s Url', 'ecommerce-x' ), $payment_method ),
     'section'               => 'ecommerce_x_payment_method_footer_section',
     'type'                  => 'url',
     'settings' => 'ecommerce_x_footer_payment_method_url_'.$key,
 ) );
}

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Footer Copyright Settings
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_copyright_footer_section',
    array(
        'priority'       => 2,
        'panel'          => 'ecommerce_x_footer_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Footer Copyright Section', 'ecommerce-x' )
    )
);

$wp_customize->add_setting( 'ecommerce_x_footer_copyright_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_footer_copyright_text', array(
    'label'                 =>  'Footer Copyright Text',
    'section'               => 'ecommerce_x_copyright_footer_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_footer_copyright_text',
) );
}