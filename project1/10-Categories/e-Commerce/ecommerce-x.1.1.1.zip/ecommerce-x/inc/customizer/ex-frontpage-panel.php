<?php
/**
 * WP Commerce Frontpage Settings panel at Theme Customizer
 *
 * @package Excommerce X
 * @since 1.0.0
 */
add_action( 'customize_register', 'ecommerce_x_frontpage_settings_register' );

function ecommerce_x_frontpage_settings_register( $wp_customize ) {

/**
 * Add Frontpage Settings Panel
 *
 * @since 1.0.0
 */
$wp_customize->add_panel(
    'ecommerce_x_frontpage_settings_panel',
    array(
        'priority'       => 15,
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Frontpage Settings', 'ecommerce-x' ),
    )
);

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Front Product Slider section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_slider_section',
    array(
    	'priority'       => 1,
    	'panel'          => 'ecommerce_x_frontpage_settings_panel',
    	'capability'     => 'edit_theme_options',
    	'theme_supports' => '',
        'title'          => __( 'Product Slider Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the slider display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Product Slider
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_slider_option',
    array(
    	'capability'     	=> 'edit_theme_options',
        'default' 			=> 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_slider_option',
    array(
        'label'     	=> __( 'Frontpage Product Slider Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Product Slider section.', 'ecommerce-x' ),
        'section'   	=> 'ecommerce_x_frontpage_slider_section',
        'settings'		=> 'ecommerce_x_frontpage_slider_option',
        'type'      	=> 'switch',
        'choices'   	=> array(
            'show'  		=> __( 'Show', 'ecommerce-x' ),
            'hide'  		=> __( 'Hide', 'ecommerce-x' )
        )
    )
)
);

 /**
 *  Page Selection for Frontpage Slider
 *
 * @since 1.0.0
 */
 for ($i=1;$i<=5;$i++) {
// Select Page For Slider title with featured image.
  $wp_customize->add_setting( 'ecommerce_x_slider_title_'.$i, array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

  $wp_customize->add_control('ecommerce_x_slider_title_'.$i,
    array(
      /* translators: %s: Slider Number. */
      'label'                 =>  sprintf( __( 'Select Page for Slider %s title with featured image', 'ecommerce-x' ), $i ),
      'section' => 'ecommerce_x_frontpage_slider_section',
      'type'=> 'dropdown-pages',
      'settings' => 'ecommerce_x_slider_title_'.$i
  )
);

  $wp_customize->add_setting( 'ecommerce_x_slider_button_title_'.$i, array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

  $wp_customize->add_control( 'ecommerce_x_slider_button_title_'.$i, array(
    /* translators: %s: Description */ 
    'label'                 =>  sprintf( __( 'Button Title For Slider %s', 'ecommerce-x' ), $i ),
    'description'           =>  __( 'Shop Collection', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_slider_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_slider_button_title_'.$i,
) );

  $wp_customize->add_setting( 'ecommerce_x_slider_button_url_'.$i, array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'esc_url_raw'
) );

  $wp_customize->add_control( 'ecommerce_x_slider_button_url_'.$i, array(
    /* translators: %s: Description */ 
    'label'                 =>  sprintf( __( 'Select URL For button Title of slider  %s', 'ecommerce-x' ), $i ),
    'description'           =>  __( '#', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_slider_section',
    'type'                  => 'url',
    'settings' => 'ecommerce_x_slider_button_url_'.$i,
) );
}

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Front Featured Products section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_feature_product_section',
    array(
    	'priority'       => 3,
    	'panel'          => 'ecommerce_x_frontpage_settings_panel',
    	'capability'     => 'edit_theme_options',
    	'theme_supports' => '',
        'title'          => __( 'Feature Products Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Feature Products Section display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Featured Products
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_feature_product_option',
    array(
    	'capability'     	=> 'edit_theme_options',
        'default' 			=> 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_feature_product_option',
    array(
        'label'     	=> __( 'Frontpage Feature Products Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Feature Products section.', 'ecommerce-x' ),
        'section'   	=> 'ecommerce_x_frontpage_feature_product_section',
        'settings'		=> 'ecommerce_x_frontpage_feature_product_option',
        'type'      	=> 'switch',
        'choices'   	=> array(
            'show'  		=> __( 'Show', 'ecommerce-x' ),
            'hide'  		=> __( 'Hide', 'ecommerce-x' )
        )
    )
)
);      

 /**
 *  Category Selection for Frontpage Featured Product
 *
 * @since 1.0.0
 */
 for ($i=1;$i<=3;$i++) {
    $wp_customize->add_setting( 'ecommerce_x_featured_image_category_id_'.$i, array(
        'capability'            => 'edit_theme_options',
        'default'               => '',
        'sanitize_callback'     => 'ecommerce_x_sanitize_select'
    ) );


    $wp_customize->add_control( 'ecommerce_x_featured_image_category_id_'.$i, array(
        /* translators: %s: Popular Destination Number */ 
        'label'                 =>  sprintf( __( 'Choose category for featured iamge %s', 'ecommerce-x' ), $i ),
        'description' => __( 'Go to Products > Categories and add. Then you will be able to select a product category  from the dropdown.', 'ecommerce-x' ),
        'section'               => 'ecommerce_x_frontpage_feature_product_section',
        'type'                  => 'select',
        'settings'              => 'ecommerce_x_featured_image_category_id_'.$i,
        'choices'     => ecommerce_x_get_categories( true, 'product_cat', false )
    ) );
}

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Front Trending Products
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_trending_product_section',
    array(
        'priority'       => 3,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Trending Product Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Trending Products Section display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Trending Products
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_trending_product_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_trending_product_option',
    array(
        'label'         => __( 'Frontpage Trending Products Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Trending Products section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_trending_product_section',
        'settings'      => 'ecommerce_x_frontpage_trending_product_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);      

$wp_customize->add_setting( 'ecommerce_x_frontpage_trending_product_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_trending_product_text', array(
    'label'                 =>  'Trending Products Text',
    'section'               => 'ecommerce_x_frontpage_trending_product_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_trending_product_text',
) );

 /**
 *  Category Selection for Frontpage Trending Products
 *
 * @since 1.0.0
 */
 $wp_customize->add_setting(
    'ecommerce_x_frontpage_trending_product_items',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_category',
    )
);

 $wp_customize->add_control( new Ecommerce_X_Customize_Product_Category_Control(
    $wp_customize,
    'ecommerce_x_frontpage_trending_product_items',
    array(
        'label' => __('Select Category for Trending Product','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_trending_product_section',
        'settings' => 'ecommerce_x_frontpage_trending_product_items',
        'type'=> 'dropdown-taxonomies',
    )
)
);

 $wp_customize->add_setting( 'ecommerce_x_frontpage_trending_product_items_number', array(
    'capability'            => 'edit_theme_options',
    'default'               => 4,
    'sanitize_callback'     => 'absint'
));

 $wp_customize->add_control( 'ecommerce_x_frontpage_trending_product_items_number', array(
    'label'                 =>  __( 'Number of Product to display', 'ecommerce-x' ),
    'description'           =>  __( 'input 3,4,5,6,7,8,9,10', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_trending_product_section',
    'type'                  => 'number',
    'settings' => 'ecommerce_x_frontpage_trending_product_items_number',
) );


 /*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Product Advertisement
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_product_advertisement_section',
    array(
        'priority'       => 3,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Advertisement Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Advertisement Section display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Repeater field for Frontpage product Advertisement options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_product_advertisement_items',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => json_encode(array(
            array(
                'mt_item_text' => '',
                'mt_item_text1' => '',
                'mt_item_text2' => '',
                'mt_item_upload' => ''
            )
        )
    ),
        'sanitize_callback' => 'ecommerce_x_sanitize_repeater',
    )
);

$wp_customize->add_control( new Ecommerce_X_Repeater_Controler(
    $wp_customize,
    'ecommerce_x_frontpage_product_advertisement_items',
    array(
        'label'         => __( 'Advertisment Items', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_product_advertisement_section',
        'settings'      => 'ecommerce_x_frontpage_product_advertisement_items',
        'ecommerce_x_box_label'       => __( 'Advertisement Item','ecommerce-x' ),
        'ecommerce_x_box_add_control' => __( 'Add Item','ecommerce-x' )
    ),
    array(
        'mt_item_text' => array(
            'type'        => 'text',
            'label'       => __( 'Product title', 'ecommerce-x' ),
        ),
        'mt_item_text1' => array(
            'type'        => 'text',
            'label'       => __( 'Product Info', 'ecommerce-x' ),
        ),
        'mt_item_text2' => array(
            'type'        => 'text',
            'label'       => __( 'Product Price', 'ecommerce-x' ),
        ),
        'mt_item_upload' => array(
            'type'        => 'upload',
            'label'       => __( 'Product Feature Image', 'ecommerce-x' ),
            'description' => __( 'Upload Feature Image.(656px*389px)', 'ecommerce-x' )
        )
    )
)
);   

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Product Category
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_product_category_section',
    array(
        'priority'       => 3,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Product Category Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Product Category Section display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Product Category
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_product_category_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_product_category_option',
    array(
        'label'         => __( 'Frontpage Product Category Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Product Category section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_product_category_section',
        'settings'      => 'ecommerce_x_frontpage_product_category_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);      

$wp_customize->add_setting( 'ecommerce_x_frontpage_product_category_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_product_category_text', array(
    'label'                 =>  'Product Category Text',
    'section'               => 'ecommerce_x_frontpage_product_category_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_product_category_text',
) );

 /**
 *  Product Selection 1 for Frontpage Product Category
 *
 * @since 1.0.0
 */
 $wp_customize->add_setting( 'ecommerce_x_frontpage_product_category_1', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

 $wp_customize->add_control( new Ecommerce_X_Product_Dropdown_Custom_Control(
    $wp_customize,
    'ecommerce_x_frontpage_product_category_1',
    array(
        'label' => __('Select Product for Product Category Section 1','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_product_category_section',
        'settings' => 'ecommerce_x_frontpage_product_category_1',
        'type'=> 'dropdown-product',
    )
)
);


/**
 *  Product Selection 2 for Frontpage Product Category
 *
 * @since 1.0.0
 */
$wp_customize->add_setting( 'ecommerce_x_frontpage_product_category_2', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

$wp_customize->add_control( new Ecommerce_X_Product_Dropdown_Custom_Control(
    $wp_customize,
    'ecommerce_x_frontpage_product_category_2',
    array(
        'label' => __('Select Product for Product Category Section 2','ecommerce-x'),
        'description' => __( 'Go to Products > Add New and add. Then you will be able to select a product from the dropdown.', 'ecommerce-x' ),
        'section' => 'ecommerce_x_frontpage_product_category_section',
        'settings' => 'ecommerce_x_frontpage_product_category_2',
        'type'=> 'dropdown-product',
    )
)
);


for ($i=1;$i<=2;$i++) {
    $wp_customize->add_setting( 'ecommerce_x_frontpage_product_category_id_'.$i, array(
        'capability'            => 'edit_theme_options',
        'default'               => '',
        'sanitize_callback'     => 'ecommerce_x_sanitize_select'
    ) );


    $wp_customize->add_control( 'ecommerce_x_frontpage_product_category_id_'.$i, array(
        /* translators: %s: Popular Destination Number */ 
        'label'                 =>  sprintf( __( 'Choose category for product category %s', 'ecommerce-x' ), $i ),
        'description' => __( 'Go to Products > Categories and add. Then you will be able to select a product category  from the dropdown.', 'ecommerce-x' ),
        'section'               => 'ecommerce_x_frontpage_product_category_section',
        'type'                  => 'select',
        'settings'              => 'ecommerce_x_frontpage_product_category_id_'.$i,
        'choices'     => ecommerce_x_get_categories( true, 'product_cat', false )
    ) );
}


/**
 *  Product Selection 3 for Frontpage Product Category
 *
 * @since 1.0.0
 */
$wp_customize->add_setting( 'ecommerce_x_frontpage_product_category_3', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

$wp_customize->add_control( new Ecommerce_X_Product_Dropdown_Custom_Control(
    $wp_customize,
    'ecommerce_x_frontpage_product_category_3',
    array(
        'label' => __('Select Product for Product Category Section 3','ecommerce-x'),
        'description' => __( 'Go to Products > Add New and add. Then you will be able to select a product from the dropdown.', 'ecommerce-x' ),
        'section' => 'ecommerce_x_frontpage_product_category_section',
        'settings' => 'ecommerce_x_frontpage_product_category_3',
        'type'=> 'dropdown-product',
    )
)
);

/**
 *  Product Selection 4 for Frontpage Product Category
 *
 * @since 1.0.0
*/
$wp_customize->add_setting( 'ecommerce_x_frontpage_product_category_4', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

$wp_customize->add_control( new Ecommerce_X_Product_Dropdown_Custom_Control(
    $wp_customize,
    'ecommerce_x_frontpage_product_category_4',
    array(
        'label' => __('Select Product for Product Category Section 4','ecommerce-x'),
        'description' => __( 'Go to Products > Add New and add. Then you will be able to select a product from the dropdown.', 'ecommerce-x' ),
        'section' => 'ecommerce_x_frontpage_product_category_section',
        'settings' => 'ecommerce_x_frontpage_product_category_4',
        'type'=> 'dropdown-product',
    )
)
);
/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Front New Arrivals section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_new_arrival_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'New Arrivals Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the New Arrivals display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for New Arrival Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_new_arrival_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_new_arrival_option',
    array(
        'label'         => __( 'Frontpage New Arrival Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage New Arrival section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_new_arrival_section',
        'settings'      => 'ecommerce_x_frontpage_new_arrival_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
); 

$wp_customize->add_setting( 'ecommerce_x_frontpage_new_arrival_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_new_arrival_text', array(
    'label'                 =>  'New Arrivals Text',
    'section'               => 'ecommerce_x_frontpage_new_arrival_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_new_arrival_text',
) );  


$wp_customize->add_setting( 'ecommerce_x_frontpage_new_arrival_items_number', array(
    'capability'            => 'edit_theme_options',
    'default'               => 9,
    'sanitize_callback'     => 'absint'
));

$wp_customize->add_control( 'ecommerce_x_frontpage_new_arrival_items_number', array(
    'label'                 =>  __( 'Number of New Arrivals Product to display', 'ecommerce-x' ),
    'description'           =>  __( 'input 3,4,5,6,7,8,9,10', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_new_arrival_section',
    'type'                  => 'number',
    'settings' => 'ecommerce_x_frontpage_new_arrival_items_number',
) );


/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Deal of the week
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_deal_of_the_week_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Deal of the week Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Service display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Deal of the week Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_deal_of_the_week_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_deal_of_the_week_option',
    array(
        'label'         => __( 'Frontpage Deal of the week Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Deal of the week section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_deal_of_the_week_section',
        'settings'      => 'ecommerce_x_frontpage_deal_of_the_week_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
); 

// Deal of the week text
$wp_customize->add_setting( 'ecommerce_x_frontpage_deal_of_the_week_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_deal_of_the_week_text', array(
    'label'                 =>  'Deal of the Week Text',
    'section'               => 'ecommerce_x_frontpage_deal_of_the_week_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_deal_of_the_week_text',
) );  

 /**
 *  Selection of product for deal of the week
 *
 * @since 1.0.0
 */
 $wp_customize->add_setting(
    'ecommerce_x_frontpage_deal_of_the_week_product',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_category',
    )
);

 $wp_customize->add_control( new Ecommerce_X_Product_Dropdown_Custom_Control($wp_customize,
    'ecommerce_x_frontpage_deal_of_the_week_product',
    array(
        'label' => __('Select Product for Deal of the week','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_deal_of_the_week_section',
        'settings' => 'ecommerce_x_frontpage_deal_of_the_week_product',
        'type'=> 'dropdown-product',
    )
)
);

//Lunch Date of deal of the product
 $wp_customize->add_setting( 'ecommerce_x_frontpage_deal_of_the_week_lunch_date', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

 $wp_customize->add_control( 'ecommerce_x_frontpage_deal_of_the_week_lunch_date', array(
    'label'                 => __('Deal of the Week Lunch Date','ecommerce-x'),
    'description'           => __('Eg:-July 1, 2018 13:00:00','ecommerce-x'),
    'section'               => 'ecommerce_x_frontpage_deal_of_the_week_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_deal_of_the_week_lunch_date',
) );  


 /*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Popular Products section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_popular_product_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Popular Products Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Popular Products display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Popular Products Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_popular_product_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_popular_product_option',
    array(
        'label'         => __( 'Frontpage Popular Products Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Service section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_popular_product_section',
        'settings'      => 'ecommerce_x_frontpage_popular_product_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

// Popular Product text
$wp_customize->add_setting( 'ecommerce_x_frontpage_popular_product_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_popular_product_text', array(
    'label'                 =>  'Popular Products Text',
    'section'               => 'ecommerce_x_frontpage_popular_product_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_popular_product_text',
) );  

$wp_customize->add_setting('ecommerce_x_popular_products', array(
  'default' => '',
  'type' => 'customtext',
  'capability' => 'edit_theme_options',
  'transport' => 'refresh',
  'sanitize_callback' => 'sanitize_text_field',
) );

$wp_customize->add_control( new Ecommerce_X_Widget_Url( $wp_customize, 'ecommerce_x_popular_products', array(
    'label' => esc_attr__( 'Go to Widget', 'ecommerce-x' ),
    'section' => 'ecommerce_x_frontpage_popular_product_section',
    'settings' => 'ecommerce_x_popular_products',
    'extra' => esc_attr__( ' for adding products in this section', 'ecommerce-x' )
) ) 
);

/*----------------------------------------------------------------------------------------------------------------------------------------*/
    /**
     * Frontpage Sale Advertisement section
     *
     * @since 1.0.0
     */
    $wp_customize->add_section(
        'ecommerce_x_frontpage_sale_advertisement_section',
        array(
            'priority'       => 5,
            'panel'          => 'ecommerce_x_frontpage_settings_panel',
            'capability'     => 'edit_theme_options',
            'theme_supports' => '',
            'title'          => __( 'Sale Advertisement Section', 'ecommerce-x' ),
            'description'    => __( 'Managed the Sale Advertisement display at Frontpage section.', 'ecommerce-x' ),
        )
    );

    /**
     * Switch option for Sale Advertisement Options
     *
     * @since 1.0.0
     */

    $wp_customize->add_setting(
        'ecommerce_x_frontpage_sale_advertisement_option',
        array(
            'capability'        => 'edit_theme_options',
            'default'           => 'show',
            'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
        )
    );

    $wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
        $wp_customize,
        'ecommerce_x_frontpage_sale_advertisement_option',
        array(
            'label'         => __( 'Frontpage Sale Advertisement Option', 'ecommerce-x' ),
            'description'   => __( 'Show/Hide option for Frontpage Sale Advertisement section.', 'ecommerce-x' ),
            'section'       => 'ecommerce_x_frontpage_sale_advertisement_section',
            'settings'      => 'ecommerce_x_frontpage_sale_advertisement_option',
            'type'          => 'switch',
            'choices'       => array(
                'show'          => __( 'Show', 'ecommerce-x' ),
                'hide'          => __( 'Hide', 'ecommerce-x' )
            )
        )
    )
);   

// Sale Advertisement Banner
    $wp_customize->add_setting('ecommerce_x_frontpage_sale_advertisement_banner', array(
        'transport'         => 'refresh',
        'height' => 1110,
        'width' => 327,
        'sanitize_callback' => 'esc_url_raw',
    ));

    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'ecommerce_x_frontpage_sale_advertisement_banner', array(
        'label'             => __('Sale Advertisement Banner(1110 * 327)', 'ecommerce-x'),
        'section'           => 'ecommerce_x_frontpage_sale_advertisement_section',
        'settings'          => 'ecommerce_x_frontpage_sale_advertisement_banner',
    )));    


/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Find Right Trend section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_find_right_trend_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Find Right Trend Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Find Right Trend display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Find Right Trend Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_find_right_trend_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_find_right_trend_option',
    array(
        'label'         => __( 'Frontpage Find Right Trend Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Find right Trend section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_find_right_trend_section',
        'settings'      => 'ecommerce_x_frontpage_find_right_trend_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

//Find right trend Section title and Featured image for background
$wp_customize->add_setting( 'ecommerce_x_find_right_trend_page_title', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

$wp_customize->add_control( 'ecommerce_x_find_right_trend_page_title', array(
    'label'                 =>  __( 'Select Page for Find right trend Title and Feaured image for background', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_find_right_trend_section',
    'type'                  => 'dropdown-pages',
    'settings'              => 'ecommerce_x_find_right_trend_page_title',
) );
/**
 *  Category Selection for Frontpage Find Right Trend 
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_find_right_trend_items',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_category',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Product_Category_Control(
    $wp_customize,
    'ecommerce_x_frontpage_find_right_trend_items',
    array(
        'label' => __('Select Category for Find Right Trend','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_find_right_trend_section',
        'settings' => 'ecommerce_x_frontpage_find_right_trend_items',
        'type'=> 'dropdown-taxonomies',
    )
)
);

$wp_customize->add_setting( 'ecommerce_x_frontpage_find_right_trend_items_number', array(
    'capability'            => 'edit_theme_options',
    'default'               => 3,
    'sanitize_callback'     => 'absint'
));


$wp_customize->add_control( 'ecommerce_x_frontpage_find_right_trend_items_number', array(
    'label'                 =>  __( 'Number of Find Right trend to display', 'ecommerce-x' ),
    'description'           =>  __( 'input 3,4,5,6,7,8,9,10', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_find_right_trend_section',
    'type'                  => 'number',
    'settings' => 'ecommerce_x_frontpage_find_right_trend_items_number',
) );






/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage New Arrivals, Top Rated and Trending Product section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'New Arrival/Top Rated/ Trending Product Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the New Arrival/Top Rated/ Trending Product display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for New Arrivals, Top Rated and Trending Product Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_option',
    array(
        'label'         => __( 'Frontpage New Arrival/Top Rated/ Trending Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage New Arrival/Top Rated/ Trending option section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_section',
        'settings'      => 'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

//New Arrival text
$wp_customize->add_setting( 'ecommerce_x_frontpage_new_arrival_product_slider_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_new_arrival_product_slider_text', array(
    'label'                 =>  'News Arrival Product Text',
    'section'               => 'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_new_arrival_product_slider_text',
) );  

//Top Rated text
$wp_customize->add_setting( 'ecommerce_x_frontpage_top_rated_product_slider_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_top_rated_product_slider_text', array(
    'label'                 =>  'Top Rated Product Text',
    'section'               => 'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_top_rated_product_slider_text',
) );  

//Trending text
$wp_customize->add_setting( 'ecommerce_x_frontpage_trending_product_slider_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_trending_product_slider_text', array(
    'label'                 =>  'Trending Product Text',
    'section'               => 'ecommerce_x_frontpage_new_arrival_top_rated_trending_product_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_trending_product_slider_text',
) );
/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Subscribe form Settings
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_subscribe_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Subscribe Section', 'ecommerce-x' )
    )
);

/**
 * Switch option for Service Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_subscribe_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_subscribe_option',
    array(
        'label'         => __( 'Frontpage Subscribe Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Subscribe section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_subscribe_section',
        'settings'      => 'ecommerce_x_frontpage_subscribe_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   
//Subscribe Section title and short info
$wp_customize->add_setting( 'ecommerce_x_subscribe_page_title', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'ecommerce_x_sanitize_dropdown_pages'
) );

$wp_customize->add_control( 'ecommerce_x_subscribe_page_title', array(
    'label'                 =>  __( 'Select Page for Subscribe Title and Description', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_subscribe_section',
    'type'                  => 'dropdown-pages',
    'settings'              => 'ecommerce_x_subscribe_page_title',
) );

// Subscribe Form Shortcode Descriptions
$wp_customize->add_setting( 'ecommerce_x_news_letter_form_code', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_news_letter_form_code', array(
    'label'                 =>  __( 'Subscribe Section Use Shortcode', 'ecommerce-x' ),
    /* translators: %s: Description */ 
    'description'           => sprintf( __( 'Use Newsletter Plugins shortcode: Eg: %1$s. %2$s See more here %3$s', 'ecommerce-x' ), '[newsletter_form type="minimal"]','<a href="'.esc_url('https://wordpress.org/plugins/newsletter/').'" target="_blank">','</a>' ),
    'section'               => 'ecommerce_x_frontpage_subscribe_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_news_letter_form_code',
) );


/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Front Service section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_service_section',
    array(
        'priority'       => 5,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Service Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Service display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Service Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_service_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);
$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_service_option',
    array(
        'label'         => __( 'Frontpage Service Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Service section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_service_section',
        'settings'      => 'ecommerce_x_frontpage_service_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

 /**
 *  Category Selection for Frontpage Service Section
 *
 * @since 1.0.0
 */
 $wp_customize->add_setting(
    'ecommerce_x_frontpage_service_category',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_category',
    )
);

 $wp_customize->add_control( new Ecommerce_X_Customize_Dropdown_Taxonomies_Control($wp_customize,
    'ecommerce_x_frontpage_service_category',
    array(
        'label' => __('Select Category for Service','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_service_section',
        'settings' => 'ecommerce_x_frontpage_service_category',
        'type'=> 'dropdown-post-taxonomies',
    )
)
);

 $wp_customize->add_setting( 'ecommerce_x_frontpage_service_items_number', array(
    'capability'            => 'edit_theme_options',
    'default'               => 3,
    'sanitize_callback'     => 'absint'
));


 $wp_customize->add_control( 'ecommerce_x_frontpage_service_items_number', array(
    'label'                 =>  __( 'Number of service to display', 'ecommerce-x' ),
    'description'           =>  __( 'input 3,4,5,6,7,8,9,10', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_service_section',
    'type'                  => 'number',
    'settings' => 'ecommerce_x_frontpage_service_items_number',
) ); 


 /*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Front Latest News section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_latest_news_section',
    array(
        'priority'       => 6,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Latest News Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Latest News display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Latest News Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_latest_news_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_latest_news_option',
    array(
        'label'         => __( 'Frontpage Latest News Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Latest News section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_latest_news_section',
        'settings'      => 'ecommerce_x_frontpage_latest_news_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

$wp_customize->add_setting( 'ecommerce_x_frontpage_latest_news_text', array(
    'capability'            => 'edit_theme_options',
    'default'               => '',
    'sanitize_callback'     => 'sanitize_text_field'
) );

$wp_customize->add_control( 'ecommerce_x_frontpage_latest_news_text', array(
    'label'                 =>   __( 'Recent Blogs Title', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_latest_news_section',
    'type'                  => 'text',
    'settings' => 'ecommerce_x_frontpage_latest_news_text',
) );

 /**
 *  Category Selection for Frontpage Latest News Section
 *
 * @since 1.0.0
 */
 $wp_customize->add_setting(
    'ecommerce_x_frontpage_latest_news_category',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => '1',
        'sanitize_callback' => 'ecommerce_x_sanitize_category',
    )
);

 $wp_customize->add_control( new Ecommerce_X_Customize_Dropdown_Taxonomies_Control(
    $wp_customize,
    'ecommerce_x_frontpage_latest_news_category',
    array(
        'label' => __('Select Category for Service','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_latest_news_section',
        'settings' => 'ecommerce_x_frontpage_latest_news_category',
        'type'=> 'dropdown-post-taxonomies',
    )
)
);

 $wp_customize->add_setting( 'ecommerce_x_frontpage_latest_news_items_number', array(
    'capability'            => 'edit_theme_options',
    'default'               => 3,
    'sanitize_callback'     => 'absint'
));


 $wp_customize->add_control( 'ecommerce_x_frontpage_latest_news_items_number', array(
    'label'                 =>  __( 'Number of Latest News to display', 'ecommerce-x' ),
    'description'           =>  __( 'input 3,4,5,6,7,8,9,10', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_latest_news_section',
    'type'                  => 'number',
    'settings' => 'ecommerce_x_frontpage_latest_news_items_number',
) ); 


 /*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Frontpage Partners section
 *
 * @since 1.0.0
 */
$wp_customize->add_section(
    'ecommerce_x_frontpage_partner_section',
    array(
        'priority'       => 6,
        'panel'          => 'ecommerce_x_frontpage_settings_panel',
        'capability'     => 'edit_theme_options',
        'theme_supports' => '',
        'title'          => __( 'Partner Section', 'ecommerce-x' ),
        'description'    => __( 'Managed the Partner display at Frontpage section.', 'ecommerce-x' ),
    )
);

/**
 * Switch option for Partner Options
 *
 * @since 1.0.0
 */
$wp_customize->add_setting(
    'ecommerce_x_frontpage_partner_option',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_switch_option',
    )
);

$wp_customize->add_control( new Ecommerce_X_Customize_Switch_Control(
    $wp_customize,
    'ecommerce_x_frontpage_partner_option',
    array(
        'label'         => __( 'Frontpage Partner Option', 'ecommerce-x' ),
        'description'   => __( 'Show/Hide option for Frontpage Partner section.', 'ecommerce-x' ),
        'section'       => 'ecommerce_x_frontpage_partner_section',
        'settings'      => 'ecommerce_x_frontpage_partner_option',
        'type'          => 'switch',
        'choices'       => array(
            'show'          => __( 'Show', 'ecommerce-x' ),
            'hide'          => __( 'Hide', 'ecommerce-x' )
        )
    )
)
);   

 /**
 *  Category Selection for Frontpage Partner Section
 *
 * @since 1.0.0
 */
 $wp_customize->add_setting(
    'ecommerce_x_frontpage_partner_category',
    array(
        'capability'        => 'edit_theme_options',
        'default'           => 'show',
        'sanitize_callback' => 'ecommerce_x_sanitize_category',
    )
);

 $wp_customize->add_control( new Ecommerce_X_Customize_Dropdown_Taxonomies_Control(
    $wp_customize,
    'ecommerce_x_frontpage_partner_category',
    array(
        'label' => __('Select Category for Partner','ecommerce-x'),
        'section' => 'ecommerce_x_frontpage_partner_section',
        'settings' => 'ecommerce_x_frontpage_partner_category',
        'type'=> 'dropdown-post-taxonomies',
    )
)
);

 $wp_customize->add_setting( 'ecommerce_x_frontpage_partner_items_number', array(
    'capability'            => 'edit_theme_options',
    'default'               => 5,
    'sanitize_callback'     => 'absint'
));


 $wp_customize->add_control( 'ecommerce_x_frontpage_partner_items_number', array(
    'label'                 =>  __( 'Number of Partner to display', 'ecommerce-x' ),
    'description'           =>  __( 'Input 3,4,5,6,7,8,9,10', 'ecommerce-x' ),
    'section'               => 'ecommerce_x_frontpage_partner_section',
    'type'                  => 'number',
    'settings' => 'ecommerce_x_frontpage_partner_items_number',
) ); 
}