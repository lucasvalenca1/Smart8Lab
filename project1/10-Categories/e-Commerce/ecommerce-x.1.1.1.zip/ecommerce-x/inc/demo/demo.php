<?php
/**
 * Demo configuration
 *
 * @package WP Commerce
 */

$config = array(
	'static_page'    => 'home',
	'menu_locations' => array(
		'primary-menu' 	=> 'primary-menu',
		'footer-top' 	=> 'footer-top',
		'footer-link-1' 	=> 'footer-link-1',
		'footer-link-2' 	=> 'footer-link-2',
		'footer-link-3' 	=> 'footer-link-3',
		'categories' 	=> 'categories',
	),
	'ocdi'           => array(
		array(
			'import_file_name'             => esc_html__( 'Import Ecommerce X Demo', 'ecommerce-x' ),
			'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo/contents.xml',
			'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo/widgets.wie',
			'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo/customizer.dat',
			'import_notice'                => __( 'It will overwrite your settings', 'ecommerce-x' ),
			'preview_url'                  => 'https://wpcodethemes.com/ecommerce-x/',
		),
		
	),
);

Ecommerce_X_Demo::init( apply_filters( 'ecommerce_x_demo_filter', $config ) );