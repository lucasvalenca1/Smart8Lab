<?php
function ecommerce_x_scripts() {
	// Google Font
	wp_enqueue_style( 'google-font', 'https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i', array(), '' );
	
	// Load Bootstrap CSS
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() .'/assets/css/bootstrap.min.css', array(), '4.1.1' );

	// Load Fontawesome CSS
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() .'/assets/css/font-awesome.min.css', array(), '4.7.0' );

	// Smartmenu CSS
	wp_enqueue_style( 'smartmenus', get_template_directory_uri() .'/assets/css/jquery.smartmenus.bootstrap-4.css', array(), '4.7.0' );

	// Jquery UI CSS
	wp_enqueue_style( 'jquery-ui', get_template_directory_uri() .'/assets/css/jquery-ui.min.css', array(), '1.12.1' );

	// Slick CSS
	wp_enqueue_style( 'slick', get_template_directory_uri() .'/assets/css/slick.css', array(), '1.9.0' );

	// Slick Theme CSS
	wp_enqueue_style( 'slick-theme', get_template_directory_uri() .'/assets/css/slick-theme.css', array(), '1.9.0' );

	//Stylesheet css 
	wp_enqueue_style( 'ecommerce-x-style', get_stylesheet_uri() );

	wp_enqueue_script("jquery-ui-core"); 
	// Popper Js
	wp_enqueue_script( 'popper', get_template_directory_uri() . '/assets/js/popper.min.js', array(), '1.12.1', true );

	// Bootstrap Js
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array(), '4.1.1', true );

	// Smartmenus Js
	wp_enqueue_script( 'jquery-smartmenus', get_template_directory_uri() . '/assets/js/jquery.smartmenus.min.js', array(), '4.1.1', true );

	// Jquery Smartmenus Bootstrap 4 Js
	wp_enqueue_script( 'jquery-smartmenus-bootstrap-js', get_template_directory_uri() . '/assets/js/jquery.smartmenus.bootstrap-4.min.js', array(), '4.1.1', true );

	// Jquery Zoom Js
	wp_enqueue_script( 'jquery-zoom', get_template_directory_uri() . '/assets/js/jquery.zoom.min.js', array(), '1.7.21', true );

	// Slick Js
	wp_enqueue_script( 'slick', get_template_directory_uri() . '/assets/js/slick.min.js', array(), '1.9.0', true );

	// Countdown Js
	wp_enqueue_script( 'ecommerce-x-countdown', get_template_directory_uri() . '/assets/js/countdown.js', array(), '1.0.0', true );

	// My Jquery Js
	wp_enqueue_script( 'ecommerce-x-main', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0.0', true );

	wp_enqueue_script( 'ecommerce-x-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'ecommerce-x-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ecommerce_x_scripts' );