<?php
/**
 * Woocommerce Functions
 */
require get_template_directory() . '/inc/woocommerce-functions.php';