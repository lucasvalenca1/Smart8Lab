<?php
/**
 * Files to managed the all function related to widgets
 *
 * @package Excommerce X
 * @since 1.0.0
 *
 */

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ecommerce_x_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'ecommerce-x' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'ecommerce-x' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s categories-item">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="main-title">
		<h5 class="widget-title">',
		'after_title'   => '</h5></div>',
	) );

	/**
	 * register Shop sidebar
	 *
	 * @since 1.0.0
	 */
	register_sidebar( array(
		'name'          => esc_html__( 'Shop Sidebar', 'ecommerce-x' ),
		'id'            => 'shop-sidebar',
		'description'   => esc_html__( 'Add widgets here.', 'ecommerce-x' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s categories-item">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="main-title"><h5 class="widget-title">',
		'after_title'   => '</h5></div>',
	) );

	/**
	 * register Frontpage Popular Products Widget
	 *
	 * @since 1.0.0
	 */
	register_sidebar( array(
		'name'          => esc_html__( 'Frontpage Popular Products', 'ecommerce-x' ),
		'id'            => 'popular-product',
		'description'   => esc_html__( 'Add widgets here.', 'ecommerce-x' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	/**
	 * register  Footer Widget
	 *
	 * @since 1.0.0
	 */
	register_sidebar( array(
		'name'          => esc_html__( 'Footer widget Section', 'ecommerce-x' ),
		'id'            => 'footer-widget',
		'description'   => esc_html__( 'Add widgets here.', 'ecommerce-x' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s col-lg-3 col-sm-6">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="widget-title f-title">
		<h6>',
		'after_title'   => '</h6></div>',
	) );
}
add_action( 'widgets_init', 'ecommerce_x_widgets_init' );
/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Register various widgets
 *
 * @since 1.0.0
 */

function ecommerce_x_register_widget() {

	if( ecommerce_x_is_woocommerce_activated() ) {
		register_widget( 'Ecommerce_X_Popular_Products' );
	}
}

add_action( 'widgets_init', 'ecommerce_x_register_widget' );

/*----------------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Load important files for widgets
 *
 * @since 1.0.0
 */

require get_template_directory() . '/inc/widgets/ex-widget-fields.php';
if( ecommerce_x_is_woocommerce_activated() ) {
	require get_template_directory() . '/inc/widgets/ex-popular-product-widget.php';
}