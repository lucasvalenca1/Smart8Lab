<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Ecommerce_X
 */

?>

<div class="blog-holder">
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<a href="<?php the_permalink();?>"><?php the_post_thumbnail();?></a>
		<div class="blog-body">
			<span class="date"><?php ecommerce_x_posted_on();?></span>
			<?php
			if ( is_singular() ) :
				the_title( '<h4 class="mt-0">', '</h4>' );
			else :
				the_title( '<h4 class="mt-0"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h4>' );
			endif;?>

			<?php the_content();?>
			<?php if(!is_page()):?>
				<ul class="btm-block">
					<li><?php ecommerce_x_posted_by();?></li>
					<li><span class="title"><?php esc_html_e('Comments:','ecommerce-x');?></span> <span class="comment-number"><?php echo esc_html(get_comments_number());?></span></li>
				</ul>
			<?php endif;?>
		</div>
		<?php

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'ecommerce-x' ),
			'after'  => '</div>',
		) );
		?>
	</article><!-- #post-<?php the_ID(); ?> -->
</div>
