<div class="b-header">
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <!-- <a class="navbar-brand" href="#">Navbar</a> -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <div id="nav-icon3">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </div>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <div class="navbar-nav category-nav xl-hidden">
         <ul>
          <li class="nav-item">
            <a class="nav-link cat-title"><span class="fa fa-bars" aria-hidden="true"></span> Categories</a>
            <?php
            if ( has_nav_menu( 'categories' ) ) {
              wp_nav_menu( array(
                'theme_location'    => 'categories',
                'depth'             => 7,
                'container'   =>'ul',
                'menu_class'  =>'category-list nav navbar-nav',
                'fallback_cb'       => 'Ecommerce_X_Navwalker::fallback',
                'walker'            => new Ecommerce_X_Navwalker(),
              ));
            }
            ?>
          </li>
    
        </ul>
      </div>
      <?php
      if ( has_nav_menu( 'primary' ) ) :
        wp_nav_menu( array(
          'theme_location'    => 'primary',
          'depth'             => 7,
          'menu_class'        => 'nav navbar-nav my-nav',
          'fallback_cb'       => 'Ecommerce_X_Navwalker::fallback',
          'walker'            => new Ecommerce_X_Navwalker(),
        ));
        ?>
        <?php else : ?>
          <ul class="nav navbar-nav my-nav">
            <li class="nav-item">
             <a href="<?php echo esc_url(admin_url( 'nav-menus.php' )); ?> " class="nav-link"> <?php esc_html_e('Add a menu','ecommerce-x'); ?></a>
           </li>
         </ul>
       <?php endif; ?>
     </div>
   </div>
 </nav>
</div>