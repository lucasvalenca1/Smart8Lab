<?php if(class_exists('WooCommerce')):?>
<div class="t-header">
    <div class="container">
        <div class="top-holder navbar-expand-sm">
            <ul class="top-link navbar-nav ml-auto">
                <li class="nav-item dropdown">
                 <?php if ( is_user_logged_in() ) { ?>
                    <a class="nav-link dropdown-toggle" href="<?php echo esc_url(get_permalink( get_option('woocommerce_myaccount_page_id') )); ?>"><?php esc_html_e('My Account','ecommerce-x'); ?></a>
                <?php } 
                else { ?>
                   <a class="nav-link dropdown-toggle" href="<?php echo esc_url(get_permalink( get_option('woocommerce_myaccount_page_id') )); ?>"><?php esc_html_e('Login / Register','ecommerce-x'); ?></a>
               <?php } ?>    
               <?php if ( is_user_logged_in() ) { ?>
                   <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="<?php echo esc_url(wp_logout_url( get_permalink( wc_get_page_id( 'myaccount' ) ) ));?>"><?php esc_html_e('Logout','ecommerce-x'); ?></a></li>
                </ul>
            <?php } ?>
        </li>
        <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" href="#">  <?php esc_html_e( 'Welcome to','ecommerce-x' );?></a>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo esc_url( home_url('/') );?>"> <?php bloginfo('title');?></a></li>
            </ul>
        </li>
    </ul>
</div>
</div>
</div>
<?php endif;?>