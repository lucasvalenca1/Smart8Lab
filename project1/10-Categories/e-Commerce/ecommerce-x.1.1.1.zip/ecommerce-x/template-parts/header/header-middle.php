<?php
/**
 * header-middle.php
 *
 * @version 1.1.1
 */
?>
<div class="m-header">
    <div class="container">
        <div class="m-holder">
            <div class="row">
                <div class="col-lg-3 col-md-12">
                    <div class="logo">
                        <a href="<?php echo esc_url( home_url('/') );?>">
                            <?php
                            if(has_custom_logo()):
                                the_custom_logo();
                            else:
                                ?>
                                <h1 class="site-title"><?php esc_html(bloginfo('title'));?></h1>
                                <span class="site-description"><?php esc_html(bloginfo('description'));?></span>
                            <?php endif;?>
                        </a>
                    </div>
                </div>
                <div class="col-lg-7 col-md-12">
                    <?php
                    $ecommerce_x_header_search_option = get_theme_mod( 'ecommerce_x_header_search_option', 'show' );
                    if( $ecommerce_x_header_search_option == 'show' ) :?>
                        <div class="search">
                          <form class="my-2 my-lg-0 search-form"  method ="get" id="searchform" action="<?php echo esc_url(home_url('/'));?>">
                             <?php
                             if ( class_exists( 'WooCommerce' ) ) {  ?>
                                <div class="select-category selectdiv">
                                    <?php $args = array(
                                        'taxonomy' => 'product_cat',
                                        'show_option_all' => esc_attr__('All Categories','ecommerce-x'),
                                        'class' => 'form-control',
                                        'name' => 'product_cat',
                                        'value_field' => 'slug',
                                        'id'      => 'exampleFormControlSelect1',
                                        'selected' => isset($_GET['product_cat'])?$_GET['product_cat']:'',
                                    );
                                    wp_dropdown_categories( $args );?>
                                </div>
                                <?php
                            }
                            ?>
                            <input type="text" class="form-control" placeholder="<?php esc_attr_e('Search','ecommerce-x');?> ..." value="<?php echo get_search_query(); ?>" name="s" aria-label="Search">
                            <input type="hidden" value="product" name="post_type" id="post_type" />
                            <button class="btn" type="submit"><?php echo esc_html__('Search','ecommerce-x');?></button>
                        </form>
                    </div>
                <?php endif;?>
            </div>
            <div class="col-lg-2 col-md-12">
              <?php
              $ecommerce_x_header_cart_option = get_theme_mod( 'ecommerce_x_header_cart_option', 'show' );
              if( $ecommerce_x_header_cart_option == 'show' ) :?>
                <?php if(class_exists('WooCommerce')):?>
                   <?php ecommerce_x_add_to_cart_dropdown();?>
               <?php endif;?>
           <?php endif;?>
       </div>
   </div>
</div>
</div>
</div>