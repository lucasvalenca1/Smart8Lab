<?php
/**
 * slider-trending-products.php
 *
 * @version 1.1.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

?>
<div class="col-lg-4">
  <div class="main-title">
    <h5><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_trending_product_slider_text'));?></h5>
  </div>
  <div class="b-new-slider">
   <div class="slider-wrapper">
     <?php
     $trending_product_item_catId = get_theme_mod( 'ecommerce_x_frontpage_trending_product_items');
     $args = array(
      'post_type'      => 'product',
      'tax_query'      => array(
        array(
          'taxonomy'   => 'product_cat',
          'field'   => 'term_id',
          'terms'   => $trending_product_item_catId
        )
      )
    );
     $trending_productloop = new WP_Query($args);
     ?>
     <?php
     if ( $trending_productloop->have_posts() ):
      $i=1;
      ?>
      <?php
      while ( $trending_productloop->have_posts() ) :
        $trending_productloop->the_post();
        if($i<=3):
          ?>
          <div class="other-p-style media">
            <a href="<?php the_permalink();?>">  <?php
            the_post_thumbnail('ecommerce-x-new-arrival-108-*-119',array('class'=>'mr-3'));?></a>
            <div class="media-body">
              <a href="<?php the_permalink();?>" class="p-title"><h6 class="mt-0"><?php the_title();?></h6></a>
              <div class="price-tag">
                <div class="tag-holder">
                  <?php echo ( $product ? $product->get_price_html() : '' ); ?>
                  <div class="cart-btn">
                   <a href="<?php echo esc_url( $product ? $product->add_to_cart_url() : '' );?>" class="add-cart"><?php echo ( $product ? $product->add_to_cart_text() : '' ); ?></a>
                 </div>
               </div>
             </div>
           </div>
         </div>
       <?php endif;?>
       <?php
       $i=$i+1;
     endwhile;
     wp_reset_postdata();
   endif;?>
 </div>
 <div class="slider-wrapper">
  <?php
  if ( $trending_productloop->have_posts() ):
    $i=1;
    ?>
    <?php
    while ( $trending_productloop->have_posts() ) :
      $trending_productloop->the_post();

      if($i>=4 && $i<=6):
        ?>
        <div class="other-p-style media">
          <a href="<?php the_permalink();?>">  <?php
          the_post_thumbnail('ecommerce-x-new-arrival-108-*-119',array('class'=>'mr-3'));?></a>
          <div class="media-body">
            <a href="<?php the_permalink();?>" class="p-title"><h6 class="mt-0"><?php the_title();?></h6></a>
            <div class="price-tag">
              <div class="tag-holder">
                <?php echo ( $product ? $product->get_price_html() : '' ); ?>
                <div class="cart-btn">
                 <a href="<?php echo esc_url( $product->add_to_cart_url() );?>" class="add-cart"><?php echo $product->add_to_cart_text(); ?></a>
               </div>
             </div>
           </div>
         </div>
       </div>
     <?php endif;?>
     <?php
     $i=$i+1;
   endwhile;
   wp_reset_postdata();
 endif;?>
</div>
</div>
</div>