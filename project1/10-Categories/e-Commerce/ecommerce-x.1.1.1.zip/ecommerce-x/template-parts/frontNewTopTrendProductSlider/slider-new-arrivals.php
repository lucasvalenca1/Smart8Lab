<div class="col-lg-4 col-md-6">
  <div class="main-title">
    <h5><?php echo esc_html(get_theme_mod('ecommerce_x_frontpage_new_arrival_product_slider_text'));?></h5>
  </div>       
  <div class="b-new-slider">
    <div class="slider-wrapper">
     <?php
     $new_arrival_args = array(
      'post_type' => 'product',
      'stock' => 1,
      'orderby' =>'date',
      'order' => 'DESC' 
    );        
     $new_arrival_query = new WP_Query( $new_arrival_args );
     ?>     
     <?php
     if ( $new_arrival_query->have_posts() ):
      $i=1;
      ?>
      <?php
      while ( $new_arrival_query->have_posts() ) :
        $new_arrival_query->the_post();
        if($i<=3):
          ?>
          <div class="other-p-style media">
            <a href="<?php the_permalink();?>">  <?php 
            the_post_thumbnail('ecommerce-x-new-arrival-108-*-119',array('class'=>'mr-3'));?></a>
            <div class="media-body">
              <a href="<?php the_permalink();?>" class="p-title"><h6 class="mt-0"><?php the_title();?></h6></a>
              <div class="price-tag">
                <?php
                global $woocommerce;

                $currency = get_woocommerce_currency_symbol();
                $price = get_post_meta( get_the_ID(), '_regular_price', true);
                $sale = get_post_meta( get_the_ID(), '_sale_price', true);
                ?>
                <div class="tag-holder">
                  <span><span class="discount-tag"><?php echo esc_html($currency); echo esc_html($price); ?></span><?php echo esc_html($currency); echo esc_html($sale); ?></span>
                  <div class="cart-btn">
                     <?php global $product;?>
                    <a href="<?php echo esc_url( $product->add_to_cart_url() );?>" class="add-cart"><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endif;?>
        <?php 
        $i=$i+1;
      endwhile;
      wp_reset_postdata();
    endif;?>  
  </div>
  <div class="slider-wrapper">
    <?php
    if ( $new_arrival_query->have_posts() ):
      $i=1;
      ?>
      <?php
      while ( $new_arrival_query->have_posts() ) :
        $new_arrival_query->the_post();

        if($i>=4 && $i<=6):
          ?>
          <div class="other-p-style media">
            <a href="<?php the_permalink();?>">  <?php 
            the_post_thumbnail('ecommerce-x-new-arrival-108-*-119',array('class'=>'mr-3'));?></a>
            <div class="media-body">
              <a href="<?php the_permalink();?>" class="p-title"><h6 class="mt-0"><?php the_title();?></h6></a>
              <div class="price-tag">
                <?php
                global $woocommerce;

                $currency = get_woocommerce_currency_symbol();
                $price = get_post_meta( get_the_ID(), '_regular_price', true);
                $sale = get_post_meta( get_the_ID(), '_sale_price', true);
                ?>
                <div class="tag-holder">
                  <span><span class="discount-tag"><?php echo esc_html($currency); echo esc_html($price); ?></span><?php echo esc_html($currency); echo esc_html($sale); ?></span>
                  <div class="cart-btn">
                     <?php global $product;?>
                    <a href="<?php echo esc_url( $product->add_to_cart_url() );?>" class="add-cart"><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php endif;?>
        <?php 
        $i=$i+1;
      endwhile;
      wp_reset_postdata();
    endif;?>  
  </div>
</div>
</div>
