<?php
/**
 * Ecommerce X functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @version 1.1.0
 * @package Ecommerce_X
 */

if ( ! function_exists( 'ecommerce_x_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function ecommerce_x_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Ecommerce X, use a find and replace
		 * to change 'ecommerce-x' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'ecommerce-x', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		add_image_size( 'ecommerce-x-add-to-cart-dropdown-74-*-81', 74,81,true);
		add_image_size( 'ecommerce-x-banner-1343-*-613', 1343,613,true);
		add_image_size( 'ecommerce-x-featured-product-1343-*-613', 350,211,true);
		add_image_size( 'ecommerce-x-trending-product-255-*-325', 255,325,true);
		add_image_size( 'ecommerce-x-product-product-category-540-*-539', 540,539,true);
		add_image_size( 'ecommerce-x-new-arrival-108-*-119', 108,119,true);
		add_image_size( 'ecommerce-x-deal-of-the-week-445-*-568', 445,568,true);
		add_image_size( 'ecommerce-x-blog-825-*-346', 825,346,true);
		add_image_size( 'ecommerce-x-service-33-*-28', 33,28,true);
		add_image_size( 'ecommerce-x-blog-featured-image-540-*-495', 540, 495,true);
		add_image_size( 'ecommerce-x-blog-image-257-*-232', 257, 232,true);
		add_image_size( 'ecommerce-x-partner-logo-215-*-156', 215, 156,true);
		add_image_size( 'ecommerce-x-single-product-270-*-345', 270, 345,true);
		add_image_size('ecommerce-x-single-product-thumb-510*-510',510,510,true);
		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary Menu', 'ecommerce-x' ),
			'categories'    => __( 'Top Left Menu (Categories)', 'ecommerce-x' ),
			'footer-top'    => __( 'Footer Top Menu', 'ecommerce-x' ),
			'footer-link-1'    => __( 'Footer Link Menu 1', 'ecommerce-x' ),
			'footer-link-2'    => __( 'Footer Link Menu 2', 'ecommerce-x' ),
			'footer-link-3'    => __( 'Footer Link Menu 3', 'ecommerce-x' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'ecommerce_x_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Woocommerce Support
		add_theme_support( 'woocommerce' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'ecommerce_x_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function ecommerce_x_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'ecommerce_x_content_width', 640 );
}
add_action( 'after_setup_theme', 'ecommerce_x_content_width', 0 );

/**
 * Enqueue scripts and styles.
 */
require get_template_directory() . '/inc/enqueue.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';

/**
* Bootstrap Navwalker
*/
require get_template_directory() . '/inc/wp-bootstrap-navwalker.php';

/**
* Popular Product Widget
*/
require get_template_directory() . '/inc/widgets/ex-widget-functions.php';

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce.php';
}


add_filter('walker_nav_menu_start_el', 'ecommere_x_walker_nav_menu_start_el', 10, 4);

function ecommere_x_walker_nav_menu_start_el($item_output, $item, $depth = 0, $args = array(), $id = 0)
{
	if ( $depth == 0 ) {
		$item_output = preg_replace('/<a /', '<a class="nav-link" ', $item_output, 1);
	} else if ( $depth > 0 ){
		$item_output = preg_replace('/<a /', '<a class="dropdown-item" ', $item_output, 1);
	}
	return $item_output;
}

/**
 * Display category image on category archive
 *
 * @version 1.1.0
 */
add_action( 'woocommerce_archive_description', 'ecommerce_x_woocommerce_category_image', 2 );
function ecommerce_x_woocommerce_category_image() {
	if ( is_product_category() ){
		global $wp_query;
		$cat = $wp_query->get_queried_object();
		$thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
		$image = wp_get_attachment_url( $thumbnail_id );
		if ( $image ) {
			echo '<div class="top-img">';
			echo '<img src="' . esc_url($image) . '" alt="' . esc_html($cat->name) . '" />';
			echo '</div>';
		}
	}
}

function ecommerce_x_get_woocommerce_product_by_id($product_id){
	if($product_id){
		$_product = new WC_Product($product_id);
		?>
		<div class="col-lg-3 col-sm-6 cols">
			<div class="product-holder">
				<div class="img-holder">
					<?php
					$img_url = get_the_post_thumbnail_url( $product_id, 'ecommerce-x-trending-product-255-*-325' );
					if($img_url){?>
						<img src="<?php echo esc_url($img_url);?>" alt="">
					<?php }
					?>
					<?php if ( $_product->is_on_sale() ) : ?>
						<div class="tag">
							<span><?php echo esc_html__('Sale','ecommerce-x');?></span>
						</div>
					<?php endif;?>
					<ul class="option">
						<li>
							<a href="<?php echo esc_url(get_permalink($product_id));?>" data-toggle="tooltip" data-placement="top" title="View">
								<span class="fa fa-search" aria-hidden="true"></span>
							</a>
						</li>
					</ul>
				</div>
				<a href="<?php echo esc_url(get_permalink($product_id));?>" class="p-title"><h6><?php echo esc_html(get_the_title($product_id));?></h6></a>
				<?php
				global $woocommerce;
				$currency = get_woocommerce_currency_symbol();
				$sale = get_post_meta( $product_id, '_sale_price', true);
				$regular_price = get_post_meta( $product_id, '_regular_price', true);
				?>
				<div class="price-tag">
					<div class="tag-holder">
						<span><span class="discount-tag"><?php echo esc_html($currency);?> <?php echo esc_html($regular_price);?></span><?php echo esc_html($currency);?> <?php echo esc_html($sale);?></span>
						<div class="cart-btn">
							<a href="<?php echo esc_url( $_product->add_to_cart_url() );?>" class="add-cart"><?php echo esc_html__('Add to cart','ecommerce-x');?></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}
}

/**
 * ecommerce_x_get_woocommerce_category_by_id.
 *
 * @version 1.1.0
 */
function ecommerce_x_get_woocommerce_category_by_id( $category_id ) {
	if($category_id){
		$catId = get_term( $category_id, 'product_cat' );
		if(!empty($catId->term_id)):
			$thumbnail_id = get_term_meta( $catId->term_id, 'thumbnail_id', true );
			$image = wp_get_attachment_image_src( $thumbnail_id, 'ecommerce-x-product-product-category-540-*-540' );
			?>
			<div class="col-lg-6 cols">
				<div class="cat-holder">
					<a href="<?php echo esc_url(get_category_link($category_id));?>"><?php
					if($image): ?>
						<img src="<?php echo esc_url($image[0]);?>" alt="">
					<?php endif; ?>
				</a>
				<div class="caption">
					<h6><?php echo esc_html($catId->name);?></h6>
					<a href="<?php echo esc_url(get_category_link($category_id));?>"><?php echo esc_html__('Discover Now','ecommerce-x');?></a>
				</div>
			</div>
		</div>
	<?php endif;
}
}


if ( is_admin() ) {
	// Load about.
	require_once trailingslashit( get_template_directory() ) . '/inc/theme-info/class-about.php';
	require_once trailingslashit( get_template_directory() ) . '/inc/theme-info/about.php';

	// Load demo.
	require_once trailingslashit( get_template_directory() ) . '/inc/demo/class-demo.php';
	require_once trailingslashit( get_template_directory() ) . '/inc/demo/demo.php';
}
/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

