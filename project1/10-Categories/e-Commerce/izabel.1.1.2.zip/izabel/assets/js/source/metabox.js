jQuery(document).ready(function(){jQuery("#izabel-ui-tabs").tabs()});
