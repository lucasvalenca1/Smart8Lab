<?php
/**
 * The template used for displaying credits
 *
 * @package Izabel
 */
?>

<?php
/**
 * izabel_credits hook
 * @hooked izabel_footer_content - 10
 */
do_action( 'izabel_credits' );
