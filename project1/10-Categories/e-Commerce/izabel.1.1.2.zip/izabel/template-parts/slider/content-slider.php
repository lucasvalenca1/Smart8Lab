<?php
/**
 * The template used for displaying slider
 *
 * @package Izabel
 */
?>

<?php
/**
 * izabel_slider hook
 * @hooked izabel_slider - 10
 */
do_action( 'izabel_slider' );
