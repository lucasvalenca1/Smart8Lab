<?php
/**
 * The template used for displaying service
 *
 * @package Izabel
 */
?>

<?php
/**
 * izabel_service hook
 * @hooked izabel_service_display - 10
 */
do_action( 'izabel_service' );
