=== Online Bazzar ===

Contributors: sparklewpthemes
Tags: one-column, two-columns, right-sidebar, left-sidebar, custom-header, custom-background, custom-menu, translation-ready, featured-images, theme-options, custom-logo, e-commerce, footer-widgets
Requires at least: 4.7
Tested up to: 4.9.8
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Online Bazaar is a powerful, dynamic and highly customized child theme of Metrostore Free multipurpose e-commerce theme. Online Bazaar free WooCommerce WordPress theme suitable for eCommerce websites of any store type : fashion store, sports store, men - women or children store, jewelry store, kitchen or food store, toys store, digital product store, affiliate store or all in one store, Its modern design is perfect to create a website for your business. Online Bazaar is easy to use and fully responsive free WordPress theme, a theme is packed with lots of exciting features that enhance the eCommerce experience. A theme is fully compatible with most popular WooCommerce, YITH WooCommerce Wishlist, YITH WooCommerce Quick View and many more plugins. This theme packs many premium features and several custom widgets which helps to make your online store professional and well organized, Use this theme for your e-commerce website, you will feel the best ever experience.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Online Bazaar WordPress Theme is child theme of MetroStore, Copyright 2017 Sparkle Themes.
Online Bazaar is distributed under the terms of the GNU GPL

== Credits ==

	Images used in screenshot

	https://pixabay.com/en/gadgets-office-equipment-iphone-336635/       License CC0 Public
	https://pixabay.com/en/fashion-accessory-book-smartphone-2569051/    License CC0 Public
	https://pixabay.com/en/headset-head-set-headphones-audio-145520/     License CC0 Public
	https://pixabay.com/en/portrait-adult-woman-people-young-3240569/    License CC0 Public
	https://pixabay.com/en/chronometer-wrist-watch-gold-golden-2157265/  License CC0 Public
	https://pixabay.com/en/analytics-charts-business-woman-3265840/      License CC0 Public
	https://pixabay.com/en/people-man-business-adult-portrait-3146278/   License CC0 Public
	https://pixabay.com/en/camera-video-tv-video-realization-1598620/    License CC0 Public


== Changelog ==

= 1.0.2 3rd Oct 2018 =

 ** Remove simple and clean theme word form screenshot.

= 1.0.1 3rd Oct 2018 =

 ** Update simple and clean theme screenshot.

= 1.0.0 18th Sept 2018 =

 ** Initial submit theme on wordpress.org trac.