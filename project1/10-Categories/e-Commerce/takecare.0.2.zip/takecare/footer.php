<?php
/**
 * footer Template.
 *
 * @package takecare
 */
?>
<?php get_template_part('design/template/footer/template', 'footerbottom');?>
<?php wp_footer(); ?>
</body>
</html>