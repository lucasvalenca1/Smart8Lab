<?php   
/**
 * @package takecare
 */
?>
<?php
require_once get_template_directory()."/vendor/require/customizer/takecare_customizer.php";
require_once get_template_directory()."/vendor/takecare_custom_jsstyle.php";
require_once get_template_directory()."/vendor/takecare_custom_themesupport.php";
require_once get_template_directory()."/vendor/takecare_custom_banners.php";
require_once get_template_directory()."/vendor/takecare_custom_widgets.php";
require_once get_template_directory()."/vendor/takecare_custom_content_excerpt.php";