<main id="main" class="site-main ">

    <div id="container" class="<?php echo esc_attr( refru_container_css_class() ); ?>">

        <div class="<?php echo esc_attr( refru_main_css_class() ); ?>">

            <div id="content" class="<?php echo esc_attr( refru_content_css_class() ); ?>">