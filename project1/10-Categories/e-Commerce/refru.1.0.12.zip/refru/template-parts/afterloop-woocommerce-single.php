					<div class="clearfix"></div>

					</div><!-- /content -->