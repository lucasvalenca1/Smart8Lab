<?php

wp_enqueue_style( 'refru_style', get_stylesheet_uri() );
