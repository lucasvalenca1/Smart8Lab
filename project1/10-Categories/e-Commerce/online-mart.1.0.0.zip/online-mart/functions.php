<?php
/**
 * Describe child theme functions
 *
 * @package Easy Store
 * @subpackage Online Mart
 * 
 */

/*-------------------------------------------------------------------------------------------------------------------------------*/
if ( ! function_exists( 'online_mart_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function online_mart_setup() {

    $online_mart_theme_info = wp_get_theme();
    $GLOBALS['online_mart_version'] = $online_mart_theme_info->get( 'Version' );

}
endif;

add_action( 'after_setup_theme', 'online_mart_setup' );

/*-------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Register Google fonts
 *
 * @return string Google fonts URL for the theme.
 * @since 1.0.0
 */
if ( ! function_exists( 'online_mart_fonts_url' ) ) :
    function online_mart_fonts_url() {

        $fonts_url = '';
        $font_families = array();

        /*
         * Translators: If there are characters in your language that are not supported
         * by Roboto, translate this to 'off'. Do not translate into your own language.
         */
        if ( 'off' !== _x( 'on', 'Roboto font: on or off', 'online-mart' ) ) {
            $font_families[] = 'Roboto:300,400,400i,500,700,900';
        }

        if( $font_families ) {
            $query_args = array(
                'family' => urlencode( implode( '|', $font_families ) ),
                'subset' => urlencode( 'latin,latin-ext' ),
            );

            $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
        }

        return $fonts_url;
    }
endif;

/*-------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Managed the theme default color
 */
function online_mart_customize_register( $wp_customize ) {
		global $wp_customize;

		$wp_customize->get_setting( 'easy_store_primary_theme_color' )->default = '#f07f13';

        $wp_customize->get_setting( 'easy_store_secondary_theme_color' )->default = '#333333';

        $wp_customize->remove_control( 'easy_store_wishlist_text' );

	}

add_action( 'customize_register', 'online_mart_customize_register', 20 );

/*-------------------------------------------------------------------------------------------------------------------------------*/
/**
 * Enqueue child theme styles and scripts
 */
add_action( 'wp_enqueue_scripts', 'online_mart_scripts', 20 );

function online_mart_scripts() {
    
    global $online_mart_version;
    
    wp_enqueue_style( 'online-mart-google-font', online_mart_fonts_url(), array(), null );
    
    wp_dequeue_style( 'easy-store-style' );
    
    wp_dequeue_style( 'easy-store-responsive-style' );
    
	wp_enqueue_style( 'easy-store-parent-style', get_template_directory_uri() . '/style.css', array(), esc_attr( $online_mart_version ) );
    
    wp_enqueue_style( 'easy-store-parent-responsive', get_template_directory_uri() . '/assets/css/es-responsive.css', array(), esc_attr( $online_mart_version ) );
    
    wp_enqueue_style( 'online-mart-style', get_stylesheet_uri(), array(), esc_attr( $online_mart_version ) );
    
    $get_categories = get_categories( array( 'hide_empty' => 1 ) );
    
    $online_mart_primary_theme_color = get_theme_mod( 'easy_store_primary_theme_color', '#f07f13' );
    $online_mart_secondary_theme_color = get_theme_mod( 'easy_store_secondary_theme_color', '#333333' );
    
    $output_css = '';
    

    $output_css .= ".edit-link .post-edit-link,.reply .comment-reply-link,.widget_search .search-submit,.widget_search .search-submit,.woocommerce .price-cart:after,.woocommerce ul.products li.product .price-cart .button:hover,.woocommerce .widget_price_filter .ui-slider .ui-slider-range,.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,.woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content,.woocommerce #respond input#submit:hover,.woocommerce a.button:hover,.woocommerce button.button:hover,.woocommerce input.button:hover,.woocommerce #respond input#submit.alt:hover,.woocommerce a.button.alt:hover,.woocommerce button.button.alt:hover,.woocommerce input.button.alt:hover,.woocommerce .added_to_cart.wc-forward:hover,.woocommerce ul.products li.product .onsale, .woocommerce span.onsale,.woocommerce #respond input#submit.alt.disabled,.woocommerce #respond input#submit.alt.disabled:hover,.woocommerce #respond input#submit.alt:disabled,.woocommerce #respond input#submit.alt:disabled:hover,.woocommerce #respond input#submit.alt[disabled]:disabled,.woocommerce #respond input#submit.alt[disabled]:disabled:hover,.woocommerce a.button.alt.disabled,.woocommerce a.button.alt.disabled:hover,.woocommerce a.button.alt:disabled,.woocommerce a.button.alt:disabled:hover,.woocommerce a.button.alt[disabled]:disabled,.woocommerce a.button.alt[disabled]:disabled:hover,.woocommerce button.button.alt.disabled,.woocommerce button.button.alt.disabled:hover,.woocommerce button.button.alt:disabled,.woocommerce button.button.alt:disabled:hover,.woocommerce button.button.alt[disabled]:disabled,.woocommerce button.button.alt[disabled]:disabled:hover,.woocommerce input.button.alt.disabled,.woocommerce input.button.alt.disabled:hover,.woocommerce input.button.alt:disabled,.woocommerce input.button.alt:disabled:hover,.woocommerce input.button.alt[disabled]:disabled,.woocommerce input.button.alt[disabled]:disabled:hover,.woocommerce-info, .woocommerce-noreviews, p.no-comments,#masthead .site-header-cart .cart-con.tenr#masthead .countts:hover,.es-main-menu-wrapper .mt-container,#site-navigation ul.sub-menu,#site-navigation ul.children,.easy_store_slider .es-slide-btn a:hover,.woocommerce-active .es-product-buttons-wrap a:hover,.woocommerce-active ul.products li.product .button:hover,.easy_store_testimonials .es-single-wrap .image-holder::after,.easy_store_testimonials .lSSlideOuter .lSPager.lSpg > li:hover a,.easy_store_testimonials .lSSlideOuter .lSPager.lSpg > li.active a,.cta-btn-wrap a,.main-post-wrap .post-date-wrap,.list-posts-wrap .post-date-wrap,.entry-content-wrapper .post-date-wrap,.widget .tagcloud a:hover,#es-scrollup,.easy_store_social_media a,.is-sticky .es-main-menu-wrapper, #masthead .site-header-cart .cart-contents:hover,#masthead .count,.home .widget .onsale{ background: ". esc_attr( $online_mart_primary_theme_color ) ."}\n";
    
    $output_css .= "a,.entry-footer a:hover,.comment-author .fn .url:hover,.commentmetadata .comment-edit-link,#cancel-comment-reply-link,#cancel-comment-reply-link:before,.logged-in-as a,.widget a:hover,.widget a:hover::before,.widget li:hover::before,.woocommerce .woocommerce-message:before,.woocommerce div.product p.price ins,.woocommerce div.product span.price ins,.woocommerce div.product p.price del,.woocommerce .woocommerce-info:before,.woocommerce .star-rating span::before,.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul a:hover,.woocommerce-account .woocommerce .woocommerce-MyAccount-navigation ul li.is-active a:hover,.es-top-header-wrap .item-icon,.promo-items-wrapper .item-icon-wrap,.main-post-wrap .blog-content-wrapper .news-title a:hover,.list-posts-wrap .blog-content-wrapper .news-title a:hover,.entry-content-wrapper .entry-title a:hover,.blog-content-wrapper .post-meta span:hover, .blog-content-wrapper .post-meta span a:hover,.entry-content-wrapper .post-meta span:hover,.entry-content-wrapper .post-meta span a:hover,#footer-navigation ul li a:hover,.custom-header .breadcrumb-trail.breadcrumbs ul li a,.es-product-title-wrap a:hover .woocommerce-loop-product__title,#masthead .site-header-cart .cart-contents  { color: ". esc_attr( $online_mart_primary_theme_color ) ."}\n";
    
    $output_css .= ".navigation .nav-links a,.bttn,button,input[type='button'],input[type='reset'],input[type='submit'],.widget_search .search-submit,.woocommerce form .form-row.woocommerce-validated .select2-container,.woocommerce form .form-row.woocommerce-validated input.input-text,.woocommerce form .form-row.woocommerce-validated select,.tagcloud a:hover,#masthead .site-header-cart .cart-contents{ border-color: ". esc_attr( $online_mart_primary_theme_color ) ."}\n";
    
    $output_css .= ".comment-list .comment-body { border-top-color: ". esc_attr( $online_mart_primary_theme_color ) ."}\n";
    
    $output_css .= "@media (max-width: 768px){.es-main-menu-wrapper #site-navigation { background: ". esc_attr( $online_mart_primary_theme_color ) ."}}\n";
    
    $output_css .= ".navigation .nav-links a:hover,.bttn:hover,button,input[type='button']:hover,input[type='reset']:hover,input[type='submit']:hover,.home .es-home-icon a,.es-home-icon a:hover,#site-navigation ul li.current-menu-item>a,#site-navigation ul li:hover>a,#site-navigation ul li.current_page_ancestor>a,.es-wishlist-btn,.es-slide-btn a,.es-slider-section .lSAction a:hover,.easy_store_featured_products .carousel-nav-action .carousel-controls:hover,.woocommerce span.onsale, .woocommerce ul.products li.product .onsale,.es-product-buttons-wrap a.add_to_wishlist:hover,.easy_store_call_to_action .cta-btn-wrap a:hover,.easy_store_social_media a:hover,#masthead .is-sticky #site-navigation ul li.current-menu-item > a, #masthead .is-sticky #site-navigation ul li:hover > a, #masthead .is-sticky #site-navigation ul li.current_page_ancestor > a,.easy_store_slider .es-slide-btn a,#masthead .es-wl-counter{ background: ". esc_attr( $online_mart_secondary_theme_color ) ."}\n";        
    
    $output_css .= "a:hover,a:focus,a:active,.woocommerce .price_label,.woocommerce.single-product div.product .price,.easy_store_advance_product_search .woocommerce-product-search .searchsubmit:hover,.price,.woocommerce ul.products li.product .price,.easy_store_categories_collection .es-coll-link,.easy_store_testimonials .es-single-wrap .post-author,.cta-content span,.custom-header .breadcrumb-trail.breadcrumbs ul li a:hover,#masthead .es-wishlist-btn{ color: ". esc_attr( $online_mart_secondary_theme_color ) ."}\n";
    
    $output_css .= ".navigation .nav-links a:hover,.bttn:hover,button,input[type='button']:hover,input[type='reset']:hover,input[type='submit']:hover,.easy_store_featured_products .carousel-nav-action .carousel-controls:hover,#masthead .es-wishlist-btn{ border-color: ". esc_attr( $online_mart_secondary_theme_color ) ."}\n";
    
    $output_css .= "@media (max-width: 768px){.es-main-menu-wrapper .menu-toggle:hover { background: ". esc_attr( $online_mart_secondary_theme_color ) ."}}\n";
    
    $output_css .= "#es-scrollup{ border-bottom-color: ". esc_attr( $online_mart_secondary_theme_color ) ."}\n";
                
    $refine_output_css = easy_store_css_strip_whitespace( $output_css );

    wp_add_inline_style( 'online-mart-style', $refine_output_css );
    
}


/**
 * Main menu section
 *
 * @since 1.0.0
 */
if( ! function_exists( 'easy_store_main_menu_section' ) ) :
    function easy_store_main_menu_section() {
?>
        <div class="es-main-menu-wrapper">
            <div class="mt-container">
                <div class="es-home-icon">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"> <i class="fa fa-home"> </i> </a>
                </div><!-- .np-home-icon -->
                <a href="javascript:void(0)" class="menu-toggle hide"> <i class="fa fa-navicon"> </i> </a>
                <nav id="site-navigation" class="main-navigation" role="navigation">
                    <?php wp_nav_menu( array( 'theme_location' => 'easy_store_primary_menu', 'menu_id' => 'primary-menu' ) );
                    ?>
                </nav><!-- #site-navigation -->
            </div><!-- .mt-container -->
        </div><!-- .es-main-menu-wrapper -->
<?php
    }
endif;

if( ! function_exists( 'online_mart_wishlist' ) ) :

    /**
     * Wishlist 
     */

    function online_mart_wishlist() {
        $online_mart_header_wishlist_option = get_theme_mod( 'easy_store_header_wishlist_option', 'show' );
        if ( function_exists( 'YITH_WCWL' ) && $online_mart_header_wishlist_option == 'show' ) {
            $online_mart_wishlist_url = YITH_WCWL()->get_wishlist_url();
?>
                <div class="es-wishlist-wrap">
                    <a class="es-wishlist-btn" href="<?php echo esc_url( $online_mart_wishlist_url ); ?>" title="<?php esc_attr_e( 'Wishlist Tab', 'online-mart' ); ?>">
                        <i class="fa fa-heart"> </i><span class="es-wl-counter"><?php printf( esc_html( '%s', 'online-mart' ), yith_wcwl_count_products() ); ?></span>
                    </a>
                </div><!-- .es-wishlist-wrap -->
<?php
        }
    }

endif;

add_action( 'easy_store_header', 'online_mart_wishlist', 32 );