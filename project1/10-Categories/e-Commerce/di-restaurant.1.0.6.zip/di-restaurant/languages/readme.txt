This is not correct directory to upload your .po .mo files. because your files will be deleted, when you will update theme.
Please upload your translation file here -wp-root-/wp-content/languages/themes/*
.po .mo file name should be like twentysixteen-en_US.mo and twentysixteen-en_US.po
>> themename-languagecode_countrycode.mo
>> themename-languagecode_countrycode.po

To learn how to translate .pot file and for more info, please take help of Google Search Engine or create a theme support ticket.

Link for translation help: https://developer.wordpress.org/themes/functionality/localization/

Thanks
