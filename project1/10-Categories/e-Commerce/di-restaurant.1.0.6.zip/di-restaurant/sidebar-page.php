<div class="col-md-4">
	<div class="right-main-container">
		<?php do_action( 'di_restaurant_page_sidebar_file' ); ?>
	</div>
</div>
