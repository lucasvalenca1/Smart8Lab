<?php
do_action( 'di_restaurant_header_img_file' );
