<?php

do_action( 'di_restaurant_header_slider_file' );
