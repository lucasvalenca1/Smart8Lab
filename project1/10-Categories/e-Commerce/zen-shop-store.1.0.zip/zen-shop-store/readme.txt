
=== Zen Shop Store ===
Contributors: dithemes
Tags: one-column, two-columns, left-sidebar, right-sidebar, grid-layout, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, flexible-header, full-width-template, microformats, post-formats, sticky-post, theme-options, threaded-comments, translation-ready, wide-blocks, blog, e-commerce, portfolio
Requires at least: 4.6
Tested up to: 5.1.1
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Zen Shop Store is a full functional WordPress theme for eCommerce websites.

== Description ==

Zen Shop Store is a full functional WordPress theme for eCommerce websites. it is child theme of Di eCommerce theme and comes with different color scheme and have two new widgets for WooCommerce plugin : Recent Products Carousel Widget and Featured Product Widget. it is Responsive, SEO Friendly, Fast to Load and Fully Customizable eCommerce theme. it is specially designed for eCommerce websites and have additional style for WooCommerce sections. it also adds options to manage WooCommerce features like enable/disable related products, products per page, products per column etc.

== Frequently Asked Questions ==

= Installation =

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in 'Zen Shop Store' in the search form and press the 'Enter' key on your keyboard.
3. Click on 'Install' and then 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel and customize the taste.

= Where are theme settings? =

Navigate to Appearance > Customize in your admin panel.

== Changelog ==

= 1.0 =
* First release

== Upgrade Notice ==

= 1.0 =
* First release


== Resources ==

Di eCommerce © 2019 dithemes, GPL
OwlCarousel2 © 2016-2018 David Deutsch, MIT
Screenshot image : https://stocksnap.io/photo/D0ZM6DLFXY, https://stocksnap.io/photo/BRUFX98YKK, https://stocksnap.io/photo/7JMYLXUMY2 © stocksnap, CC0
