( function( $ ) {
	$(document).ready(function() {
		$('.di-recet-products-cur').owlCarousel({
			items:1,
			nav:false,
			dots:true,
			autoplay:true,
			autoplayHoverPause:true,
			loop:true,
		});
	});
} )( jQuery );
