<div class="frontTwoContainer">

	<div class="frontTwoWelcomeContainer">
		
			<?php
			
				$seyanaWelcomePostTitle = '';
				$seyanaWelcomePostDesc = '';
				$seyanaWelcomePostContent = '';

				if( '' != get_theme_mod('seyana_two_welcome_post') && 'select' != get_theme_mod('seyana_two_welcome_post') ){

					$seyanaWelcomePostId = get_theme_mod('seyana_two_welcome_post');

					if( ctype_alnum($seyanaWelcomePostId) ){

						$seyanaWelcomePost = get_post( $seyanaWelcomePostId );

						$seyanaWelcomePostTitle = $seyanaWelcomePost->post_title;
						$seyanaWelcomePostDesc = $seyanaWelcomePost->post_excerpt;
						$seyanaWelcomePostContent = $seyanaWelcomePost->post_content;

					}

				}			
			
			?>
			
			<h1><?php echo esc_html($seyanaWelcomePostTitle); ?></h1>
			<div class="frontTwoWelcomeContent">
				<p>
					<?php 
					
						if( '' != $seyanaWelcomePostDesc ){
							
							echo esc_html($seyanaWelcomePostDesc);
							
						}else{
							
							echo esc_html($seyanaWelcomePostContent);
							
						}
					
					?>
				</p>
			</div><!-- .frontTwoWelcomeContent -->	
		
	</div><!-- .frontTwoWelcomeContainer -->
	
	<div class="frontPageTwoProductsContainer">
		
		<div class="frontPageTwoProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_two_product_post_one') && 'select' != get_theme_mod('seyana_two_product_post_one') ):
			
				$seyanaProductOneTitle = '';
				$seyanaProductOneDesc = '';

				{

					$seyanaProductOneId = get_theme_mod('seyana_two_product_post_one');

					if( ctype_alnum($seyanaProductOneId) ){

						$seyanaProductOne = get_post( $seyanaProductOneId );

						$seyanaProductOneTitle = $seyanaProductOne->post_title;
						$seyanaProductOneDesc = $seyanaProductOne->post_excerpt;
						$seyanaProductOneContent = seyana_limitedstring($seyanaProductOne->post_content, 150);
						$seyanaProductOneLink = get_permalink($seyanaProductOneId);
						
						if( has_post_thumbnail( $seyanaProductOneId ) ){
							
							$seyanaProductOneImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaProductOneId ), 'seyana-producttwo' );
							$seyanaProductOneImage = $seyanaProductOneImage[0];
							
						}else{
							
							$seyanaProductOneImage = get_template_directory_uri() . '/assets/images/service.jpg';
							
						}

					}

				}			
			
			?>
			<div class="frontPageTwoProductImage">
				<img src="<?php echo esc_url($seyanaProductOneImage); ?>" />
			</div><!-- .frontPageTwoProductImage -->
			<h2><a href="<?php echo esc_url($seyanaProductOneLink); ?>"><?php echo esc_html($seyanaProductOneTitle); ?></a></h2>
			<div class="frontPageTwoProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaProductOneDesc ){
							
							echo esc_html($seyanaProductOneDesc);
							
						}else{
							
							echo esc_html($seyanaProductOneContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontTwoWelcomeContent -->			
			<?php endif; ?>
		</div><!-- .frontPageTwoProductContainer -->
		
		<div class="frontPageTwoProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_two_product_post_two') && 'select' != get_theme_mod('seyana_two_product_post_two') ):
			
				$seyanaProductTwoTitle = '';
				$seyanaProductTwoDesc = '';

					$seyanaProductTwoId = get_theme_mod('seyana_two_product_post_two');

					if( ctype_alnum($seyanaProductTwoId) ){

						$seyanaProductTwo = get_post( $seyanaProductTwoId );

						$seyanaProductTwoTitle = $seyanaProductTwo->post_title;
						$seyanaProductTwoDesc = $seyanaProductTwo->post_excerpt;
						$seyanaProductTwoContent = seyana_limitedstring($seyanaProductTwo->post_content, 150);
						$seyanaProductTwoLink = get_permalink($seyanaProductTwoId);
						
						if( has_post_thumbnail( $seyanaProductTwoId ) ){
							
							$seyanaProductTwoImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaProductTwoId ), 'seyana-producttwo' );
							$seyanaProductTwoImage = $seyanaProductTwoImage[0];
							
						}else{
							
							$seyanaProductTwoImage = get_template_directory_uri() . '/assets/images/service.jpg';
							
						}						

					}		
			
			?>
			<div class="frontPageTwoProductImage">
				<img src="<?php echo esc_url($seyanaProductTwoImage); ?>" />
			</div><!-- .frontPageTwoProductImage -->
			<h2><a href="<?php echo esc_url($seyanaProductTwoLink); ?>"><?php echo esc_html($seyanaProductTwoTitle); ?></a></h2>
			<div class="frontPageTwoProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaProductTwoDesc ){
							
							echo esc_html($seyanaProductTwoDesc);
							
						}else{
							
							echo esc_html($seyanaProductTwoContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontTwoWelcomeContent -->			
			<?php endif; ?>
		</div><!-- .frontPageTwoProductContainer -->
		
		<div class="frontPageTwoProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_two_product_post_three') && 'select' != get_theme_mod('seyana_two_product_post_three') ):
			
				$seyanaProductThreeTitle = '';
				$seyanaProductThreeDesc = '';

					$seyanaProductThreeId = get_theme_mod('seyana_two_product_post_three');

					if( ctype_alnum($seyanaProductThreeId) ){

						$seyanaProductThree = get_post( $seyanaProductThreeId );

						$seyanaProductThreeTitle = $seyanaProductThree->post_title;
						$seyanaProductThreeDesc = $seyanaProductThree->post_excerpt;
						$seyanaProductThreeContent = seyana_limitedstring($seyanaProductThree->post_content, 150);
						$seyanaProductThreeLink = get_permalink($seyanaProductThreeId);
						
						if( has_post_thumbnail( $seyanaProductThreeId ) ){
							
							$seyanaProductThreeImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaProductThreeId ), 'seyana-producttwo' );
							$seyanaProductThreeImage = $seyanaProductThreeImage[0];
							
						}else{
							
							$seyanaProductThreeImage = get_template_directory_uri() . '/assets/images/service.jpg';
							
						}						

					}			
			
			?>
			<div class="frontPageTwoProductImage">
				<img src="<?php echo esc_url($seyanaProductThreeImage); ?>" />
			</div><!-- .frontPageTwoProductImage -->
			<h2><a href="<?php echo esc_url($seyanaProductThreeLink); ?>"><?php echo esc_html($seyanaProductThreeTitle); ?></a></h2>
			<div class="frontPageTwoProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaProductThreeDesc ){
							
							echo esc_html($seyanaProductThreeDesc);
							
						}else{
							
							echo esc_html($seyanaProductThreeContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontTwoWelcomeContent -->			
			<?php endif; ?>
		</div><!-- .frontPageTwoProductContainer -->		
		
	</div><!-- .frontPageTwoProductsContainer -->
	
</div><!-- .frontPageTwoContainer -->