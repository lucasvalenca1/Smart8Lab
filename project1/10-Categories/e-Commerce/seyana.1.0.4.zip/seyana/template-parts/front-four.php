<div class="frontFourContainer">

	<div class="frontFourWelcomeContainer">
		
			<?php
			
				$seyanaWelcomePostFourTitle = '';
				$seyanaWelcomePostFourDesc = '';
				$seyanaWelcomePostFourContent = '';

				if( '' != get_theme_mod('seyana_four_welcome_post') && 'select' != get_theme_mod('seyana_four_welcome_post') ){

					$seyanaWelcomePostFourId = get_theme_mod('seyana_four_welcome_post');

					if( ctype_alnum($seyanaWelcomePostFourId) ){

						$seyanaWelcomePostFour = get_post( $seyanaWelcomePostFourId );

						$seyanaWelcomePostFourTitle = $seyanaWelcomePostFour->post_title;
						$seyanaWelcomePostFourDesc = $seyanaWelcomePostFour->post_excerpt;
						$seyanaWelcomePostFourContent = $seyanaWelcomePostFour->post_content;

					}

				}			
			
			?>
			
			<h1><?php echo esc_html($seyanaWelcomePostFourTitle); ?></h1>
			<div class="frontFourWelcomeContent">
				<p>
					<?php 
					
						if( '' != $seyanaWelcomePostFourDesc ){
							
							echo esc_html($seyanaWelcomePostFourDesc);
							
						}else{
							
							echo esc_html($seyanaWelcomePostFourContent);
							
						}
					
					?>
				</p>
			</div><!-- .frontFourWelcomeContent -->	
		
	</div><!-- .frontFourWelcomeContainer -->
	
	<div class="frontPageFourProductsContainer">
		
		<div class="frontPageFourProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_four_product_post_one') && 'select' != get_theme_mod('seyana_four_product_post_one') ):
			
				$seyanaFourProductOneTitle = '';
				$seyanaFourProductOneDesc = '';

					$seyanaFourProductOneId = get_theme_mod('seyana_four_product_post_one');

					if( ctype_alnum($seyanaFourProductOneId) ){

						$seyanaFourProductOne = get_post( $seyanaFourProductOneId );

						$seyanaFourProductOneTitle = $seyanaFourProductOne->post_title;
						$seyanaFourProductOneDesc = $seyanaFourProductOne->post_excerpt;
						$seyanaFourProductOneContent = seyana_limitedstring($seyanaFourProductOne->post_content, 50);
						$seyanaFourProductOneLink = get_permalink($seyanaFourProductOneId);
						
						if( has_post_thumbnail( $seyanaFourProductOneId ) ){
							
							$seyanaFourProductOneImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaFourProductOneId ), 'seyana-productfour' );
							$seyanaFourProductOneImage = $seyanaFourProductOneImage[0];
							
						}else{
							
							$seyanaFourProductOneImage = get_template_directory_uri() . '/assets/images/frontitemimage.png';
							
						}

					}			
			
			?>
			<div class="frontPageFourProductImage">
				<img src="<?php echo esc_url($seyanaFourProductOneImage); ?>" />
			</div><!-- .frontPageFourProductImage -->
			<h2><a href="<?php echo esc_url($seyanaFourProductOneLink); ?>"><?php echo esc_html($seyanaFourProductOneTitle); ?></a></h2>
			<div class="frontPageFourProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaFourProductOneDesc ){
							
							echo esc_html($seyanaFourProductOneDesc);
							
						}else{
							
							echo esc_html($seyanaFourProductOneContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontFourWelcomeContent -->			
			<?php endif; ?>
			
		</div><!-- .frontPageFourProductContainer -->
		
		<div class="frontPageFourProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_four_product_post_two') && 'select' != get_theme_mod('seyana_four_product_post_two') ):
			
				$seyanaFourProductTwoTitle = '';
				$seyanaFourProductTwoDesc = '';

					$seyanaFourProductTwoId = get_theme_mod('seyana_four_product_post_two');

					if( ctype_alnum($seyanaFourProductTwoId) ){

						$seyanaFourProductTwo = get_post( $seyanaFourProductTwoId );

						$seyanaFourProductTwoTitle = $seyanaFourProductTwo->post_title;
						$seyanaFourProductTwoDesc = $seyanaFourProductTwo->post_excerpt;
						$seyanaFourProductTwoContent = seyana_limitedstring($seyanaFourProductTwo->post_content, 50);
						$seyanaFourProductTwoLink = get_permalink($seyanaFourProductTwoId);
						
						if( has_post_thumbnail( $seyanaFourProductTwoId ) ){
							
							$seyanaFourProductTwoImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaFourProductTwoId ), 'seyana-productfour' );
							$seyanaFourProductTwoImage = $seyanaFourProductTwoImage[0];
							
						}else{
							
							$seyanaFourProductTwoImage = get_template_directory_uri() . '/assets/images/frontitemimage.png';
							
						}						

					}
			
			?>
			<div class="frontPageFourProductImage">
				<img src="<?php echo esc_url($seyanaFourProductTwoImage); ?>" />
			</div><!-- .frontPageFourProductImage -->
			<h2><a href="<?php echo esc_url($seyanaFourProductTwoLink); ?>"><?php echo esc_html($seyanaFourProductTwoTitle); ?></a></h2>
			<div class="frontPageFourProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaFourProductTwoDesc ){
							
							echo esc_html($seyanaFourProductTwoDesc);
							
						}else{
							
							echo esc_html($seyanaFourProductTwoContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontFourWelcomeContent -->			
			<?php endif; ?>
			
		</div><!-- .frontPageFourProductContainer -->
		
		<div class="frontPageFourProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_four_product_post_three') && 'select' != get_theme_mod('seyana_four_product_post_three') ):
			
				$seyanaFourProductThreeTitle = '';
				$seyanaFourProductThreeDesc = '';

					$seyanaFourProductThreeId = get_theme_mod('seyana_four_product_post_three');

					if( ctype_alnum($seyanaFourProductThreeId) ){

						$seyanaFourProductThree = get_post( $seyanaFourProductThreeId );

						$seyanaFourProductThreeTitle = $seyanaFourProductThree->post_title;
						$seyanaFourProductThreeDesc = $seyanaFourProductThree->post_excerpt;
						$seyanaFourProductThreeContent = seyana_limitedstring($seyanaFourProductThree->post_content, 50);
						$seyanaFourProductThreeLink = get_permalink($seyanaFourProductThreeId);
						
						if( has_post_thumbnail( $seyanaFourProductThreeId ) ){
							
							$seyanaFourProductThreeImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaFourProductThreeId ), 'seyana-productfour' );
							$seyanaFourProductThreeImage = $seyanaFourProductThreeImage[0];
							
						}else{
							
							$seyanaFourProductThreeImage = get_template_directory_uri() . '/assets/images/frontitemimage.png';
							
						}						

					}			
			
			?>
			<div class="frontPageFourProductImage">
				<img src="<?php echo esc_url($seyanaFourProductThreeImage); ?>" />
			</div><!-- .frontPageFourProductImage -->
			<h2><a href="<?php echo esc_url($seyanaFourProductThreeLink); ?>"><?php echo esc_html($seyanaFourProductThreeTitle); ?></a></h2>
			<div class="frontPageFourProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaFourProductThreeDesc ){
							
							echo esc_html($seyanaFourProductThreeDesc);
							
						}else{
							
							echo esc_html($seyanaFourProductThreeContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontFourWelcomeContent -->			
			<?php endif; ?>
		</div><!-- .frontPageFourProductContainer -->
		
		<div class="frontPageFourProductContainer">
			
			<?php
				
				if( '' != get_theme_mod('seyana_four_product_post_three') && 'select' != get_theme_mod('seyana_four_product_post_three') ):
			
				$seyanaFourProductFourTitle = '';
				$seyanaFourProductFourDesc = '';

					$seyanaFourProductFourId = get_theme_mod('seyana_four_product_post_three');

					if( ctype_alnum($seyanaFourProductFourId) ){

						$seyanaFourProductFour = get_post( $seyanaFourProductFourId );

						$seyanaFourProductFourTitle = $seyanaFourProductFour->post_title;
						$seyanaFourProductFourDesc = $seyanaFourProductFour->post_excerpt;
						$seyanaFourProductFourContent = seyana_limitedstring($seyanaFourProductFour->post_content, 50);
						$seyanaFourProductFourLink = get_permalink($seyanaFourProductFourId);
						
						if( has_post_thumbnail( $seyanaFourProductFourId ) ){
							
							$seyanaFourProductFourImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaFourProductFourId ), 'seyana-productfour' );
							$seyanaFourProductFourImage = $seyanaFourProductFourImage[0];
							
						}else{
							
							$seyanaFourProductFourImage = get_template_directory_uri() . '/assets/images/frontitemimage.png';
							
						}						

					}
			
			?>
			<div class="frontPageFourProductImage">
				<img src="<?php echo esc_url($seyanaFourProductFourImage); ?>" />
			</div><!-- .frontPageFourProductImage -->
			<h2><a href="<?php echo esc_url($seyanaFourProductFourLink); ?>"><?php echo esc_html($seyanaFourProductFourTitle); ?></a></h2>
			<div class="frontPageFourProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaFourProductFourDesc ){
							
							echo esc_html($seyanaFourProductFourDesc);
							
						}else{
							
							echo esc_html($seyanaFourProductFourContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontFourWelcomeContent -->			
			<?php endif; ?>
		</div><!-- .frontPageFourProductContainer -->
		
		<div class="frontPageFourProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_four_product_post_three') && 'select' != get_theme_mod('seyana_four_product_post_three') ):
			
				$seyanaFourProductFiveTitle = '';
				$seyanaFourProductFiveDesc = '';

					$seyanaFourProductFiveId = get_theme_mod('seyana_four_product_post_three');

					if( ctype_alnum($seyanaFourProductFiveId) ){

						$seyanaFourProductFive = get_post( $seyanaFourProductFiveId );

						$seyanaFourProductFiveTitle = $seyanaFourProductFive->post_title;
						$seyanaFourProductFiveDesc = $seyanaFourProductFive->post_excerpt;
						$seyanaFourProductFiveContent = seyana_limitedstring($seyanaFourProductFive->post_content, 50);
						$seyanaFourProductFiveLink = get_permalink($seyanaFourProductFiveId);
						
						if( has_post_thumbnail( $seyanaFourProductFiveId ) ){
							
							$seyanaFourProductFiveImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaFourProductFiveId ), 'seyana-productfour' );
							$seyanaFourProductFiveImage = $seyanaFourProductFiveImage[0];
							
						}else{
							
							$seyanaFourProductFiveImage = get_template_directory_uri() . '/assets/images/frontitemimage.png';
							
						}						

					}			
			
			?>
			<div class="frontPageFourProductImage">
				<img src="<?php echo esc_url($seyanaFourProductFiveImage); ?>" />
			</div><!-- .frontPageFourProductImage -->
			<h2><a href="<?php echo esc_url($seyanaFourProductFiveLink); ?>"><?php echo esc_html($seyanaFourProductFiveTitle); ?></a></h2>
			<div class="frontPageFourProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaFourProductFiveDesc ){
							
							echo esc_html($seyanaFourProductFiveDesc);
							
						}else{
							
							echo esc_html($seyanaFourProductFiveContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontFourWelcomeContent -->			
			<?php endif; ?>
			
		</div><!-- .frontPageFourProductContainer -->
		
		<div class="frontPageFourProductContainer">
			
			<?php
			
				if( '' != get_theme_mod('seyana_four_product_post_three') && 'select' != get_theme_mod('seyana_four_product_post_three') ):
			
				$seyanaFourProductSixTitle = '';
				$seyanaFourProductSixDesc = '';

					$seyanaFourProductSixId = get_theme_mod('seyana_four_product_post_three');

					if( ctype_alnum($seyanaFourProductSixId) ){

						$seyanaFourProductSix = get_post( $seyanaFourProductSixId );

						$seyanaFourProductSixTitle = $seyanaFourProductSix->post_title;
						$seyanaFourProductSixDesc = $seyanaFourProductSix->post_excerpt;
						$seyanaFourProductSixContent = seyana_limitedstring($seyanaFourProductSix->post_content, 50);
						$seyanaFourProductSixLink = get_permalink($seyanaFourProductSixId);
						
						if( has_post_thumbnail( $seyanaFourProductSixId ) ){
							
							$seyanaFourProductSixImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaFourProductSixId ), 'seyana-productfour' );
							$seyanaFourProductSixImage = $seyanaFourProductSixImage[0];
							
						}else{
							
							$seyanaFourProductSixImage = get_template_directory_uri() . '/assets/images/frontitemimage.png';
							
						}						

					}			
			
			?>
			<div class="frontPageFourProductImage">
				<img src="<?php echo esc_url($seyanaFourProductSixImage); ?>" />
			</div><!-- .frontPageFourProductImage -->
			<h2><a href="<?php echo esc_url($seyanaFourProductSixLink); ?>"><?php echo esc_html($seyanaFourProductSixTitle); ?></a></h2>
			<div class="frontPageFourProductContent">
				
				<p>
					<?php 
					
						if( '' != $seyanaFourProductSixDesc ){
							
							echo esc_html($seyanaFourProductSixDesc);
							
						}else{
							
							echo esc_html($seyanaFourProductSixContent);
							
						}
					
					?>
				</p>
				
			</div><!-- .frontFourWelcomeContent -->			
			<?php endif; ?>
			
		</div><!-- .frontPageFourProductContainer -->		
		
	</div><!-- .frontPageFourProductsContainer -->
	
</div><!-- .frontPageFourContainer -->