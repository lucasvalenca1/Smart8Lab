<?php
	
	$seyanaHeaderPostId = '';
	$seyanaHeaderPostTitle = '';
	$seyanaHeaderPostDesc = '';

	if( '' != get_theme_mod('seyana_header_one_post') && 'select' != get_theme_mod('seyana_header_one_post') ){

		$seyanaHeaderPostId = get_theme_mod('seyana_header_one_post');

		if( ctype_alnum($seyanaHeaderPostId) ){

			$seyanaHeaderPost = get_post( $seyanaHeaderPostId );

			$seyanaHeaderPostTitle = $seyanaHeaderPost->post_title;
			$seyanaHeaderPostDesc = $seyanaHeaderPost->post_excerpt;
			$seyanaHeaderPostContent = $seyanaHeaderPost->post_content;
			$seyanaHeaderPostUrl = get_the_permalink($seyanaHeaderPostId);
			
			$seyanaHeaderPostThumbnail = get_the_post_thumbnail_url($seyanaHeaderPostId,'seyana-producttwo');

		}

	}			
	
	if( '' != $seyanaHeaderPostId ):

?>

<div class="header-one-container">

	<div class="header-one-image">
		
		<?php
		
			if( '' != $seyanaHeaderPostThumbnail ){
				
				echo '<img src="' . esc_url($seyanaHeaderPostThumbnail) . '">';
				
			}
		
		?>
		
	</div><!-- .header-one-image -->
	
	<div class="header-one-content">
		
		<h2><?php echo esc_html($seyanaHeaderPostTitle); ?></h2>
		<p>
			<?php 
					
				if( '' != $seyanaHeaderPostDesc ){
							
					echo esc_html($seyanaHeaderPostDesc);
							
				}else{
							
					echo esc_html($seyanaHeaderPostContent);
							
				}
					
			?>		
		</p>
		<?php if( '' != $seyanaHeaderPostUrl ): ?>
		<p>
			<a class="readMore" href="<?php echo esc_url($seyanaHeaderPostUrl); ?>"><?php _e('Read More', 'seyana') ?></a>
		</p>
		<?php endif; ?>
		
	</div><!-- .header-one-content -->
	
</div><!-- .header-one-container -->

<?php endif; ?>