<div class="wooOneContainer">

	<div class="wooOneWelcomeContainer">
		
			<?php
			
				$seyanaWelcomePostTitle = '';
				$seyanaWelcomePostDesc = '';
				$seyanaWelcomePostContent = '';

				if( '' != get_theme_mod('seyana_wooone_welcome_post') && 'select' != get_theme_mod('seyana_wooone_welcome_post') ){

					$seyanaWelcomePostId = get_theme_mod('seyana_wooone_welcome_post');

					if( ctype_alnum($seyanaWelcomePostId) ){

						$seyanaWelcomePost = get_post( $seyanaWelcomePostId );

						$seyanaWelcomePostTitle = $seyanaWelcomePost->post_title;
						$seyanaWelcomePostDesc = $seyanaWelcomePost->post_excerpt;
						$seyanaWelcomePostContent = $seyanaWelcomePost->post_content;

					}

				}			
			
			?>
			
			<h1><?php echo esc_html($seyanaWelcomePostTitle); ?></h1>
			<div class="wooOneWelcomeContent">
				<p>
					<?php 
					
						if( '' != $seyanaWelcomePostDesc ){
							
							echo esc_html($seyanaWelcomePostDesc);
							
						}else{
							
							echo esc_html($seyanaWelcomePostContent);
							
						}
					
					?>
				</p>
			</div><!-- .wooOneWelcomeContent -->	
		
	</div><!-- .wooOneWelcomeContainer -->
	
	
	<div class="new-arrivals-container">
		
		<?php 
					
			if( 'no' != get_theme_mod('seyana_show_wooone_heading') ): 
			
				$seyanaWooOneLatestHeading = __('Latest Products', 'seyana');	
				$seyanaWooOneLatestText = __('Some of our latest products', 'seyana');
			
					
				if( '' != get_theme_mod('seyana_wooone_latest_heading') ){
					$seyanaWooOneLatestHeading = get_theme_mod('seyana_wooone_latest_heading');
				}
				
				if( '' != get_theme_mod('seyana_wooone_latest_text') ){
					$seyanaWooOneLatestText = get_theme_mod('seyana_wooone_latest_text');
				}				
			
					
		?>
		<div class="new-arrivals-title">
		
			<h3><?php echo esc_html($seyanaWooOneLatestHeading); ?></h3>
			<p><?php echo esc_html($seyanaWooOneLatestText); ?></p>
		
		</div><!-- .new-arrivals-title -->
		<?php endif; ?>
		
		<?php
			
			$seyanaWooOnePaged = get_query_var( 'page' ) ? get_query_var( 'page' ) : 1;
			
			$seyana_front_page_ecom = array(
				'post_type' => 'product',
				'paged' => $seyanaWooOnePaged
			);
			$seyana_front_page_ecom_the_query = new WP_Query( $seyana_front_page_ecom );
			
			$seyana_front_page_temp_query = $wp_query;
			$wp_query   = NULL;
			$wp_query   = $seyana_front_page_ecom_the_query;
			
		?>		
		
		<div class="new-arrivals-content">
		<?php if ( have_posts() && post_type_exists('product') ) : ?>
		
		
			<div class="seyana-woocommerce-content">
			
				<ul class="products">
			
					<?php /* Start the Loop */ ?>
					<?php while ( $seyana_front_page_ecom_the_query->have_posts() ) : $seyana_front_page_ecom_the_query->the_post(); ?>			
					<?php wc_get_template_part( 'content', 'product' ); ?>
					<?php endwhile; ?>
				
				</ul><!-- .products -->
				
				<?php //the_posts_navigation(); ?>
				
				<?php seyana_pagination( $seyanaWooOnePaged, $seyana_front_page_ecom_the_query->max_num_pages); // Pagination Function ?>
				
			</div><!-- .seyana-woocommerce-content -->
			
		<?php else : ?>
		
			<p><?php echo __('Please install wooCommerce and add products.', 'seyana') ?></p>

		<?php 
			
			endif; 
			wp_reset_postdata();
			$wp_query = NULL;
			$wp_query = $seyana_front_page_temp_query;
		?>			
		
		
		</div><!-- .new-arrivals-content -->		
	
	</div><!-- .new-arrivals-container -->	

</div>