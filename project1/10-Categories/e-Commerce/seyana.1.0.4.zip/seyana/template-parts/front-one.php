<div class="frontPageContainer">
	
	<div class="frontPageServices">
		
		<div class="frontPageWelcome">
		
			<?php
			
				$seyanaWelcomePostTitle = '';
				$seyanaWelcomePostDesc = '';
				$seyanaWelcomePostContent = '';

				if( '' != get_theme_mod('seyana_welcome_post') && 'select' != get_theme_mod('seyana_welcome_post') ){

					$seyanaWelcomePostId = get_theme_mod('seyana_welcome_post');

					if( ctype_alnum($seyanaWelcomePostId) ){

						$seyanaWelcomePost = get_post( $seyanaWelcomePostId );

						$seyanaWelcomePostTitle = $seyanaWelcomePost->post_title;
						$seyanaWelcomePostDesc = $seyanaWelcomePost->post_excerpt;
						$seyanaWelcomePostContent = $seyanaWelcomePost->post_content;

					}

				}			
			
			?>
			
			<h1><?php echo esc_html($seyanaWelcomePostTitle); ?></h1>
			<div class="frontWelcomeContent">
				<p>
					<?php 
					
						if( '' != $seyanaWelcomePostDesc ){
							
							echo esc_html($seyanaWelcomePostDesc);
							
						}else{
							
							echo esc_html($seyanaWelcomePostContent);
							
						}
					
					?>
				</p>
			</div><!-- .frontWelcomeContent -->			
			
		</div><!-- .frontPageWelcome -->
		
		<div class="frontPageServiceItems">
			
			<?php

				$seyana_left_cat = '';

				if(get_theme_mod('seyana_services_cat')){
					$seyana_left_cat = get_theme_mod('seyana_services_cat');
					$seyana_left_cat_num = -1;
				}else{
					$seyana_left_cat = 0;
					$seyana_left_cat_num = 5;
				}		

				$seyana_left_args = array(
				   // Change these category SLUGS to suit your use.
				   'ignore_sticky_posts' => 1,
				   'post_type' => array('post'),
				   'posts_per_page'=> $seyana_left_cat_num,
				   'cat' => $seyana_left_cat
				);

				$seyana_left = new WP_Query($seyana_left_args);		

				if ( $seyana_left->have_posts() ) : while ( $seyana_left->have_posts() ) : $seyana_left->the_post();
   			?> 			
			<div class="frontPageServiceItem">
				
				<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail('seyana-home-posts');
						}else{
							echo '<img src="' . esc_url( esc_url( get_template_directory_uri() ) ) . '/assets/images/frontitemimage.png" />';
						}						
				?>
				<?php the_title( '<h3><a href="' . esc_url( get_permalink() ) . '">', '</a></h3>' ); ?>
				<p>
					<?php  
						
						//$frontPostExcerpt = '';
						//$frontPostExcerpt = get_the_excerpt();
					
						if( has_excerpt() ){
							echo esc_html(get_the_excerpt());
						}else{
							echo esc_html(seyana_limitedstring(get_the_content(), 50));
						}
					
					?>
				</p>				
				
			</div><!-- .frontPageServiceItem -->
			<?php endwhile; wp_reset_postdata(); endif;?>
			
		</div><!-- .frontPageServiceItems -->
		
	</div><!-- .frontPageServices -->
	
	<div class="frontPagePortfolio">
		
		<h1><?php _e('Portfolio', 'seyana'); ?></h1>
		
		<div class="frontPagePortfolioItems">
			
			<?php

				$seyana_portfolio_cat = '';

				if(get_theme_mod('seyana_portfolio_cat')){
					$seyana_portfolio_cat = get_theme_mod('seyana_portfolio_cat');
					$seyana_portfolio_cat_num = -1;
				}else{
					$seyana_portfolio_cat = 0;
					$seyana_portfolio_cat_num = 5;
				}		

				$seyana_portfolio_args = array(
				   // Change these category SLUGS to suit your use.
				   'ignore_sticky_posts' => 1,
				   'post_type' => array('post'),
				   'posts_per_page'=> $seyana_portfolio_cat_num,
				   'cat' => $seyana_portfolio_cat
				);

				$seyana_portfolio = new WP_Query($seyana_portfolio_args);		

				if ( $seyana_portfolio->have_posts() ) : while ( $seyana_portfolio->have_posts() ) : $seyana_portfolio->the_post();
   			?>			
			<div class="frontPagePortfolioItem">
				
				<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail();
						}else{
							echo '<img src="' . esc_url( esc_url( get_template_directory_uri() ) ) . '/assets/images/service.jpg" />';
						}						
				?>
				<?php the_title( '<h3>', '</h3>' ); ?>				
				
			</div><!-- .frontPagePortfolioItem -->
			<?php endwhile; wp_reset_postdata(); endif;?>
			
		</div><!-- .frontPagePortfolioItems -->
		
	</div><!-- .frontPagePortfolio -->
	
	<div class="frontPageNews">
		
			<h1><?php _e('News', 'seyana'); ?></h1>
			
			<?php

				$seyana_right_cat = '';

				if(get_theme_mod('seyana_news_cat')){
					$seyana_right_cat = get_theme_mod('seyana_news_cat');
				}else{
					$seyana_right_cat = 0;
				}		

				$seyana_right_args = array(
				   // Change these category SLUGS to suit your use.
				   'ignore_sticky_posts' => 1,
				   'post_type' => array('post'),
				   'posts_per_page'=> 4,
				   'cat' => $seyana_right_cat
				);

				$seyana_right = new WP_Query($seyana_right_args);		

				if ( $seyana_right->have_posts() ) : while ( $seyana_right->have_posts() ) : $seyana_right->the_post();
   			?> 			
			<div class="frontNewsItem">
				
				<?php the_title( '<h3>', '</h3>' ); ?>
				<p>
					<?php  
						
						//$frontPostExcerpt = '';
						//$frontPostExcerpt = get_the_excerpt();
					
						if( has_excerpt() ){
							echo esc_html(get_the_excerpt());
						}else{
							echo esc_html(seyana_limitedstring(get_the_content(), 100));
						}
					
					?>				
				</p>
				<p class="readmore"><a href="<?php echo esc_url(get_the_permalink()); ?>">Read More</a></p>
				
			</div><!-- .frontNewsItem -->
			<?php endwhile; wp_reset_postdata(); endif;?>			
		
	</div><!-- .frontPageNews -->	
	
</div><!-- .frontPageContainer -->	