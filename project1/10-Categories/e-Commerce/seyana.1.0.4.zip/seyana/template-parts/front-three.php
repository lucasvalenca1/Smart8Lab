<div class="front-three-container">

	<div class="front-three-services">
	
		<?php 
					
				$seyanaWelcomePostTitle = '';
				$seyanaWelcomePostDesc = '';
				$seyanaWelcomePostContent = '';
				
				if( '' != get_theme_mod('seyana_three_welcome_post') && 'select' != get_theme_mod('seyana_three_welcome_post') ){
					
					$seyanaWelcomePostId = get_theme_mod('seyana_three_welcome_post');
					
					if( ctype_alnum($seyanaWelcomePostId) ){

						$seyanaWelcomePost = get_post( $seyanaWelcomePostId );
					
						$seyanaWelcomePostTitle = $seyanaWelcomePost->post_title;
						$seyanaWelcomePostDesc = $seyanaWelcomePost->post_excerpt;
						$seyanaWelcomePostContent = $seyanaWelcomePost->post_content;
						
					}
					
				}
				
				
				
		?>
		<div class="frontpage-welcome-container">

			<h1><?php echo esc_html($seyanaWelcomePostTitle); ?></h1>
			<div>
			<?php 
					
				if( '' != $seyanaWelcomePostDesc ){
							
					echo esc_html($seyanaWelcomePostDesc);
							
				}else{
							
					echo esc_html($seyanaWelcomePostContent);
							
				}
					
			?>			
			</div>

		</div><!-- .frontpage-welcome-container -->

		
		<div class="bizthree-items">
		
			<?php
				
				if( '' != get_theme_mod('seyana_three_products_one') && 'select' != get_theme_mod('seyana_three_products_one') ):
				
				$seyanaProductOneTitle = '';
				$seyanaProductOneDesc = '';
				$seyanaProductOneUrl = '';
				$seyanaProductOneImage = '';			
				
				$seyanaProductOneId = get_theme_mod('seyana_three_products_one');
				
				if( ctype_alnum($seyanaProductOneId) ){

					$seyanaProductOne = get_post( $seyanaProductOneId );
				
					$seyanaProductOneTitle = $seyanaProductOne->post_title;
					$seyanaProductOneDesc = $seyanaProductOne->post_excerpt;
					$seyanaProductOneContent = seyana_limitedstring($seyanaProductOne->post_content, 150);
					$seyanaProductOneUrl = get_permalink( $seyanaProductOneId );
					
					if( has_post_thumbnail($seyanaProductOneId) ){
						$seyanaProductOneImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaProductOneId ), 'full' );
						$seyanaProductOneImage = $seyanaProductOneImage[0];
					}				
					
				}			
				
			?>
			<div class="bizthree-item">
			
				<div class="bizthree-image">
					
					<?php 

						if( '' != $seyanaProductOneImage ){
							echo '<a href="' . esc_url($seyanaProductOneUrl) . '"><img src="' . esc_url($seyanaProductOneImage) . '" /></a>';
						}else{
							echo '<img src="' . esc_url( get_template_directory_uri() ) . '/assets/images/service.jpg" />';
						}
							
					?>				
					
				</div><!-- .bizthree-image -->
				
				<div class="bizthree-content">
				
					<h3><a href="<?php echo esc_url($seyanaProductOneUrl); ?>"><?php echo esc_html($seyanaProductOneTitle); ?></a></h3>
					<div>
					<?php 
					
						if( '' != $seyanaProductOneDesc ){
							
							echo esc_html($seyanaProductOneDesc);
							
						}else{
							
							echo esc_html($seyanaProductOneContent);
							
						}
					
					?>		
					</div>	
				
				</div><!-- .bizthree-content -->		
			
			</div><!-- .bizthree-item -->
			<?php endif; ?>
			
			<?php 
			
				if( '' != get_theme_mod('seyana_three_products_two') && 'select' != get_theme_mod('seyana_three_products_two') ):
				
				$seyanaProductTwoTitle = '';
				$seyanaProductTwoDesc = '';
				$seyanaProductTwoUrl = '';
				$seyanaProductTwoImage = '';			
				
				$seyanaProductTwoId = get_theme_mod('seyana_three_products_two');
				
				if( ctype_alnum($seyanaProductTwoId) ){

					$seyanaProductTwo = get_post( $seyanaProductTwoId );
				
					$seyanaProductTwoTitle = $seyanaProductTwo->post_title;
					$seyanaProductTwoDesc = $seyanaProductTwo->post_excerpt;
					$seyanaProductTwoContent = seyana_limitedstring($seyanaProductTwo->post_content, 150);
					$seyanaProductTwoUrl = get_permalink( $seyanaProductTwoId );
					
					if( has_post_thumbnail($seyanaProductTwoId) ){
						$seyanaProductTwoImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaProductTwoId ), 'full' );
						$seyanaProductTwoImage = $seyanaProductTwoImage[0];
					}				
					
				}			
				
			?>
			<div class="bizthree-item">
			
				<div class="bizthree-image">
					
					<?php 

						if( '' != $seyanaProductTwoImage ){
							echo '<a href="' . esc_url($seyanaProductTwoUrl) . '"><img src="' . esc_url($seyanaProductTwoImage) . '" /></a>';
						}else{
							echo '<img src="' . esc_url( get_template_directory_uri() ) . '/assets/images/service.jpg" />';
						}
							
					?>				
					
				</div><!-- .bizthree-image -->
				
				<div class="bizthree-content">
				
					<h3><a href="<?php echo esc_url($seyanaProductTwoUrl); ?>"><?php echo esc_html($seyanaProductTwoTitle); ?></a></h3>
					<div>
					<?php 
					
						if( '' != $seyanaProductTwoDesc ){
							
							echo esc_html($seyanaProductTwoDesc);
							
						}else{
							
							echo esc_html($seyanaProductTwoContent);
							
						}
					
					?>		
					</div>	
				
				</div><!-- .bizthree-content -->		
			
			</div><!-- .bizthree-item -->
			<?php endif; ?>

			<?php 
			
				if( '' != get_theme_mod('seyana_three_products_three') && 'select' != get_theme_mod('seyana_three_products_three') ):
				
				$seyanaProductThreeTitle = '';
				$seyanaProductThreeDesc = '';
				$seyanaProductThreeUrl = '';
				$seyanaProductThreeImage = '';			
				
				$seyanaProductThreeId = get_theme_mod('seyana_three_products_three');
				
				if( ctype_alnum($seyanaProductThreeId) ){

					$seyanaProductThree = get_post( $seyanaProductThreeId );
				
					$seyanaProductThreeTitle = $seyanaProductThree->post_title;
					$seyanaProductThreeDesc = $seyanaProductThree->post_excerpt;
					$seyanaProductThreeContent = seyana_limitedstring($seyanaProductThree->post_content, 150);
					$seyanaProductThreeUrl = get_permalink( $seyanaProductThreeId );
					
					if( has_post_thumbnail($seyanaProductThreeId) ){
						$seyanaProductThreeImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaProductThreeId ), 'full' );
						$seyanaProductThreeImage = $seyanaProductThreeImage[0];
					}				
					
				}			
				
			?>
			<div class="bizthree-item">
			
				<div class="bizthree-image">
					
					<?php 

						if( '' != $seyanaProductThreeImage ){
							echo '<a href="' . esc_url($seyanaProductThreeUrl) . '"><img src="' . esc_url($seyanaProductThreeImage) . '" /></a>';
						}else{
							echo '<img src="' . esc_url( get_template_directory_uri() ) . '/assets/images/service.jpg" />';
						}
							
					?>				
					
				</div><!-- .bizthree-image -->
				
				<div class="bizthree-content">
				
					<h3><a href="<?php echo esc_url($seyanaProductThreeUrl); ?>"><?php echo esc_html($seyanaProductThreeTitle); ?></a></h3>
					<div>
					<?php 
					
						if( '' != $seyanaProductThreeDesc ){
							
							echo esc_html($seyanaProductThreeDesc);
							
						}else{
							
							echo esc_html($seyanaProductThreeContent);
							
						}
					
					?>		
					</div>	
				
				</div><!-- .bizthree-content -->		
			
			</div><!-- .bizthree-item -->
			<?php endif; ?>		
		
		</div><!-- .bizthree-items -->
	
	</div><!-- .front-three-services -->
	
	<div class="front-three-portfolio">
	
		<h3><?php echo __( 'Portfolio', 'seyana' ); ?></h3>
		
		<div class="front-three-portfolio-content">
		
			<?php
				
				if( '' != get_theme_mod('seyana_three_portfolio_one') && 'select' != get_theme_mod('seyana_three_portfolio_one') ):
				
				$seyanaPortfolioOneTitle = '';
				$seyanaPortfolioOneImage = '';			
				
				$seyanaPortfolioOneId = get_theme_mod('seyana_three_portfolio_one');
				
				if( ctype_alnum($seyanaPortfolioOneId) ){

					$seyanaProductOne = get_post( $seyanaPortfolioOneId );
				
					$seyanaPortfolioOneTitle = $seyanaProductOne->post_title;
					$seyanaPortfolioOneUrl = get_permalink( $seyanaProductOneId );
					
					if( has_post_thumbnail($seyanaPortfolioOneId) ){
						$seyanaPortfolioOneImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaPortfolioOneId ), 'full' );
						$seyanaPortfolioOneImage = $seyanaPortfolioOneImage[0];
					}				
					
				}			
				
			?>

			<div class="front-three-portfolio-item">
			
				<?php
					
					if( '' != $seyanaPortfolioOneImage ){
						
						echo '<img src="' . esc_url( $seyanaPortfolioOneImage ) . '" />';
						
					}else{
						
						echo '<img src="' . esc_url( get_template_directory_uri() ) . '/assets/images/service.jpg" />';
						
					}
					
				?>
				<p><?php echo esc_html($seyanaPortfolioOneTitle); ?></p>
			
			</div><!-- .front-three-portfolio-item -->
			
			<?php endif; ?>	
			
			<?php
				
				if( '' != get_theme_mod('seyana_three_portfolio_two') && 'select' != get_theme_mod('seyana_three_portfolio_two') ):
				
				$seyanaPortfolioTwoTitle = '';
				$seyanaPortfolioTwoImage = '';			
				
				$seyanaPortfolioTwoId = get_theme_mod('seyana_three_portfolio_two');
				
				if( ctype_alnum($seyanaPortfolioTwoId) ){

					$seyanaProductTwo = get_post( $seyanaPortfolioTwoId );
				
					$seyanaPortfolioTwoTitle = $seyanaProductTwo->post_title;
					$seyanaPortfolioTwoUrl = get_permalink( $seyanaProductTwoId );
					
					if( has_post_thumbnail($seyanaPortfolioTwoId) ){
						$seyanaPortfolioTwoImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaPortfolioTwoId ), 'full' );
						$seyanaPortfolioTwoImage = $seyanaPortfolioTwoImage[0];
					}				
					
				}			
				
			?>

			<div class="front-three-portfolio-item">
			
				<?php
					
					if( '' != $seyanaPortfolioTwoImage ){
						
						echo '<img src="' . esc_url( $seyanaPortfolioTwoImage ) . '" />';
						
					}else{
						
						echo '<img src="' . esc_url( get_template_directory_uri() ) . '/assets/images/service.jpg" />';
						
					}
					
				?>
				<p><?php echo esc_html($seyanaPortfolioTwoTitle); ?></p>
			
			</div><!-- .front-three-portfolio-item -->
			
			<?php endif; ?>	

			<?php
				
				if( '' != get_theme_mod('seyana_three_portfolio_three') && 'select' != get_theme_mod('seyana_three_portfolio_three') ):
				
				$seyanaPortfolioThreeTitle = '';
				$seyanaPortfolioThreeImage = '';			
				
				$seyanaPortfolioThreeId = get_theme_mod('seyana_three_portfolio_three');
				
				if( ctype_alnum($seyanaPortfolioThreeId) ){

					$seyanaProductThree = get_post( $seyanaPortfolioThreeId );
				
					$seyanaPortfolioThreeTitle = $seyanaProductThree->post_title;
					$seyanaPortfolioThreeUrl = get_permalink( $seyanaProductThreeId );
					
					if( has_post_thumbnail($seyanaPortfolioThreeId) ){
						$seyanaPortfolioThreeImage = wp_get_attachment_image_src( get_post_thumbnail_id( $seyanaPortfolioThreeId ), 'full' );
						$seyanaPortfolioThreeImage = $seyanaPortfolioThreeImage[0];
					}				
					
				}			
				
			?>

			<div class="front-three-portfolio-item">
			
				<?php
					
					if( '' != $seyanaPortfolioThreeImage ){
						
						echo '<img src="' . esc_url( $seyanaPortfolioThreeImage ) . '" />';
						
					}else{
						
						echo '<img src="' . esc_url( get_template_directory_uri() ) . '/assets/images/service.jpg" />';
						
					}
					
				?>
				<p><?php echo esc_html($seyanaPortfolioThreeTitle); ?></p>
			
			</div><!-- .front-three-portfolio-item -->
			
			<?php endif; ?>				
		
		</div><!-- .front-three-portfolio-content -->
	
	</div><!-- .front-three-portfolio -->

</div><!-- .front-three-container -->