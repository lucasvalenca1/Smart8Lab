<?php

$seyanaPostsPagesArray = array(
	'select' => __('Select a post/page', 'seyana'),
);

$seyanaPostsPagesArgs = array(
	
	// Change these category SLUGS to suit your use.
	'ignore_sticky_posts' => 1,
	'post_type' => array('post', 'page'),
	'orderby' => 'date',
	'posts_per_page' => -1,
	'post_status' => 'publish',
	
);
$seyanaPostsPagesQuery = new WP_Query( $seyanaPostsPagesArgs );
	
if ( $seyanaPostsPagesQuery->have_posts() ) :
							
	while ( $seyanaPostsPagesQuery->have_posts() ) : $seyanaPostsPagesQuery->the_post();
			
		$seyanaPostsPagesId = get_the_ID();
		if(get_the_title() != ''){
				$seyanaPostsPagesTitle = get_the_title();
		}else{
				$seyanaPostsPagesTitle = get_the_ID();
		}
		$seyanaPostsPagesArray[$seyanaPostsPagesId] = $seyanaPostsPagesTitle;
	   
	endwhile; wp_reset_postdata();
							
endif;

$seyanaYesNo = array(
	'select' => __('Select', 'seyana'),
	'yes' => __('Yes', 'seyana'),
	'no' => __('No', 'seyana'),
);

$seyanaSliderType = array(
	'select' => __('Select', 'seyana'),
	'header' => __('WP Custom Header', 'seyana'),
	'header-one' => __('seyana Header', 'seyana'),
);

$seyanaServiceLayouts = array(
	'select' => __('Select', 'seyana'),
	'one' => __('One', 'seyana'),
	'two' => __('Two', 'seyana'),
);

$seyanaAvailableCats = array( 'select' => __('Select', 'seyana') );

$seyana_categories_raw = get_categories( array( 'orderby' => 'name', 'order' => 'ASC', 'hide_empty' => 0, ) );

foreach( $seyana_categories_raw as $category ){
	
	$seyanaAvailableCats[$category->term_id] = $category->name;
	
}

$seyanaBusinessLayoutType = array( 
	'select' => __('Select', 'seyana'), 
	'one' => __('One', 'seyana'), 
	'two' => __('Two', 'seyana'),
	'three' => __('Three', 'seyana'),
	'four' => __('Four', 'seyana'),
	'woo-one' => __('Woocommerce One', 'seyana'),
);
