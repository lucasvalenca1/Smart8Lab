// JavaScript Document
jQuery(document).ready(function() {
	
	var seyanaViewPortWidth = '',
		seyanaViewPortHeight = '';

	function seyanaViewport(){

		seyanaViewPortWidth = jQuery(window).width(),
		seyanaViewPortHeight = jQuery(window).outerHeight(true);	
		
		if( seyanaViewPortWidth > 1200 ){
			
			jQuery('.main-navigation').removeAttr('style');
			
			var seyanaSiteHeaderHeight = jQuery('.site-header').outerHeight();
			var seyanaSiteHeaderWidth = jQuery('.site-header').width();
			var seyanaSiteHeaderPadding = ( seyanaSiteHeaderWidth * 2 )/100;
			var seyanaMenuHeight = jQuery('.menu-container').height();
			
			var seyanaMenuButtonsHeight = jQuery('.site-buttons').height();
			
			var seyanaMenuPadding = ( seyanaSiteHeaderHeight - ( (seyanaSiteHeaderPadding * 2) + seyanaMenuHeight ) )/2;
			var seyanaMenuButtonsPadding = ( seyanaSiteHeaderHeight - ( (seyanaSiteHeaderPadding * 2) + seyanaMenuButtonsHeight ) )/2;
		
			
			jQuery('.menu-container').css({'padding-top':seyanaMenuPadding});
			jQuery('.site-buttons').css({'padding-top':seyanaMenuButtonsPadding});
			
			
		}else{

			jQuery('.menu-container, .site-buttons, .header-container-overlay, .site-header').removeAttr('style');

		}	
	
	}

	jQuery(window).on("resize",function(){
		
		seyanaViewport();
		
	});
	
	seyanaViewport();


	jQuery('.site-branding .menu-button').on('click', function(){
				
		if( seyanaViewPortWidth > 1200 ){

		}else{
			jQuery('.main-navigation').slideToggle();
		}				
		
				
	});	

		
	
});		