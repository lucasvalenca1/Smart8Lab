=== Opstore Lite ===
Contributors: WPoperation
Tags: right-sidebar,left-sidebar,custom-background,custom-menu,featured-images,threaded-comments,translation-ready,custom-logo,footer-widgets,blog,post-formats,sticky-post,theme-options,news,editor-style,custom-header,e-commerce
Requires at least: 4.0
Tested up to: 5.2.4
Stable tag: 1.0.0
Requires PHP: 5.6
License: GNU General Public License, version 3 (GPLv3)
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

Opstore Lite is Child Theme Of Opstore.

Opstore Lite is a WordPress Theme, 
Copyright (C) 2019, WPoperation
Opstore Lite is distributed under the terms of the GNU GPL


== Description ==
Opstore Lite is free WordPress theme built to power online stores specially for furnitures and interior decorations. But it can power any ecommerce websites with beautiful interface and features which you really will enjoy. This is child theme of Opstore. The theme is fully built for elementor page builder so you can create your layouts with just drag and drop interface.


== Install Steps: ==

1. Activate the theme
2. Go to the Customize page
3. Setup theme options


== Resources ==

----------------------
Screenshot Images
----------------------
License: CC0
License Url : https://stocksnap.io/license

https://pikwizard.com/photo/table-furniture-desk/f9c00425ba1dfe1720bcd5b7657e0c24
https://stocksnap.io/photo/XCOZ3XTV7M
https://pikwizard.com/photo/chair-cozy-decor-furniture/3fe6e7c99517f7385c76ae0b5baa47f3
https://pikwizard.com/photo/table-dining-table-furniture/757271ebf4bbee1384479c3dd17acff2
https://pikwizard.com/photo/free-clock-image/51e2657871fac58759bab873a04b3b99
https://pxhere.com/en/photo/1076294

All other images are designed by WPoperation and licenced under CC0



== Changelog == 
please refer changelog.txt for changelogs