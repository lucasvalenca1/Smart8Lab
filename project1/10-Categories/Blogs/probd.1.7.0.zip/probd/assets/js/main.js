;( function( $ ){

    //owl.carousel
	$('.owl-carousel').owlCarousel({
        items: 1,
        loop: true,
        autoplay: true,
        autoplayTimeout: 2000,
        autoplayHoverPause:true,
        margin: 0,
        nav: true,
        dots : false,
    })

} )( jQuery );