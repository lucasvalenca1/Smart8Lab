=== V Blog ===

Contributors: amplethemes
Tags: blog, news, custom-background, custom-header, one-column, two-columns, three-columns, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, post-formats
Requires at least: 4.5
Tested up to: 5.2
Stable tag: 0.0.1
Requires PHP: 5.6
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the theme.

== Description ==

V Blog is a responsive WordPress theme, its the child theme of ample Blog. This is one best ever crafted free WordPress themes for Blog, news, and Magazine. It's 2 column with masonary layout, its is a simple, easy to use, modern and creative, user-friendly WordPress theme with color options.
With the help of its live customizer, you can modify the theme with ease like setting a new header and footer, changing the colors and many others. The theme has some amazing features to offer to its users. It has good compatibility with all kinds of web browsers like Google Chrome, Firefox, and Safari etc.

In addition, It comes with added custom widgets for author,Recent post, Feature widget, sticky sidebar options, footer widget, sidebar options, meta option, copyright option, social options etc.


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Frequently Asked Questions ==

= Does this theme support any plugins? =

   Supports Contact Form 7.
   Supports Jetpack.
   Supports Mailchimp.


==  Theme License & Copyright ==

V Blog is a child theme of ample Blog WordPress Theme, Copyright 2018 Ample Themes
V Blog is distributed under the terms of the GNU General Public License v2

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

V Blog WordPress Theme, Copyright 2018 Ample Themes
V Blog is distributed under the terms of the GNU General Public License v2

== Screenshots ==

All the images are CCO license, https://pxhere.com/en/license

* https://pxhere.com/en/photo/1593469
* https://pxhere.com/en/photo/764585
* https://pxhere.com/en/photo/1543007

== Change log ==

= 0.0.1 - July 19 2019
* Initial release

=0.0.2 -july 19 2019

* Text domain fixed