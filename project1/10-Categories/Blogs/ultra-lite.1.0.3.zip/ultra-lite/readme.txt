=== Ultra Lite ===
Contributors: wpoperations
Tags: right-sidebar,left-sidebar,custom-background, custom-menu, featured-images, threaded-comments, translation-ready,custom-logo, footer-widgets,blog,post-formats,sticky-post,theme-options,news
Requires at least: 4.0
Tested up to: 5.3.2
Stable tag: 1.0.3
Requires PHP: 5.6
License: GNU General Public License, version 3 (GPLv3)
License URI: http://www.gnu.org/licenses/gpl-3.0.txt

Ultra Lite is Child Theme Of Ultra Seven.

Ultra Lite is a WordPress Theme, 
Copyright (C) 2019, WPoperation
Ultra Lite is distributed under the terms of the GNU GPL


Ultra Seven WordPress Theme, 
Copyright 2019 WPoperation
Ultra Seven is distributed under the terms of the GNU General Public License v3


== Description ==
Create flexible news,magazine,blog and travel diaries with easy drag & drop page builder within minutes. It's now easy to share your ideas through your posts without any hassle.


== Install Steps: ==

1. Activate the theme
2. Go to the Customize page
3. Setup theme options


== Resources ==

----------------------
Screenshot Images
----------------------
License: CC0
License Url : https://stocksnap.io/license

https://stocksnap.io/photo/IKW16TPP9U
https://stocksnap.io/photo/42MI2XQAXN

https://pikwizard.com/photo/mountain-snow-mountains/2325d92c8812a25d0e9781dd99bb6844
https://pikwizard.com/photo/free-plate-image/550d4a52cdf1578f408881dd4323d915
https://pikwizard.com/photo/woman-looking-at-turkish-sweets-in-shop/86233c5a3dec069167d6ea5c02617ba5


All other images are designed by WPoperation and licenced under CC0



== Changelog == 
please refer changelog.txt for changelogs