<?php 
	include get_template_directory() . '/inc/customizer/header.php';
	include get_template_directory() . '/inc/customizer/hero.php';