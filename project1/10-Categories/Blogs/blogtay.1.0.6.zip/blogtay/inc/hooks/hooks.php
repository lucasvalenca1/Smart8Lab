<?php 
require get_template_directory() . '/inc/hooks/header-hook.php';
require get_template_directory() . '/inc/hooks/hero-hook.php';