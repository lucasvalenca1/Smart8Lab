<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mismo
 */

?>

</div><!-- mt-container -->
	</div><!-- #content -->

	<?php
		/**
		 * hook - mismo_footer_open
		 * 
		 * @hooked - mismo_site_footer_tag_open - 10
		 */
		do_action( 'mismo_footer_open' );

		/**
		 * hook - mismo_footer_widget_area
		 * 
		 * @hooked - mismo_footer_widget_section - 20
		 */
		do_action( 'mismo_footer_widget_area' );

		/**
		 * hook - mismo_bottom_footer_widget_area
		 * 
		 * @hooked - mismo_bottom_footer_widget_section - 20
		 */
		do_action( 'mismo_bottom_footer_widget_area' );

		/**
		 * hook - mismo_bottom_footer
		 * 
		 * @hooked - mismo_bottom_footer_start - 10
		 * @hooked - mismo_bottom_footer_site_info - 20
		 * @hooked - mismo_bottom_footer_end - 50
		 */
		do_action( 'mismo_bottom_footer' );

		/**
		 * hook - mismo_footer_close
		 * 
		 * @hooked - mismo_site_footer_tag_close - 10
		 * @hooked - mismo_scrol_to_top -50 
		 */
		do_action( 'mismo_footer_close' );
	?>

</div><!-- #page -->

<?php
	/**
	 * mismo_after_page - hook  
	 */
	do_action( 'mismo_after_page' );

	wp_footer();
?>

</body>
</html>