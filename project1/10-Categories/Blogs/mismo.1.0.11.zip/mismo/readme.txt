﻿=== Mismo ===

Contributors:       mysterythemes
Tags:               blog, news, entertainment, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-header, custom-logo, custom-menu, featured-images, footer-widgets, rtl-language-support, theme-options, threaded-comments, translation-ready
Requires at least:  4.5
Tested up to:       5.1
Requires PHP:       5.2.4
Stable tag:         1.0.11
License:            GPLv3 or later
License URI:        http://www.gnu.org/licenses/gpl-3.0.html

Mismo is an ultimate magazine theme that is perfect for creating the magazine, editorial, news, publishing as well as blogging website.

== Description ==

Mismo is an ultimate magazine theme that is perfect for creating the magazine, editorial, news, publishing as well as blogging website. It has a responsive design that displays a clean and elegant look on all mobile and desktop devices. It is a highly customizable theme that comes with multiple site layouts and page templates. Plus, it is compatible with popular plugins like wooCommerce and compact form 7 to quickly get your website established. The feature-rich theme offers header sticky sidebar, wide ad space, carousal, wow animation effect, widgetized footer, dynamic color scheme including category colors. Additionally, it is Gutenberg ready, SEO friendly and speed optimized. Create your website with Mismo for awesome satisfaction.

Get the demo at https://demo.mysterythemes.com/mismo-landing/

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

Mismo WordPress Theme, Copyright 2019 Mystery Themes.
Mismo is distributed under the terms of the GNU GPL


== Resources ==
    
    Animate CSS, Copyright © 2016 Daniel Eden
    License: MIT
    Source: https://github.com/daneden/animate.css

    Font Awesome by Dave Gandy
    Licenses: SIL OFL 1.1, MIT, CC BY 3.0
    Source: https://github.com/FortAwesome/Font-Awesome

    jQuery Marquee, Copyright (c) 2017 Aamir Afridi
    License: MIT License.
    Source: https://github.com/aamirafridi/jQuery.Marquee

    Lightslider, Copyright (c) 2015 Sachin N
    License: MIT License.
    Source: https://github.com/sachinchoolur/lightslider

    Sticky js, Copyright © 2014-2016, Anthony Garand
    License: GPL
    Source: https://github.com/garand/sticky

    Theia Sticky Sidebar, Copyright 2013-2016 by WeCodePixels
    License: MIT
    https://github.com/WeCodePixels/theia-sticky-sidebar

    WOW, Copyright © 2016 Matthieu Aussaguel
    License: GPLv3
    Source: https://github.com/matthieua/WOW

    TGM-Plugin-Activation Copyright © 2011 by Thomas Griffin, Gary Jones, Juliette Reinders Folmer
    License : GPL
    Source: http://tgmpluginactivation.com/

    * screenshot.png, CC0 Public Domain
        https://stocksnap.io/photo/GD5GEZNXX5
        https://stocksnap.io/photo/U7AJD2A34C
        https://pxhere.com/en/photo/1088210
        https://pxhere.com/en/photo/1355361
        https://pxhere.com/en/photo/645517
        https://pxhere.com/en/photo/36717
        https://pxhere.com/en/photo/1436707
        https://stocksnap.io/photo/VOVU4FRFKD
        https://pxhere.com/en/photo/826138
        https://pxhere.com/en/photo/1172401


== Changelog ==

= 1.0.11 - March 30, 2020 =
    * Fixed - Main menu bug fixed.
    * Fixed - single post featured image html.
    * Changed - Increase the height of the image in the related posts.

= 1.0.10 - January 13, 2020 =
    * Added default value for social icons repeater field.
    * Change in the default value for the email field.
    * Template directory url change for radioimage.js file.
    
= 1.0.9 - January 01, 2020 =
    * Removed - Popular Tab section from Default Tab Widget.

= 1.0.8 - December 31, 2019 =
    * Added - Full Screen Layout Feature.
    * Fixed - Changed the speed of the highlighted post.
    * Changed - New screenshot updated.
    * Removed - Unused icon images from the theme.

= 1.0.7 - December 28, 2019 =
    * Added - You may miss section at the archive and single post page.
    * Added - Timeline Widget.
    * Added - Theme welcome page.
    * Fixed - Post format icons on the post.
    * Fixed - Some design tweaks.
    * Changed - New screenshot updated.

= 1.0.6 - December 27, 2019 =
    * Changed author.
    * Changed the div id and class as per new author.

= 1.0.5 - December 02, 2019 =
    * Removed the footer menu location.
    * Fixed skip link focus color property.

= 1.0.4 - November 28, 2019 =
    * Fixed - escaping issues at several files.

= 1.0.3 - November 27, 2019 =
    * Fixed - the issue at template-tags.php file.
    * Changed - the author-box.php file name.
    * Updated - .pot file.

= 1.0.2 - September 19, 2019 =
    * Code Refine in header and widgets sections.
    * Changes styling for boxed layout.
    * Updates in image heights.
    * Added theme upsell button.
    * Changes all widget class name with widget name.
    * Added one-click demo import function to manage the frontpage and menu.
    * Updated .pot file.

= 1.0.1 - August 20, 2019 =
    * Removed some line of code.
    * Fixed bugs at sidebar conditions.

= 1.0.0 - August 19, 2019 =
    * Upload the theme on wordpress.org trac.