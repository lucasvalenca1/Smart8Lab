<?php
/**
 * Display Header Media
 *
 * @package Catch_Mag
 */

catch_mag_featured_overall_image();
