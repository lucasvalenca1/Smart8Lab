<?php
/**
 * The template used for displaying credits
 *
 * @package Catch_Mag
 */
?>

<?php
/**
 * catch_mag_credits hook
 * @hooked catch_mag_footer_content - 10
 */
do_action( 'catch_mag_credits' );
