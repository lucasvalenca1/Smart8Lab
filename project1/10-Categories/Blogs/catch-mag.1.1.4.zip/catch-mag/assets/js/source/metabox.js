jQuery(document).ready(function(){jQuery("#catch-mag-ui-tabs").tabs()});
