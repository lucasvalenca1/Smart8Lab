=== Starter Gazette Plus ===

Contributors: unitedtheme

Requires at least: 4.0
Tested up to: 5.2
Stable tag: 1.0.4
License: GNU General Public License v2 or later
License URI: LICENSE

A starter theme called Starter Gazette.

== Description ==
Starter Gazette is a powerful News/Magazine WordPress theme suitable for all the Professional out there who strive towards minimalism and clean lines. It's retina ready and fully responsive design will look amazing, and work fluently, on all devices (mobile, tablet, and desktop). Our developers and designers spent countless hours crafting the ideal layout for Starter Gazette. The outcome is a minimal and sophisticated theme for you to show your fine content and writing.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Starter Gazette includes support for Infinite Scroll in Jetpack.

== Copyright ==
Starter Gazette Plus WordPress Theme, Copyright 2018 YOUR UNITED THEME
Starter Gazette Plus is distributed under the terms of the GNU GPL

== Credits ==

Unless otherwise specified, all the theme files and scripts are licensed under GNU General Public License.

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)

* Google Fonts:

   Source Sans Pro (https://fonts.google.com/specimen/Source+Sans+Pro)
   Licensed under SIL Open Font License, 1.1 (http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web)
   Copyright Paul D. Hunt


   Shadows Into Light (https://fonts.google.com/specimen/Shadows+Into+Light)
   Licensed under SIL Open Font License, 1.1 (http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web)
   Copyright Kimberly Geswein


sidr:
Author: Alberto Varela
URL: http://www.berriart.com/sidr/
License: Licensed under the MIT license

http://www.jquerynewsticker.com/

The Elegant Icon Font by elegantthemes https://www.elegantthemes.com/blog/resources/elegant-icon-font
These icons are dual licensed under the GPL 2.0 https://www.gnu.org/licenses/gpl-2.0.html and MIT https://opensource.org/licenses/MIT,

* Slick, Copyright (c) Ken Wheeler, Licensed under MIT,  http://github.com/kenwheeler/slick/
* normalize.css, Copyright 2012-2016 Nicolas Gallagher and Jonathan Neal Licensed under MIT, https://necolas.github.io/normalize.css/

Image Used from stocksnap.io and is released under CC0 Creative Commons,
https://stocksnap.io/photo/V6Y5SKKEEE
https://stocksnap.io/photo/NDI2OD0TQO
https://stocksnap.io/photo/QVIEE1UZSX
https://stocksnap.io/photo/ZNZZGFVY89
https://stocksnap.io/photo/6B1SUAYDO1

https://stocksnap.io/photo/V8G3PEWVYL
https://stocksnap.io/photo/NUO2DCWUQE
https://stocksnap.io/photo/IBTRJYDWWZ
https://stocksnap.io/photo/4CNNMKE9IQ

https://stocksnap.io/photo/DHGGHLVO1K

Image License information at https://stocksnap.io/license

== Changelog ==

= 1.0.0 - Dec 01 2018 =
* Initial release

= 1.0.1 - Feb 03 2019 =
* Update fixing some change on design

= 1.0.2 - Feb 14 2019 =
* Update fixing some change on design


= 1.0.3 - May 07 2019 =
* Update fixing the zoom image remove option via customizer

= 1.0.4 - Nov 1 2019 =
* Updated adding language file.