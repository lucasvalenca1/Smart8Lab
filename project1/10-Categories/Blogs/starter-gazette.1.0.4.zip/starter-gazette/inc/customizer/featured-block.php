<?php
/**
 * Featured Blog section
 *
 * @package starter_gazette
 */

$default = starter_gazette_get_default_theme_options();

// Fearured Blog Section.
$wp_customize->add_section('breaking_news_settings',
    array(
        'title'      => esc_html__('Breaking News Section', 'starter-gazette'),
        'priority'   => 95,
        'capability' => 'edit_theme_options',
        'panel'      => 'front_page_option_panel',
    )
);

// Setting - show_breaking_news_section.
$wp_customize->add_setting('enable_breaking_news',
    array(
        'default'           => $default['enable_breaking_news'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control('enable_breaking_news',
    array(
        'label'    => esc_html__('Enable Breaking News', 'starter-gazette'),
        'section'  => 'breaking_news_settings',
        'type'     => 'checkbox',
        'priority' => 100,
    )
);

$wp_customize->add_setting('breaking_news_title',
    array(
        'default'           => $default['breaking_news_title'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control('breaking_news_title',
    array(
        'label'    => esc_html__('Section Title', 'starter-gazette'),
        'section'  => 'breaking_news_settings',
        'type'     => 'text',
        'priority' => 100,
    )
);
// Setting - drop down category for breaking_news.
$wp_customize->add_setting('select_category_for_breaking_news',
    array(
        'default'           => $default['select_category_for_breaking_news'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(new Starter_Gazette_Dropdown_Taxonomies_Control($wp_customize, 'select_category_for_breaking_news',
    array(
        'label'           => esc_html__('Select Category for Breaking News', 'starter-gazette'),
        'section'         => 'breaking_news_settings',
        'type'            => 'dropdown-taxonomies',
        'taxonomy'        => 'category',
        'priority'        => 130,
        'active_callback' => 'starter_gazette_is_select_cat_slider',

    )));

// end of featured news


// Fearured Blog Section.
$wp_customize->add_section('featured_blog_settings',
    array(
        'title'      => esc_html__('Footer Recomended Section', 'starter-gazette'),
        'priority'   => 200,
        'capability' => 'edit_theme_options',
        'panel'      => 'front_page_option_panel',
    )
);

// Setting - show_slider_section.
$wp_customize->add_setting('enable_featured_blog',
    array(
        'default'           => $default['enable_featured_blog'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control('enable_featured_blog',
    array(
        'label'    => esc_html__('Enable Footer Recomended Blog', 'starter-gazette'),
        'section'  => 'featured_blog_settings',
        'type'     => 'checkbox',
        'priority' => 100,
    )
);

$wp_customize->add_setting('featured_blog_title',
    array(
        'default'           => $default['featured_blog_title'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control('featured_blog_title',
    array(
        'label'    => esc_html__('Section Title', 'starter-gazette'),
        'section'  => 'featured_blog_settings',
        'type'     => 'text',
        'priority' => 100,
    )
);
// Setting - drop down category for slider.
$wp_customize->add_setting('select_category_for_featured_blog',
    array(
        'default'           => $default['select_category_for_featured_blog'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(new Starter_Gazette_Dropdown_Taxonomies_Control($wp_customize, 'select_category_for_featured_blog',
    array(
        'label'           => esc_html__('Select Category for Recomended Blog', 'starter-gazette'),
        'section'         => 'featured_blog_settings',
        'type'            => 'dropdown-taxonomies',
        'taxonomy'        => 'category',
        'priority'        => 130,
        'active_callback' => 'starter_gazette_is_select_cat_slider',

    )));

// end of featured news


// Fearured Blog Section.
$wp_customize->add_section('featured_news_carousel',
    array(
        'title'      => esc_html__('Featured News Carousel Section', 'starter-gazette'),
        'priority'   => 100,
        'capability' => 'edit_theme_options',
        'panel'      => 'front_page_option_panel',
    )
);

// Setting - show_slider_section.
$wp_customize->add_setting('enable_featured_news_carousel',
    array(
        'default'           => $default['enable_featured_news_carousel'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control('enable_featured_news_carousel',
    array(
        'label'    => esc_html__('Enable Featured News Carousel', 'starter-gazette'),
        'section'  => 'featured_news_carousel',
        'type'     => 'checkbox',
        'priority' => 100,
    )
);

$wp_customize->add_setting('featured_news_carousel_title',
    array(
        'default'           => $default['featured_news_carousel_title'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control('featured_news_carousel_title',
    array(
        'label'    => esc_html__('Section Title', 'starter-gazette'),
        'section'  => 'featured_news_carousel',
        'type'     => 'text',
        'priority' => 100,
    )
);
// Setting - drop down category for slider.
$wp_customize->add_setting('select_category_for_news_carousel',
    array(
        'default'           => $default['select_category_for_news_carousel'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(new Starter_Gazette_Dropdown_Taxonomies_Control($wp_customize, 'select_category_for_news_carousel',
    array(
        'label'           => esc_html__('Select Category for Featured News Carousel', 'starter-gazette'),
        'section'         => 'featured_news_carousel',
        'type'            => 'dropdown-taxonomies',
        'taxonomy'        => 'category',
        'priority'        => 130,
        'active_callback' => 'starter_gazette_is_select_cat_slider',

    )));


// Setting - featured_background_color.
$wp_customize->add_setting( 'featured_background_color',
    array(
        'default'           => $default['featured_background_color'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control( 'featured_background_color',
    array(
        'label'    => __( 'Section Background Color', 'starter-gazette' ),
        'section'  => 'featured_news_carousel',
        'type'     => 'color',
        'priority' => 130,
    )
);


// Setting - featured_text_color.
$wp_customize->add_setting( 'featured_text_color',
    array(
        'default'           => $default['featured_text_color'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control( 'featured_text_color',
    array(
        'label'    => __( 'Section Text Color', 'starter-gazette' ),
        'section'  => 'featured_news_carousel',
        'type'     => 'color',
        'priority' => 130,
    )
);


// Setting - featured_border_color.
$wp_customize->add_setting( 'featured_border_color',
    array(
        'default'           => $default['featured_border_color'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control( 'featured_border_color',
    array(
        'label'    => __( 'Section Border Color', 'starter-gazette' ),
        'section'  => 'featured_news_carousel',
        'type'     => 'color',
        'priority' => 130,
    )
);


// Fearured Blog Section.
$wp_customize->add_section('featured_news_tiles',
    array(
        'title'      => esc_html__('Featured News Tiles Section', 'starter-gazette'),
        'priority'   => 100,
        'capability' => 'edit_theme_options',
        'panel'      => 'front_page_option_panel',
    )
);

// Setting - show_slider_section.
$wp_customize->add_setting('enable_featured_news_tiles',
    array(
        'default'           => $default['enable_featured_news_tiles'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control('enable_featured_news_tiles',
    array(
        'label'    => esc_html__('Enable Featured News Tiles', 'starter-gazette'),
        'section'  => 'featured_news_tiles',
        'type'     => 'checkbox',
        'priority' => 100,
    )
);

$wp_customize->add_setting('featured_news_tiles_title',
    array(
        'default'           => $default['featured_news_tiles_title'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control('featured_news_tiles_title',
    array(
        'label'    => esc_html__('Section Title', 'starter-gazette'),
        'section'  => 'featured_news_tiles',
        'type'     => 'text',
        'priority' => 100,
    )
);
// Setting - drop down category for slider.
$wp_customize->add_setting('select_category_for_news_tiles',
    array(
        'default'           => $default['select_category_for_news_tiles'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(new Starter_Gazette_Dropdown_Taxonomies_Control($wp_customize, 'select_category_for_news_tiles',
    array(
        'label'           => esc_html__('Select Category for Featured News Tiles', 'starter-gazette'),
        'section'         => 'featured_news_tiles',
        'type'            => 'dropdown-taxonomies',
        'taxonomy'        => 'category',
        'priority'        => 130,
        'active_callback' => 'starter_gazette_is_select_cat_slider',

    )));


// Fearured Blog Section.
$wp_customize->add_section('featured_popular_news',
    array(
        'title'      => esc_html__('Popular News Section', 'starter-gazette'),
        'priority'   => 190,
        'capability' => 'edit_theme_options',
        'panel'      => 'front_page_option_panel',
    )
);

// Setting - enable_featured_news_tiles.
$wp_customize->add_setting('enable_featured_news_tiles',
    array(
        'default'           => $default['enable_featured_news_tiles'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control('enable_featured_news_tiles',
    array(
        'label'    => esc_html__('Enable Popular News', 'starter-gazette'),
        'section'  => 'featured_popular_news',
        'type'     => 'checkbox',
        'priority' => 100,
    )
);

$wp_customize->add_setting('featured_popular_news_title',
    array(
        'default'           => $default['featured_popular_news_title'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_text_field',
    )
);
$wp_customize->add_control('featured_popular_news_title',
    array(
        'label'    => esc_html__('Section Title', 'starter-gazette'),
        'section'  => 'featured_popular_news',
        'type'     => 'text',
        'priority' => 100,
    )
);
// Setting - drop down category for slider.
$wp_customize->add_setting('select_category_for_popular_news',
    array(
        'default'           => $default['select_category_for_popular_news'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'absint',
    )
);
$wp_customize->add_control(new Starter_Gazette_Dropdown_Taxonomies_Control($wp_customize, 'select_category_for_popular_news',
    array(
        'label'           => esc_html__('Select Category for Popular News', 'starter-gazette'),
        'section'         => 'featured_popular_news',
        'type'            => 'dropdown-taxonomies',
        'taxonomy'        => 'category',
        'priority'        => 130,
        'active_callback' => 'starter_gazette_is_select_cat_slider',

    )));
