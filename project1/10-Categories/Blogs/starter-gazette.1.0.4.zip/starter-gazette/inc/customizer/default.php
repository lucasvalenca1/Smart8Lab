<?php
/**
 * Default theme options.
 *
 * @package Starter Gazette
 */

if (!function_exists('starter_gazette_get_default_theme_options')):

/**
 * Get default theme options
 *
 * @since 1.0.0
 *
 * @return array Default theme options.
 */
function starter_gazette_get_default_theme_options() {

	$defaults = array();

	// Top Section.
	$defaults['move_logo_center']     = '';
	$defaults['top_section_advertisement']     = '';
	$defaults['top_section_advertisement_url'] = '';

	//Main Banner Tiles section
    $defaults['enable_main_banner_tiles_section'] = 1;
    $defaults['select_category_for_main_banner_tiles_section'] = 1;

	// Slider Section.
	$defaults['show_slider_section']           = 1;
	$defaults['number_of_home_slider']         = 6;
	$defaults['number_of_content_home_slider'] = 25;
	$defaults['select_slider_from']            = 'from-category';
    $defaults['select-page-for-slider']        = 0;
    $defaults['select_category_for_slider']    = 1;

    $defaults['enable_breaking_news'] = 1;
    $defaults['breaking_news_title'] = esc_html__('Breaking News', 'starter-gazette');
    $defaults['select_category_for_breaking_news'] = 1;

    $defaults['enable_featured_blog'] = 0;
    $defaults['featured_blog_title'] = esc_html__('You May Like', 'starter-gazette');
    $defaults['select_category_for_featured_blog'] = 1;

    $defaults['enable_featured_news_carousel'] = 0;
    $defaults['featured_news_carousel_title'] = esc_html__('Featured News Carousel', 'starter-gazette');
    $defaults['select_category_for_news_carousel'] = 1;

    $defaults['featured_background_color'] = '#1e1e1e';
    $defaults['featured_text_color'] = '#fff';
    $defaults['featured_border_color'] = '#2d2d2d';

    $defaults['enable_featured_news_tiles'] = 1;
    $defaults['featured_news_tiles_title'] = esc_html__('Featured News Tiles', 'starter-gazette');
    $defaults['select_category_for_news_tiles'] = 1;


    $defaults['enable_popular_news'] = 0;
    $defaults['featured_popular_news_title'] = esc_html__('Popular News Tiles', 'starter-gazette');
    $defaults['select_category_for_popular_news'] = 1;

    /*layout*/
	$defaults['enable_overlay_option']    = 0;
	$defaults['enable_social_nav_header']    = 1;
	$defaults['enable_zoom_on_featured_img']    = 1;
	$defaults['read_more_button_text']    = esc_html__('Continue Reading', 'starter-gazette');
	$defaults['global_layout']            = 'right-sidebar';
	$defaults['excerpt_length_global']    = 50;
	$defaults['pagination_type']          = 'default';
	$defaults['copyright_text']           = esc_html__('Copyright All right reserved', 'starter-gazette');
	$defaults['enable_footer_credit']            = 1;

	$defaults['primary_color'] = '#262626';
	$defaults['secondary_color'] = '#E5192C';
	$defaults['tertiary_color'] = '#0172ff';
	$defaults['primary_font']      = 'Roboto:100,300,400,500,700';
	$defaults['site_title_font']    = 'Bangers';
	$defaults['secondary_font']    = 'Oswald:400,300,700';
	// Pass through filter.
	$defaults = apply_filters('starter_gazette_filter_default_theme_options', $defaults);

	return $defaults;

}

endif;