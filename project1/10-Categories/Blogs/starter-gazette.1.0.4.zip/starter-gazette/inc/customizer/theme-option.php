<?php

/**
 * Theme Options Panel.
 *
 * @package Starter Gazette
 */

$default = starter_gazette_get_default_theme_options();

// Setting - move_logo_center.
$wp_customize->add_setting('move_logo_center',
    array(
        'default'           => $default['move_logo_center'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control('move_logo_center',
    array(
        'label'    => esc_html__('Align Logo at center', 'starter-gazette'),
        'section'  => 'title_tagline',
        'type'     => 'checkbox',
        'capability' => 'edit_theme_options',
        'priority' => 100,
    )
);
// Add Front PAge Options Panel.
$wp_customize->add_panel('front_page_option_panel',
    array(
        'title'      => esc_html__('Front Page Options', 'starter-gazette'),
        'priority'   => 200,
        'capability' => 'edit_theme_options',
    )
);
/*slider and its property section*/
require get_template_directory().'/inc/customizer/slider.php';
require get_template_directory().'/inc/customizer/featured-block.php';


// Add Theme Options Panel.
$wp_customize->add_panel('theme_option_panel',
	array(
		'title'      => esc_html__('Theme Options', 'starter-gazette'),
		'priority'   => 200,
		'capability' => 'edit_theme_options',
	)
);


// Latest featured Section.
$wp_customize->add_section('top_add_section',
    array(
        'title'      => esc_html__('Header Advertisement Section', 'starter-gazette'),
        'priority'   => 10,
        'capability' => 'edit_theme_options',
        'panel'      => 'theme_option_panel',
    )
);

// Setting top_section_advertisement.
$wp_customize->add_setting('top_section_advertisement',
    array(
        'default'           => $default['top_section_advertisement'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_image',
    )
);
$wp_customize->add_control(
    new WP_Customize_Image_Control($wp_customize, 'top_section_advertisement',
        array(
            'label'       => esc_html__('Top Section Advertisement', 'starter-gazette'),
            'description' => sprintf(esc_html__('Recommended Size %1$s px X %2$s px', 'starter-gazette'), 728, 90),
            'section'     => 'top_add_section',
            'priority'    => 120,
        )
    )
);

/*top_section_advertisement_url*/
$wp_customize->add_setting('top_section_advertisement_url',
    array(
        'default'           => $default['top_section_advertisement_url'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'esc_url_raw',
    )
);
$wp_customize->add_control('top_section_advertisement_url',
    array(
        'label'    => esc_html__('URL Link', 'starter-gazette'),
        'section'  => 'top_add_section',
        'type'     => 'text',
        'priority' => 130,
    )
);


/*layout management section start */
$wp_customize->add_section('theme_option_section_settings',
	array(
		'title'      => esc_html__('Layout Management', 'starter-gazette'),
		'priority'   => 100,
		'capability' => 'edit_theme_options',
		'panel'      => 'theme_option_panel',
	)
);

$wp_customize->add_setting( 'enable_zoom_on_featured_img',
    array(
        'default'           => $default['enable_zoom_on_featured_img'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control( 'enable_zoom_on_featured_img',
    array(
        'label'    => esc_html__( 'Enable Zoom On Featured Image', 'starter-gazette' ),
        'section'  => 'theme_option_section_settings',
        'type'     => 'checkbox',
        'priority' => 10,
    )
);

$wp_customize->add_setting( 'enable_social_nav_header',
    array(
        'default'           => $default['enable_social_nav_header'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control( 'enable_social_nav_header',
    array(
        'label'    => esc_html__( 'Enable Social Nav on Header Menu Section', 'starter-gazette' ),
        'section'  => 'theme_option_section_settings',
        'type'     => 'checkbox',
        'priority' => 10,
    )
);

/*Home Page Layout*/
$wp_customize->add_setting('enable_overlay_option',
	array(
		'default'           => $default['enable_overlay_option'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
	)
);
$wp_customize->add_control('enable_overlay_option',
	array(
		'label'    => esc_html__('Enable Banner Overlay', 'starter-gazette'),
		'section'  => 'theme_option_section_settings',
		'type'     => 'checkbox',
		'priority' => 150,
	)
);

/*Global Layout*/
$wp_customize->add_setting('global_layout',
	array(
		'default'           => $default['global_layout'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'starter_gazette_sanitize_select',
	)
);
$wp_customize->add_control('global_layout',
	array(
		'label'          => esc_html__('Sidebar Options', 'starter-gazette'),
		'section'        => 'theme_option_section_settings',
		'choices'        => array(
			'left-sidebar'  => esc_html__('Right Sidebar', 'starter-gazette'),
			'right-sidebar' => esc_html__('Left Sidebar', 'starter-gazette'),
			'no-sidebar'    => esc_html__('No Sidebar', 'starter-gazette'),
		),
		'type'     => 'select',
		'priority' => 170,
	)
);

// Setting - read_more_button_text.
$wp_customize->add_setting('read_more_button_text',
	array(
		'default'           => $default['read_more_button_text'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	)
);
$wp_customize->add_control('read_more_button_text',
	array(
		'label'    => esc_html__('Button Text for Read More', 'starter-gazette'),
		'section'  => 'theme_option_section_settings',
		'type'     => 'text',
		'priority' => 170,
	)
);

/*content excerpt in global*/
$wp_customize->add_setting('excerpt_length_global',
	array(
		'default'           => $default['excerpt_length_global'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'starter_gazette_sanitize_positive_integer',
	)
);
$wp_customize->add_control('excerpt_length_global',
	array(
		'label'       => esc_html__('Archive Excerpt Length', 'starter-gazette'),
		'section'     => 'theme_option_section_settings',
		'type'        => 'number',
		'priority'    => 175,
		'input_attrs' => array('min' => 1, 'max' => 200, 'style' => 'width: 150px;'),

	)
);


// Pagination Section.
$wp_customize->add_section('pagination_section',
	array(
		'title'      => esc_html__('Pagination Options', 'starter-gazette'),
		'priority'   => 110,
		'capability' => 'edit_theme_options',
		'panel'      => 'theme_option_panel',
	)
);

// Setting pagination_type.
$wp_customize->add_setting('pagination_type',
	array(
		'default'           => $default['pagination_type'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'starter_gazette_sanitize_select',
	)
);
$wp_customize->add_control('pagination_type',
	array(
		'label'    => esc_html__('Pagination Type', 'starter-gazette'),
		'section'  => 'pagination_section',
		'type'     => 'select',
		'choices'  => array(
			'numeric' => esc_html__('Numeric', 'starter-gazette'),
			'default' => esc_html__('Default (Older / Newer Post)', 'starter-gazette'),
		),
		'priority' => 100,
	)
);

// Footer Section.
$wp_customize->add_section('footer_section',
	array(
		'title'      => esc_html__('Footer Options', 'starter-gazette'),
		'priority'   => 130,
		'capability' => 'edit_theme_options',
		'panel'      => 'theme_option_panel',
	)
);

// Setting copyright_text.
$wp_customize->add_setting('copyright_text',
	array(
		'default'           => $default['copyright_text'],
		'capability'        => 'edit_theme_options',
		'sanitize_callback' => 'sanitize_text_field',
	)
);
$wp_customize->add_control('copyright_text',
	array(
		'label'    => esc_html__('Footer Copyright Text', 'starter-gazette'),
		'section'  => 'footer_section',
		'type'     => 'text',
		'priority' => 120,
	)
);


$wp_customize->add_setting( 'enable_footer_credit',
    array(
        'default'           => $default['enable_footer_credit'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_checkbox',
    )
);
$wp_customize->add_control( 'enable_footer_credit',
    array(
        'label'    => esc_html__( 'Enable Footer Credit Option', 'starter-gazette' ),
        'section'  => 'footer_section',
        'type'     => 'checkbox',
        'priority' => 10,
    )
);

/**
 * Theme Options .
 */



global $starter_gazette_google_fonts;

$wp_customize->add_section( 'colors',
    array(
        'title'      => esc_html__( 'Color Options', 'starter-gazette' ),
        'priority'   => 10,
        'capability' => 'edit_theme_options',
        'panel'      => 'theme_option_panel',
    )
);
// Setting - primary_color.
$wp_customize->add_setting('primary_color',
    array(
        'default'           => $default['primary_color'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control('primary_color',
    array(
        'label'    => esc_html__('Primary Color', 'starter-gazette'),
        'section'  => 'colors',
        'type'     => 'color',
        'priority' => 100,
    )
);

// Setting - secondary_color.
$wp_customize->add_setting('secondary_color',
    array(
        'default'           => $default['secondary_color'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control('secondary_color',
    array(
        'label'    => esc_html__('Secondary Color', 'starter-gazette'),
        'section'  => 'colors',
        'type'     => 'color',
        'priority' => 100,
    )
);

// Setting - tertiary_color.
$wp_customize->add_setting('tertiary_color',
    array(
        'default'           => $default['tertiary_color'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    )
);
$wp_customize->add_control('tertiary_color',
    array(
        'label'    => esc_html__('Tertiary Color', 'starter-gazette'),
        'section'  => 'colors',
        'type'     => 'color',
        'priority' => 100,
    )
);

$wp_customize->add_section('font_typo_section',
    array(
        'title'      => esc_html__('Fonts & Typography', 'starter-gazette'),
        'priority'   => 10,
        'capability' => 'edit_theme_options',
        'panel'      => 'theme_option_panel',
    )
);
// Setting - primary_font.
$wp_customize->add_setting('primary_font',
    array(
        'default'           => $default['primary_font'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_select',
    )
);
$wp_customize->add_control('primary_font',
    array(
        'label'    => esc_html__('Primary Font', 'starter-gazette'),
        'section'  => 'font_typo_section',
        'type'     => 'select',
        'choices'  => $starter_gazette_google_fonts,
        'priority' => 100,
    )
);
// Setting - secondary_font.
$wp_customize->add_setting('secondary_font',
    array(
        'default'           => $default['secondary_font'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_select',
    )
);
$wp_customize->add_control('secondary_font',
    array(
        'label'    => esc_html__('Secondary Font', 'starter-gazette'),
        'section'  => 'font_typo_section',
        'type'     => 'select',
        'choices'  => $starter_gazette_google_fonts,
        'priority' => 100,
    )
);

// Setting - site_title_font.
$wp_customize->add_setting('site_title_font',
    array(
        'default'           => $default['site_title_font'],
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'starter_gazette_sanitize_select',
    )
);
$wp_customize->add_control('site_title_font',
    array(
        'label'    => esc_html__('Site Title Font', 'starter-gazette'),
        'section'  => 'title_tagline',
        'type'     => 'select',
        'choices'  => $starter_gazette_google_fonts,
        'priority' => 10,
    )
);