<?php
// main_banner_tiles_section news
if (!function_exists('starter_main_banner_tiles_section')):
    /**
     *  main banner tile News
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_main_banner_tiles_section()
    {
        if (1 != starter_gazette_get_option('enable_main_banner_tiles_section')) {
            return null;
        }
        $id = absint(starter_gazette_get_option('select_category_for_main_banner_tiles_section'));
        //$category = get_category($id);
        //$count = $category->category_count;

        $starter_main_banner_tiles_section_args = array(
            'post_type' => 'post',
            'posts_per_page' => 5,
            'cat' => $id,
        ); ?>
            <!--Main Banner Tiles section-->
            <section class="united-block united-block-bg banner-tiles">
                <div class="wrapper">
                    <div class="row">
                        <?php 
                        $i = 1;
                        $starter_main_banner_tiles_section_query = new WP_Query($starter_main_banner_tiles_section_args);
                        if ($starter_main_banner_tiles_section_query->have_posts()) :
                            while ($starter_main_banner_tiles_section_query->have_posts()) : $starter_main_banner_tiles_section_query->the_post();
                                if (has_post_thumbnail()) {
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                    $large_image = $thumb['0'];
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'starter-gazette-720-480');
                                    $small_image = $thumb['0'];
                                }else {
                                    $large_image = '';
                                    $small_image = '';
                                }
                                ?>
                                <?php if ($i < 3) { ?>
                                    <?php if ($i == 1) { 
                                        echo '<div class="col col-three">';
                                    } ?>
                                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                            <div class="photo-grid photo-grid-2">
                                                <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                                    <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                        <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                            <?php
                                                            echo '<img src="' . esc_url($small_image) . '">';
                                                            ?>
                                                        </a>
                                                    </div>
                                                <?php } else { ?>
                                                    <div class="photo-wrapper photo-wrapper-2">
                                                        <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                            <?php
                                                            echo '<img src="' . esc_url($small_image) . '">';
                                                            ?>
                                                        </a>
                                                    </div>
                                                <?php } ?>

                                                <header class="entry-header">
                                                    <div class="entry-meta-bullets">
                                                        <?php starter_gazette_posted_category_only(); ?>
                                                    </div>

                                                    <h2 class="entry-title">
                                                        <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                                    </h2>

                                                    <div class="entry-meta entry-meta-small">
                                                        <?php starter_gazette_posted_on(); ?>
                                                    </div>
                                                </header>
                                            </div>
                                        </article>
                                    <?php if ($i == 2) { 
                                        echo '</div>';
                                    } ?>
                                <?php $i++;
                                } elseif ($i < 4) { ?>
                                    <div class="col col-four">
                                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                            <div class="photo-grid photo-grid-2 photo-grid-3">
                                                <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                                    <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                        <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                            <?php
                                                            echo '<img src="' . esc_url($small_image) . '">';
                                                            ?>
                                                        </a>
                                                    </div>
                                                <?php } else { ?>
                                                    <div class="photo-wrapper photo-wrapper-2">
                                                        <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                            <?php
                                                            echo '<img src="' . esc_url($small_image) . '">';
                                                            ?>
                                                        </a>
                                                    </div>
                                                <?php } ?>
                                                <header class="entry-header">
                                                    <div class="entry-meta-bullets">
                                                        <?php starter_gazette_posted_category_only(); ?>
                                                    </div>

                                                    <h2 class="entry-title">
                                                        <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                                    </h2>

                                                    <div class="entry-meta entry-meta-small">
                                                        <?php starter_gazette_posted_on(); ?>
                                                    </div>
                                                </header>
                                            </div>
                                        </article>
                                    </div>
                                <?php $i++;
                                } else { ?>
                                    <?php if ($i == 4) { 
                                        echo '<div class="col col-three">';
                                    } ?>
                                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                            <div class="photo-grid photo-grid-2">
                                                <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                                    <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                        <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                            <?php
                                                            echo '<img src="' . esc_url($small_image) . '">';
                                                            ?>
                                                        </a>
                                                    </div>
                                                <?php } else { ?>
                                                    <div class="photo-wrapper photo-wrapper-2">
                                                        <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                            <?php
                                                            echo '<img src="' . esc_url($small_image) . '">';
                                                            ?>
                                                        </a>
                                                    </div>
                                                <?php } ?>
                                                <header class="entry-header">
                                                    <div class="entry-meta-bullets">
                                                        <?php starter_gazette_posted_category_only(); ?>
                                                    </div>

                                                    <h2 class="entry-title">
                                                        <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                                    </h2>

                                                    <div class="entry-meta entry-meta-small">
                                                        <?php starter_gazette_posted_on(); ?>
                                                    </div>

                                                </header>
                                            </div>
                                        </article>
                                        <?php if ($i == 5) { 
                                        echo '</div>';
                                    } $i++;?>
                                <?php } ?>

                            <?php
                            wp_reset_postdata();
                        endwhile; ?>
                    </div>
                </div>
            </section>
            <!--Main Banner Tiles section ends-->
        <?php endif;
    }
endif;
add_action('starter_gazette_action_slider_post', 'starter_main_banner_tiles_section', 5);


if (!function_exists('starter_gazette_banner_slider_args')):
    /**
     * Banner Slider Details
     *
     * @since Starter Gazette 1.0.0
     *
     * @return array $qargs Slider details.
     */
    function starter_gazette_banner_slider_args()
    {
        $starter_gazette_banner_slider_number = absint(starter_gazette_get_option('number_of_home_slider'));
        $starter_gazette_banner_slider_from = esc_attr(starter_gazette_get_option('select_slider_from'));
        switch ($starter_gazette_banner_slider_from) {
            case 'from-page':
                $starter_gazette_banner_slider_page_list_array = array();
                for ($i = 1; $i <= $starter_gazette_banner_slider_number; $i++) {
                    $starter_gazette_banner_slider_page_list = starter_gazette_get_option('select_page_for_slider_' . $i);
                    if (!empty($starter_gazette_banner_slider_page_list)) {
                        $starter_gazette_banner_slider_page_list_array[] = absint($starter_gazette_banner_slider_page_list);
                    }
                }
                // Bail if no valid pages are selected.
                if (empty($starter_gazette_banner_slider_page_list_array)) {
                    return;
                }
                /*page query*/
                $qargs = array(
                    'posts_per_page' => absint($starter_gazette_banner_slider_number),
                    'orderby' => 'post__in',
                    'post_type' => 'page',
                    'post__in' => $starter_gazette_banner_slider_page_list_array,
                );
                return $qargs;
                break;

            case 'from-category':
                $starter_gazette_banner_slider_category = absint(starter_gazette_get_option('select_category_for_slider'));
                $qargs = array(
                    'posts_per_page' => absint($starter_gazette_banner_slider_number),
                    'post_type' => 'post',
                    'cat' => $starter_gazette_banner_slider_category,
                );
                return $qargs;
                break;

            default:
                break;
        }
        ?>
        <?php
    }
endif;

if (!function_exists('starter_gazette_banner_slider')):
    /**
     * Banner Slider
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_gazette_banner_slider()
    {
        $starter_gazette_slider_excerpt_number = absint(starter_gazette_get_option('number_of_content_home_slider'));
        if (1 != starter_gazette_get_option('show_slider_section')) {
            return null;
        }
        $starter_gazette_banner_slider_args = starter_gazette_banner_slider_args();
        $starter_gazette_banner_slider_query = new WP_Query($starter_gazette_banner_slider_args);
        $i = 0;
        ?>
        <section class="united-block slider">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <div id="mainslider">
                            <?php
                            if ($starter_gazette_banner_slider_query->have_posts()) :
                                while ($starter_gazette_banner_slider_query->have_posts()) : $starter_gazette_banner_slider_query->the_post();
                                    if (has_excerpt()) {
                                        $starter_gazette_slider_content = get_the_excerpt();
                                    } else {
                                        $starter_gazette_slider_content = starter_gazette_words_count($starter_gazette_slider_excerpt_number, get_the_content());
                                    }
                                    ?>
                                    <div class="item slide">

                                        <?php if (has_post_thumbnail()) {
                                            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                            $url = $thumb['0']; ?>
                                        <div class="slick-slide-image">
                                            <img src="<?php echo esc_url($url); ?>" class="img-responsive">
                                        <div class="entry-meta-bullets">
                                            <?php starter_gazette_posted_category_only(); ?>
                                        </div>
                                        </div>
                                        <?php } ?>
                                        <div class="slide-caption">
                                            <h2 class="slides-title">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_title(); ?>
                                                </a>
                                            </h2>
                                            <div class="entry-meta entry-meta-small">
                                                <?php starter_gazette_posted_on(); ?>
                                            </div>
                                            <div class="excerpt slides-excerpt hidden-mobile">
                                                <?php if ($starter_gazette_slider_excerpt_number != 0) { ?>
                                                    <span class="smalltext"><?php echo wp_kses_post($starter_gazette_slider_content); ?></span>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    $i++;
                                endwhile;
                                wp_reset_postdata();
                            endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
endif;
add_action('starter_gazette_action_slider_post', 'starter_gazette_banner_slider', 10);
// end of slider


// Breaking news
if (!function_exists('starter_gazette_news_breaking')):
    /**
     * Featured Breaking News
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_gazette_news_breaking()
    {
        if (1 != starter_gazette_get_option('enable_breaking_news')) {
            return null;
        }

        $starter_gazette_news_breaking_args = array(
            'post_type' => 'post',
            'posts_per_page' => 10,
            'cat' => absint(starter_gazette_get_option('select_category_for_breaking_news')),
        ); ?>
            <section class="exclusive-news">
                <div class="wrapper">
                    <div class="row">
                        <div class="col breaking-title">
                            <span class="breaking-news-title"><?php 
                        $breaking_news_title  = starter_gazette_get_option('breaking_news_title');
                        echo esc_html($breaking_news_title); ?></span>
                        </div>
                        <div class="col breaking-content">
                            <div class="exclusive-news-box">
                                <ul id="js-news">
                                    <?php $starter_gazette_news_breaking_query = new WP_Query($starter_gazette_news_breaking_args);
                                    if ($starter_gazette_news_breaking_query->have_posts()) :
                                        while ($starter_gazette_news_breaking_query->have_posts()) : $starter_gazette_news_breaking_query->the_post();
                                            ?>
                                                <li class="news-item">
                                                    <span class="time-news"><?php printf(_x('%s ago', '%s = human-readable time difference', 'starter-gazette'), human_time_diff(get_the_time('U'), current_time('timestamp'))); ?></span>
                                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                                </li>
                                            <?php
                                            wp_reset_postdata();
                                        endwhile; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif;
    }
endif;
add_action('starter_gazette_action_breaking_news', 'starter_gazette_news_breaking', 10);


if (!function_exists('starter_gazette_featured_blog')):
    /**
     * Featured Blog
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_gazette_featured_blog()
    {
        if (1 != starter_gazette_get_option('enable_featured_blog')) {
            return null;
        }

        $starter_gazette_featured_blog_args = array(
            'post_type' => 'post',
            'posts_per_page' => 6,
            'cat' => absint(starter_gazette_get_option('select_category_for_featured_blog')),
        ); ?>
        <section class="united-block recommended-section">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <h2 class="title-header">
                            <span>
                                <?php
                                $featured_blog_title  = starter_gazette_get_option('featured_blog_title');
                                echo esc_html($featured_blog_title); ?>
                            </span>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="wrapper">
                <div class="row">
                <?php $starter_gazette_featured_blog_query = new WP_Query($starter_gazette_featured_blog_args);
                if ($starter_gazette_featured_blog_query->have_posts()) :
                    while ($starter_gazette_featured_blog_query->have_posts()) : $starter_gazette_featured_blog_query->the_post();
                        if (has_post_thumbnail()) {
                            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                            $large_image = $thumb['0'];
                            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'starter-gazette-720-480');
                            $small_image = $thumb['0'];
                        }else {
                            $large_image = '';
                            $small_image = '';
                        }
                        ?>
                        <div class="col col-three-1">
                            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                <div class="photo-grid">
                                    <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                        <div class="photo-wrapper photo-wrapper-1 zoom-gallery">
                                            <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                <?php
                                                echo '<img src="' . esc_url($small_image) . '">';
                                                ?>
                                            </a>
                                            <div class="entry-meta-bullets">
                                                <?php starter_gazette_posted_category_only(); ?>
                                            </div>
                                        </div>
                                    <?php } else { ?>
                                        <div class="photo-wrapper photo-wrapper-1 ">
                                            <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                <?php
                                                echo '<img src="' . esc_url($small_image) . '">';
                                                ?>
                                            </a>
                                            <div class="entry-meta-bullets">
                                                <?php starter_gazette_posted_category_only(); ?>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <header class="entry-header">
                                        <h2 class="entry-title">
                                            <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                        </h2>
                                        <div class="entry-meta">
                                            <?php
                                            starter_gazette_posted_on();
                                            ?>
                                        </div><!-- .entry-meta -->
                                    </header>
                                </div>
                            </article>
                        </div>
                        <?php
                        wp_reset_postdata();
                    endwhile; ?>
                    </div>
                </div>
            </section>
        <?php endif;
    }
endif;
add_action('starter_gazette_action_footer_recomended', 'starter_gazette_featured_blog', 10);


// news carouel
if (!function_exists('starter_gazette_news_carousel')):
    /**
     * Featured News Carousel
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_gazette_news_carousel()
    {
        if (1 != starter_gazette_get_option('enable_featured_news_carousel')) {
            return null;
        }

        $starter_gazette_news_carousel_args = array(
            'post_type' => 'post',
            //'posts_per_page' => 6,
            'cat' => absint(starter_gazette_get_option('select_category_for_news_carousel')),
        ); ?>
        <section class="united-block united-block-bg featured-carousel">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <h2 class="title-header">
                            <?php
                            $featured_news_carousel  = starter_gazette_get_option('featured_news_carousel_title');
                            echo esc_html($featured_news_carousel); ?>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <div class="carousel-slider carousel-center">
                            <?php $starter_gazette_news_carousel_query = new WP_Query($starter_gazette_news_carousel_args);
                            if ($starter_gazette_news_carousel_query->have_posts()) :
                                while ($starter_gazette_news_carousel_query->have_posts()) : $starter_gazette_news_carousel_query->the_post();
                                if (has_post_thumbnail()) {
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                    $large_image = $thumb['0'];
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'starter-gazette-720-480');
                                    $small_image = $thumb['0'];
                                }else {
                                    $large_image = '';
                                    $small_image = '';
                                }
                                ?>
                                <div class="item slider-item">
                                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                        <div class="photo-grid">
                                            <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                            <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                    <?php
                                                    echo '<img src="' . esc_url($small_image) . '">';
                                                    ?>
                                                </a>
                                                <div class="entry-meta-bullets">
                                                    <?php starter_gazette_posted_category_only(); ?>
                                                </div>
                                            </div>
                                            <?php } else { ?>
                                            <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                    <?php
                                                    echo '<img src="' . esc_url($small_image) . '">';
                                                    ?>
                                                </a>
                                                <div class="entry-meta-bullets">
                                                    <?php starter_gazette_posted_category_only(); ?>
                                                </div>
                                            </div>
                                            <?php } ?>

                                            <header class="entry-header">
                                                <div class="entry-meta entry-meta-small">
                                                    <?php
                                                    starter_gazette_posted_on();
                                                    ?>
                                                </div>
                                                <h2 class="entry-title">
                                                    <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                                </h2>
                                            </header>
                                        </div>
                                    </article>
                                </div>
                                <?php
                                wp_reset_postdata();
                            endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php endif;
    }
endif;
add_action('starter_gazette_action_news_carousel', 'starter_gazette_news_carousel', 10);


if (!function_exists('starter_gazette_news_tiles')):
    /**
     * Featured news tiles
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_gazette_news_tiles()
    {
        if (1 != starter_gazette_get_option('enable_featured_news_tiles')) {
            return null;
        }

        $starter_gazette_news_tiles_args = array(
            'post_type' => 'post',
            'posts_per_page' => 6,
            'cat' => absint(starter_gazette_get_option('select_category_for_news_tiles')),
        ); ?>

        <section class="united-block united-block-bg featurerd-tiles">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <h2 class="title-header">
                            <?php
                            $featured_news_tiles  = starter_gazette_get_option('featured_news_tiles_title');
                            echo esc_html($featured_news_tiles); ?>
                        </h2>
                    </div>
                    <div class="col col-full">
                        <div class="row">
                            <?php $starter_gazette_news_tiles_query = new WP_Query($starter_gazette_news_tiles_args);
                            if ($starter_gazette_news_tiles_query->have_posts()) :
                            while ($starter_gazette_news_tiles_query->have_posts()) : $starter_gazette_news_tiles_query->the_post();
                                if (has_post_thumbnail()) {
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                    $large_image = $thumb['0'];
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'starter-gazette-720-480');
                                    $small_image = $thumb['0'];
                                } else {
                                    $large_image = '';
                                    $small_image = '';
                                }
                                ?>
                                <div class="col col-three-1">
                                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                        <div class="photo-grid">
                                            <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                                <div class="photo-wrapper photo-wrapper-1 zoom-gallery">
                                                    <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                        <?php
                                                        echo '<img src="' . esc_url($small_image) . '">';
                                                        ?>
                                                    </a>
                                                    <div class="entry-meta-bullets">
                                                        <?php starter_gazette_posted_category_only(); ?>
                                                    </div>
                                                </div>
                                            <?php } else { ?>
                                                <div class="photo-wrapper photo-wrapper-1 ">
                                                    <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                        <?php
                                                        echo '<img src="' . esc_url($small_image) . '">';
                                                        ?>
                                                    </a>
                                                    <div class="entry-meta-bullets">
                                                        <?php starter_gazette_posted_category_only(); ?>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                            <header class="entry-header">
                                                <h2 class="entry-title">
                                                    <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                                </h2>
                                                <div class="entry-meta">
                                                    <?php
                                                    starter_gazette_posted_on();
                                                    ?>
                                                </div>
                                            </header>
                                        </div>
                                    </article>
                                </div>
                                <?php
                                wp_reset_postdata();
                            endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif;
    }
endif;
add_action('starter_gazette_action_news_carousel', 'starter_gazette_news_tiles', 20);


if (!function_exists('starter_gazette_popular_news')):
    /**
     * Featured news tiles
     *
     * @since Starter Gazette 1.0.0
     *
     */
    function starter_gazette_popular_news()
    {
        if (1 != starter_gazette_get_option('enable_popular_news')) {
            return null;
        }

        $starter_gazette_popular_news_args = array(
            'post_type' => 'post',
            'posts_per_page' => 12,
            'cat' => absint(starter_gazette_get_option('select_category_for_popular_news')),
        ); ?>

        <section class="united-block united-block-bg popular-carousel">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <h2 class="title-header">
                            <span>
                                <?php
                                $featured_popular_news = starter_gazette_get_option('featured_popular_news_title');
                                echo esc_html($featured_popular_news);
                                ?>
                            </span>
                        </h2>
                    </div>
                </div>
            </div>
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <div class="popular-slider carousel-center">
                        <?php $starter_gazette_popular_news_query = new WP_Query($starter_gazette_popular_news_args);
                        if ($starter_gazette_popular_news_query->have_posts()) :
                            while ($starter_gazette_popular_news_query->have_posts()) : $starter_gazette_popular_news_query->the_post();
                                if (has_post_thumbnail()) {
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
                                    $large_image = $thumb['0'];
                                    $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'starter-gazette-720-480');
                                    $small_image = $thumb['0'];
                                } else {
                                    $large_image = '';
                                    $small_image = '';
                                }
                                ?>
                                <div class="item slider-item">
                                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                                        <div class="photo-grid photo-grid-2">
                                            <?php if (starter_gazette_get_option('enable_zoom_on_featured_img') == 1 ) { ?>
                                            <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                <a href="<?php echo esc_url($large_image); ?>" class="zoom-image">
                                                    <?php
                                                    echo '<img src="' . esc_url($small_image) . '">';
                                                    ?>
                                                </a>
                                            </div>
                                            <?php } else { ?>
                                            <div class="photo-wrapper photo-wrapper-2 zoom-gallery">
                                                <a href="<?php the_permalink(); ?>" class="non-zoom-image">
                                                    <?php
                                                    echo '<img src="' . esc_url($small_image) . '">';
                                                    ?>
                                                </a>
                                            </div>
                                            <?php } ?>
                                            <header class="entry-header">
                                                <h2 class="entry-title">
                                                    <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                                </h2>
                                                <div class="entry-meta">
                                                    <?php
                                                    starter_gazette_posted_on();
                                                    ?>
                                                </div>
                                            </header>
                                        </div>
                                    </article>
                                </div>
                                <?php
                                wp_reset_postdata();
                            endwhile; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif;
    }
endif;
add_action('starter_gazette_action_news_carousel', 'starter_gazette_popular_news', 20);



/**
 * Metabox.
 *
 * @package starter-gazette
 */

if ( ! function_exists( 'starter_gazette_add_meta_box' ) ) :

    /**
     * Add the Meta Box
     *
     * @since 1.0.0
     */
    function starter_gazette_add_meta_box() {

        $meta_box_on = array( 'post', 'page' );

        foreach ( $meta_box_on as $meta_box_as ) {
            add_meta_box(
                'starter-gazette-theme-settings',
                esc_html__( 'Layout Options', 'starter-gazette' ),
                'starter_gazette_render_layout_option_metabox',
                $meta_box_as,
                'side',
                'low'
            );
        }

    }

endif;

add_action( 'add_meta_boxes', 'starter_gazette_add_meta_box' );

if ( ! function_exists( 'starter_gazette_render_layout_option_metabox' ) ) :

    /**
     * Render theme settings meta box.
     *
     * @since 1.0.0
     */
    function starter_gazette_render_layout_option_metabox( $post, $metabox ) {

        $post_id = $post->ID;
        $starter_gazette_post_meta_value = get_post_meta($post_id);

        // Meta box nonce for verification.
        wp_nonce_field( basename( __FILE__ ), 'starter_gazette_meta_box_nonce' );
        ?>
        <div id="pb_metabox-container" class="pb-metabox-container">
            <div id="pb-metabox-layout">
                <div class="row-content">
                    <p>
                        <div class="pb-row-content">
                            <label for="starter-gazette-meta-checkbox">
                                <input type="checkbox" name="starter-gazette-meta-checkbox" id="starter-gazette-meta-checkbox"
                                       value="yes" <?php if (isset ($starter_gazette_post_meta_value['starter-gazette-meta-checkbox'])) checked($starter_gazette_post_meta_value['starter-gazette-meta-checkbox'][0], 'yes'); ?> />
                                <?php _e('Disable Featured Image on single page', 'starter-gazette') ?>
                            </label>
                        </div>
                    </p>
                </div>
            </div>
        </div>

        <?php
    }

endif;



if ( ! function_exists( 'starter_gazette_save_settings_meta' ) ) :

    /**
     * Save meta box value.
     *
     * @since 1.0.0
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post Post object.
     */
    function starter_gazette_save_settings_meta( $post_id, $post ) {

        // Verify nonce.
        if ( ! isset( $_POST['starter_gazette_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['starter_gazette_meta_box_nonce'], basename( __FILE__ ) ) ) {
            return; }

        // Bail if auto save or revision.
        if ( defined( 'DOING_AUTOSAVE' ) || is_int( wp_is_post_revision( $post ) ) || is_int( wp_is_post_autosave( $post ) ) ) {
            return;
        }

        // Check the post being saved == the $post_id to prevent triggering this call for other save_post events.
        if ( empty( $_POST['post_ID'] ) || $_POST['post_ID'] != $post_id ) {
            return;
        }

        // Check permission.
        if ( 'page' === $_POST['post_type'] ) {
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return; }
        } else if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $starter_gazette_meta_checkbox = isset($_POST['starter-gazette-meta-checkbox']) ? esc_attr($_POST['starter-gazette-meta-checkbox']) : '';
        update_post_meta($post_id, 'starter-gazette-meta-checkbox', sanitize_text_field($starter_gazette_meta_checkbox));

    }

endif;

add_action( 'save_post', 'starter_gazette_save_settings_meta', 10, 2 );