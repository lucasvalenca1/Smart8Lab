<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package starter_gazette
 */

?>

</div><!-- #content -->

<?php do_action('starter_gazette_action_footer_recomended'); ?>

<footer id="colophon" class="site-footer">
<?php if (is_active_sidebar('footer-col-1') || is_active_sidebar('footer-col-2') || is_active_sidebar('footer-col-3')) { ?>
    <div class="site-widget-area clear">
        <div class="wrapper">
            <div class="row">
                    <?php if (is_active_sidebar('footer-col-1')) : ?>
                        <div class="col col-three-1">
                            <?php dynamic_sidebar('footer-col-1'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('footer-col-2')) : ?>
                        <div class="col col-three-1">
                            <?php dynamic_sidebar('footer-col-2'); ?>
                        </div>
                    <?php endif; ?>
                    <?php if (is_active_sidebar('footer-col-3')) : ?>
                        <div class="col col-three-1">
                            <?php dynamic_sidebar('footer-col-3'); ?>
                        </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
    <?php } ?>

    <?php
    if (has_nav_menu('social')) : ?>
    <div class="footer-social-menu">
        <div class="wrapper">
            <div class="row">
                <div class="col col-full">
                    <div class="social-navigation" role="navigation" aria-label="<?php esc_attr_e('Footer Social Links Menu', 'starter-gazette'); ?>">
                        <?php
                        wp_nav_menu(array(
                            'theme_location' => 'social',
                            'menu_class' => 'social-links-menu',
                            'depth' => 1,
                            'link_before' => '<span class="screen-reader-text">',
                            'link_after' => '</span>' . starter_gazette_get_svg(array('icon' => 'chain')),
                        ));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>


    <div class="footer-end">
        <div class="wrapper">
            <div class="row">
                <div class="col col-full">
                    <div class="copyright-info">
                        <?php
                        $pb_copyright_text = starter_gazette_get_option('copyright_text');
                        if (!empty ($pb_copyright_text)) {
                            echo wp_kses_post(starter_gazette_get_option('copyright_text'));
                        }
                        ?>
                        <?php if (1 == starter_gazette_get_option('enable_footer_credit')) { ?>
                            <span class="sep"> | </span>
                            <?php printf(esc_html__('Theme: %1$s by %2$s.', 'starter-gazette'), 'Starter Gazette', '<a href="http://unitedtheme.com/">Unitedtheme</a>');
                            ?>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
</div>


<a id="scroll-up"><i class="arrow_carrot-up"></i></a>

<?php wp_footer(); ?>

</body>
</html>
