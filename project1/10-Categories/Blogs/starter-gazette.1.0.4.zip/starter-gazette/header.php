<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package starter_gazette
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="profile" href="http://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php if ( function_exists( 'wp_body_open' ) ) {
    wp_body_open();
}
?>
<div class="preloader">
    <div class="preloader-wrapper">
        <div class="spinner">
            <svg class="filter" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                <circle class="length" fill="none" stroke-width="8" stroke-linecap="round" cx="33" cy="33" r="28"></circle>
            </svg>
            <svg class="filter" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                <circle fill="none" stroke-width="8" stroke-linecap="round" cx="33" cy="33" r="28"></circle>
            </svg>
            <svg class="filter" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                <circle fill="none" stroke-width="8" stroke-linecap="round" cx="33" cy="33" r="28"></circle>
            </svg>
            <svg class="filter" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                <circle fill="none" stroke-width="8" stroke-linecap="round" cx="33" cy="33" r="28"></circle>
            </svg>
        </div>
    </div>
</div>



<div id="page" class="site <?php if (starter_gazette_get_option('enable_featured_page_section') == 1) { echo "content-block"; } ?>">
    <a class="skip-link screen-reader-text" href="#content"><?php esc_html_e('Skip to content', 'starter-gazette'); ?></a>
    <header id="masthead" class="site-header">
        <div class="header-block header-block-1">
            <div class="wrapper">
                <div class="row">
                    <div class="col col-full">
                        <div id="mobile-header">
                            <a id="responsive-menu-button" href="#sidr-main">
                                <?php esc_html_e('Menu', 'starter-gazette'); ?>
                            </a>
                        </div>
                        <div class="top-navigation">
                            <?php
                            wp_nav_menu(array(
                                'theme_location' => 'topnav',
                                'menu_id' => 'top-menu',
                                'container' => 'div',
                                'container_class' => 'menu'
                            ));
                            ?>
                        </div>

                        <div class="tobar-time">
                            <?php $time = current_time('l, F j, Y');
                            echo esc_html($time);
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


<?php 
$div_heade_add_class = "";
if (starter_gazette_get_option('move_logo_center')  == 1) {
    $div_heade_add_class = "header-block-center";
}
?>
        <div class="header-block header-block-2 <?php echo $div_heade_add_class; ?>">
            <div class="wrapper">
                <div class="site-branding">
                    <div class="logo">
                            <?php
                            the_custom_logo();
                            if (is_front_page() && is_home()) : ?>
                                <h1 class="site-title">
                                    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                                        <?php bloginfo('name'); ?>
                                    </a>
                                </h1>
                            <?php else : ?>
                                <p class="site-title">
                                    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                                        <?php bloginfo('name'); ?>
                                    </a>
                                </p>
                            <?php
                            endif;

                            $description = get_bloginfo('description', 'display');
                            if ($description || is_customize_preview()) : ?>
                                <p class="site-description">
                                    <?php echo esc_html($description); ?>
                                </p>
                            <?php
                            endif; ?>
                        </div>
                </div>

                <?php $add_img = starter_gazette_get_option('top_section_advertisement');
                $add_url = starter_gazette_get_option('top_section_advertisement_url');
                if (!empty ($add_img)){ ?>
                    <div class="header-banner">
                        <a href="<?php echo esc_url($add_url); ?>" target="_blank">
                            <img src="<?php echo esc_url($add_img); ?>">
                        </a>
                    </div>

                <?php } ?>
            </div>
        </div>
        <div class="header-block header-block-3">
            <div class="united-navigation">
                <div class="wrapper">
                    <div class="row">
                        <div class="col col-full col-pad-0">
                            <nav id="site-navigation" class="main-navigation">
                                <span class="toggle-menu" aria-controls="primary-menu" aria-expanded="false">
                                    <span class="screen-reader-text"><?php esc_html_e('Primary Menu', 'starter-gazette'); ?></span>
                                    <i class="toogle-icon"></i>
                                </span>
                                <?php
                                wp_nav_menu(array(
                                    'theme_location' => 'mainnav',
                                    'menu_id' => 'primary-menu',
                                    'container' => 'div',
                                    'container_class' => 'menu'
                                ));
                                ?>


                                <div class="nav-right">
                                    <div class="nav-socialmedia">
                                        <?php
                                        if (starter_gazette_get_option('enable_social_nav_header') == 1 ) {
                                            if (has_nav_menu('social')) : ?>
                                                <div class="social-navigation social-navigation-nav" role="navigation"
                                                     aria-label="<?php esc_attr_e('Footer Social Links Menu', 'starter-gazette'); ?>">
                                                    <?php
                                                    wp_nav_menu(array(
                                                        'theme_location' => 'social',
                                                        'menu_class' => 'social-links-menu',
                                                        'depth' => 1,
                                                        'link_before' => '<span class="screen-reader-text">',
                                                        'link_after' => '</span>' . starter_gazette_get_svg(array('icon' => 'chain')),
                                                    ));
                                                    ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php } ?>
                                    </div>
                                    <div class="nav-search">
                                        <div class="icon-search">
                                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 129 129"
                                                 xmlns:xlink="http://www.w3.org/1999/xlink" enable-background="new 0 0 129 129">
                                                <g>
                                                    <path d="M51.6,96.7c11,0,21-3.9,28.8-10.5l35,35c0.8,0.8,1.8,1.2,2.9,1.2s2.1-0.4,2.9-1.2c1.6-1.6,1.6-4.2,0-5.8l-35-35   c6.5-7.8,10.5-17.9,10.5-28.8c0-24.9-20.2-45.1-45.1-45.1C26.8,6.5,6.5,26.8,6.5,51.6C6.5,76.5,26.8,96.7,51.6,96.7z M51.6,14.7   c20.4,0,36.9,16.6,36.9,36.9C88.5,72,72,88.5,51.6,88.5c-20.4,0-36.9-16.6-36.9-36.9C14.7,31.3,31.3,14.7,51.6,14.7z"/>
                                                </g>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <div class="model-search">
        <div class="model-search-wrapper">
            <div class="popup-form">
                <?php get_search_form(); ?>
            </div>
        </div>
        <div class="cross-exit"></div>
    </div>

    <?php do_action('starter_gazette_action_breaking_news'); ?>

    <?php
    if (is_front_page() || is_home()) {
        do_action('starter_gazette_action_slider_post');
        do_action('starter_gazette_action_news_carousel');
    } else {
    }
    ?>
    <div id="content" class="site-content">