<div class="copyright">
	<?php echo wp_kses_post( html_entity_decode( blogberg_get_option( 'footer_text' ) ) ); ?> <?php esc_html_e( 'Blogberg Theme by', 'blogberg' ); ?> <a href="<?php echo esc_url( '//keonthemes.com' ); ?>" target="_blank"> <?php esc_html_e( 'Keon Themes', 'blogberg' ); ?> </a>
</div><!-- .site-info -->