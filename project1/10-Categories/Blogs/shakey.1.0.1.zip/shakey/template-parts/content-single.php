<?php
/**
 * Template used to display post content on single pages.
 *
 * @package Shakey
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-content clearfix'); ?>>

	<?php
	do_action( 'shakey_single_post_top' );

	/**
	 * Functions hooked into shakey_single_post add_action
	 *
	 * @hooked shakey_post_header          - 10
	 * @hooked ashakey_post_meta           - 20
	 * @hooked shakey_post_content         - 30
	 */
	do_action( 'shakey_single_post' );

	/**
	 * Functions hooked in to shakey_single_post_bottom action
	 *
	 * @hooked shakey_post_nav         - 10
	 * @hooked shakey_display_comments - 20
	 */
	do_action( 'shakey_single_post_bottom' );
	?>

</article><!-- #post-## -->
