<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Shakey
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-item clearfix'); ?>>

	<?php
	/**
	 * Functions hooked in to basepress_loop_post action.
	 *
	 * @hooked shakey_post_header          - 10
	 * @hooked shakey_post_meta            - 20
	 * @hooked shakey_post_content         - 30
	 * @hooked shakey_init_structured_data - 40
	 */
	do_action( 'shakey_loop_post' );

	?>	
	
</article><!-- #post-## -->