<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Shakey
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-grid clearfix'); ?>>

	<?php
	/**
	 * Functions hooked in to basepress_loop_post action.
	 *
	 * @hooked shakey_post_grid_header          - 10
	 * @hooked shakey_post_grid_meta            - 20
	 * @hooked shakey_post_grid_content         - 30
	 */
	do_action( 'shakey_loop_grid_post' );

	?>	
	
</article><!-- #post-## -->