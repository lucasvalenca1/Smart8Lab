=== Shakey Theme ===
Contributors: sophy
Requires at least: 5.0
Tested up to: 5.2
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


The Shakey Theme by ThemeCountry, https://themecountry.com/themes/satmag

== Tags ==
news, entertainment, blog, two-columns, left-sidebar, right-sidebar, custom-colors, custom-menu, custom-logo, featured-images, footer-widgets, theme-options, threaded-comments

== About Shakey ==

Shakey is a beautifully designed and modern gradient style WordPress theme, with the fast, clean, and SEO optimize. The theme will help your site to rank better in search engines.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0.1 - July 17, 2019 =
* Initial Release

= 1.0.2 - August 06, 2019 =
* Update Style Widget, Comment Form, A links

== Copyright ==

Shakey WordPress Theme, Copyright 2019 ThemeCountry
Shakey is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR SHAKEY. See the
GNU General Public License for more details.

== Google Webfonts ==
Open Sans (https://fonts.google.com/specimen/Montserrat)
Licensed under pache License, Version 2.0, (https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web)
Copyright © Julieta Ulanovsky (Principal design)

== Font Awesome ==
Font Awesome Free 5.7.0 by @fontawesome - https://fontawesome.com
License - https://fontawesome.com/license/free (Icons: CC BY 4.0, Fonts — SIL OFL 1.1 License, Code: MIT License)

* Modular Scale
Modular Scale by Scott Kellum (@scottkellum), Adam Stacoviak (@adamstac) and Mason Wendell (@codingdesigner) , https://github.com/modularscale/modularscale-sass
License: The MIT License (MIT)
License URI: https://github.com/modularscale/modularscale-sass/blob/3.x/license.md

* Normalize.css
Normalize.css By Nicolas Gallagher and Jonathan Neal, http://necolas.github.com/normalize.css/
License: The MIT License (MIT)
License URI: https://github.com/necolas/normalize.css/blob/master/LICENSE.md


* Susy
Susy by Miriam Eric Suzanne with Aaron Gray, Jina, Rachel Nabors, Tsachi Shlidor, Zell Liew, and many others, http://susy.oddbird.net/
License: Copyright (c) 2015, Miriam Eric Suzanne
License URI: https://github.com/oddbird/susy/blob/master/LICENSE.txt


== Screenshots ==

https://pixabay.com/photos/reading-book-girl-woman-people-925589/
https://pixabay.com/photos/camera-old-retro-holding-in-hands-549153/
https://pixabay.com/photos/photography-dog-woman-fun-animal-3510132/
https://pixabay.com/photos/photographer-tourist-snapshot-407068/

License: CC0 Creative Commons
License URL: https://pixabay.com/en/service/terms/#usage

== Credits ==
* Based on Underscores http://underscores.me/, (C) 2012-2015 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
