<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package Shakey
 */
?>

		</div><!-- .col-full -->
	</div><!-- #content -->

	<?php do_action( 'shakey_before_footer' ); ?>

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="container">

			<?php
			/**
			 * Functions hooked in to shakey_footer action
			 *
			 * @hooked shakey_footer_widgets - 10
			 * @hooked shakey_credit         - 20
			 */
			do_action( 'shakey_footer' );
			?>

		</div><!-- .col-full -->
	</footer><!-- #colophon -->

	<?php do_action( 'shakey_after_footer' ); ?>

</div><!-- #page -->

<?php
	/**
	* Functions hooked in to wiral_after_page action
	*
	* @hooked shakey_search_overlay 	- 10
	* @hooked shakey_loading_overlay 	- 10
	* 
	*/
	do_action( 'shakey_after_page' );
?>

<?php wp_footer(); ?>

</body>
</html>