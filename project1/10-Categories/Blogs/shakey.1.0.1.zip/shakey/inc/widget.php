<?php
// Include Recent Posts Widget
require get_template_directory() . '/inc/widget/recent-posts.php';