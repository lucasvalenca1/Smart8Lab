<?php
/**
 * Cutomize Settings
 *
 * Includes all theme's customize settings here.
 *
 * @author   ThemeCountry
 * @since    1.0.0
 * @package  shakey
 *
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds generate settings
 *
 * @since 1.0.0
 * @return array
 */
function shakey_customize_general_settings() {

	$settings = array(

					array(
						'settings'          => 'general_post_show_excerpt',
						'label'             => __('Show Excerpt', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'switch',
						'default'           => 1,
						'priority'          => 3,
						'choices'     		=> array(
							'on'				=> esc_attr__( 'On', 'shakey' ),
							'off'				=> esc_attr__( 'Off', 'shakey' ),
						),

					),

					array(
						'settings'          => 'general_post_excerpt_length',
						'label'             => __('Excerpt Length', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'slider',
						'default'           => 20,
						'priority'          => 4,
						'choices'     => array(
							'min'  => '5',
							'max'  => '80',
							'step' => '1',
						),
						'active_callback' => array(
							array(
								'setting'  => 'general_post_show_excerpt',
								'operator' => '==',
								'value'    => true,
							)
						)

					),

					array(
						'settings'          => 'general_post_show_excerpt_more',
						'label'             => __('Excerpt More String', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'text',
						'default'           => '[...]',
						'priority'          => 5,

						'active_callback' => array(
							array(
								'setting'  => 'general_post_show_excerpt',
								'operator' => '==',
								'value'    => true,
							)
						)

					),

					array(
						'settings'          => 'general_post_show_readmore',
						'label'             => __('Show Read More Button', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'switch',
						'default'           => 1,
						'priority'          => 8,
						'choices'     		=> array(
							'on'				=> esc_attr__( 'On', 'shakey' ),
							'off'				=> esc_attr__( 'Off', 'shakey' ),
						),
					),

					array(
						'settings'          => 'general_post_show_readmore_label',
						'label'             => __('Read More Label', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'text',
						'default'           => __('Read More', 'shakey'),
						'priority'          => 9,

						'active_callback' => array(
							array(
								'setting'  => 'general_post_show_readmore',
								'operator' => '==',
								'value'    => true,
							)
						)

					),


					array(
						'settings'          => 'general_post_show_thumbnail',
						'label'             => __('Show Post Thumbnail', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'switch',
						'default'           => 1,
						'priority'          => 10,
						'choices'     		=> array(
							'on'				=> esc_attr__( 'On', 'shakey' ),
							'off'				=> esc_attr__( 'Off', 'shakey' ),
						),

					),

					// Post meta data

					array(
						'settings'          => 'general_posts_metadata',
						'label'             => sprintf('<h3 class="azb-customize-title">%s</h3>', __('Show/Hide Post Meta Data', 'shakey') ),
						'description'		=> __( 'Check them to show post meta data.', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'multicheck',
						'default'           => array('date', 'category', 'tag', 'author'),
						'priority'          => 11,
						'choices'     		=> array(
							'date'					=> esc_attr__( 'Date', 'shakey' ),
							'category'				=> esc_attr__( 'Category', 'shakey' ),
							'tag'					=> esc_attr__( 'Tag', 'shakey' ),
							'author'				=> esc_attr__( 'Author', 'shakey' ),
						),

					),

					array(
						'settings'          => 'general_posts_modified_date',
						'label'             => __('Show Modified Date', 'shakey'),
						'section'           => 'shakey_general_section',
						'type'              => 'switch',
						'default'           => 'off',
						'priority'          => 12,
						'choices'     		=> array(
							'on'				=> esc_attr__( 'On', 'shakey' ),
							'off'				=> esc_attr__( 'Off', 'shakey' ),
						),

					),

					array(
						'type'     => 'text',
						'settings' => 'general_posts_date_prefix',
						'label'    => __( 'Date Prefix', 'shakey' ),
						'section'  => 'shakey_general_section',
						'description'  => esc_attr__( 'Prefix before date archive. It will show for all archive and single post.', 'shakey' ),
						'priority' => 13,
					),
			);

	return apply_filters('shakey_customize_general_settings', $settings);
}

/**
 * Add layout customize settings
 *
 * @since 1.0.0
 * @return array
 */
function shakey_customize_layout_settings() {

	$settings = array(

			array(
				'settings'          => 'layout',
				'label'             => __('Site Layout', 'shakey'),
				'description'		=> __('This layout will apply hold website. But will not apply to custom homepage.', 'shakey'),
				'section'           => 'shakey_layout_section',
				'type'              => 'radio-image',
				'default'           => 'right',
				'priority'          => 10,
				'choices'     		=> array(
					'none'   => get_template_directory_uri() . '/assets/images/customizer/controls/none.png',
					'left' 	=> get_template_directory_uri() . '/assets/images/customizer/controls/left.png',
					'right'  => get_template_directory_uri() . '/assets/images/customizer/controls/right.png',
					),

			),
			array(
				'settings'          => 'layout_show_thumbnail',
				'label'             => __('Show Post Thumbnail', 'shakey'),
				'description'		=> __('Show or hide post\'s thumbnail for each archvie.', 'shakey'),
				'section'           => 'shakey_layout_section',
				'type'              => 'switch',
				'default'           => 1,
				'priority'          => 20,
				'choices'     		=> array(
					'on'				=> esc_attr__( 'On', 'shakey' ),
					'off'				=> esc_attr__( 'Off', 'shakey' ),
				),

			),
			array(
				'settings'          => 'layout_thumbnail_pos',
				'label'             => __('Thumbnail Position', 'shakey'),
				'description'		=> __('Choose post\'s thumbnail position of each archvie.', 'shakey'),
				'section'           => 'shakey_layout_section',
				'type'              => 'radio-buttonset',
				'default'           => 'left',
				'priority'          => 30,
				'choices'     		=> array(
					'left'				=> __('Left', 'shakey'),
					'top'				=> __('Top', 'shakey'),
					'right'				=> __('Right', 'shakey')
				),

			),
	);

	return apply_filters( 'shakey_customize_layout_settings', $settings );
}

/**
 * Adds customize settings for single post.
 *
 * @since 1.0.0
 * @return array
 */
function shakey_customize_single_post_settings() {

	$settings  = array(

		array(
				'settings'          => 'single_post_show_thumbnail',
				'label'             => __('Show Post Thumbnail', 'shakey'),
				'section'           => 'shakey_single_post_section',
				'type'              => 'switch',
				'default'           => 1,
				'priority'          => 3,
				'choices'     		=> array(
					'on'				=> esc_attr__( 'On', 'shakey' ),
					'off'				=> esc_attr__( 'Off', 'shakey' ),
				),

			),
			// Post navigation
			array(
				'settings'          => 'single_post_show_nav',
				'label'             => __('Show Post Navigation', 'shakey'),
				'section'           => 'shakey_single_post_section',
				'type'              => 'switch',
				'default'           => 1,
				'priority'          => 4,
				'choices'     		=> array(
					'on'				=> esc_attr__( 'On', 'shakey' ),
					'off'				=> esc_attr__( 'Off', 'shakey' ),
				),

			),

			// Post meta data

			array(
				'settings'          => 'single_post_metadata',
				'label'             => sprintf('<h3 class="azb-customize-title">%s</h3>', __('Show/Hide Post Meta Data', 'shakey') ),
				'description'		=> __( 'Check them to show post meta data.', 'shakey'),
				'section'           => 'shakey_single_post_section',
				'type'              => 'multicheck',
				'default'           => array('date', 'category', 'tag', 'author'),
				'priority'          => 5,
				'choices'     		=> array(
					'date'					=> esc_attr__( 'Date', 'shakey' ),
					'category'				=> esc_attr__( 'Category', 'shakey' ),
					'tag'					=> esc_attr__( 'Tag', 'shakey' ),
					'author'				=> esc_attr__( 'Author', 'shakey' ),
				),

			),

			array(
				'settings'          => 'single_post_modified_date',
				'label'             => __('Show Modified Date', 'shakey'),
				'section'           => 'shakey_single_post_section',
				'type'              => 'switch',
				'default'           => 'off',
				'priority'          => 6,
				'choices'     		=> array(
					'on'				=> esc_attr__( 'On', 'shakey' ),
					'off'				=> esc_attr__( 'Off', 'shakey' ),
				),

			)
	);

	return apply_filters( 'shakey_customize_single_post_settings', $settings );

}

/**
 * Adds customize footer widget settings
 *
 * @since 1.0.0
 * @return array
 */
function shakey_customize_footer_widget_settings () {

	$settings  = array(

		array(
				'settings'          => 'footer_widget_cols',
				'label'             => __('Footer Widget Columns', 'shakey'),
				'section'           => 'shakey_footer_widget_section',
				'type'              => 'radio-buttonset',
				'default'           => '4',
				'priority'          => 10,
				'choices'     => array(
					'0'				=> __('None', 'shakey'),
					'1'				=> __('1', 'shakey'),
					'2'				=> __('2', 'shakey'),
					'3'				=> __('3', 'shakey'),
					'4'				=> __('4', 'shakey')
				),

			),
			array(
				'settings'          => 'footer_widget_rows',
				'label'             => __('Footer Widget Rows', 'shakey'),
				'section'           => 'shakey_footer_widget_section',
				'type'              => 'radio-buttonset',
				'default'           => '2',
				'priority'          => 11,
				'choices'     => array(
					'1'				=> __('1', 'shakey'),
					'2'				=> __('2', 'shakey'),
					'3'				=> __('3', 'shakey'),
					'4'				=> __('4', 'shakey')
				),

			)
	);

	return apply_filters( 'shakey_customize_footer_widget_settings', $settings );
}
