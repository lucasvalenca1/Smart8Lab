<?php 

if ( ! function_exists( 'shakey_custom_style' ) ) :

/**
|------------------------------------------------------------------------------
| Generate custom style from theme option
|------------------------------------------------------------------------------
 */

function shakey_custom_style() {
	?>

	<style type="text/css">



	<?php


	$hover_color = shakey_get_theme_option( 'hover_color_setting', '1');

	if ($hover_color == 1): 

		$primary_color = shakey_get_theme_option('primary_color', '#fe0ed6'); 
		$secondary_color = shakey_get_theme_option('secondary_color', '#e10019');

		?>

		.content-wrap .entry-title a:hover,
		.menu-wrapper .main-navigation ul li a:hover,
		.homepage-feature .homepage-feature-wrap .item-wrap .item .header-wrap .entry-title a:hover,
		.content-wrap .entry-meta span a:hover,
		.content-wrap .read-more:hover,
		.copyright a:hover,
		.menu-wrapper .follow-us span:hover, 
		.menu-wrapper .subscribe-nav span:hover,
		.menu-wrapper .follow-us ul li a:hover, 
		.menu-wrapper .subscribe-nav ul li a:hover,
		.search-close:hover,
		.toggle-navigation ul li a:hover,
		.toggle-navigation ul .sub-arrow .fa-angle-down:hover,
		.site-header .container .search a .fa:hover,
		.site-header .container .search a .fas:hover,
		#search-overlay .search-overlay-inner .search-close:hover,
		.top-pathing .top-pathing-wrap .item .entry-title a:hover,
		.widget-area .widget_tag_cloud .tagcloud a:hover,
		.shakey-recent-posts-widget ul li .post-data .cat-links a:hover,
		.shakey-recent-posts-widget ul li .post-data>a:hover,
		.widget ul li a:hover,
		.wraper-tags-link .tags-link a:hover,
		.post-grid .entry-title a:hover,
		.footer-widgets .widget_tag_cloud .tagcloud a:hover,
		.mobile-only ul li a:hover,
		.mobile-only ul .sub-arrow .fa-angle-down:hover {
			background: -webkit-linear-gradient(right, <?php echo $primary_color; ?>, <?php echo $secondary_color; ?>);
		    -webkit-background-clip: text;
		    -webkit-text-fill-color: transparent;
		}

		.nav-links .current,
		.nav-links .page-numbers:hover {
		    background: linear-gradient(to right, <?php echo $primary_color; ?>, <?php echo $secondary_color; ?>);
		    color: #fff;
		    border-color: transparent;
		}

		.post-navigation .nav-links .nav-next a, 
		.post-navigation .nav-links .nav-previous a {
			color: <?php echo $secondary_color; ?>;
		}

		.post-navigation .nav-links .nav-next a:hover, 
		.post-navigation .nav-links .nav-previous a:hover {
			color: <?php echo $primary_color; ?>;
		}

		.nav-links .dots:hover {
		    color: #000;
		    background: 0 0;
		}

		.back-to-top,
		#comments .reply a,
		.progress-bar .progressing,
		#comments .comment-form .form-submit input {
			 background: linear-gradient(to right, <?php echo $primary_color; ?>, <?php echo $secondary_color; ?>);
		}

		.post-item .post-thumbnail a:hover::after {
			background: linear-gradient(to right, <?php echo $primary_color; ?>, <?php echo $secondary_color; ?>);
			opacity: .5;
		}

		.comments-area .comment-list .comment-body {
			border-left: 2px solid <?php echo $secondary_color; ?>;
		}

		<?php

	endif; ?>

	</style>

	<?php

	}

add_action('wp_head','shakey_custom_style');
endif;