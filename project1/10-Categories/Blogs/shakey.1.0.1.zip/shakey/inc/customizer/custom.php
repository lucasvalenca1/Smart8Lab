<?php

function shakey_add_feature_settings( $sections ) {

	$sections['shakey_feature_section'] = array(
		    'title'          => __( 'Feature Settings', 'shakey' ),
		    'panel'          => 'shakey_panel',
		    'priority'       => 1,
		);


	 return $sections;
}

 add_filter( 'shakey_customize_sections', 'shakey_add_feature_settings' );


function shakey_add_style_settings( $sections ) {

	$sections['shakey_style_section'] = array(
		    'title'          => __( 'Style Settings', 'shakey' ),
		    'panel'          => 'shakey_panel',
		    'priority'       => 1,
		);


	 return $sections;
}

 add_filter( 'shakey_customize_sections', 'shakey_add_Style_settings' );

/**
 * Custom cutomize section and settings.
 *
 */
function shakey_custom_general_settings( $settings ) {
	
	$general_settings = array(

		// Back To Top
			array(
				'settings'          => 'general_back_to_top',
				'label'             => __('Back To Top', 'shakey'),
				'section'           => 'shakey_general_section',
				'type'              => 'switch',
				'default'           => 1,
				'priority'          => 14,
				'choices'     		=> array(
					'on'			=> esc_attr__( 'On', 'shakey' ),
					'off'			=> esc_attr__( 'Off', 'shakey' ),
				),

			),
		//General section

		array(
			'settings'			=> 'general_sticky_menu',
			'label'				=> __( 'Sticky Menu', 'shakey' ),
			'section'           => 'shakey_general_section',
			'type'				=> 'switch',
			'default'			=> 1,
			'priority'			=> 2,
		),	

		// Site	Layout

		array(
			'settings'          => 'general_site_layout',
			'label'             => __('Site Layout', 'shakey'),
			'description'		=> __('This layout will apply hold website. But will not apply to custom homepage.', 'shakey'),
			'section'           => 'shakey_general_section',
			'type'              => 'radio-image',
			'default'           => 'right',
			'priority'          => 1,
			'choices'     		=> array(
				'left' 			=> get_template_directory_uri() . '/assets/images/customizer/controls/left.png',
				'right'  		=> get_template_directory_uri() . '/assets/images/customizer/controls/right.png',
				),

		),	
	);

	$settings = array_merge( $general_settings, $settings);
	return apply_filters( 'shakey_custom_general_settings', $settings );
}

add_filter( 'shakey_customize_settings', 'shakey_custom_general_settings' );


/**
 * Custom single post section and settings.
 *
 */

 function shakey_customize_single_settings( $settings ) {

 	$single_settings = array(

 		// Feature Single

 		array(
			'settings'          => 'single_feature',
			'label'             => __('Show Feature Single', 'shakey'),
			'section'           => 'shakey_single_post_section',
			'type'              => 'switch',
			'default'           => 1,
			'priority'          => 2,
			'choices'     		=> array(
				'on'			=> esc_attr__( 'On', 'shakey' ),
				'off'			=> esc_attr__( 'Off', 'shakey' ),
			),

		),

		// Single Post meta data

		array(
			'settings'          => 'sigle_posts_metadata',
			'label'             => sprintf('<h3 class="azb-customize-title">%s</h3>', __('Show/Hide Single Post Meta Data', 'shakey') ),
			'description'		=> __( 'Check them to show single post meta data.', 'shakey'),
			'section'           => 'shakey_single_post_section',
			'type'              => 'multicheck',
			'default'           => array('author', 'date'),
			'priority'          => 1,
			'choices'     		=> array(
				'author'				=> esc_attr__( 'Author', 'shakey' ),
				'date'					=> esc_attr__( 'Date', 'shakey' ),
			),
		),

		//Show Tag List section

		array(
			'settings'			=> 'single_tag_list',
			'label'				=> __( 'Tag List', 'shakey' ),
			'section'           => 'shakey_single_post_section',
			'type'				=> 'switch',
			'default'			=> 1,
			'priority'			=> 6,
		),	

 	);

 	$settings = array_merge( $single_settings, $settings);
	return apply_filters( 'shakey_customize_single_settings', $settings );
 }

 add_filter( 'shakey_customize_settings', 'shakey_customize_single_settings' );

/**
 * Custom feature section and settings.
 *
 */

function shakey_section_feature_settings ( $settings ) {

	$feature_settings = array (

		array(
			'settings'          => 'homepage_feature',
			'label'             => __('Show Feature Homepage', 'shakey'),
			'section'           => 'shakey_feature_section',
			'type'              => 'switch',
			'default'           => 1,
			'priority'          => 1,

		),

		array(
			'settings'          => 'feature_title',
			'label'             => __('Feature Title', 'shakey'),
			'section'           => 'shakey_feature_section',
			'type'              => 'text',
			'default'           => __('Daily Picks', 'shakey'),
			'priority'          => 2,

			'active_callback' => array(
				array(
					'setting'  => 'homepage_feature',
					'operator' => '==',
					'value'    => true,
				)
			)

		),

		array(
			'settings'		=> 'shakey_select_list',
			'type'        	=> 'select',
			'label'       	=> __( 'Select One Category', 'shakey' ),
			'section'		=> 'shakey_feature_section',
			'default'    	=> 0,
			'choices'		=> shakey_get_category_list(),
			'priority'			=> 3,
			'active_callback'	=> array(
					array(
						'setting'  => 'homepage_feature',
						'operator' => '==',
						'value'    => 1,
					)
			)
		),
	);

	$settings = array_merge( $feature_settings, $settings);

	return apply_filters( 'shakey_section_feature_settings', $settings );
}


 add_filter( 'shakey_customize_settings', 'shakey_section_feature_settings' );

 /**
 * Custom style section and settings.
 *
 */

function shakey_section_style_settings ( $settings ) {

	$style_settings = array (

		array(
			'settings'          => 'hover_color_setting',
			'label'             => __('Hover Color', 'shakey'),
			'section'           => 'shakey_style_section',
			'type'              => 'switch',
			'default'           => 1,
			'priority'          => 1,

		),

		array(
			'settings'          => 'primary_color',
			'label'             => __('Primary Color', 'shakey'),
			'section'           => 'shakey_style_section',
			'type'              => 'color',
			'default'           => __('#fe0ed6', 'shakey'),
			'priority'          => 2,

			'active_callback' => array(
				array(
					'setting'  => 'hover_color_setting',
					'operator' => '==',
					'value'    => true,
				)
			)

		),

		array(
			'settings'          => 'secondary_color',
			'label'             => __('Secondary Color', 'shakey'),
			'section'           => 'shakey_style_section',
			'type'              => 'color',
			'default'           => __('#e10019', 'shakey'),
			'priority'          => 3,

			'active_callback' => array(
				array(
					'setting'  => 'hover_color_setting',
					'operator' => '==',
					'value'    => true,
				)
			)

		),
	);

	$settings = array_merge( $style_settings, $settings);

	return apply_filters( 'shakey_section_style_settings', $settings );
}


 add_filter( 'shakey_customize_settings', 'shakey_section_style_settings' );

/**
 * Custom footer section and settings.
 *
 */

 function shakey_customize_footer_settings( $settings ) {

 	$footer_settings = array(

 		// Copyright

 		array(
			'settings'          => 'footer_copyright',
			'label'             => __('Copyright', 'shakey'),
			'section'           => 'shakey_footer_widget_section',
			'type'              => 'switch',
			'default'           => 1,
			'priority'          => 9,
			'choices'     		=> array(
				'on'			=> esc_attr__( 'On', 'shakey' ),
				'off'			=> esc_attr__( 'Off', 'shakey' ),
			),

		),
 	);

 	$settings = array_merge( $footer_settings, $settings);
	return apply_filters( 'shakey_customize_footer_settings', $settings );
 }

 add_filter( 'shakey_customize_settings', 'shakey_customize_footer_settings' );

// Remove Control

add_filter( 'shakey_customize_general_settings', 'shakey_remove_some_controls' );

	function shakey_remove_some_controls( $fields ) {

		$fields[] = array(

			'settings'		=> 'general_post_show_thumbnail',
			'type'			=> 'switch',

		);

		$fields[] = array(

			'settings'		=> 'general_posts_date_prefix',
			'type'			=> 'text',

		);

		$fields[] = array(

			'settings'		=> 'general_posts_modified_date',
			'type'			=> 'switch',

		);

		return $fields;
}

// Remove Layout Setting

add_filter( 'shakey_customize_layout_settings', 'shakey_remove_layout_controls' );

	function shakey_remove_layout_controls( $fields ) {

		$fields[] = array(

			'settings'		=> 'layout',
			'type'			=> 'radio-image',

		);

		$fields[] = array(

			'settings'		=> 'layout_show_thumbnail',
			'type'			=> 'switch',

		);

		$fields[] = array(

			'settings'		=> 'layout_thumbnail_pos',
			'type'			=> 'radio-buttonset',

		);

		return $fields;
}

// Remove Single Setting

add_filter( 'shakey_customize_single_post_settings', 'shakey_remove_single_controls' );

	function shakey_remove_single_controls( $fields ) {

		$fields[] = array(

			'settings'		=> 'single_post_metadata',
			'type'			=> 'multicheck',

		);

		$fields[] = array(

			'settings'		=> 'single_post_modified_date',
			'type'			=> 'switch',

		);

		return $fields;
}

// Get Category List

function shakey_get_category_list() {
	
	$categories = get_categories();
	$cats[0] = __('All Categories', 'shakey');
	
	foreach ($categories as $cat) {
		$cats[$cat->cat_ID] = $cat->name;
	}

	return $cats;
}