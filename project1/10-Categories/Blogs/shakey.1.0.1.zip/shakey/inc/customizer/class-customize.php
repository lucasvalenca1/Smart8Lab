<?php
/**
 * Shakey Customize Class
 *
 * @author   ThemeCountry
 * @since    1.0.0
 * @package  shakey
 *
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'Shakey_Customizer' ) ) {

	/**
	 * Shakey Customize Class
	 *
	 * @since 1.0.0
	 * @version 1.0
	 */
	class Shakey_Customize {

		/**
		 * Class setup
		 *
		 * @since  1.0
		 * @access public
		 */
		public function __construct() {

			// Include Kirki Helper Class
			$this->includes();

			// Add Field
			add_action( 'init', array( $this, 'init_kirki' ) );
			add_filter( 'body_class', array( $this, 'body_classes' ) );
		}

		/**
		 * Includes files for Shakey Customizer
		 *
		 * @since 1.0
		 * @access private
		 * @return void
		 */
		private function includes() {

			require_once get_template_directory() . '/inc/helpers/class-include-kirki.php';
			require_once get_template_directory() . '/inc/helpers/class-shakey-kirki.php';
			require_once get_template_directory() . '/inc/customizer/customize-settings.php';
			require_once get_template_directory() . '/inc/customizer/custom.php';
		}

		/**
		 * Initials Kirki customize
		 *
		 * @since 1.0
		 * @return void
		 */
		public function init_kirki() {

			Shakey_Kirki::add_config( SHAKEY_CUSTOMIZE_ID, array(
				'capability'    => 'edit_theme_options',
				'option_type'   => 'option',
				'option_name'	=> SHAKEY_CUSTOMIZE_ID . '_name'
			) );


			Shakey_Kirki::add_panel( 'shakey_panel' , array(
			    'priority'    => 100,
			    'title'       => __( 'Theme Options', 'shakey' ),
			    'description' => __( 'The basic theme options for free version.', 'shakey' ),
			) );

			// Add customize sections and fields
			$this->add_sections_settings();
		}

		/**
		 * Initils to add customize sections and settings.
		 *
		 * @since 1.0
		 * @return void
		 */
		private function add_sections_settings() {

			$sections = apply_filters ('shakey_customize_sections', $this->sections() );

			$fields = apply_filters ('shakey_customize_settings', $this->add_settings() );

			// Generate sections
			foreach( $sections as $key => $section ) {

				Shakey_Kirki::add_section( $key, $section);

			}

			// Generate fields
			foreach ( $fields as $field) {

				Shakey_Kirki::add_field( SHAKEY_CUSTOMIZE_ID, $field );
			}

		}

		/**
		 * Adds theme cutomize section
		 *
		 * @since 1.0
		 * @return void
		 */
		private function sections() {

			return array(
				'shakey_general_section' => array(
				    'title'          => __( 'Genneral Settings', 'shakey' ),
				    'panel'          => 'shakey_panel',
				    'priority'       => 10,
				),
				'shakey_layout_section' => array(
				    'title'          => __( 'Layout Settings', 'shakey' ),
				    'panel'          => 'shakey_panel',
				    'priority'       => 20,
				),
				'shakey_single_post_section' => array(
				    'title'          => __( 'Single Post Settings', 'shakey' ),
				    'panel'          => 'shakey_panel',
				    'priority'       => 30,
				),
				'shakey_footer_widget_section' => array(
				    'title'          => __( 'Footer Widget Settings', 'shakey' ),
				    'panel'          => 'shakey_panel',
				    'priority'       => 40,
				)
			);
		}

		/**
		 * Adds theme customize settings
		 *
		 * @since 1.0
		 * @return array
		 */
		private function add_settings() {
			// Default layout fields
			$setttings = array_merge(
							shakey_customize_general_settings(),
							shakey_customize_layout_settings(),
							shakey_customize_single_post_settings(),
							shakey_customize_footer_widget_settings()
						);

			return $setttings;
		}

		/**
		 * Adds custom classes to the array of body classes.
		 *
		 * @param array $classes Classes for the body element.
		 * @since  1.0
		 * @return array
		 */
		public function body_classes( $classes ) {

			// Adds a class of group-blog to blogs with more than 1 published author.
			if ( is_multi_author() ) {
				$classes[] = 'group-blog';
			}

			$layout = shakey_get_theme_option( 'general_site_layout', 'right' );

			// Switch Sidebar Layout to left
			if ( 'left' == $layout ) {
				$classes[] = 'sidebar-left';
			}

			return $classes;
		}

	}
}

return new Shakey_Customize();
