<?php
/**
 * Shakey template functions.
 *
 * @author  ThemeCountry
 * @since 	1.0.0
 * @package Shakey
 */

if ( ! function_exists( 'shakey_skip_links' ) ) {
	/**
	 * Skip links
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_skip_links() {
		?>

			<a class="skip-link screen-reader-text" href="#site-navigation"><?php esc_attr_e( 'Skip to navigation', 'shakey' ); ?></a>
			<a class="skip-link screen-reader-text" href="#content"><?php esc_attr_e( 'Skip to content', 'shakey' ); ?></a>

		<?php
	}
}

if ( ! function_exists( 'shakey_add_editor_style' ) ) {
	/**
	 * Fix No reference to add_editor_style()
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_add_editor_style() {

		add_editor_style( 'custom-editor-style.css' );

	}
}

if ( ! function_exists( 'shakey_toggle_menu' ) ) {

	function shakey_toggle_menu() {

		if ( has_nav_menu( 'toggle' ) ) {

		?>

		<div class="toggle-menu">
			<span></span>
			<span></span>
			<span></span>
		</div>

		<?php

		} else {

		?>

		<div class="toggle-menu toggle-mobile">
			<span></span>
			<span></span>
			<span></span>
		</div>

		<?php

		}
	}
}

if ( ! function_exists( 'shakey_site_branding' ) ) {
	/**
	 * Site branding wrapper and display
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_site_branding() {
		?>

			<div id="logo" class="site-branding clearfix">
				<?php shakey_site_title_or_logo(); ?>
			</div>

		<?php
	}
}


if ( ! function_exists( 'shakey_site_title_or_logo' ) ) {
	/**
	 * Display the site title or logo
	 *
	 * @since 1.0.0
	 * @param bool $echo Echo the string or return it.
	 * @return string
	 */
	function shakey_site_title_or_logo( $echo = true ) {

		if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {

			$logo = get_custom_logo();
			$html = is_home() ? '<h1 class="logo">' . $logo . '</h1>' : '<h2 class="logo">' . $logo . '</h2>';

		} elseif ( function_exists( 'jetpack_has_site_logo' ) && jetpack_has_site_logo() ) {

			// Copied from jetpack_the_site_logo() function.
			$logo    = site_logo()->logo;
			$logo_id = get_theme_mod( 'custom_logo' ); // Check for WP 4.5 Site Logo
			$logo_id = $logo_id ? $logo_id : $logo['id']; // Use WP Core logo if present, otherwise use Jetpack's.
			$size    = site_logo()->theme_size();
			$html    = sprintf( '<a href="%1$s" class="site-logo-link" rel="home" itemprop="url">%2$s</a>',
				esc_url( home_url( '/' ) ),
				wp_get_attachment_image(
					$logo_id,
					$size,
					false,
					array(
						'class'     => 'site-logo attachment-' . $size,
						'data-size' => $size,
						'itemprop'  => 'logo'
					)
				)
			);

			$html = apply_filters( 'jetpack_the_site_logo', $html, $logo, $size );

		} else {

			$tag = is_home() ? 'h1' : 'h2';

			$html = '<' . esc_attr( $tag ) . ' class="site-title"><a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . esc_html( get_bloginfo( 'name' ) ) . '</a></' . esc_attr( $tag ) .'>';

			if ( '' !== get_bloginfo( 'description' ) ) {
				$html .= '<p class="site-description">' . esc_html( get_bloginfo( 'description', 'display' ) ) . '</p>';
			}

		}

		if ( ! $echo ) {

			return $html;
		}

		echo $html;
	}
}


if ( ! function_exists( 'shakey_progress_bar' ) ) {
	/**
	 * Site branding wrapper and display
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_progress_bar() {
		?>

			<div class="progress-bar"><div class="progressing"></div></div>

		<?php
	}
}


if ( ! function_exists( 'shakey_menu_header' ) ) {

	function shakey_menu_header() {

		if ( has_nav_menu( 'primary' ) || has_nav_menu( 'subscribe' ) || has_nav_menu( 'social' ) ) :

			echo '<div class="menu-wrapper">';

			if ( has_nav_menu( 'primary' )):

				?>

				<nav id="site-navigation" class="main-navigation default-menustyle" role="navigation">

					<?php
						// Display Primary Navigation.
						wp_nav_menu( array(
							'theme_location' => 'primary',
							'menu_id' 		 => 'primary-navigation',
							'container' 	 => '',
							'menu_class' 	 => 'main-navigation-menu',
							)
						);

					?>

				</nav><!-- #site-navigation -->

			<?php

			endif;

			if ( has_nav_menu( 'subscribe' )):

			?>

				<div class="subscribe-nav">

					<?php

					printf( '<span>' . esc_html__( 'Subscribe' , 'shakey' )  . '</span>' );
						// Display Social Menu
						wp_nav_menu( array(
							'theme_location' => 'subscribe',
							'menu_id' 		 => 'subscribe-menu',
							'container' 	 => '',
							'menu_class' 	 => 'subscribe-menu',
							)
						);

					?>
				</div> <!--.subscribe-menu -->

			<?php

			endif;

			if ( has_nav_menu( 'social' )):

			?>

				<div class="follow-us">

					<?php

						printf( '<span>' . esc_html__( 'Follow' , 'shakey' )  . '</span>' );
						// Display Social Menu
						wp_nav_menu( array(
							'theme_location' => 'social',
							'menu_id' 		 => 'social-menu',
							'container' 	 => '',
							'menu_class' 	 => 'social-menu',
							)
						);

					?>
				</div> <!-- .follow-us -->

			<?php

		endif;

		echo '</div>';

	endif;

	}
}

if ( ! function_exists( 'shakey_search' ) ) {

	function shakey_search() {

		?>

		<div class="search">

		 	<a id="trigger-overlay">
		 		<i class="fas fa-search"></i>
		 	</a>

		</div><!-- .search -->

	<?php

	}

}

if ( ! function_exists( 'shakey_paging_nav' ) ) :
/**
 * Display navigation to next/previous set of posts when applicable.
 */
function shakey_paging_nav() {

	the_posts_pagination( array(
		'prev_text'      	=> __( '<i class="fa fa-angle-left"></i>', 'shakey' ),
		'next_text'		  => __( '<i class="fa fa-angle-right"></i>', 'shakey' ),
		'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'shakey' ) . ' </span>',
	) );

}
endif;


if ( ! function_exists( 'shakey_single_post_title' ) ) {
	/**
	 * Display the Single Post Title
	 *
	 * @since 1.0.0
	 */
	function shakey_single_post_title() {

		if ( is_single() ) {

		?>
			<div class="wraper-header-single">
				<div class="container">
					<header class="entry-header">

						<?php do_action('shakey_before_single_title'); ?>

						<?php the_title( '<h1 class="entry-title single-title">', '</h1>' ); ?>

						<?php do_action('shakey_after_single_title'); ?>
					</header>
				</div>
			</div>
			<?php

		}

	}

}

if ( ! function_exists( 'shakey_tags_list' ) ) {
	/**
	 * Display the Tag list
	 *
	 * @since 1.0.0
	 */
	function shakey_tags_list() {

		$tags_list = get_the_tag_list( '', ' ');

		$enable_tags = shakey_get_theme_option( 'single_tag_list', 1 );

		if(!$enable_tags)
			return;

		if ( is_single() && $tags_list ) {

		printf( '<div class="wraper-tags-link"><div class="container"><div class="tags-link">' . ' %1$s ' . ' </div></div></div>', $tags_list );
		}

	}

}

if ( ! function_exists( 'shakey_post_thumbnail' ) ) :
	/**
	 * Display Post Thumbnail
	 */
	function shakey_post_thumbnail() {

		$size = apply_filters( 'shakey_post_thumbnail_size', 'shakey-large-thumbnail' );
		$show = apply_filters( 'shakey_post_thumbnail_show', true );

			?>
				<div class="post-thumbnail">
					<a href="<?php the_permalink() ?>" rel="bookmark">
						<?php shakey_the_post_thumbnail( $size, '', true ) ?>
					 </a>
				</div>
			<?php
		}

endif;

if ( ! function_exists( 'shakey_post_grid_thumbnail' ) ) :

	/**
	 * Display Post Grid Thumbnail
	 */

	function shakey_post_grid_thumbnail() {

		$size = apply_filters( 'shakey_post_thumbnail_size', 'shakey-grid-thumbnail' );
		$show = apply_filters( 'shakey_post_thumbnail_show', true );

		if ( $show ) {
			?>
				<div class="post-thumbnail">
					<a href="<?php the_permalink() ?>" rel="bookmark">
						<?php shakey_the_post_thumbnail( $size, '', true ) ?>
					 </a>
				</div>
			<?php
		}


	}

endif;

if ( ! function_exists( 'shakey_post_header' ) ) :

			/**
	 * Display post single header
	 */

	function shakey_post_header() {

		?>

		<header class="entry-header">

			<?php

			do_action( 'shakey_before_post_title');

			if ( is_single() ) {

				the_title( '<h1 class="entry-title single-title">', '</h1>' );
			} else {

				the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
			}

			do_action( 'shakey_after_post_title');

			?>

		</header><!-- .entry-header -->

		<?php

	}

endif;


if ( ! function_exists( 'shakey_single_post_thumbnail' ) ) :
	/**
	 * Display Single Post Thumbnail
	 */
	function shakey_single_post_thumbnail() {

		$enable_thumbnail = shakey_get_theme_option( 'single_post_show_thumbnail', 1 );

		if ( $enable_thumbnail ) :

		?>
			<p>
				<?php if ( has_post_thumbnail() ) : ?>

				<?php the_post_thumbnail( 'full') ?>

				<?php else : ?>

					 <img src="<?php echo get_template_directory_uri(); ?>/assets/images/single-thumbnails.jpg" />

				<?php endif; ?>

			</p>
		<?php

		endif;

	}

endif;

if ( ! function_exists( 'shakey_post_nav' ) ) {

	/**
	 * Display navigation to next/previous post when applicable.
	 */
	function shakey_post_nav() {

		$args = array(
			'next_text' => '%title',
			'prev_text' => '%title',
		);

		$enable_postnav = shakey_get_theme_option('single_post_show_nav', true);

		if ( $enable_postnav ) {

			the_post_navigation( $args );

		}
	}

}


if ( ! function_exists( 'shakey_display_comments' ) ) {
	/**
	 * Shakey display comments
	 *
	 * @since  1.0.0
	 */
	function shakey_display_comments() {
		// If comments are open or we have at least one comment, load up the comment template.
		if ( comments_open() || '0' != get_comments_number() ) :
			comments_template();
		endif;
	}
}


if ( ! function_exists( 'shakey_content_open' ) ) :

	/**
	 * Content Wrapper
	 */

	function shakey_content_open() {

		?>
			<div class="content-wrap">

		<?php
	}

endif;

if ( ! function_exists( 'shakey_read_more' ) ) :
	/**
	 * Displays the more link on posts
	 */
	function shakey_read_more() {

		$read_more = shakey_get_theme_option('general_post_show_readmore', 1);

		if(!$read_more)
			return;

		$readmore_text = trim( shakey_get_theme_option( 'general_post_show_readmore_label', 'Read More' ) );

			if ( ! empty( $readmore_text ) ) {

		?>

		<a href="<?php echo esc_url( get_permalink() ) ?>"  title="<?php the_title() ?>" class="read-more"><?php echo esc_html( $readmore_text ); ?></a>

		<?php

		}
	}

endif;

if ( ! function_exists( 'shakey_content_close' ) ) :

	/**
	 * Content Wrapper
	 */

	function shakey_content_close() {
		echo '</div><!-- .content-wrap -->';
	}

endif;



if ( ! function_exists( 'shakey_post_on' ) ) :

	/**
	 * Display post on
	 */

	function shakey_post_on() {

		$posted_on = apply_filters( 'shakey_posted_on_show', true );

		?>
			<?php if ( 'post' === get_post_type() && $posted_on ) : ?>
				<?php shakey_posted_on(); ?>
			<?php endif; ?>

		<?php
	}

endif;

if ( ! function_exists( 'shakey_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function shakey_posted_on() {

	$meta_options = shakey_get_theme_option( 'general_posts_metadata', array('date', 'category') );

	if(empty($meta_options))
		return;

	if(is_array($meta_options))
		$meta_options = array_flip($meta_options);

	echo '<div class="entry-meta">';

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%3$s">%4$s</time>';
	}

	$categories_list = get_the_category_list( ' ' );

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>';

	if ( isset ( $meta_options['category'] ) && $categories_list ) {

		printf( '<span class="cat-links">' . ' %1$s ' . ' </span>', $categories_list ); // WPCS: XSS OK.
	}

	if ( isset ( $meta_options['date'] ) ) {

		printf( '<span class="posted-on"> ' . ' %1$s ' . ' </span>', $posted_on );
	}

	echo '</div><!-- .entry-meta -->';

}
endif;

//Entry Footer Meta


if ( ! function_exists( 'shakey_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function shakey_entry_footer() {

	$meta_options = shakey_get_theme_option( 'general_posts_metadata', array('author', 'tag') );

	if(empty($meta_options))
		return;

	if(is_array($meta_options))
		$meta_options = array_flip($meta_options);


	echo '<div class="entry-meta entry-footer">';

	$tags_list = get_the_tag_list( '', esc_html__( ', ', 'shakey' ) );

	$byline = '<a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a>';

	if ( isset ( $meta_options['author'] ) ) {

		printf( '<span class="author"> ' . esc_html__( ' By %1$s ', 'shakey' ) . ' </span>', $byline );
	}

	if ( isset ($meta_options['tag'] ) && $tags_list  ) {

		printf( '<span class="tags-links">' . esc_html__( 'Tag: %1$s ', 'shakey' ) . ' </span>', $tags_list ); // WPCS: XSS OK.
	}

	echo '</div><!-- .entry-meta -->';

}
endif;


if ( ! function_exists( 'shakey_post_content' ) ) {
	/**
	 * Display the post content with a link to the single post
	 *
	 * @since 1.0.0
	 */
	function shakey_post_content() {

		$excerpt = shakey_get_theme_option( 'general_post_show_excerpt', true );

		?>
		<div class="entry-content">
		<?php

		/**
		 * Functions hooked in to shakey_post_content_before action.
		 *
		 * @hooked shakey_post_thumbnail - 10
		 */
		do_action( 'shakey_post_content_before' );

		if ( $excerpt ) {

			the_excerpt();

		}

		do_action( 'shakey_post_content_after' );

		wp_link_pages( array(
			'before' => '<div class="page-links">' . __( 'Pages:', 'shakey' ),
			'after'  => '</div>',
		) );
		?>
		</div><!-- .entry-content -->

		<?php
	}
}

//Single Post Meta

if ( ! function_exists( 'shakey_single_post_meta' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function shakey_single_post_meta() {
	global $post;
	$author_id=$post->post_author;


	$meta_options = shakey_get_theme_option( 'sigle_posts_metadata', array('author', 'date') );

	if(empty($meta_options))
		return;

	if(is_array($meta_options))
		$meta_options = array_flip($meta_options);

	echo '<div class="entry-meta">';

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>';

	$byline = '<a class="url fn n" href="' . esc_url( get_author_posts_url( $author_id ) ) . '">' . esc_html( get_the_author_meta( 'display_name', $author_id ) ) . '</a>';

	if ( isset ( $meta_options['author'] ) ) {

		printf( '<span class="author">' . esc_html__( 'By %1$s ', 'shakey' ) . ' </span>', $byline );
	}

	if ( isset ( $meta_options['date'] ) ) {

		printf( '<span class="posted-on"> ' . ' %1$s ' . ' </span>', $posted_on );
	}

	echo '</div><!-- .entry-meta -->';

}
endif;


if ( ! function_exists( 'shakey_footer_widgets' ) ) {
	/**
	 * Display the footer widget regions.
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_footer_widgets() {
		$rows    = intval( apply_filters( 'shakey_footer_widget_rows', 1 ) );
		$regions = intval( apply_filters( 'shakey_footer_widget_columns', 4 ) );

		for ( $row = 1; $row <= $rows; $row++ ) :

			// Defines the number of active columns in this footer row.
			for ( $region = $regions; 0 < $region; $region-- ) {
				if ( is_active_sidebar( 'footer-' . strval( $region + $regions * ( $row - 1 ) ) ) ) {
					$columns = $region;
					break;
				}
			}

			if ( isset( $columns ) ) : ?>
				<div class=<?php echo '"footer-widgets row-' . strval( $row ) . ' col-' . strval( $columns ) . ' fix"'; ?>><?php

					for ( $column = 1; $column <= $columns; $column++ ) :
						$footer_n = $column + $regions * ( $row - 1 );

						if ( is_active_sidebar( 'footer-' . strval( $footer_n ) ) ) : ?>

							<div class="block footer-widget-<?php echo strval( $column ); ?>">
								<?php dynamic_sidebar( 'footer-' . strval( $footer_n ) ); ?>
							</div><?php

						endif;
					endfor; ?>

				</div><!-- .footer-widgets.row-<?php echo strval( $row ); ?> --><?php

				unset( $columns );

			endif;
		endfor;
	}
}


if ( ! function_exists( 'shakey_single_post_header' ) ) {
	/**
	 * Display single post header
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_single_post_header() {
		?>
		<?php
	}
}

if ( ! function_exists( 'shakey_inner_wrapper' ) ) {
	/**
	 * Display inner wrapper
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_inner_wrapper() {
		?>
		<div class="site-info clearfix">

			<?php echo "shakey_inner_wrapper"; ?>

		</div><!-- .site-info -->
		<?php
	}
}

if ( ! function_exists( 'shakey_post_single_content' ) ) {
	/**
	 * Display post content single
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_post_single_content() {
		?>

		<div class="entry-content">
		<?php

			/**
			 * Functions hooked in to shakey_post_content_before action.
			 *
			 * @hooked shakey_single_post_thumbnail - 10
			 */
			do_action( 'shakey_post_single_content_before' );

			the_content(
				sprintf(
					__( 'Continue reading %s', 'shakey' ),
					'<span class="screen-reader-text">' . get_the_title() . '</span>'
				)
			);

			do_action( 'shakey_post_single_content_after' );

			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'shakey' ),
				'after'  => '</div>',
			) );
		?>
		</div><!-- .entry-content -->

		<?php
	}
}

if ( ! function_exists( 'shakey_get_sidebar' ) ) {
	/**
	 * Display shakey sidebar
	 *
	 * @uses get_sidebar()
	 * @since 1.0.0
	 */
	function shakey_get_sidebar() {

		get_sidebar();

	}

}

if ( ! function_exists( 'shakey_credit' ) ) {
	/**
	 * Display the theme credit
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_credit() {

		$enable_copyright = shakey_get_theme_option( 'footer_copyright', 1 );

		if ( $enable_copyright ) :

		?>
		<div class="copyright">

				<?php echo esc_html( apply_filters( 'shakey_copyright_text', $content = '&copy; ' . get_bloginfo( 'name' ) . ' ' . date( 'Y' ) ) ); ?>

				<?php if ( apply_filters( 'shakey_credit_link', true ) ) { ?>

					<?php echo ( sprintf(__( '&bull; <a href="%s" rel="author" title="Shakey - The best free WordPress blog theme for WordPress"> Shakey</a> powered by <a href="http://wordpress.org/">WordPress</a>', 'shakey' ), 'https://www.thesatmag.com/themes/shakey/' )); ?>


				<?php } ?>

		</div><!-- .copyright -->
		<?php

		endif;
	}
}

if ( ! function_exists( 'shakey_page_title' ) ) {
	/**
	 * Display the post header with a link to the single post
	 *
	 * @since 1.0.0
	 */
	function shakey_page_title() {
		if ( is_page() ) {

			?>
			<div class="wraper-header-page">
				<div class="container">
					<header class="entry-header">
				<?php
					the_title( '<h1 class="entry-title page-title">', '</h1>' );
				?>
					</header><!-- .entry-header -->
				</div>
			</div>
			<?php
		}
	}
}

//Page Meta

if ( ! function_exists( 'shakey_page_meta' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
	function shakey_page_meta() {
		global $post;
		$author_id=$post->post_author;


		$meta_options = shakey_get_theme_option( 'general_posts_metadata', array('author', 'date') );

		if(empty($meta_options))
			return;

		if(is_array($meta_options))
			$meta_options = array_flip($meta_options);

		echo '<div class="entry-meta">';

		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		$posted_on = '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>';

		$byline = '<a class="url fn n" href="' . esc_url( get_author_posts_url( $author_id ) ) . '">' . esc_html( get_the_author_meta( 'display_name', $author_id ) ) . '</a>';

		if ( isset ( $meta_options['author'] ) ) {

			printf( '<span class="author">' . esc_html__( 'By %1$s ', 'shakey' ) . ' </span>', $byline );
		}

		if ( isset ( $meta_options['date'] ) ) {

			printf( '<span class="posted-on"> ' . ' %1$s ' . ' </span>', $posted_on );
		}

		echo '</div><!-- .entry-meta -->';

	}
endif;

if ( ! function_exists( 'shakey_page_content' ) ) {
	/**
	 * Display the post content with a link to the single post
	 *
	 * @since 1.0.0
	 */
	function shakey_page_content() {
		?>
		<div class="entry-content">
			<?php the_content(); ?>
			<?php
				wp_link_pages( array(
					'before' => '<div class="page-links">' . __( 'Pages:', 'shakey' ),
					'after'  => '</div>',
				) );
			?>
		</div><!-- .entry-content -->
		<?php
	}
}


if ( ! function_exists( 'shakey_footer_nav' ) ) {
	/**
	 * Display Footer Menu
	 *
	 * @since  1.0.0
	 * @return void
	 */
	function shakey_footer_nav() {

		// Check if there is a footer menu.
		if ( has_nav_menu( 'footer' ) ) {

			echo '<nav id="footer-links" class="footer-navigation" role="navigation">';

			wp_nav_menu( array(
					'theme_location' => 'footer',
					'container' => false,
					'menu_class' => 'footer-menu',
					'echo' => true,
					'fallback_cb' => '',
					'depth' => 1,
				)
			);

			echo '</nav><!-- #footer-links -->';
		}

	}

}

// Back to Top

if ( ! function_exists( 'shakey_back_to_top' ) ) {
	/**
	 * Button back to top.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shakey_back_to_top() {

		$back_to_top = shakey_get_theme_option( 'general_back_to_top' , '1' );

		if ( $back_to_top == 1) {
			echo '<span class="back-to-top"><i class="fa fa-chevron-up"></i></span>';
		}
	}
}

/**
|------------------------------------------------------------------------------
| Excerpt
|------------------------------------------------------------------------------
|
*/

function shakey_excerpt_length( $length ) {

	$excerpt_length = shakey_get_theme_option('general_post_excerpt_length' , 20);

	$number = intval ($excerpt_length) > 0 ?  intval ($excerpt_length) : $length;
	return $number;
}
add_filter( 'excerpt_length', 'shakey_excerpt_length', 999 );

function shakey_excerpt_more( $more ) {

	return shakey_get_theme_option( 'general_post_show_excerpt_more' , ' ...' );
}

add_filter('excerpt_more', 'shakey_excerpt_more');

function shakey_remove_title_archive( $title ) {

		if ( is_category() ) {

			$title = single_cat_title( '', false );

		} elseif ( is_tag() ) {

			$title = single_tag_title( '', false );

		} elseif ( is_author() ) {

			$title = '<span class="vcard">' . get_the_author() . '</span>' ;

		}

		return $title;
}
add_filter('get_the_archive_title', 'shakey_remove_title_archive');

/**
|------------------------------------------------------------------------------
| Search Header
|------------------------------------------------------------------------------
|
*/

if ( ! function_exists( 'shakey_search_overlay' ) ) {

	function shakey_search_overlay() { ?>

		<div id="search-overlay">
			<div class="search-overlay-inner">
				<i class="fas fa-times search-close"></i>
				<?php
					/**
					 * Search Form
					 *
					 * @search from WordPress
					 */
					echo get_search_form();
				?>
				<p class="search-label"><?php _e( 'Type keyword to search','shakey' ) ?></p>
			</div>
		</div>

	<?php
	}
}

if ( ! function_exists( 'shakey_toggle_nav' ) ) {

	/**
	 * Toggle Navigation
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shakey_toggle_nav() {

		if ( has_nav_menu( 'toggle' ) ) :

			?>
			<nav id="toggle-navigation" class="toggle-navigation" role="navigation">
				<div class="close-toggle-menu">
					<div class="menu-toggle-close"><i class="fas fa-times search-close"></i></div>
				</div>
				<?php
					wp_nav_menu( array(
						'theme_location' 	=> 'toggle',
						'menu_id' 			=> 'toggle-nav',
						'menu_class' 		=> 'toggle-nav',
						'container'			=> '',
					) );
				?>
			</nav><!-- #site-navigation -->

			<?php
		endif;
	}
}

if ( ! function_exists( 'shakey_light_box' ) ) {

	/**
	 * Light Box
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shakey_light_box() {

		if ( has_nav_menu( 'toggle' ) ) { echo '<div id="lightbox"></div>'; }
	}
}

/**
|------------------------------------------------------------------------------
| Search Result
|------------------------------------------------------------------------------
|
*/
if ( ! function_exists( 'shakey_search_result' ) ) {

	function shakey_search_result() { ?>

		<div id="search-result">
			<div class="search-result-inner">
				<?php
					/**
					 * Search Form
					 *
					 * @search from WordPress
					 */
					echo get_search_form();
				?>
				<p class="search-label"><?php _e( 'Type keyword to search','shakey' ) ?></p>
			</div>
		</div>

	<?php
	}
}

/**
|------------------------------------------------------------------------------
| Top Pathing
|------------------------------------------------------------------------------
|
*/
if ( ! function_exists( 'shakey_top_pathing' ) ) {

	function shakey_top_pathing() {

		$feature_single = shakey_get_theme_option( 'single_feature', 1 );

		if ( is_single() && $feature_single ) :

			?>

			<div class="top-pathing">

				<div class="container">

				<?php
				global $wp_query;

				$args = array(
					'category__in'			=> '',
					'posts_per_page'		=> 4,
					'ignore_sticky_posts'	=> 1
				);

				$top_pathing = new WP_Query( $args );



				if ( $top_pathing->have_posts() ) :

				?>
					<div class="top-pathing-wrap">
						<?php if ( have_posts() ) : ?>

							<?php
							while ($top_pathing->have_posts() ) : $top_pathing->the_post();

								if ( has_post_thumbnail() ) :

							?>
							<div class="item">
								<a href="<?php the_permalink() ?>">
									<?php the_post_thumbnail('shakey-small-thumbnail') ?>
								</a>
								<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
							</div>

						<?php
								endif;
							endwhile;
						endif;
						wp_reset_query();
						?>
					</div>

				<?php
					endif;
					wp_reset_postdata();
				?>

				</div>

			</div>

		<?php

		endif;
	}
}

/**
|------------------------------------------------------------------------------
| Feature Homepage
|------------------------------------------------------------------------------
|
*/

if ( ! function_exists( 'shakey_homepage_thumbnail' ) ) {

	function shakey_homepage_thumbnail() {

			$enable_feature = shakey_get_theme_option( 'homepage_feature', 1 );

			if(!$enable_feature)
				return;

			$feature_title = trim( shakey_get_theme_option( 'feature_title', 'Daily Picks' ) );

			$featured_cat = shakey_get_theme_option( 'shakey_select_list', 0 );

			global $paged;
			global $wp_query;

			// $paged = $wp_query->get( 'paged' );

			if (is_home() && (! $paged || $paged < 2 ) ) :

			?>

			<div class="homepage-feature">

				<div class="container">

			<?php

			// Get latest posts from database
			$args = array(
				'posts_per_page' => 3,
				'ignore_sticky_posts' => true
			);

			if ( $featured_cat > 0 ) {
				$args['cat'] = $featured_cat;
			}

			$home_feature = new WP_Query( $args );



			if ( $home_feature->have_posts() ) :

			?>
				<div class="homepage-feature-wrap">
					<?php if ( have_posts() ) :

						if ( ! empty( $feature_title ) ) {

							printf('<h2>' . $feature_title . '</h2>' );

						}

						echo '<div class="item-wrap">';


						while ($home_feature->have_posts() ) : $home_feature->the_post();

							if ( has_post_thumbnail() ) :

						?>
							<div class="item">
							<a href="<?php the_permalink() ?>">
								<?php the_post_thumbnail('shakey-feature-thumbnail') ?>
							</a>
							<?php the_title( sprintf( '<div class="header-wrap"><h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2></div>' ); ?>
							</div>

						<?php
							endif;
						endwhile;

							echo '</div>';

					endif;
					wp_reset_query();
					?>
				</div>

			<?php
				  endif;
				  wp_reset_postdata();
			?>

				</div>

			</div>

		<?php

		endif;
	}
}

/**
|----------------------------------------------------------------------
| Sticky Header
|----------------------------------------------------------------------
|
*/

if ( ! function_exists( 'shakey_before_header_container_open' ) ) {

	function shakey_before_header_container_open() {

		$sticky = shakey_get_theme_option( 'general_sticky_menu' , '1' );

		if ( $sticky == 1 ) { ?>

		<div id="sticky">

			<?php

		}

	}
}

if ( ! function_exists( 'shakey_before_header_container_close' ) ) {

	function shakey_before_header_container_close() {

		$sticky = shakey_get_theme_option( 'general_sticky_menu' , '1' );

		if ( $sticky == 1 ) { ?>

			</div>

			<div id="catcher"></div>

			<?php
		}
	}
}

/*
|------------------------------------------------------------------------------
| Truncate string to x letters/words
|------------------------------------------------------------------------------
*/

function shakey_truncate( $str, $length = 40, $units = 'letters', $ellipsis = '&nbsp;&hellip;' ) {
    if ( $units == 'letters' ) {
        if ( mb_strlen( $str ) > $length ) {
            return mb_substr( $str, 0, $length ) . $ellipsis;
        } else {
            return $str;
        }
    } else {
        $words = explode( ' ', $str );
        if ( count( $words ) > $length ) {
            return implode( " ", array_slice( $words, 0, $length ) ) . $ellipsis;
        } else {
            return $str;
        }
    }
}

if ( ! function_exists( 'shakey_excerpt' ) ) {
    function shakey_excerpt( $limit = 40 ) {
      return shakey_truncate( get_the_excerpt(), $limit, 'words' );
    }
}

