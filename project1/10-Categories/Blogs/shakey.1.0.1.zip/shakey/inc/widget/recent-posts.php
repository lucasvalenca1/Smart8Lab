<?php
/*
|
|	Plugin Name: Shakey Recent Posts
|	Description: A widget to display Recent Posts.
|	Version: 1.0
|
*/

/*
|------------------------------------------------------------------------------
| Recent Posts Widget Class
|------------------------------------------------------------------------------
*/

class Shakey_Recent_Posts_Widget extends WP_Widget {

	var $defaults;
	var $customs;


	/*
	|------------------------------------------------------------------------------
	| Widget Setup
	|------------------------------------------------------------------------------
	|
	| @return void
	|
	*/
	public function __construct() {
		$widget_ops = array(
			'classname' => 'shakey-recent-posts-widget',
			'description' => __('Shakey Recent Posts.','shakey')
		);

		$control_ops = array(
			'id_base' => 'shakey-recent-posts'
			);

		parent::__construct('shakey-recent-posts', __('Shakey: Recent Posts','shakey'), $widget_ops, $control_ops);
	}

	/*
	|------------------------------------------------------------------------------
	| Display Widget
	|------------------------------------------------------------------------------
	|
	| @return void
	|
	*/
	public function widget( $args, $instance ) {
		extract( $args );

		$title = esc_html( apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : __( 'Recent Posts', 'shakey' ) ) );
		$comment_num = intval( isset( $instance['comment_num'] ) ? $instance['comment_num'] : '1' );
		$category = intval( isset( $instance['category'] ) ? $instance['category'] : '1' );
		$author = intval( isset( $instance['author'] ) ? $instance['author'] : '1' );
		$date = intval( isset( $instance['date'] ) ? $instance['date'] : '1' );
		$qty = intval( isset( $instance['qty'] ) ? $instance['qty'] : '5' );
		$show_thumbnail_1 = intval( isset( $instance['show_thumbnail_1'] ) ? $instance['show_thumbnail_1'] : '1' );
		$show_excerpt = intval( isset( $instance['show_excerpt'] ) ? $instance['show_excerpt'] : '1' );
		$excerpt_length = intval( isset( $instance['excerpt_length'] ) ? $instance['excerpt_length'] : '10' );


		echo $before_widget;
		if ( ! empty( $title ) ) {
			echo $before_title . $title . $after_title;
		}

		echo self::shakey_get_recent_posts( $qty, $comment_num, $date, $author, $show_thumbnail_1, $show_excerpt, $excerpt_length );
		echo $after_widget;

	}
    /*
	|------------------------------------------------------------------------------
	| Update Widget
	|------------------------------------------------------------------------------
	|
	| @return void
	|
	*/
	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = strip_tags( $new_instance['title'] );
		$instance['qty'] = intval( $new_instance['qty'] );
		$instance['category'] = intval( $new_instance['category'] );
		$instance['comment_num'] = intval( $new_instance['comment_num'] );
		$instance['author'] = intval( $new_instance['author'] );
		$instance['date'] = intval( $new_instance['date'] );
		$instance['show_thumbnail_1'] = intval( $new_instance['show_thumbnail_1'] );
		$instance['show_excerpt'] = intval( $new_instance['show_excerpt'] );
		$instance['excerpt_length'] = intval( $new_instance['excerpt_length'] );
		return $instance;
	}

	/*
	|------------------------------------------------------------------------------
	| Widget Settings
	|------------------------------------------------------------------------------
	|
	| Displays the widget settings controls on the widget panel
	|
	| @return void
	|
	*/
 	public function form( $instance ) {
		$defaults = array(
			'comment_num' => 1,
			'category' => 1,
			'date' => 1,
			'author' => 1,
			'show_thumbnail_1' => 1,
			'show_excerpt' => 0,
			'excerpt_length' => 10
		);

		$instance = wp_parse_args((array) $instance, $defaults);
		$category = isset( $instance[ 'category' ] ) ? esc_attr( $instance[ 'category' ] ) : 1;
		$title = isset( $instance[ 'title' ] ) ? $instance[ 'title' ] : __( 'Recent Posts','shakey' );
		$qty = isset( $instance[ 'qty' ] ) ? esc_attr( $instance[ 'qty' ] ) : 5;
		$comment_num = isset( $instance[ 'comment_num' ] ) ? esc_attr( $instance[ 'comment_num' ] ) : 1;
		$author = isset( $instance[ 'author' ] ) ? esc_attr( $instance[ 'author' ] ) : 1;
		$show_excerpt = isset( $instance[ 'show_excerpt' ] ) ? esc_attr( $instance[ 'show_excerpt' ] ) : 1;
		$date = isset( $instance[ 'date' ] ) ? esc_attr( $instance[ 'date' ] ) : 1;
		$excerpt_length = isset( $instance[ 'excerpt_length' ] ) ? intval( $instance[ 'excerpt_length' ] ) : 10;
		$show_thumbnail_1 = isset( $instance[ 'show_thumbnail_1' ] ) ? esc_attr( $instance[ 'show_thumbnail_1' ] ) : 1;
		$show_excerpt = isset( $instance[ 'show_excerpt' ] ) ? esc_attr( $instance[ 'show_excerpt' ] ) : 1;
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:','shakey' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'qty' ); ?>"><?php esc_html_e( 'Number of Posts to show','shakey' ); ?></label>
			<input id="<?php echo $this->get_field_id( 'qty' ); ?>" name="<?php echo $this->get_field_name( 'qty' ); ?>" type="number" min="1" step="1" value="<?php echo $qty; ?>" />
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("show_thumbnail_1"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("show_thumbnail_1"); ?>" name="<?php echo $this->get_field_name("show_thumbnail_1"); ?>" value="1" <?php if (isset($instance['show_thumbnail_1'])) { checked( 1, $instance['show_thumbnail_1'], true ); } ?> />
				<?php esc_html_e( 'Show Thumbnails', 'shakey'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("date"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("category"); ?>" name="<?php echo $this->get_field_name("category"); ?>" value="1" <?php checked( 1, $instance['category'], true ); ?> />
				<?php esc_html_e( 'Show Category Post', 'shakey'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("date"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("date"); ?>" name="<?php echo $this->get_field_name("date"); ?>" value="1" <?php checked( 1, $instance['date'], true ); ?> />
				<?php esc_html_e( 'Show post date', 'shakey'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("comment_num"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("comment_num"); ?>" name="<?php echo $this->get_field_name("comment_num"); ?>" value="1" <?php checked( 1, $instance['comment_num'], true ); ?> />
				<?php esc_html_e( 'Show number of comments', 'shakey'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("author"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("author"); ?>" name="<?php echo $this->get_field_name("author"); ?>" value="1" <?php checked( 1, $instance['author'], true ); ?> />
				<?php esc_html_e( 'Show Author', 'shakey'); ?>
			</label>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id("show_excerpt"); ?>">
				<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id("show_excerpt"); ?>" name="<?php echo $this->get_field_name("show_excerpt"); ?>" value="1" <?php checked( 1, $instance['show_excerpt'], true ); ?> />
				<?php esc_html_e( 'Show excerpt', 'shakey'); ?>
			</label>
		</p>

		<p>
	       <label for="<?php echo $this->get_field_id( 'excerpt_length' ); ?>"><?php esc_html_e( 'Excerpt Length:', 'shakey' ); ?>
	       <input id="<?php echo $this->get_field_id( 'excerpt_length' ); ?>" name="<?php echo $this->get_field_name( 'excerpt_length' ); ?>" type="number" min="1" step="1" value="<?php echo esc_attr( $excerpt_length ); ?>" />
	       </label>
       </p>

		<?php
	}
	/**
	 * Returns the assigned categories of a post in a string
	 *
	 * @access   private
	 * @since     4.6
	 *
	 */
	private function get_the_categories ( $id ) {
		$terms = get_the_terms( $id, 'category' );

		if ( is_wp_error( $terms ) ) {
			return __( 'Error on listing categories', 'shakey' );
		}

		if ( empty( $terms ) ) {
			$text = __( 'No categories', 'shakey' );
			return $text;
		}

		$categories = array();

		foreach ( $terms as $term ) {
			// get link to category
			$categories[] = sprintf(
				'<a href="%s">%s</a>',
				get_category_link( $term->term_id ),
				esc_html( $term->name )
			);
		}

		/*foreach ( $terms as $term ) {
			$categories[] = $term->name;
		}*/

		$string = '';
		if ( $this->customs[ 'category_label' ] ) {
			$string = $this->customs[ 'category_label' ] . ' ';
		}
		$string .= join( $this->defaults[ 'comma' ], $categories );

		return $string;
	}

	/*
	|------------------------------------------------------------------------------
	| Get Recent Posts
	|------------------------------------------------------------------------------
	|
	| To display recent posts by user filter
	|
	| @return void
	|
	*/
	public function shakey_get_recent_posts( $qty, $comment_num, $date, $author, $show_thumbnail_1, $show_excerpt, $excerpt_length ) {

		$byline = esc_html( get_the_author() );

		$categories_list = get_the_category_list( ' ' );

		$posts = new WP_Query(
			"orderby=date&order=DESC&posts_per_page=".$qty
		);

		if ($show_thumbnail_1 != 1) :
		 	echo '<ul class="shakey-recent-posts no-thumbnail">';
		else :
			echo '<ul class="shakey-recent-posts have-thumbnail">';
		endif;

		while ( $posts->have_posts() ) : $posts->the_post(); ?>
			<li>

				<div class="post-data">

					<?php if ( $date == 1 ) : ?>

						<div class="cat-links"><?php echo $this->get_the_categories( $posts->post->ID ); ?></div>

					<?php endif; ?>

					<a href="<?php the_permalink(); ?>" alt="<?php the_title(); ?>"><?php the_title(); ?></a>

					<div class="post-meta">

						<?php if ( $date == 1 ) : ?>
							<span><?php the_time('F j, Y'); ?></span>
						<?php endif; ?>

						<?php

						if ( $author == 1 ) {

							printf( '<span class="author">' . esc_html__( ' By %1$s ', 'shakey' ) . ' </span>', $byline );
							}
						 ?>

						<?php if ( $comment_num == 1 ) : ?>
							<?php echo comments_number(__('<span>No Comment</span>','shakey'), __('<span>One Comment</span>','shakey'), '<span class="comm">% Comments</span> ');?>
						<?php endif; ?>
					</div> <!--end .entry-meta-->

				</div>

				<?php
				if ( has_post_thumbnail() && $show_thumbnail_1 ) : ?>
					<div class="post-img">
						<a href="<?php the_permalink(); ?>">
						    <?php the_post_thumbnail('shakey-widget-thumbnail',array('title' => '')); ?>
						</a>
					</div>
				<?php elseif ( !has_post_thumbnail() && $show_thumbnail_1 ) : ?>
					<div class="post-img">
						<a href="<?php the_permalink(); ?>">
						    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/widget-thumbnails.jpg" />
						</a>
					</div>
				<?php endif; ?>
				<?php if ( $show_excerpt == 1 ) : ?>
						<p>
							<?php echo shakey_excerpt($excerpt_length); ?>
						</p>
					<?php endif; ?>
				<span class="clear"></span>
			</li>
		<?php
		endwhile;
		echo '</ul>'."\r\n";
	}

}

/*
|------------------------------------------------------------------------------
| Load Widgets
|------------------------------------------------------------------------------
*/
add_action('widgets_init', 'shakey_recent_posts_load_widgets');

/*
 |------------------------------------------------------------------------------
 | Register widget
 |------------------------------------------------------------------------------
 |
 | @return void
 |
 */
function shakey_recent_posts_load_widgets()
{
	register_widget('Shakey_Recent_Posts_Widget');
}
