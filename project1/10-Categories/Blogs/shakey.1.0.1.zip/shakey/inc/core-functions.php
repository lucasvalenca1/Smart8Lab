<?php
/**
 * Shakey  functions.
 *
 * @package Shakey
 * @author ThemeCountry
 * @since 1.0.0
 */

if ( ! function_exists( 'shakey_the_post_thumbnail' ) ) :

	/**
	 * Renders post's thumbnail
	 *
	 * @param  string  $size
	 * @param  string  $attr
	 * @param  boolean $echo
	 * @since 1.0.0
	 * @return mix
	 */
	function shakey_the_post_thumbnail( $size, $attr = '', $echo = true ) {

		if ( has_post_thumbnail() ) {

			$img = get_the_post_thumbnail( null, $size, $attr );

		} else {

			$img = sprintf('<img class="wp-post-image" src="%s/assets/images/default-%s.jpg" alt="%s" />',  get_template_directory_uri(), esc_attr( $size ), esc_attr( get_the_title()) );

		}

		if ( $echo ) {

			echo $img;

		} else {

			return $img;

		}
	}
endif;

if ( ! function_exists('shakey_get_theme_option') ) :

	/**
	 * Get Theme Options
	 *
	 * @since 1.0.0
	 * @param  mix $setting
	 * @param  mix $default
	 * @return mix
	 */
	function shakey_get_theme_option( $setting, $default = '' ) {

	    $options = get_option( SHAKEY_CUSTOMIZE_ID . '_name', array() );

	    $value = $default;

	    if ( isset( $options[ $setting ] ) ) {

	        $value = $options[ $setting ];

	    }

	    return $value;
	}


endif;

if ( ! function_exists('shakey_set_custom_thumbnail') ) :
	/**
	 * Hooks to set custom post thumbnails
	 *
	 * @since 1.0.0
	 * @return void
	 */
	function shakey_set_custom_thumbnail() {

	    // Default Thumbnail Sizes
		set_post_thumbnail_size( 300, 250 );
		add_image_size( 'shakey-small-thumbnail', 224, 112, true  );
		add_image_size( 'shakey-large-thumbnail', 550, 270, true );
		add_image_size( 'shakey-grid-thumbnail', 360, 200, true );
		add_image_size( 'shakey-feature-thumbnail', 354, 180, true );
		add_image_size( 'shakey-widget-thumbnail', 300, 150, true );

	}

endif;
add_action( 'after_setup_theme', 'shakey_set_custom_thumbnail' );
