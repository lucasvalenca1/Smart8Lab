<?php
/**
 * Shakey hooks
 *
 * @author   ThemeCountry
 * @package  shakey
 */

/**
 * Header
 *
 * @see shakey_skip_links
 * @see shakey_site_branding
 * @see shakey_primary_navigation
 */
add_action( 'shakey_header',				'shakey_skip_links',					 0 );
add_action( 'shakey_header',				'shakey_toggle_menu',					10 );
add_action( 'shakey_header',				'shakey_site_branding',					20 );
add_action( 'shakey_header',				'shakey_menu_header',					30 );
add_action( 'shakey_header',				'shakey_search',						40 );

add_action( 'shakey_before_header',			'shakey_progress_bar',					10 );

/**
 * Header container
 *
 * @see shakey_before_header_container_open
 * @see shakey_before_header_container_close
 */

add_action( 'shakey_before_header_container',				'shakey_before_header_container_open',					 0 );
add_action( 'shakey_after_header_container',				'shakey_before_header_container_close',					10 );

/**
 * Post
 */
add_action( 'shakey_loop_post', 	'shakey_content_open',		 5 );
add_action( 'shakey_loop_post', 	'shakey_post_on',			10 );
add_action( 'shakey_loop_post',		'shakey_post_header',		20 );
add_action( 'shakey_loop_post',		'shakey_post_content',		30 );
add_action( 'shakey_loop_post',		'shakey_entry_footer',		35 );
add_action( 'shakey_loop_post',		'shakey_read_more',			40 );
add_action( 'shakey_loop_post', 	'shakey_content_close',		45 );
add_action( 'shakey_loop_post',		'shakey_post_thumbnail',	50 );
add_action( 'shakey_loop_after',	'shakey_paging_nav',		10 );

/**
 * Post Meta
 */
//add_action( 'shakey_after_post_title', 'shakey_post_on', 		10);

/**
 * Single Post
 */
//add_action( 'shakey_single_post', 'shakey_post_header',							10 );
add_action( 'shakey_single_post', 'shakey_post_single_content',						20 );

add_action( 'shakey_post_single_content_before', 'shakey_single_post_meta',			10 );
add_action( 'shakey_post_single_content_before', 'shakey_single_post_thumbnail',	20 );

/**
 * Content Top
 */

add_action( 'shakey_before_content', 	'shakey_top_pathing',						10 );
add_action( 'shakey_before_content', 	'shakey_homepage_thumbnail',				15 );
add_action( 'shakey_before_content', 	'shakey_single_post_title',					20 );
add_action( 'shakey_before_content', 	'shakey_toggle_nav',						10 );

//tags-list
add_action( 'shakey_before_footer', 	'shakey_tags_list', 						10 );

/**
 * Functions hooked in to shakey_single_post_bottom action
 *
 * @hooked shakey_post_nav         - 10
 * @hooked shakey_display_comments - 20
 */

add_action( 'shakey_single_post_bottom',	'shakey_post_nav',						10 );
add_action( 'shakey_single_post_bottom',	'shakey_display_comments',				20 );

/**
 * Sidebar
 */
add_action( 'shakey_sidebar',				'shakey_get_sidebar',					10 );


/**
 * Page - Hooks
 *
 * @see  shakey_page_header()
 * @see  shakey_page_content()
 * @see  shakey_display_comments()
 */

// add_action( 'shakey_page',				'shakey_page_header',					10 );
add_action( 'shakey_before_content',		'shakey_page_title',					10 );
add_action( 'shakey_page', 					'shakey_page_meta',						10 );
add_action( 'shakey_page',					'shakey_page_content',					20 );
add_action( 'shakey_page_after',			'shakey_display_comments',				10 );


/**
 * Post Grid - Hooks
 *
 * @see  shakey_post_grid_header()
 * @see  shakey_post_grid_meta()
 * @see  shakey_post_grid_content()
 */

add_action( 'shakey_loop_grid_post',		'shakey_post_grid_thumbnail',			10 );
add_action( 'shakey_loop_grid_post',		'shakey_post_header',					20 );
/*add_action( 'shakey_loop_grid_after',		'shakey_post_grid_content',				10 );


/**
 * Footer
 *
 * @see  modol_footer_widgets()
 * @see  shakey_credit()
 * @see  shakey_footer_back_top()
 */

add_action( 'shakey_footer',	'shakey_footer_widgets',							10 );
add_action( 'shakey_footer',	'shakey_footer_nav',								20 );
add_action( 'shakey_footer',	'shakey_credit',									30 );


/**
 * Back To Top
 *
 * @see  shakey_back_to_top()
 */

add_action( 'shakey_after_footer', 	'shakey_back_to_top',							10 );

/**
* Display Search
*
* @see
*/
add_action( 'shakey_after_page', 'shakey_search_overlay',							10 );
//add_action('shakey_after_page' , 'themaga_menu_overlay',							20 );

add_action('shakey_after_page' , 'shakey_light_box',								20 );

/**
* Display Search Result
*
* @see
*/
add_action( 'shakey_loop_search_before',   'shakey_search_result',					10 );
