<?php
/**
 * Shakey Class: The main class of theme
 *
 * @author   ThemeCountry
 * @since    1.0.0
 * @package  shakey
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Shakey' ) ) :

	/**
	 * The main Shakey class to init & setup theme
	 *
	 * @since  1.0.0
	 * @version  1.0
	 */
	class Shakey
	{

		function __construct() {

			add_action( 'after_setup_theme',          array( $this, 'setup' ) );
			add_action( 'widgets_init',               array( $this, 'widgets_init' ) );
			add_action( 'wp_enqueue_scripts',         array( $this, 'scripts' ),       10 );
			add_filter( 'body_class',                 array( $this, 'body_classes' ) );
		}

		/**
		 * Sets up theme defaults and registers support for various WordPress features.
		 *
		 * Note that this function is hooked into the after_setup_theme hook, which
		 * runs before the init hook. The init hook is too late for some features, such
		 * as indicating support for post thumbnails.
		 *
		 * @since 1.0
		 */
		public function setup() {

			/*
			 * Make theme available for translation.
			 * Translations can be filed in the /languages/ directory.
			 * If you're building a theme based on shakey, use a find and replace
			 * to change 'shakey' to the name of your theme in all the template files.
			 */

			// Loads wp-content/themes/base/languages/it_IT.mo.
			load_theme_textdomain( 'shakey', get_template_directory() . '/languages' );

			// Add default posts and comments RSS feed links to head.
			add_theme_support( 'automatic-feed-links' );

			/*
			 * Let WordPress manage the document title.
			 * By adding theme support, we declare that this theme does not use a
			 * hard-coded <title> tag in the document head, and expect WordPress to
			 * provide it for us.
			 */
			add_theme_support( 'title-tag' );

			/*
			 * Enable support for Post Thumbnails on posts and pages.
			 *
			 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
			 */

			add_theme_support( 'post-thumbnails' );

			/**
			 * Enable support for site logo
			 */
			// Set up the WordPress core custom logo feature.
			add_theme_support( 'custom-logo', apply_filters( 'shakey_custom_logo_args', array(
					'height'		=> 60,
					'width'			=> 180,
					'flex-width'	=> true,
			) ) );


			// This theme uses wp_nav_menu() in two locations.
			register_nav_menus( array(
				'primary'   => __( 'Primary Menu', 'shakey' ),
				'social'	=> __( 'Social Menu' , 'shakey' ),
				'subscribe' => __( 'Subscribe Menu', 'shakey' ),
				'toggle'	=> __( 'Toggle Menu' , 'shakey' ),
				'footer'  	=> __( 'Footer Menu', 'shakey' ),
			) );

			/*
			 * Switch default core markup for search form, comment form, and comments
			 * to output valid HTML5.
			 */
			add_theme_support( 'html5', array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			) );


			/**
			 *  Add support for the Site Logo plugin and the site logo functionality in JetPack
			 *  https://github.com/automattic/site-logo
			 *  http://jetpack.me/
			 */
			add_theme_support( 'site-logo', array( 'size' => 'full' ) );

			// Set up the WordPress core custom background feature.
			add_theme_support( 'custom-background', apply_filters( 'shakey_custom_background_args', array(
					'default-color'		=> 'ffffff',
					'default-image'		=> '',
			) ) );

			add_theme_support( 'custom-header', apply_filters( 'shakey_custom_header_args', array(
				'header-text'			=> false,
				'width'					=> 1600,
				'height'				=> 640,
				'flex-height'			=> true,
			) ) );

			// Add thirt party plugin
			$this->_addons_support();

			// Add theme support for selective refresh for widgets.
			add_theme_support( 'customize-selective-refresh-widgets' );
		}

		/**
		 * Adds theme support pro version
		 *
		 * @since 1.0
		 * @return void
		 */
		private function _addons_support() {

			// Add theme support for Shakey Pro plugin.
			add_theme_support( 'shakey-pro' );


		}

		/**
		 * Register widget area.
		 *
		 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
		 * @since 1.0
		 */
		public function widgets_init() {

			$sidebar_args['sidebar'] = array(
				'name'          => __( 'Sidebar', 'shakey' ),
				'id'            => 'sidebar-1',
				'description'   => ''
			);

			$rows    = intval( apply_filters( 'shakey_footer_widget_rows', 1 ) );
			$regions = intval( apply_filters( 'shakey_footer_widget_columns', 4 ) );

			for ( $row = 1; $row <= $rows; $row++ ) {
				for ( $region = 1; $region <= $regions; $region++ ) {
					$footer_n = $region + $regions * ( $row - 1 ); // Defines footer sidebar ID.
					$footer   = sprintf( 'footer_%d', $footer_n );

					if ( 1 == $rows ) {
						// translators: The position of the widget title
						$footer_region_name = sprintf( __( 'Footer Column %1$d', 'shakey' ), $region );

						// translators: The position of the widget desction
						$footer_region_description = sprintf( __( 'Widgets added here will appear in column %1$d of the footer.', 'shakey' ), $region );
					} else {
						// translators: number of widget row
						$footer_region_name = sprintf( __( 'Footer Row %1$d - Column %2$d', 'shakey' ), $row, $region );
						// translators: Widget appears description
						$footer_region_description = sprintf( __( 'Widgets added here will appear in column %1$d of footer row %2$d.', 'shakey' ), $region, $row );
					}

					$sidebar_args[ $footer ] = array(
						'name'        => $footer_region_name,
						'id'          => sprintf( 'footer-%d', $footer_n ),
						'description' => $footer_region_description,
					);
				}
			}

			foreach ( $sidebar_args as $sidebar => $args ) {
				$widget_tags = array(
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget'  => '</div>',
					'before_title'  => '<span class="widget-title">',
					'after_title'   => '</span>',
				);

				/**
				 * Dynamically generated filter hooks. Allow changing widget wrapper and title tags. See the list below.
				 *
				 * 'shakey_header_widget_tags'
				 * 'shakey_sidebar_widget_tags'
				 *
				 * 'shakey_footer_1_widget_tags'
				 * 'shakey_footer_2_widget_tags'
				 * 'shakey_footer_3_widget_tags'
				 * 'shakey_footer_4_widget_tags'
				 */
				$filter_hook = sprintf( 'shakey_%s_widget_tags', $sidebar );
				$widget_tags = apply_filters( $filter_hook, $widget_tags );

				if ( is_array( $widget_tags ) ) {
					register_sidebar( $args + $widget_tags );
				}
			}
		}
		/**
		 * Enqueue scripts and styles.
		 *
		 * @since  1.0
		 */
		public function scripts() {

			global $wp_query, $shakey_version;

			/**
			 * Styles
			 */

			wp_enqueue_style( 'shakey-style', get_template_directory_uri() . '/style.css', '', $shakey_version );

			wp_enqueue_style( 'themaga-icons', get_template_directory_uri() . '/assets/css/base/icons.css', '', $shakey_version );



			/**
			 * Fonts
			 */
			$google_fonts = apply_filters( 'shakey_google_font_families', array(
				'Montserrat' 	=> 'Montserrat:300,400,500,700&subset=latin,latin-ext'
			) );

			if ( $google_fonts ) {

				$query_args = array(
					'family' => implode( '|', $google_fonts )
				);

				$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );


				wp_enqueue_style( 'shakey-fonts', $fonts_url, array(), null );

			}

			/**
			 * Scripts
			 */
			wp_enqueue_script( 'shakey-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), $shakey_version, true);

			if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
				wp_enqueue_script( 'comment-reply' );
			}


		}
		/**
		 * Enqueue child theme stylesheet.
		 * A separate function is required as the child theme css needs to be enqueued _after_ the parent theme
		 *
		 * @since  1.0
		 * @return void
		 */
		public function child_scripts() {
			if ( is_child_theme() ) {
				wp_enqueue_style( 'shakey-child-style', get_stylesheet_uri(), '' );
			}
		}

		/**
		 * Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
		 *
		 * @param array $args Configuration arguments.
		 * @since  1.0
		 * @return array
		 */
		public function page_menu_args( $args ) {
			$args['show_home'] = true;
			return $args;
		}


		/**
		 * Adds custom classes to the array of body classes.
		 *
		 * @param array $classes Classes for the body element.
		 * @since  1.0
		 * @return array
		 */
		public function body_classes( $classes ) {
			// Adds a class of group-blog to blogs with more than 1 published author.
			if ( is_multi_author() ) {
				$classes[] = 'group-blog';
			}

			// If our main sidebar doesn't contain widgets, adjust the layout to be full-width.
			if ( ! is_active_sidebar( 'sidebar-1' ) ) {

				$classes[] = 'shakey-full-width-content';

			}

			return $classes;
		}

	}

endif;

return new Shakey();
