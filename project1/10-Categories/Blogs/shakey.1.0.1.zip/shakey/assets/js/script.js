(function($) {
	var shakey = {

		init: function() {
			this.stickyMenu();
			this.navMenu();
			this.navSearch();
			this.scrollTop();
			this.menuHeader();
			this.loadingBar();
		},

		loadingBar: function() {

			$(window).scroll(function() {
				var s = $(window).scrollTop();
				var d = $(document).height();
				var c = $(window).height();
				var scrollPercent = (s / (d-c)) * 100;
				var position = scrollPercent;
				
				$('.progressing').css('width', position + '%');
			});

		},
		
		stickyMenu: function() {
			var self = this;

			var catcher = $('#catcher'),
				sticky  = $('#sticky'),
				bodyTop = $('body').offset().top;
				
			if ( sticky.length ) {
				$(window).scroll(function() {
					self.stickThatMenu(sticky,catcher,bodyTop);
				});
				$(window).resize(function() {
					self.stickThatMenu(sticky,catcher,bodyTop);
				});
			}
		},
		isScrolledTo: function(elem,top) {
			var docViewTop = $(window).scrollTop();
			//var docViewBottom = docViewTop + $(window).height();

			var elemTop = $(elem).offset().top - top;
			//var elemBottom = elemTop + $(elem).height();

			return ((elemTop <= docViewTop));
		},
		stickThatMenu: function(sticky,catcher,top) {
			var self = this;

			if(self.isScrolledTo(sticky,top)) {
				sticky.addClass('sticky-nav');
				catcher.height(sticky.height());
			} 
			var stopHeight = catcher.offset().top;
	
			if ( stopHeight > sticky.offset().top) {
				sticky.removeClass('sticky-nav');
				catcher.height(0);
			}
		},

		/**
		 * Toggle Menu
		 * 
		 * @return void
		 */
		navMenu: function() {

			if ( $('#toggle-navigation').length ) {

			} else {

				var $primary_menu = $('#primary-navigation');
				var $menu = '';
				var menu_wrapper = '';
				
				if ($primary_menu.length === 0) {
					return;
				} else {
					$menu = $primary_menu;
				}

				menu_wrapper = $menu
				.clone().attr('class', 'mobile-menu')
				.wrap('<div id="mobile-menu-wrapper" class="mobile-only"></div>').parent()
				.appendTo('body');

				$('#mobile-menu-wrapper').prepend('<div class="close-toggle-menu"><div class="menu-toggle-close"><i class="fas fa-times search-close"></i></div></div>');

			}

			$('<span class="sub-arrow"><i class="fa fa-angle-down"></i></span>').insertAfter( $('.menu-item-has-children > a') );

			$('.menu-item-has-children .sub-arrow').click(function(e) {
				e.preventDefault();
				e.stopPropagation();

				var subMenuOpen = $(this).hasClass('sub-menu-open');
				
				if ( subMenuOpen ) {
					
					$(this).removeClass('sub-menu-open');
					$(this).find('i').removeClass('fa-angle-up').addClass('fa-angle-down');
					$(this).next('ul.sub-menu, ul.children').removeClass('active').slideUp();
				
				} else {
					
					$(this).addClass('sub-menu-open');
					$(this).find('i').removeClass('fa-angle-down').addClass('fa-angle-up');
					$(this).next('ul.sub-menu, ul.children').addClass('active').slideDown();

				}

			});
			
			$('.toggle-menu').on('click', function(e) {

				e.preventDefault();
				$(this).addClass('active');
				$('body').addClass('nav-open');			

			});

			$('.menu-toggle-close').on('click', function(e) {
				e.preventDefault();

				$('.menu-toggle').removeClass('active');
				$('body').removeClass('nav-open');

			});

			$('#lightbox').click(function() {
				if ($('body').hasClass('nav-open')) {
					$('body').removeClass('nav-open');
				}
			});
			
		},
		/**
		 * Toggle Search Click
		 * 
		 * @return void
		 */
		navSearch: function() {

			$('#trigger-overlay').on('click', function(e) {
				e.preventDefault();

				var hasActive = $('#search-overlay').hasClass('search-active');

				if (!hasActive) {
					$('#search-overlay').addClass('search-active');
					$('#search-overlay .search-field').focus();
				}

			});

			$('.search-close').on('click', function(e){
				e.preventDefault();

				$('#search-overlay').removeClass('search-active');

			});

		},
		/**
		 * Scroll To Top
		 * 
		 * @return void
		 */

		scrollTop: function() {

			$('.back-to-top').click( function() {

				$('html, body').animate({scrollTop : 0},800);
				return false;

			});

			$(document).scroll ( function() {
				
				var topPositionScrollBar = $(document).scrollTop();
				
				if ( topPositionScrollBar < '150' ) {
					
					$('.back-to-top').fadeOut();
				
				} else {

					$('.back-to-top').fadeIn();

				}

			});


		},

		menuHeader: function() {

			$('.subscribe-nav').hover( function(e) {
				e.preventDefault();
				e.stopPropagation();

				$('.subscribe-nav').parent('.menu-wrapper').addClass('show-subscribe');

			}, function(e) {

				e.preventDefault();
				e.stopPropagation();

				$('.subscribe-nav').parent('.menu-wrapper').removeClass('show-subscribe');

			});

			$('.follow-us').hover( function(e) {
				e.preventDefault();
				e.stopPropagation();

				$('.follow-us').parent('.menu-wrapper').addClass('show-social');

			}, function(e) {

				e.preventDefault();
				e.stopPropagation();

				$('.follow-us').parent('.menu-wrapper').removeClass('show-social');

			});

		}

	}; // var shakey

	$(document).ready(function() {
		shakey.init();
	});

	$(document).mouseleave(function () {
		
	});

	$(window).load(function(){
  		//
	});
}) (jQuery);