<?php
/**
 * Shakey main functions
 */


/**
 * Assign the Shakey version to a var
 */
$theme              = wp_get_theme( 'shakey' );
$shakey_version = $theme['Version'];

/**
 * Theme's constants
 */

// Theme Version Constant
define( 'SHAKEY_THEME_VERSION', $theme['Version'] );
// Theme Customize ID
define( 'SHAKEY_CUSTOMIZE_ID', 'shakey_customize_id' );
/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 980; /* pixels */
}

$shakey = (object) array(
	'version' => $shakey_version,

	/**
	 * Initialize all the things.
	 */
	'main'       => require 'inc/class-shakey.php',
	'customizer' => require 'inc/customizer/class-customize.php',
);

/**
 * Include functions
 */
if ( is_admin() ) {

	$shakey->admin = require 'inc/admin/class-admin.php';

	// Includes recommend plugin
	require 'inc/helpers/class-tgm-plugin-activation.php';
}

require 'inc/core-functions.php';
require 'inc/template-hooks.php';
require 'inc/template-functions.php';
require 'inc/helpers/class-customize-output.php';
require 'inc/widget.php';
require 'inc/customizer/custom-style.php';
