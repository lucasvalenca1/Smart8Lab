<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package  shakey
 */

get_header();

?>

	
			
			<?php
			if ( have_posts() ) : 	

				?>

				<section id="primary" class="content-area">
					<main id="main" class="site-main" role="main">

				<?php
				
				do_action( 'shakey_loop_search_before' );

				?>

				<div class="wrap-post">

				<?php 
				
				get_template_part( 'loop_grid' );

				do_action( 'shakey_loop_search_after' );

				echo '</div>';
				
			else :

				?>

				<section id="primary" class="content-area page-area">
					<main id="main" class="site-main" role="main">

				<?php

				get_template_part( 'template-parts/content', 'none' );

			endif; ?>

		</main><!-- #main -->
	</section><!-- #primary -->

<?php

if(!have_posts()){
	do_action( 'shakey_sidebar' );
}

get_footer();
