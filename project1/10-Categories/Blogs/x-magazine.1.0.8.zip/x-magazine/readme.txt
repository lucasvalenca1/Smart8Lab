=== X Magazine ===

Contributors: nalam
Requires at least: 4.0
Tested up to: 5.2.2
Tags: blog, news, education, custom-logo, one-column, two-columns, grid-layout, right-sidebar, custom-background, custom-header, custom-menu, featured-image-header, featured-images, flexible-header, full-width-template, sticky-post, threaded-comments, translation-ready, block-styles
Version: 1.0.2
Stable tag: 1.0.1
Requires PHP: 5.5
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Copyright License ==
Be 100% GPL and/or 100% GPL-compatible licensed.
Declare copyright and license explicitly. Use the license and license uri header slugs to style.css.
Declare licenses of any resources included such as fonts or images.
All code and design should be your own or legally yours. Cloning of designs is not acceptable.
Any copyright statements on the front end should display the user's copyright, not the theme author's copyright.

X magazine WordPress Theme, Copyright 2019 Noor alam
X magazine is distributed under the terms of the GNU GPL


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.



== Description ==
Magazine and Blog WordPress theme.
X magazine a free responsive pure Magazine and blog WordPress theme. This is the child theme of X Blog theme. X magazine is very good for magazine and blog site with morden color touch to display your website very beautiful and good looking.  X magazine is editable and super flexible new functionality. The theme has nice, beautiful and professional layouts. This theme is made for any search engine, SEO Compatible. it’s totally responsive.  Html5 and css3 based coded.  It is the multipurpose theme you case to use for the magazine, Blog, corporate, agency, startup, consulting websites.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==
### Images:
License: All Images are licensed under CC0
License URI: https://creativecommons.org/publicdomain/zero/1.0/

* Screenshot image one and default header image: CC0 by free photos via pxhere (https://pxhere.com/en/photo/1437969 )
* Screenshot image two: CC0 by free photos via pxhere (https://pxhere.com/en/photo/1434861 ) 

    Other images in screenshot are self created and all are under GPLv2.

    Other Images:
        screenshot.png self created GPLv2
        header.jpg self modified GPLv2


== Brand Icons ==

* All brand icons are trademarks of their respective owners.
* The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.



== Changelog ==

= 1.0.4 ==
* Change screenshot for wrong word
= 1.0.3 ==
* Added Theme Homepage
= 1.0.2 ==
* Added wp_body_open function.
* validate readme.txt file.
* Theme Sniffer plugin error fixed.

= 1.0.1 ==
* Fixed header image position.

= 1.0.0 ==

* Released


 
	