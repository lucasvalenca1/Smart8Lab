</div><!-- .container -->
<footer>

  <div class="copy-text">
      <?php echo '&copy; '.date_i18n(__('Y','shiny-blog')); ?>
      <span class="sep"> | </span>
      <?php printf( esc_html__( 'Shiny Blog WordPress Theme ','shiny-blog')); ?>
      <span class="sep"> | </span>
      <?php printf( esc_html__( 'Proudly powered by WordPress ','shiny-blog')); ?>
      <span class="sep"> | </span>
      <?php printf( esc_html__( 'By Janki Moradiya', 'shiny-blog' )); ?>

  </div><!-- .copy-text -->

</footer>

<?php wp_footer(); ?>

</div><!-- #content -->

</body>
</html>

