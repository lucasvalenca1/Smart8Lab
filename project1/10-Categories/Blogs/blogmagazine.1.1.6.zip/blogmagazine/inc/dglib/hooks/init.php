<?php
/*
 * Initialize Hooks on Dglib
 */

require_once dglib_file_directory('hooks/setup.php');

require_once dglib_file_directory('hooks/ajax.php');