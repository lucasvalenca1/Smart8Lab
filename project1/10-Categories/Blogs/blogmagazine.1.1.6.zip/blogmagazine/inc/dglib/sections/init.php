<?php
/*
 * Front Breadcrumbs Section
 */
require_once dglib_file_directory('sections/dg-front-breadcrumb-section.php');
