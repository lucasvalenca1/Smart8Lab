<?php
/**
 * The template for displaying header image
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package dineshghimire
 * @subpackage blogmagazine
 * @since 1.0.7
 */
?>
<div class="custom-header-media">
	<?php the_custom_header_markup(); ?>
</div>
