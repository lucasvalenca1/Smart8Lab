<?php

if ( ! defined( 'ABSPATH' ) ) exit;

if(defined('ELEMENTOR_VERSION')):

include_once NEWSEQO_EDITOR . '/elementor/manager/controls.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound

class Newseqo_Shortcode{

	/**
     * Holds the class object.
     *
     * @since 1.0
     *
     */
    public static $_instance;
    

    /**
     * Localize data array
     *
     * @var array
     */
    public $localize_data = array();

	/**
     * Load Construct
     * 
     * @since 1.0
     */

	public function __construct(){

		add_action( 'elementor/init', array($this, '_elementor_init'));
        add_action( 'elementor/controls/controls_registered', array( $this, '_icon_pack' ), 11 );
        add_action( 'elementor/controls/controls_registered', array( $this, 'control_image_choose' ), 13 );
        add_action( 'elementor/controls/controls_registered', array( $this, '_ajax_select2' ), 13 );
        add_action( 'elementor/widgets/widgets_registered', array($this, '_shortcode_elements'));
        add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'editor_enqueue_styles' ) );
        add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'elementor/preview/enqueue_styles', array( $this, 'preview_enqueue_scripts' ) );
        // elemntor icon load
        $this ->elementor_icon_pack(); 
	}


    /**
     * Enqueue Scripts
     *
     * @return void  
     */ 
    
     public function enqueue_scripts() {
         wp_enqueue_script( 'newseqo-main-elementor', NEWSEQO_JS  . '/elementor.js',array( 'jquery', 'elementor-frontend' ), NEWSEQO_VERSION, true );
    }

    /**
     * Enqueue editor styles
     *
     * @return void
     */

    public function editor_enqueue_styles() {

        wp_enqueue_style( 'newseqo-icon-elementor', NEWSEQO_CSS.'/iconfont.css',null, NEWSEQO_VERSION );

    }

    /**
     * Preview Enqueue Scripts
     *
     * @return void
     */

    public function preview_enqueue_scripts() {}
	/**
     * Elementor Initialization
     *
     * @since 1.0
     *
     */

    public function _elementor_init(){
    
        \Elementor\Plugin::$instance->elements_manager->add_category(
            'newseqo-elements',
            [
                'title' =>esc_html__( 'Newseqo', 'newseqo' ),
                'icon' => 'fa fa-plug',
            ],
            1
        );
    }

    /**
     * Extend Icon pack core controls.
     *
     * @param  object $controls_manager Controls manager instance.
     * @return void
     */ 

    public function _icon_pack( $controls_manager ) {

        require_once NEWSEQO_EDITOR_ELEMENTOR. '/controls/icon.php';

        $controls = array(
            $controls_manager::ICON => 'Newseqo_Icon_Controler',
        );

        foreach ( $controls as $control_id => $class_name ) {
            $controls_manager->unregister_control( $control_id );
            $controls_manager->register_control( $control_id, new $class_name() );
        }

    }

    
    // elementor icon fonts loaded
    public function elementor_icon_pack(  ) {

		
		
        add_filter( 'elementor/icons_manager/additional_tabs', [ $this, '__add_font']);
		
    }
    
    public function __add_font( $font){
        $font_new['icon-electionify'] = [
            'name' => 'icon-newseqo',
            'label' => esc_html__( 'newseqo Icon', 'newseqo' ),
            'url' => NEWSEQO_CSS . '/iconfont.css',
            'enqueue' => [ NEWSEQO_CSS . '/iconfont.css' ],
            'prefix' => 'tsicon-',
            'displayPrefix' => 'tsicon',
            'labelIcon' => 'tsicon tsicon-hand',
            'ver' => '5.9.0',
            'fetchJson' => NEWSEQO_JS . '/iconfont.js',
            'native' => true,
        ];
        return  array_merge($font, $font_new);
    }


    // registering ajax select 2 control
    public function _ajax_select2( $controls_manager ) {
        require_once NEWSEQO_EDITOR_ELEMENTOR. '/controls/select2.php';
        $controls_manager->register_control( 'ajaxselect2', new \Newseqo_Control_Ajax_Select2() );
    }
    
    // registering image choose
    public function control_image_choose( $controls_manager ) {
        require_once NEWSEQO_EDITOR_ELEMENTOR. '/controls/choose.php';
        $controls_manager->register_control( 'imagechoose', new \ Newseqo_Control_Image_Choose() );
    }

    public function _shortcode_elements($widgets_manager){
           
            require_once NEWSEQO_EDITOR_ELEMENTOR.'/widgets/title.php';
            $widgets_manager->register_widget_type(new Elementor\Newseqo_Title_Widget());

            require_once NEWSEQO_EDITOR_ELEMENTOR.'/widgets/main-slider.php';
            $widgets_manager->register_widget_type(new Elementor\Newseqo_Main_Slider_Widget());

            require_once NEWSEQO_EDITOR_ELEMENTOR.'/widgets/post-grid.php';
            $widgets_manager->register_widget_type(new Elementor\Newseqo_Post_Grid_Widget());

            require_once NEWSEQO_EDITOR_ELEMENTOR.'/widgets/post-grid-slider.php';
            $widgets_manager->register_widget_type(new Elementor\Newseqo_Post_Grid_Slider_Widget());

            require_once NEWSEQO_EDITOR_ELEMENTOR.'/widgets/post-tab.php';
            $widgets_manager->register_widget_type(new Elementor\Newseqo_post_tab_widget());   

            require_once NEWSEQO_EDITOR_ELEMENTOR.'/widgets/post-block-slider.php';
            $widgets_manager->register_widget_type(new Elementor\Newseqo_Post_block_Slider_Widget());                    
    }
    
	public static function _get_instance() {
        if (!isset(self::$_instance)) {
            self::$_instance = new Newseqo_Shortcode();
        }
        return self::$_instance;
    }

}
$Newseqo_Shortcode = Newseqo_Shortcode::_get_instance();

endif;