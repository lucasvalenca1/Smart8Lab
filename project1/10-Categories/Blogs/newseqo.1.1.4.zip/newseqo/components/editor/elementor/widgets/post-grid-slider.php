<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit;

class Newseqo_Post_Grid_Slider_Widget extends Widget_Base {

  public $base;

    public function get_name() {
        return 'newseqo-post-grid-slider';
    }

    public function get_title() {
        return esc_html__( 'Posts Grid Slider', 'newseqo' );
    }

    public function get_icon() { 
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return [ 'newseqo-elements' ];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Post', 'newseqo'),
            ]
        );
 
      $this->add_control(
         'post_gradient',
             [
             'label' => esc_html__( 'Gradient Color', 'newseqo' ),
             'type' => \Elementor\Controls_Manager::SWITCHER,
             'label_on' => esc_html__( 'Yes', 'newseqo' ),
             'label_off' => esc_html__( 'No', 'newseqo' ),
             'return_value' => 'yes',
             'default' => 'no'
             ]
         );
     
      $this->add_control(
        'post_count',
        [
          'label'         => esc_html__( 'Post count', 'newseqo' ),
          'type'          => Controls_Manager::NUMBER,
          'default'       => '9',

        ]
      );

      $this->add_control(
         'post_count_slider',
         [
           'label'         => esc_html__( 'Slider Post count', 'newseqo' ),
           'type'          => Controls_Manager::NUMBER,
           'default'       => '4',

         ]
       );

     $this->add_control(
      'post_title_crop',
      [
        'label'         => esc_html__( 'Post Title limit', 'newseqo' ),
        'type'          => Controls_Manager::NUMBER,
        'default' => '6',
       
      ]
    );  

    $this->add_responsive_control(
			'thumbnail_height',
			[
				'label' =>esc_html__( 'Thumbnail Height', 'newseqo' ),
            'type' => \Elementor\Controls_Manager::SLIDER,
            'default' => [
					'unit' => 'px',
					'size' => 310,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'desktop_default' => [
					'size' => 300,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => 250,
					'unit' => 'px',
				],
				'mobile_default' => [
					'size' => 250,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .featured-post .item' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            
			]
      );
     
        $this->add_control(
         'post_cats',
         [
             'label' =>esc_html__('Select Categories', 'newseqo'),
             'type'      => Custom_Controls_Manager::SELECT2,
             'options'   =>$this->post_category(),
             'label_block' => true,
             'multiple'  => true,
            
         ]
        );
         $this->add_control(
            'show_date',
            [
                'label' => esc_html__('Show Date', 'newseqo'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'newseqo'),
                'label_off' => esc_html__('No', 'newseqo'),
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_cat',
            [
                'label' => esc_html__('Show Category', 'newseqo'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'newseqo'),
                'label_off' => esc_html__('No', 'newseqo'),
                'default' => 'no',
            ]
        );
        $this->add_control(
         'show_author',
               [
                  'label' => esc_html__('Show Author', 'newseqo'),
                  'type' => Controls_Manager::SWITCHER,
                  'label_on' => esc_html__('Yes', 'newseqo'),
                  'label_off' => esc_html__('No', 'newseqo'),
                  'default' => 'no',
               ]
         );

        $this->add_control(
            'post_sortby',
            [
                'label'     =>esc_html__( 'Post sort by', 'newseqo' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'latestpost',
                'options'   => [
                        'latestpost'      =>esc_html__( 'Latest posts', 'newseqo' ),
                        'popularposts'    =>esc_html__( 'Popular posts', 'newseqo' ),
                        'mostdiscussed'    =>esc_html__( 'Most discussed', 'newseqo' ),
                    ],
            ]
        );
    
        $this->add_control(
            'post_order',
            [
                'label'     =>esc_html__( 'Post order', 'newseqo' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'DESC',
                'options'   => [
                        'DESC'      =>esc_html__( 'Descending', 'newseqo' ),
                        'ASC'       =>esc_html__( 'Ascending', 'newseqo' ),
                    ],
            ]
        );



        $this->end_controls_section();

        $this->start_controls_section('newseqo_style_block_section',
        [
           'label' => esc_html__( ' Post', 'newseqo' ),
           'tab' => Controls_Manager::TAB_STYLE,
        ]
       );
  
       $this->add_control(
           'block_title_color',
           [
              'label' => esc_html__('Title color', 'newseqo'),
              'type' => Controls_Manager::COLOR,
              'default' => '',
            
              'selectors' => [
                 '{{WRAPPER}} .ts-overlay-style.featured-post .post-content .post-title a' => 'color: {{VALUE}};',
              ],
           ]
        );
  
        $this->add_control(
           'block_title_hv_color',
           [
              'label' => esc_html__('Title hover color', 'newseqo'),
              'type' => Controls_Manager::COLOR,
              'default' => '',
            
              'selectors' => [
                 '{{WRAPPER}} .ts-overlay-style.featured-post .post-content .post-title:hover a' => 'color: {{VALUE}};',
              ],
           ]
        );
  
        $this->add_group_control(
           Group_Control_Typography::get_type(),
           [
              'name' => 'post_title_typography',
              'label' => __( 'Typography', 'newseqo' ),
              'scheme' => Scheme_Typography::TYPOGRAPHY_1,
              'selector' => '{{WRAPPER}} .ts-overlay-style.featured-post .post-content .post-title a',
           ]
        );
  
        
        $this->add_control(
           'block_meta_date_color',
           [
              'label' => esc_html__('Footer content color', 'newseqo'),
              'type' => Controls_Manager::COLOR,
              'default' => '',
            
              'selectors' => [
                 '{{WRAPPER}} .ts-overlay-style.featured-post .post-content .post-meta-info li a,{{WRAPPER}} .ts-overlay-style.featured-post .post-content .post-meta-info li ' => 'color: {{VALUE}};',
              ],
           ]
        );
  
        $this->end_controls_section();
        
       
    }

    protected function render( ) { 
        $settings = $this->get_settings();
        $post_gradient = $settings['post_gradient'];
     
        $slide_controls    = [
        
         'item_count'=>$settings['post_count_slider'], 

       ];
   
     $slide_controls = \json_encode($slide_controls); 
        $arg = [
            'post_type'   =>  'post',
            'post_status' => 'publish',
            'order' => $settings['post_order'],
            'posts_per_page' => $settings['post_count'],
          
        ];

   

        if(count($settings['post_cats'])){
         $arg['tax_query'] = array(
            array(
                'taxonomy' => 'category',
                'terms'    => $settings['post_cats'],
                'field' => 'id',
                'include_children' => true,
                'operator' => 'IN'
                 ),
               );
        }

        switch($settings['post_sortby']){
            case 'popularposts':
                $arg['meta_key'] = 'newseqo_post_views_count';
                $arg['orderby'] = 'meta_value_num';
            break;
            case 'mostdiscussed':
                $arg['orderby'] = 'comment_count';
            break;
            default:
                $arg['orderby'] = 'date';
            break;
        }


        $query = new \WP_Query( $arg ); ?>

      
        
        <?php if ( $query->have_posts() ) : ?>
            <div data-controls="<?php echo esc_attr($slide_controls); ?>" class="weekend-top owl-carousel owl-theme <?php echo esc_attr(($post_gradient=='yes') ? 'post-gradient': ''); ?>">
                <?php while ($query->have_posts()) : $query->the_post(); ?>
                    <?php  get_template_part('components/editor/elementor/widgets/style/post-grid/content', 'style1'); ?>    
                <?php endwhile; ?>
            </div>
        <?php endif; ?>



      <?php  
    }
    protected function _content_template() { }

    public function post_category() {

      $terms = get_terms( array(
            'taxonomy'    => 'category',
            'hide_empty'  => false,
            'posts_per_page' => -1, 
      ) );

      $cat_list = [];
      foreach($terms as $post) {
      $cat_list[$post->term_id]  = [$post->name];
      }
      return $cat_list;
   }
}