<?php

function newseqo_body_classes($classes)
{

   if (!is_singular()) {
      $classes[] = 'hfeed';
   }

   if ( is_active_sidebar( 'sidebar-1' ) ) {
      $classes[] = 'sidebar-active';
  }else{
      $classes[] = 'sidebar-inactive no-sidebar';
  }


   return $classes;
}
add_filter('body_class', 'newseqo_body_classes');

function newseqo_pingback_header()
{
   if (is_singular() && pings_open()) {
      printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
   }
}
add_action('wp_head', 'newseqo_pingback_header');

function newseqo_get_post_category($tax = 'category')
{

   static $list = null;
   if (!is_array($list)) {
      $categories = get_terms($tax, array(
         'orderby'       => 'name',
         'order'         => 'DESC',
         'hide_empty'    => false,
         'number'        => 200

      ));

      foreach ($categories as $category) {
         $list[$category->term_id] = $category->name;
      }
   }

   return $list;
}


function newseqo_child_category_meta()
{

   $newseqo_cat_term = get_queried_object();
   $newseqo_cat_children = get_terms($newseqo_cat_term->taxonomy, array(
      'parent'    => $newseqo_cat_term->term_id,
      'hide_empty' => false
   ));

   if (!$newseqo_cat_children) {
      return;
   }

   if ($newseqo_cat_children) {
      echo '<div class="sub-category-list">';
      foreach ($newseqo_cat_children as $newseqo_subcat) {
         echo '<a class="post-cat" href="' . esc_url(get_term_link($newseqo_subcat, esc_html($newseqo_subcat->taxonomy))) . '" >' .
            esc_html($newseqo_subcat->name) .
            '</a>';
      }
      echo '</div>';
   }
}

function newseqo_category_meta()
{

   $blog_cat_show = get_theme_mod('newseqo_blog_category', true);
   $blog_cat_single = get_theme_mod('newseqo_blog_category_single', false);
   if ($blog_cat_show != true) {
      return;
   }
   $cat = get_the_category();
   if ($blog_cat_single) {

      shuffle($cat);
      if (isset($cat[0])) {
         echo '<a 
          class="post-cat" 
          href="' . esc_url(get_category_link($cat[0]->term_id)) . '"
         
          >' . '<span class="before"></span>' .

            esc_html(get_cat_name($cat[0]->term_id)) .
            '<span class="after"></span> ' .
            '</a>';
      }
      return;
   }

   if ($cat) {
      foreach ($cat as $value) :
         echo '<a 
          class="post-cat " 
          href="' . esc_url(get_category_link($value->term_id)) . '"
          >' . esc_html(get_cat_name($value->term_id)) . '</a>';
      endforeach;
   }
}

function newseqo_category_post_meta()
{
?>

   <?php

   $blog_author_show = get_theme_mod('newseqo_blog_category');

   if ($blog_author_show) {

      printf(
         '<span class="post-author">' . '<i class="icon icon-author_icon"></i>' . '<a href="%2$s">%3$s</a></span>',
         get_avatar(get_the_author_meta('ID'), 55),
         esc_url(get_author_posts_url(get_the_author_meta('ID'))),
         get_the_author()
      );
   }

   $blog_date_show = get_theme_mod('newseqo_blog_date');

   if (get_post_type() === 'post' && $blog_date_show == true) {
      echo '<span class="post-meta-date">
                  <i class="icon icon-date_icon"></i>
                     ' . get_the_date() .
         '</span>';
   }

   ?>

<?php }

// display meta information for a specific post
// ----------------------------------------------------------------------------------------
function newseqo_post_meta()
{
?>
   <ul class="post-meta">

      <?php

      if (get_theme_mod('newseqo_blog_author', true) && is_single()) :
         printf(
            '<li class="post-author">%1$s<a href="%2$s">%3$s</a></li>',
            get_avatar(get_the_author_meta('ID'), 55),
            esc_url(get_author_posts_url(get_the_author_meta('ID'))),
            get_the_author()
         );

      else :
         if (get_theme_mod('newseqo_blog_author', true)) {
            printf(
               '<li class="post-author"> <i class="icon icon-author_icon"></i> <a href="%1$s">%2$s</a></li>',
               esc_url(get_author_posts_url(get_the_author_meta('ID'))),
               get_the_author()
            );
         }

      endif;
      if (get_theme_mod('newseqo_blog_category', true)) : ?>
         <li class="post-category">
            <?php newseqo_category_meta(); ?>
         </li>
      <?php

      endif;
      if (get_post_type() === 'post' && get_theme_mod('newseqo_blog_date', true)) {
         echo '<li class="post-meta-date">
                  <i class="fa fa-calendar"></i>
                     ' . get_the_date() .
            '</li>';
      }

      if (is_category() && get_theme_mod('newseqo_blog_comment', true)) {
         printf(
            ' <li class="post-comment"><i class="icon icon-comment"></i><a href="#" class="comments-link">%1$s</a></li>',
            esc_html(get_comments_number(get_the_ID()))
         );
      }


      if (is_single()) :

         if (get_theme_mod('newseqo_blog_post_comment_open', true)) :
            printf(
               ' <li class="post-comment"><i class="fa fa-comments"></i><a href="#" class="comments-link">%1$s </a></li>',
               esc_html(get_comments_number(get_the_ID()))
            );
         endif;

         if (get_theme_mod('newseqo_blog_read_time', false)) {

            echo  '<li class="read-time">' . wp_kses_post(newseqo_content_estimated_reading_time(get_the_content())) . '</li>';
         }

      endif;

      ?>
   </ul>
<?php }

if (!function_exists('newseqo_content_estimated_reading_time')) {

   function newseqo_content_estimated_reading_time($content = '', $wpm = 200)
   {
      $clean_content = esc_html($content);
      $word_count = str_word_count($clean_content);
      $time = ceil($word_count / $wpm);
      if ($time <= 1) {
         $time .= esc_html__(' minute read', 'newseqo');
      } else {
         $time .= esc_html__(' minutes read', 'newseqo');
      }
      $output = '<span class="post-read-time">';
      $output .= '<i class="fa fa-eye"></i>';
      $output .= '<span class="read-time">' . $time . '</span>' . ' ';
      $output .= '</span>';
      return $output;
   }
}

function newseqo_link_pages()
{
   $args = array(
      'before'          => '<div class="page-links"><span class="page-link-text">' . esc_html__('More pages: ', 'newseqo') . '</span>',
      'after'             => '</div>',
      'link_before'       => '<span class="page-link">',
      'link_after'       => '</span>',
      'next_or_number'    => 'number',
      'separator'          => '  ',
      'nextpagelink'       => esc_html__('Next ', 'newseqo') . '<I class="fa fa-angle-right"></i>',
      'previouspagelink'    => '<I class="fa fa-angle-left"></i>' . esc_html__(' Previous', 'newseqo'),
   );
   wp_link_pages($args);
}

function newseqo_title_limit($title)
{
   $limit = get_theme_mod('newseqo_blog_post_title_char_limit_length', 20);
   if (get_theme_mod('newseqo_blog_listing_title_length', false)) {
      $title  =  wp_trim_words($title, $limit, '');
   }
   echo esc_html($title);
}

function newseqo_comment_style($comment, $args, $depth)
{
   if ('div' === $args['style']) {
      $tag       = 'div';
      $add_below    = 'comment';
   } else {
      $tag       = 'li ';
      $add_below    = 'div-comment';
   }
?>
   <?php
   if ($args['avatar_size'] != 0) {
      echo get_avatar($comment, $args['avatar_size'], '', '', array('class' => 'comment-avatar pull-left'));
   }
   ?>
   <<?php
      echo wp_kses_post($tag);
      comment_class(empty($args['has_children']) ? '' : 'parent');
      ?> id="comment-<?php comment_ID() ?>"><?php if ('div' != $args['style']) { ?>
         <div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php }
                                                                           ?>
         <div class="meta-data">

            <div class="pull-right reply"><?php
                                          comment_reply_link(
                                             array_merge(
                                                $args,
                                                array(
                                                   'add_below'    => $add_below,
                                                   'depth'       => $depth,
                                                   'max_depth'    => $args['max_depth']
                                                )
                                             )
                                          );
                                          ?>
            </div>


            <span class="comment-author vcard"><?php
                                                printf(wp_kses_post('<cite class="fn">%s</cite> <span class="says">%s</span>', 'newseqo'), get_comment_author_link(), esc_html__('says:', 'newseqo'));
                                                ?>
            </span>
            <?php if ($comment->comment_approved == '0') { ?>
               <em class="comment-awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'newseqo'); ?></em><br /><?php }
                                                                                                                                          ?>

            <div class="comment-meta commentmetadata comment-date">
               <?php

               printf(esc_html__('%1$s at %2$s', 'newseqo'), esc_html(get_comment_date()), esc_html(get_comment_time())); // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment
               ?>
               <?php edit_comment_link(esc_html__('(Edit)', 'newseqo'), '  ', ''); ?>
            </div>
         </div>
         <div class="comment-content">
            <?php comment_text(); ?>
         </div>
         <?php if ('div' != $args['style']) : ?>
         </div><?php
            endif;
         }
