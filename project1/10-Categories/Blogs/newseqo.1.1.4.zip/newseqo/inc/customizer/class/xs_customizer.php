<?php 

class newseqo_xs_customizer {

   public static  $panels = [];

   public static  $sections = [];

   public static  $fields = [];

   public function __construct(){

   }

   public static function addPanel($panel){
      self::$panels[]   = $panel;
   }

  

   public static function  addSection($section){
      self::$sections[]   = $section;
   }

 

   public static function  addfield($field){
      self::$fields[]   = $field;
   }

 

   public static function build($wp_customizer){
     
     $panels = self::$panels;
     $fields = self::$fields;
     if(count($panels)){
      foreach($panels as $p_key=>$p_val){
        if(isset($p_val['id']) && $p_val['title'] && $p_val['sections']){
          $wp_customizer->add_panel( $p_val['id'], array(
             'title'       => $p_val['title'],
             'description' => isset($p_val['description'])?$p_val['description']:'', 
             'priority'    => isset($p_val['priority'])?$p_val['priority']:'31', 
          ) );

          if(isset($p_val['sections'])){
             if(count($p_val['sections'])){
                foreach($p_val['sections'] as $section){
                  if(isset($section['id']) && isset($section['title'])){
                   $wp_customizer->add_section( $section['id'], array(
                      'title'           => $section['title'],
                      'priority'        => isset($section['priority'])?$section['priority']:0,
                      'panel'           => $p_val['id'],
                   ) );
                  }
                }
             }
          }
        }
      }
   }

   // control 

   foreach($fields as $f_key=>$field){
      if(isset($field['id'])){
        
         $wp_customizer->add_setting( $field['id'], array(
            'default'   => isset($field['default'])?$field['default']:' ',
            'transport' => isset($field['transport'])?$field['transport']:'postMessage',
            'type'      =>'theme_mod' 
         ) );

         if(isset($field["section"])){ 
          
               $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, $field["id"],
                     array(
                        'label'       => isset($field['label'])?$field['label']:$field['id'],
                        'description' => isset($field['description'])?$field['description']:' ',
                        'section'     => $field['section'],
                     
                     )
                  ) 
               );
            }
         }
      }
       
   }



}