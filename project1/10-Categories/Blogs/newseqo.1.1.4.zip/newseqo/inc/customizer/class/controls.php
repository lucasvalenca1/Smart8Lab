<?php
// We're in a plugin directory and need to determine the url accordingly.
function newseqo_get_tw_resource_url() {
   if( strpos( wp_normalize_path( __DIR__ ), wp_normalize_path( WP_PLUGIN_DIR ) ) === 0 ) {
      
      return plugin_dir_url( __DIR__ );
   }
   return trailingslashit( get_template_directory_uri() );
}

if( class_exists( 'WP_Customize_Control' ) ):

  
   class Newseqo_Image_Radio_Button_Custom_Control extends WP_Customize_Control {
		/**
		 * The type of control being rendered
		 */
 		public $type = 'image_radio_button';
		/**
		 * Enqueue our scripts and styles
		 */ 
 		public function enqueue() {
         wp_enqueue_script( 'newseqo_customizer-js', apply_filters('newseqo_customizer_get_template_directory_uri',get_template_directory_uri() . '/core') . '/customizer/js/newseqo_xs_customizer.js', array( 'jquery' ), NEWSEQO_CUSTOMIZER_VERSION, true );
         wp_enqueue_style( 'newseqo_customizer-css', apply_filters('newseqo_customizer_get_template_directory_uri',get_template_directory_uri() . '/core') . '/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
 		}
		/**
		 * Render the control in the customizer
		 */
 		public function render_content() { ?>
			<div class="image_radio_button_control">
				<?php if( !empty( $this->label ) ) { ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php } ?>
				<?php if( !empty( $this->description ) ) { ?>
					<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php } ?>

				<?php foreach ( $this->choices as $key => $value ) { ?>
					<label class="radio-button-label">
						<input type="radio" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $key ); ?>" <?php $this->link(); ?> <?php checked( esc_attr( $key ), $this->value() ); ?>/>
						<img src="<?php echo esc_attr( $value['image'] ); ?>" alt="<?php echo esc_attr( $value['name'] ); ?>" title="<?php echo esc_attr( $value['name'] ); ?>" />
					</label>
				<?php	} ?>
			</div>
 		<?php
 		}
    }
    
     /**
      * Toggle switch control
      */

   class Newseqo_Toggle_Switch_Custom_control extends WP_Customize_Control {
      /**
       * The type of control being rendered
      */
      public $type = 'toggle_switch';
      /**
       * Enqueue our scripts and styles
      */
      
      public function enqueue(){
   
         wp_enqueue_script( 'newseqo_customizer-js', apply_filters('newseqo_customizer_get_template_directory_uri',get_template_directory_uri() . '/core') . '/customizer/js/newseqo_xs_customizer.js', array( 'jquery' ), NEWSEQO_CUSTOMIZER_VERSION, true );
         wp_enqueue_style( 'newseqo_customizer-css', apply_filters('newseqo_customizer_get_template_directory_uri',get_template_directory_uri() . '/core') . '/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
      }
      /**
       * Render the control in the customizer
      */
      public function render_content(){ ?>
       <div class="toggle-switch-control">
         <div class="toggle-switch">
            <input type="checkbox" id="<?php echo esc_attr($this->id); ?>" name="<?php echo esc_attr($this->id); ?>" class="toggle-switch-checkbox" value="<?php echo esc_attr( $this->value() ); ?>" <?php $this->link(); checked( $this->value() ); ?>>
            <label class="toggle-switch-label" for="<?php echo esc_attr( $this->id ); ?>">
               <span class="toggle-switch-inner"></span>
               <span class="toggle-switch-switch"></span>
            </label>
         </div>
         <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
         <?php if( !empty( $this->description ) ) { ?>
            <span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
         <?php } ?>
      </div>
      <?php
      }
   }
    /**
     * Select2 custom Control  
     */

   class Newseqo_Dropdown_Select2_Custom_Control extends WP_Customize_Control {
		/**
		 * The type of control being rendered
		 */
		public $type = 'dropdown_select2';
		/**
		 * The type of Select2 Dropwdown to display. Can be either a single select dropdown or a multi-select dropdown. Either false for true. Default = false
		 */
		private $multiselect = false;
		/**
		 * The Placeholder value to display. Select2 requires a Placeholder value to be set when using the clearall option. Default = 'Please select...'
		 */
		private $placeholder = 'Please select...';
		/**
		 * Constructor
		*/
		public function __construct( $manager, $id, $args = array(), $options = array() ) {
			parent::__construct( $manager, $id, $args );
			// Check if this is a multi-select field
			if ( isset( $this->input_attrs['multiselect'] ) && $this->input_attrs['multiselect'] ) {
				$this->multiselect = true;
			}
			// Check if a placeholder string has been specified
			if ( isset( $this->input_attrs['placeholder'] ) && $this->input_attrs['placeholder'] ) {
				$this->placeholder = $this->input_attrs['placeholder'];
			}
		}
		/**
		 * Enqueue our scripts and styles
		 */
		public function enqueue() {
         wp_enqueue_script( 'select2-min', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core') . '/customizer/js/select2.min.js', array( 'jquery' ), '4.0.6', true );
		   wp_enqueue_script( 'newseqo_customizer-repeater-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core') . 'customizer/js/customizer_repeater.js', array( 'jquery' ), NEWSEQO_CUSTOMIZER_VERSION, true );
         wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core') . '/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
         wp_enqueue_style( 'select2-min', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core') . '/customizer/css/select2.min.css', array(), '4.0.6', 'all' );
		}
		/**
		 * Render the control in the customizer
		 */
		public function render_content() {
			$defaultValue = $this->value();
			if ( $this->multiselect ) {
            $defaultValue = explode( ',', $this->value() );
            
			}
		?>
			<div class="dropdown_select2_control">
				<?php if( !empty( $this->label ) ) { ?>
					<label for="<?php echo esc_attr( $this->id ); ?>" class="customize-control-title">
						<?php echo esc_html( $this->label ); ?>
					</label>
				<?php } ?>
				<?php if( !empty( $this->description ) ) { ?>
					<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php } ?>
				<input type="hidden" id="<?php echo esc_attr( $this->id ); ?>" class="customize-control-dropdown-select2" value="<?php echo esc_attr( $this->value() ); ?>" name="<?php echo esc_attr( $this->id ); ?>" <?php $this->link(); ?> />
				<select name="select2-list-<?php echo esc_attr( $this->multiselect ? 'multi[]' : 'single' ); ?>" class="customize-control-select2" data-placeholder="<?php echo esc_attr($this->placeholder); ?>" <?php echo esc_attr( $this->multiselect ? 'multiple="multiple" ' : '' ); ?>>
					<?php
						if ( !$this->multiselect ) {
						
							echo '<option></option>';
						}
						foreach ( $this->choices as $key => $value ) {
							if ( is_array( $value ) ) {
								echo '<optgroup label="' . esc_attr( $key ) . '">';
								foreach ( $value as $optgroupkey => $optgroupvalue ) {
									echo '<option value="' . esc_attr( $optgroupkey ) . '" ' . ( in_array( esc_attr( $optgroupkey ), $defaultValue ) ? 'selected="selected"' : '' ) . '>' . esc_attr( $optgroupvalue ) . '</option>';
								}
								echo '</optgroup>';
							}
							else {
                        if ( $this->multiselect ) { 
                           $selected = in_array($key,$defaultValue)?$key:'';
                           echo '<option value="' . esc_attr( $key ) . '" ' . selected( esc_attr( $key ), $selected, false )  . '>' . esc_attr( $value ) . '</option>';   
                        }else{
                           echo '<option value="' . esc_attr( $key ) . '" ' . selected( esc_attr( $key ), $defaultValue, false )  . '>' . esc_attr( $value ) . '</option>';
                        }
								
							}
	 					}
	 				?>
				</select>
			</div>
		<?php
		}
   }
   
   class Newseqo_Custom_Textarea_Control extends WP_Customize_Control {
		public $type = 'customizer-textarea';
 
		public function render_content() {
		?>
			<label>
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<textarea rows="5" style="width:100%;" <?php $this->link(); ?>><?php echo esc_textarea( $this->value() ); ?></textarea>
			</label>
		<?php
		}
   }

   class Newseqo_Dimension_Control extends WP_Customize_Control {
      /**
       * Official control name.
       *
       * @var string
       */
      public $type = 'dimension-control';
   
      public $unit = "";
      public $dimension_type = "";
      
      public $dimensions;
   
      private $selector = '';
      private $responsive = '';
      
      public function __construct( $manager, $id, $args = array(), $options = array() ) {
         parent::__construct( $manager, $id, $args );
   
          $this->dimensions = [
             "top" => null,
             "right" => null,
             "bottom" => null,
             "left" => null,
            
          ];
   
          if(isset($this->input_attrs["type"])){
            $this->dimension_type = $this->input_attrs["type"];
          }
   
          if(isset($this->input_attrs["selector"])){
            $this->selector = $this->input_attrs["selector"];
          }
   
          if(isset($this->input_attrs["responsive"])){
                if($this->input_attrs["responsive"]) {
   
                  $this->responsive = true;
               }
          }
   
          $db_value = json_decode($this->value(),true);
         if(isset($db_value["desktop"])){
            $this->unit = $this->getUnit($db_value["desktop"]); 
         }elseif(isset($db_value["tablet"])){
            $this->unit = $this->getUnit($db_value["tablet"]); 
         }elseif(isset($db_value["mobile"])){
            $this->unit = $this->getUnit($db_value["mobile"]); 
         } 
         
      }
   
      public function to_json() {
         parent::to_json();
         $this->json['statuses'] = $this->unit;
         $this->json['selector'] = $this->selector;
       }
   
      public function getUnit($value){
         $unit = "px";
         $value = json_decode($value,true);
        
         if(is_null($value) || $value==''){
            return $unit;
         }
         if(!is_array($value)){
            return $unit;
         }
   
         foreach($value as $key=>$item){
             $unit = $item;
             if( strpos($key, 'margin') === 0 || strpos($key, 'padding') === 0 ){
                $number_key=explode("-",$key)[1];
                $this->dimensions[$number_key] = preg_replace("/[^0-9]/", "", $item );
             }else{
              
               $this->dimensions[$key] = preg_replace("/[^0-9]/", "", $item );  
             } 
             
         }
        
         return preg_replace('/[0-9]+/', '', $unit);
      }
   
     
      
      /**
       * Enqueue scripts and styles.
       *
       * Ideally these would get registered and given proper paths before this control object
       * gets initialized, then we could simply enqueue them here, but for completeness as a
       * stand alone class we'll register and enqueue them here.
       */
      public function enqueue() {
      
         wp_enqueue_script( 'newseqo_customizer-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core') . '/customizer/js/newseqo_xs_customizer.js', array( 'jquery' ), NEWSEQO_CUSTOMIZER_VERSION, true );
         wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core') . '/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
      }
      /**
       * Render the control.
       */
      public function render_content() {
        ?>
         <label>
            <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <input id="<?php echo esc_attr($this->id); ?>" class="custom-dimension-control" type="hidden" <?php esc_attr( $this->link() ); ?>  value="<?php echo esc_attr($this->value()); ?>" />
            <div class="custom-dimension-control-visible-section">
               
            <?php if($this->responsive): ?>
                 <div class="xs_customizer-divice-preview">
                 <span class="dashicons dashicons-desktop xs-preview-desktop"></span>
                 <span class="dashicons dashicons-tablet xs-preview-tablet"></span>
                 <span class="dashicons dashicons-smartphone xs-preview-mobile"></span>
                </div>
             <?php endif; ?> 
            
            <ul data-unit="<?php echo esc_attr($this->unit); ?>" class="custom-control-dimension-size"> <li class="dimension-px <?php echo esc_attr($this->unit=="px"?"active":''); ?>" data-value="px"> <?php echo esc_html__("px","newseqo"); ?> </li> <li class="dimension-percent <?php echo esc_attr($this->unit=="%"?"active":''); ?>" data-value="%"> <?php echo esc_html__("%","newseqo"); ?> </li> <li class="dimension-em <?php echo esc_attr($this->unit=='em'?'active':''); ?>" data-value="em"> <?php echo esc_html__("em","newseqo"); ?> </li> <ul>   
            
            <div data-type="<?php echo esc_attr($this->dimension_type); ?>" class="customizer-all-dimensions <?php echo esc_attr($this->id); ?>" data-id="<?php echo esc_attr($this->id); ?>"> 
           
            <?php foreach($this->dimensions as $key=>$value): ?>
           
               
            <div  class="custom-dimension">
                <input size="10" class="custom-dimension-control-input <?php echo esc_attr($key) ?>" type="number" value="<?php echo esc_attr($value); ?>" />
                <span> <?php echo esc_attr($key) ?> </span>  
           </div>
          
            <?php endforeach ?>   
           </div>  
            </div>      
         </label>
      <?php 	
      }
   }

   
	class Newseqo_Icon_Picker_Control_Social extends WP_Customize_Control {

		public $type = 'social-icon-picker';

      public $iconset = array();
      
      public $customizer_icon_container = '';

	
      
     /*Class constructor*/
	public function __construct( $manager, $id, $args = array() ) {
      parent::__construct( $manager, $id, $args ); 

      if ( file_exists( apply_filters("newseqo_customizer_get_template_directory",get_template_directory() . '/core').'/customizer/inc/icons_social.php' ) ) {
			$this->customizer_icon_container =  apply_filters("newseqo_customizer_get_template_directory_abs_path", '/core').'/customizer/inc/icons_social';
		}

   }

		public function enqueue() {
    
         wp_enqueue_style( 'newseqo_customizer-rt-admin-stylesheet', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/css/admin-style.css', array(), NEWSEQO_CUSTOMIZER_VERSION );
         wp_enqueue_style( 'newseqo_customizer-rt-fontawesome-iconpicker-script', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/css/fontawesome-iconpicker.min.css', array(), NEWSEQO_CUSTOMIZER_VERSION );
            
         wp_enqueue_style( 'font-awesome-min', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/css/font-awesome.min.css', array(), NEWSEQO_CUSTOMIZER_VERSION );
         
         wp_enqueue_script( 'newseqo_customizer-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/js/newseqo_xs_customizer.js', array( 'jquery' ), NEWSEQO_CUSTOMIZER_VERSION, true );
         wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
         
		}

		public function render_content() {
		
		?>
			<label>
		 	  <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			  <span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
		     <input class="customizer-social-icon-picker" value="<?php echo esc_attr($this->value()); ?>" type="text" id="customizer-social-icon-<?php echo esc_attr( $this->id ); ?>" <?php esc_attr( $this->link() ); ?> />
            <?php get_template_part( $this->customizer_icon_container ); ?>
			</label>
		<?php }

   }
   
   class Newseqo_Range_Value_Control extends \WP_Customize_Control {
      public $type = 'range-value';
      private $selector = '';
   
      public function __construct( $manager, $id, $args = array(), $options = array() ) {
         parent::__construct( $manager, $id, $args ); 
         
         if(isset($this->input_attrs["selector"])){
            $this->selector = $this->input_attrs["selector"];
          }
      
      }
   
      public function to_json() {
         parent::to_json();
      
         $this->json['selector'] = $this->selector;
       }
   
      /**
       * Enqueue scripts/styles.
       *
       * @since 3.4.0
       */
      public function enqueue() {
    
        wp_enqueue_script( 'newseqo_customizer-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/js/newseqo_xs_customizer.js', array( 'jquery', 'jquery-ui-core' ), NEWSEQO_CUSTOMIZER_VERSION, true );
            wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
      }
   
      /**
       * Render the control's content.
       *
       * @author soderlind
       * @version 1.2.0
       */
      public function render_content() {
         ?>
         <label>
            <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
            <div class="range-slider"  style="width:100%; display:flex;flex-direction: row;justify-content: flex-start;">
               <span  style="width:100%; flex: 1 0 0; vertical-align: middle;"><input class="range-slider__range" type="range" value="<?php echo esc_attr( $this->value() ); ?>"
                       <?php
                           $this->input_attrs();
                           $this->link();
                         ?>
               >
               <span class="range-slider__value">0</span></span>
            </div>
            <?php if ( ! empty( $this->description ) ) : ?>
            <span class="description customize-control-description"><?php echo wp_kses_post($this->description); ?></span>
            <?php endif; ?>
         </label>
         <?php
      }
   
      
      private function abs_path_to_url( $path = '' ) {
         $url = str_replace(
            wp_normalize_path( untrailingslashit( ABSPATH ) ),
            site_url(),
            wp_normalize_path( $path )
         );
         return esc_url_raw( $url );
      }
   }

   class Newseqo_Sortable_Repeater_Control extends  \WP_Customize_Control {
		/**
		 * The type of control being rendered
		 */
		public $type = 'sortable_repeater';
		/**
 		 * Button labels
 		 */
		public $button_labels = array();
		/**
		 * Constructor
		 */
		public function __construct( $manager, $id, $args = array(), $options = array() ) {
			parent::__construct( $manager, $id, $args );
			// Merge the passed button labels with our default labels
			$this->button_labels = wp_parse_args( $this->button_labels,
				array(
					'add' => __( 'Add', 'newseqo' ),
				)
			);
		}
		/**
		 * Enqueue our scripts and styles
		 */
		public function enqueue() {
			 wp_enqueue_script( 'newseqo_customizer-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/js/newseqo_xs_customizer.js', array( 'jquery', 'jquery-ui-core' ), NEWSEQO_CUSTOMIZER_VERSION, true );
          wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
		}
		/**
		 * Render the control in the customizer
		 */
		public function render_content() {
      ?>  
       
	      <div class="sortable_repeater_control">
				<?php if( !empty( $this->label ) ) { ?>
					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php } ?>
				<?php if( !empty( $this->description ) ) { ?>
					<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php } ?>
				<input type="hidden" id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" class="customize-control-sortable-repeater" <?php $this->link(); ?> />
				<div class="sortable">
					<div class="repeater">
                  <input type="text" value="" class="repeater-input" placeholder="https://" /><span class="dashicons dashicons-sort"></span><a class="customize-control-sortable-repeater-delete" href="#"><span class="dashicons dashicons-no-alt"></span></a>
              
					</div>
				</div>
				<button class="button customize-control-sortable-repeater-add" type="button"><?php echo esc_html($this->button_labels['add']); ?></button>
			</div>
		<?php
		}
   }

   class Newseqo_Text_Editor_Custom_Control extends WP_Customize_Control {
         /**
          * Render the content on the theme customizer page
          */
         public $type = 'textarea';
         public function render_content()
         {
               ?>
                  <label>
                     <h3 class="customize-text_editor"><?php echo esc_html( $this->label ); ?></h3>
                     <?php
                     $settings = array(
                        'textarea_name' => $this->id,
                        'media_buttons' => false
                        );
                     wp_editor($this->value(), $this->id, $settings );
                     ?>
                  </label>
               <?php
         }
   }

   class Newseqo_TinyMCE_Custom_control extends \WP_Customize_Control {
		/**
		 * The type of control being rendered
		 */
		public $type = 'tinymce_editor';
		/**
		 * Enqueue our scripts and styles
		 */
		public function enqueue(){
         wp_enqueue_script( 'newseqo_customizer-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/js/newseqo_xs_customizer.js', array( 'jquery', 'jquery-ui-core' ), NEWSEQO_CUSTOMIZER_VERSION, true );
         wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );


			wp_enqueue_editor();
		}
		/**
		 * Pass our TinyMCE toolbar string to JavaScript
		 */
		public function to_json() {
			parent::to_json();
			$this->json['newseqotinymcetoolbar1'] = isset( $this->input_attrs['toolbar1'] ) ? esc_attr( $this->input_attrs['toolbar1'] ) : 'bold italic bullist numlist alignleft aligncenter alignright link';
			$this->json['newseqotinymcetoolbar2'] = isset( $this->input_attrs['toolbar2'] ) ? esc_attr( $this->input_attrs['toolbar2'] ) : '';
			$this->json['newseqomediabuttons'] = isset( $this->input_attrs['mediaButtons'] ) && ( $this->input_attrs['mediaButtons'] === true ) ? true : false;
		}
		/**
		 * Render the control in the customizer
		 */
		public function render_content(){
		?>
			<div class="tinymce-control">
				<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
				<?php if( !empty( $this->description ) ) { ?>
					<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
				<?php } ?>
				<textarea id="<?php echo esc_attr( $this->id ); ?>" class="customize-control-tinymce-editor" <?php $this->link(); ?>><?php echo esc_attr( $this->value() ); ?></textarea>
			</div>
		<?php
		}
   }
   
   class Newseqo_Custom_Typography_Group_Control extends WP_Customize_Control {
		/**
		 * The type of control being rendered
		 */
		public $type = 'google_fonts';
		/**
		 * The list of Google Fonts
		 */
		private $fontList = false;
		/**
		 * The saved font values decoded from json
		 */
		private $fontValues = [];
		/**
		 * The index of the saved font within the list of Google fonts
		 */
		private $fontListIndex = 0;
		/**
		 * The number of fonts to display from the json file. Either positive integer or 'all'. Default = 'all'
		 */
		private $fontCount = 'all';
		/**
		 * The font list sort order. Either 'alpha' or 'popular'. Default = 'alpha'
		 */
      private $fontOrderBy = 'alpha';
      
      private $default_font_size = '';
      private $function = 'css';
      private $selector = '';

         
		/**
		 * Get our list of fonts from the json file
		 */
		public function __construct( $manager, $id, $args = array(), $options = array() ) {
			parent::__construct( $manager, $id, $args );
			// Get the font sort order
			if ( isset( $this->input_attrs['orderby'] ) && strtolower( $this->input_attrs['orderby'] ) === 'popular' ) {
				$this->fontOrderBy = 'popular';
         }
         
        
			// Get the list of Google fonts
			if ( isset( $this->input_attrs['font_count'] ) ) {
				if ( 'all' != strtolower( $this->input_attrs['font_count'] ) ) {
					$this->fontCount = ( abs( (int) $this->input_attrs['font_count'] ) > 0 ? abs( (int) $this->input_attrs['font_count'] ) : 'all' );
				}
			}
         $this->fontList = $this->customizer_getGoogleFonts( 'all' );
        
			// Decode the default json font value
         $this->fontValues = json_decode( $this->value() ,true);
       
         // Find the index of our default font within our list of Google fonts
         if($this->value()!=''){
          
            $this->fontListIndex = $this->newseqo_getFontIndex( $this->fontList, $this->fontValues["font-family"] );
         }
         if( isset($this->input_attrs["font-family"]) && !isset($this->fontValues["font-family"]) ) {
            $this->fontValues["font-family"] =  $this->input_attrs["font-family"];
         }elseif(!isset($this->fontValues["font-family"])){
            $this->fontValues["font-family"] = '';
         }
         if( isset($this->input_attrs["font-size"]) && !isset($this->fontValues["font-size"]) ) {
            $this->fontValues["font-size"] =  $this->input_attrs["font-size"];
         }elseif(!isset($this->fontValues["font-size"])){
            $this->fontValues["font-size"] = '';
         }

         if( isset($this->input_attrs["line-height"]) && !isset($this->fontValues["line-height"]) ) {
            $this->fontValues["line-height"] =  $this->input_attrs["line-height"];
         }elseif(!isset($this->fontValues["line-height"])){
            $this->fontValues["line-height"] = '';
         }

         if( isset($this->input_attrs["letter-spacing"]) && !isset($this->fontValues["letter-spacing"]) ) {
            $this->fontValues["letter-spacing"] =  $this->input_attrs["letter-spacing"];
         }elseif(!isset($this->fontValues["letter-spacing"])){
            $this->fontValues["letter-spacing"] = '';
         }

         if( isset($this->input_attrs["trasnform"]) && !isset($this->fontValues["trasnform"]) ) {
            $this->fontValues["trasnform"] =  $this->input_attrs["trasnform"];
         }elseif(!isset($this->fontValues["trasnform"])){
            $this->fontValues["trasnform"] = 'lowercase';
         }

         if( isset($this->input_attrs["text-decoration"]) && !isset($this->fontValues["text-decoration"]) ) {
            $this->fontValues["text-decoration"] =  $this->input_attrs["text-decoration"];
         }elseif(!isset($this->fontValues["text-decoration"])){
            $this->fontValues["text-decoration"] = 'none';
         }

      
			
		}
		/**
		 * Enqueue our scripts and styles
		 */
		public function enqueue() {
			wp_enqueue_script( 'select2-min', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/js/select2.min.js', array( 'jquery' ), '4.0.6', true );
			wp_enqueue_script( 'newseqo_customizer-js', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/js/newseqo_xs_customizer.js', array( 'select2-min' ), NEWSEQO_CUSTOMIZER_VERSION, true );
			wp_enqueue_style( 'newseqo_customizer-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/css/newseqo_xs_customizer.css', array(), NEWSEQO_CUSTOMIZER_VERSION, 'all' );
			wp_enqueue_style( 'select2-min-css', apply_filters("newseqo_customizer_get_template_directory_uri",get_template_directory_uri() . '/core').'/customizer/css/select2.min.css', array(), '4.0.6', 'all' );
		}
		/**
		 * Export our List of Google Fonts to JavaScript
		 */
		public function to_json() {
			parent::to_json();
         $this->json['newseqofontslist'] = $this->fontList;
         $this->json['selector'] = isset( $this->input_attrs['selector'] ) ? $this->input_attrs['selector'] : '';
         $this->json['function'] = isset( $this->input_attrs['function'] ) ? $this->input_attrs['function'] : '';
		}
		/**
		 * Render the control in the customizer
		 */
		public function render_content() {
   
			$fontCounter = 0;
			$isFontInList = false;
         $fontListStr = '';
        
			if( !empty($this->fontList) ) {
       
             
				?>
				<div class="google_fonts_select_control">
					<?php if( !empty( $this->label ) ) { ?>
						<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<?php } ?>
					<?php if( !empty( $this->description ) ) { ?>
						<span class="customize-control-description"><?php echo esc_html( $this->description ); ?></span>
					<?php } ?>
					<input type="hidden" id="<?php echo esc_attr( $this->id ); ?>" name="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" class="customize-control-google-font-selection" <?php $this->link(); ?> />
					<div class="google-fonts">
						<select class="google-fonts-list" control-name="<?php echo esc_attr( $this->id ); ?>">
      
							<?php
                        
								foreach( $this->fontList as $key => $value ) {
                       
									$fontCounter++;
                           $fontListStr .= '<option value="' . $value->family . '" ' . selected( $this->fontValues["font-family"], $value->family, false ) . '>' . $value->family . '</option>';
                           
									if ( $this->fontValues["font-family"] === $value->family ) {
										$isFontInList = true;
									}
									if ( is_int( $this->fontCount ) && $fontCounter === $this->fontCount ) {
										break;
									}
								}
								if ( !$isFontInList && $this->fontListIndex ) {
									// If the default or saved font value isn't in the list of displayed fonts, add it to the top of the list as the default font
									$fontListStr = '<option value="' . $this->fontList[$this->fontListIndex]->family . '" ' . selected( $this->fontValues["font-family"], $this->fontList[$this->fontListIndex]->family, false ) . '>' . $this->fontList[$this->fontListIndex]->family . ' (default)</option>' . $fontListStr;
                        }
                       
								// Display our list of font options
								echo newseqo_kses($fontListStr); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</select>
					</div>
					<div class="customize-control-description"> <?php echo esc_html__("Select weight &amp; style for regular text","newseqo"); ?></div>
					<div class="weight-style">
						<select class="google-fonts-regularweight-style">
							<?php
                     
								foreach( $this->fontList[$this->fontListIndex]->variants as $key => $value ) {
									echo '<option value="' . esc_attr($value) . '" ' . selected( $this->fontValues["font-weight"], $value, false ) . '>' . esc_attr($value) . '</option>';
								}
							?>
						</select>
					</div>
               <div class="customize-control-font-size"><?php echo esc_html__("Select font size","newseqo"); ?></div>
               <input class="range-slider custom_group_typhography_range_font_size" type="range" min="0" max="100"  value="<?php echo (float)$this->fontValues["font-size"]; ?>">
               <input type="text" value=" <?php echo esc_html(trim($this->fontValues["font-size"])) ; ?> " class="google-fonts-size-style" /> 
             
               <div class="customize-control-line-height"><?php echo esc_html__("Select line height","newseqo"); ?> </div>
            
               <input class="range-slider custom_group_typhography_line_height" type="range" min="0" max="100"  value="<?php echo (float)$this->fontValues["line-height"]; ?>">
               <input type="text" value=" <?php echo esc_html(trim($this->fontValues["line-height"])); ?> " class="google-fonts-lineheight-style custom_font_line_height" /> 

               <div class="customize-control-letter-space"><?php echo esc_html__("Select letter spacing","newseqo"); ?></div>
               <input class="range-slider custom_group_typhography_letterspace" type="range" min="0" max="100"  value="<?php echo (float)$this->fontValues["letter-spacing"]; ?>">
				   <input type="text" value="<?php echo esc_html(trim( $this->fontValues["letter-spacing"]) ); ?>" class="google-fonts-letterspace" /> 

               <div class="customize-control-transform"><?php echo esc_html__("Select transform","newseqo"); ?></div>
				   <select class="google-fonts-trasnform">  
                  <option <?php echo selected( $this->fontValues["trasnform"], "lowercase", false ); ?> value="lowercase"> <?php echo esc_html__("lowercase","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["trasnform"], "uppercase", false ); ?> value="uppercase"> <?php echo esc_html__("uppercase","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["trasnform"], "capitalize", false ); ?> value="capitalize"> <?php echo esc_html__("capitalize","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["trasnform"], "none", false ); ?> value="none"> <?php echo esc_html__("none","newseqo"); ?> </option> 
              </select>  
              <div class="customize-control-decoration"><?php echo esc_html__("Select decoration","newseqo"); ?> </div>
              <select class="google-fonts-decoration">  
                  <option <?php echo selected( $this->fontValues["text-decoration"], "underline", false ); ?> value="underline"> <?php echo esc_html__("underline","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["text-decoration"], "overline", false ); ?> value="overline"> <?php echo esc_html__("overline","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["text-decoration"], "line-through", false ); ?> value="line-through"> <?php echo esc_html__("line-through","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["text-decoration"], "blink", false ); ?> value="blink"> <?php echo esc_html__("blink","newseqo"); ?> </option> 
                  <option <?php echo selected( $this->fontValues["text-decoration"], "none", false ); ?> value="none"> <?php echo esc_html__("none","newseqo"); ?> </option> 
              </select>  
				</div>
				<?php
			}
		}
		/**
		 * Find the index of the saved font in our multidimensional array of Google Fonts
		 */
		public function newseqo_getFontIndex( $haystack, $needle ) {
			if(!is_array($haystack)){
            return false;
			}
		  try{
				foreach( $haystack as $key => $value ) {
					if( $value->family == $needle ) {
						return $key;
					}
				}  
		  } catch(\Exception $e) {
			return false;
		}
		return false;  
				
			
		}
		/**
		 * Return the list of Google Fonts from our json file. Unless otherwise specfied, list will be limited to 30 fonts.
		 */
		public function customizer_getGoogleFonts( $count = 30 ) {
         $transient = "_newseqo_customizer_google_fonts";
         $key = 'AIzaSyAP_KwRh1HX7tNAbLDSGhZ8K4tfu4MW4kA';
         if(get_transient($transient)==false){
            $google_api= 'https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key='.$key.'';
			   
            $request = wp_remote_get( newseqo_get_tw_resource_url().'/inc/customizer/class/google-fonts-popularity.json' );
           
            if( is_wp_error( $request ) ) {
               return "";
            }
            $body = wp_remote_retrieve_body( $request );
            $content = json_decode( $body );
            
            set_transient( $transient, $content, 86000 );
         }else{
             $content =get_transient($transient); 
         }
		 
			if( $count == 'all' ) {
				return $content->items;
			} else {
				return array_slice( $content->items, 0, $count );
			}
		}
   }
   
   class Newseqo_Repeater_Control extends WP_Customize_Control {

      public $id;
      private $boxtitle = array();
      private $add_field_label = array();
      private $customizer_icon_container = '';
      private $allowed_html = array();
      public $customizer_repeater_image_control = false;
      public $customizer_repeater_icon_control = false;
      public $customizer_repeater_color_control = false;
      public $customizer_repeater_color2_control = false;
      public $customizer_repeater_title_control = false;
      public $customizer_repeater_subtitle_control = false;
      public $customizer_repeater_text_control = false;
      public $customizer_repeater_link_control = false;
      public $customizer_repeater_text2_control = false;
      public $customizer_repeater_link2_control = false;
      public $customizer_repeater_shortcode_control = false;
      public $customizer_repeater_repeater_control = false;
   
   
   
      /*Class constructor*/
      public function __construct( $manager, $id, $args = array() ) {
         parent::__construct( $manager, $id, $args );
         /*Get options from customizer.php*/
         $this->add_field_label = esc_html__( 'Add new field', 'newseqo' );
         if ( ! empty( $args['add_field_label'] ) ) {
            $this->add_field_label = $args['add_field_label'];
         }
   
         $this->boxtitle = esc_html__( 'Customizer Repeater', 'newseqo' );
         if ( ! empty ( $args['item_name'] ) ) {
            $this->boxtitle = $args['item_name'];
         } elseif ( ! empty( $this->label ) ) {
            $this->boxtitle = $this->label;
         }
   
         if ( ! empty( $args['customizer_repeater_image_control'] ) ) {
            $this->customizer_repeater_image_control = $args['customizer_repeater_image_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_icon_control'] ) ) {
            $this->customizer_repeater_icon_control = $args['customizer_repeater_icon_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_color_control'] ) ) {
            $this->customizer_repeater_color_control = $args['customizer_repeater_color_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_color2_control'] ) ) {
            $this->customizer_repeater_color2_control = $args['customizer_repeater_color2_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_title_control'] ) ) {
            $this->customizer_repeater_title_control = $args['customizer_repeater_title_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_subtitle_control'] ) ) {
            $this->customizer_repeater_subtitle_control = $args['customizer_repeater_subtitle_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_text_control'] ) ) {
            $this->customizer_repeater_text_control = $args['customizer_repeater_text_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_link_control'] ) ) {
            $this->customizer_repeater_link_control = $args['customizer_repeater_link_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_text2_control'] ) ) {
            $this->customizer_repeater_text2_control = $args['customizer_repeater_text2_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_link2_control'] ) ) {
            $this->customizer_repeater_link2_control = $args['customizer_repeater_link2_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_shortcode_control'] ) ) {
            $this->customizer_repeater_shortcode_control = $args['customizer_repeater_shortcode_control'];
         }
   
         if ( ! empty( $args['customizer_repeater_repeater_control'] ) ) {
            $this->customizer_repeater_repeater_control = $args['customizer_repeater_repeater_control'];
         }
   
         if ( ! empty( $id ) ) {
            $this->id = $id;
         }
   
         if ( file_exists( apply_filters("newseqo_customizer_get_template_directory",get_template_directory() . '/core').'/customizer/inc/icons.php' ) ) {
            $this->customizer_icon_container =  apply_filters("newseqo_customizer_get_template_directory_abs_path", '/core').'/customizer/inc/icons';
         }
   
         $allowed_array1 = wp_kses_allowed_html( 'post' );
         $allowed_array2 = array(
            'input' => array(
               'type'        => array(),
               'class'       => array(),
               'placeholder' => array()
            )
         );
   
         $this->allowed_html = array_merge( $allowed_array1, $allowed_array2 );
      }
   
      /*Enqueue resources for the control*/
      public function enqueue() {
         wp_enqueue_style( 'font-awesome', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/css/font-awesome.min.css', array(), NEWSEQO_CUSTOMIZER_VERSION );
   
         wp_enqueue_style( 'newseqo_customizer-repeater-admin-stylesheet', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/css/admin-style.css', array(), NEWSEQO_CUSTOMIZER_VERSION );
   
         wp_enqueue_style( 'wp-color-picker' );
   
         wp_enqueue_script( 'newseqo_customizer-repeater-script', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/js/customizer_repeater.js', array('jquery', 'jquery-ui-draggable', 'wp-color-picker' ), NEWSEQO_CUSTOMIZER_VERSION, true  );
   
         wp_enqueue_script( 'newseqo_customizer-repeater-fontawesome-iconpicker', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/js/fontawesome-iconpicker.min.js', array( 'jquery' ), NEWSEQO_CUSTOMIZER_VERSION, true );
   
         wp_enqueue_style( 'newseqo_customizer-repeater-fontawesome-iconpicker-script', apply_filters("newseqo_customizer_get_template_directory_uri",  get_template_directory_uri().'/core').'/customizer/css/fontawesome-iconpicker.min.css', array(), NEWSEQO_CUSTOMIZER_VERSION );
      }
   
      public function render_content() {
   
         /*Get default options*/
         $this_default = json_decode( $this->setting->default );
   
         /*Get values (json format)*/
         $values = $this->value();
   
         /*Decode values*/
         $json = json_decode( $values );
   
         if ( ! is_array( $json ) ) {
            $json = array( $values );
         } ?>
   
           <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
           <div class="customizer-repeater-general-control-repeater customizer-repeater-general-control-droppable">
            <?php
            if ( ( count( $json ) == 1 && '' === $json[0] ) || empty( $json ) ) {
               if ( ! empty( $this_default ) ) {
                  $this->iterate_array( $this_default ); ?>
                       <input type="hidden"
                              id="customizer-repeater-<?php echo esc_attr( $this->id ); ?>-colector" <?php esc_attr( $this->link() ); ?>
                              class="customizer-repeater-colector"
                              value="<?php echo esc_textarea( json_encode( $this_default ) ); ?>"/>
                  <?php
               } else {
                  $this->iterate_array(); ?>
                       <input type="hidden"
                              id="customizer-repeater-<?php echo esc_attr( $this->id ); ?>-colector" <?php esc_attr( $this->link() ); ?>
                              class="customizer-repeater-colector"/>
                  <?php
               }
            } else {
               $this->iterate_array( $json ); ?>
                   <input type="hidden" id="customizer-repeater-<?php echo esc_attr( $this->id ); ?>-colector" <?php esc_attr( $this->link() ); ?>
                          class="customizer-repeater-colector" value="<?php echo esc_textarea( $this->value() ); ?>"/>
               <?php
            } ?>
           </div>
           <button type="button" class="button add_field customizer-repeater-new-field">
            <?php echo esc_html( $this->add_field_label ); ?>
           </button>
         <?php
      }
   
      private function iterate_array($array = array()){
         /*Counter that helps checking if the box is first and should have the delete button disabled*/
         $it = 0;
         if(!empty($array)){
            foreach($array as $titlekey=>$icon){ ?>
                   <div class="customizer-repeater-general-control-repeater-container customizer-repeater-draggable">
                       <div class="customizer-repeater-customize-control-title">
                           <?php
                               echo esc_html( $this->boxtitle." ".++$titlekey); 
                           ?>
                       </div>
                       <div class="customizer-repeater-box-content-hidden">
                     <?php
                     $choice = $image_url = $icon_value = $title = $subtitle = $text = $text2  = $link2 = $link = $shortcode = $repeater = $color = $color2 = '';
                     if(!empty($icon->id)){
                        $id = $icon->id;
                     }
                     if(!empty($icon->choice)){
                        $choice = $icon->choice;
                     }
                     if(!empty($icon->image_url)){
                        $image_url = $icon->image_url;
                     }
                     if(!empty($icon->icon_value)){
                        $icon_value = $icon->icon_value;
                     }
                     if(!empty($icon->color)){
                        $color = $icon->color;
                     }
                     if(!empty($icon->color2)){
                        $color2 = $icon->color2;
                     }
                     if(!empty($icon->title)){
                        $title = $icon->title;
                     }
                     if(!empty($icon->subtitle)){
                        $subtitle =  $icon->subtitle;
                     }
                     if(!empty($icon->text)){
                        $text = $icon->text;
                     }
                     if(!empty($icon->link)){
                        $link = $icon->link;
                     }
                     if(!empty($icon->text2)){
                        $text2 = $icon->text2;
                     }
                     if(!empty($icon->link2)){
                        $link2 = $icon->link2;
                     }
                     if(!empty($icon->shortcode)){
                        $shortcode = $icon->shortcode;
                     }
   
                     if(!empty($icon->social_repeater)){
                        $repeater = $icon->social_repeater;
                     }
   
                     if($this->customizer_repeater_image_control == true && $this->customizer_repeater_icon_control == true) {
                        $this->icon_type_choice( $choice );
                     }
                     if($this->customizer_repeater_image_control == true){
                        $this->image_control($image_url, $choice);
                     }
                     if($this->customizer_repeater_icon_control == true){
                        $this->icon_picker_control($icon_value, $choice);
                     }
                     if($this->customizer_repeater_color_control == true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Color','newseqo' ), $this->id, 'customizer_repeater_color_control' ),
                           'class' => 'customizer-repeater-color-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'color', $this->id, 'customizer_repeater_color_control' ),
                           'sanitize_callback' => 'sanitize_hex_color',
                           'choice' => $choice,
                        ), $color);
                     }
                     if($this->customizer_repeater_color2_control == true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Color','newseqo' ), $this->id, 'customizer_repeater_color2_control' ),
                           'class' => 'customizer-repeater-color2-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'color', $this->id, 'customizer_repeater_color2_control' ),
                           'sanitize_callback' => 'sanitize_hex_color'
                        ), $color2);
                     }
                     if($this->customizer_repeater_title_control==true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Title','newseqo' ), $this->id, 'customizer_repeater_title_control' ),
                           'class' => 'customizer-repeater-title-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_title_control' ),
                        ), $title);
                     }
                     if($this->customizer_repeater_subtitle_control==true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Subtitle','newseqo' ), $this->id, 'customizer_repeater_subtitle_control' ),
                           'class' => 'customizer-repeater-subtitle-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_subtitle_control' ),
                        ), $subtitle);
                     }
                     if($this->customizer_repeater_text_control==true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Text','newseqo' ), $this->id, 'customizer_repeater_text_control' ),
                           'class' => 'customizer-repeater-text-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'textarea', $this->id, 'customizer_repeater_text_control' ),
                        ), $text);
                     }
                     if($this->customizer_repeater_link_control){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Link','newseqo' ), $this->id, 'customizer_repeater_link_control' ),
                           'class' => 'customizer-repeater-link-control',
                           'sanitize_callback' => 'esc_url_raw',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_link_control' ),
                        ), $link);
                     }
                     if($this->customizer_repeater_text2_control==true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Text','newseqo' ), $this->id, 'customizer_repeater_text2_control' ),
                           'class' => 'customizer-repeater-text2-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'textarea', $this->id, 'customizer_repeater_text2_control' ),
                        ), $text2);
                     }
                     if($this->customizer_repeater_link2_control){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Link','newseqo' ), $this->id, 'customizer_repeater_link2_control' ),
                           'class' => 'customizer-repeater-link2-control',
                           'sanitize_callback' => 'esc_url_raw',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_link2_control' ),
                        ), $link2);
                     }
                     if($this->customizer_repeater_shortcode_control==true){
                        $this->input_control(array(
                           'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Shortcode','newseqo' ), $this->id, 'customizer_repeater_shortcode_control' ),
                           'class' => 'customizer-repeater-shortcode-control',
                           'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_shortcode_control' ),
                        ), $shortcode);
                     }
                     if($this->customizer_repeater_repeater_control==true){
                        $this->repeater_control($repeater);
                     } ?>
   
                           <input type="hidden" class="social-repeater-box-id" value="<?php if ( ! empty( $id ) ) {
                        echo esc_attr( $id );
                     } ?>">
                           <button type="button" class="social-repeater-general-control-remove-field" <?php if ( $it == 0 ) {
                        echo 'style="display:none;"';
                     } ?>>
                        <?php esc_html_e( 'Delete field', 'newseqo' ); ?>
                           </button>
   
                       </div>
                   </div>
   
               <?php
               $it++;
            }
         } else { ?>
               <div class="customizer-repeater-general-control-repeater-container">
                   <div class="customizer-repeater-customize-control-title">
                  <?php echo esc_html( $this->boxtitle ) ?>
                   </div>
                   <div class="customizer-repeater-box-content-hidden">
                  <?php
                  if ( $this->customizer_repeater_image_control == true && $this->customizer_repeater_icon_control == true ) {
                     $this->icon_type_choice();
                  }
                  if ( $this->customizer_repeater_image_control == true ) {
                     $this->image_control();
                  }
                  if ( $this->customizer_repeater_icon_control == true ) {
                     $this->icon_picker_control();
                  }
                  if($this->customizer_repeater_color_control==true){
                     $this->input_control(array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Color','newseqo' ), $this->id, 'customizer_repeater_color_control' ),
                        'class' => 'customizer-repeater-color-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'color', $this->id, 'customizer_repeater_color_control' ),
                        'sanitize_callback' => 'sanitize_hex_color'
                     ) );
                  }
                  if($this->customizer_repeater_color2_control==true){
                     $this->input_control(array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Color','newseqo' ), $this->id, 'customizer_repeater_color2_control' ),
                        'class' => 'customizer-repeater-color2-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'color', $this->id, 'customizer_repeater_color2_control' ),
                        'sanitize_callback' => 'sanitize_hex_color'
                     ) );
                  }
                  if ( $this->customizer_repeater_title_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Title','newseqo' ), $this->id, 'customizer_repeater_title_control' ),
                        'class' => 'customizer-repeater-title-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_title_control' ),
                     ) );
                  }
                  if ( $this->customizer_repeater_subtitle_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Subtitle','newseqo' ), $this->id, 'customizer_repeater_subtitle_control' ),
                        'class' => 'customizer-repeater-subtitle-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_subtitle_control' ),
                     ) );
                  }
                  if ( $this->customizer_repeater_text_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Text','newseqo' ), $this->id, 'customizer_repeater_text_control' ),
                        'class' => 'customizer-repeater-text-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'textarea', $this->id, 'customizer_repeater_text_control' ),
                     ) );
                  }
                  if ( $this->customizer_repeater_link_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Link','newseqo' ), $this->id, 'customizer_repeater_link_control' ),
                        'class' => 'customizer-repeater-link-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_link_control' ),
                     ) );
                  }
                  if ( $this->customizer_repeater_text2_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Text','newseqo' ), $this->id, 'customizer_repeater_text2_control' ),
                        'class' => 'customizer-repeater-text2-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', 'textarea', $this->id, 'customizer_repeater_text2_control' ),
                     ) );
                  }
                  if ( $this->customizer_repeater_link2_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Link','newseqo' ), $this->id, 'customizer_repeater_link2_control' ),
                        'class' => 'customizer-repeater-link2-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_link2_control' ),
                     ) );
                  }
                  if ( $this->customizer_repeater_shortcode_control == true ) {
                     $this->input_control( array(
                        'label' => apply_filters('newseqo_repeater_input_labels_filter', esc_html__( 'Shortcode','newseqo' ), $this->id, 'customizer_repeater_shortcode_control' ),
                        'class' => 'customizer-repeater-shortcode-control',
                        'type'  => apply_filters('newseqo_customizer_repeater_input_types_filter', '', $this->id, 'customizer_repeater_shortcode_control' ),
                     ) );
                  }
                  if($this->customizer_repeater_repeater_control==true){
                     $this->repeater_control();
                  } ?>
                       <input type="hidden" class="social-repeater-box-id">
                       <button type="button" class="social-repeater-general-control-remove-field button" style="display:none;">
                     <?php esc_html_e( 'Delete field', 'newseqo' ); ?>
                       </button>
                   </div>
               </div>
            <?php
         }
      }
   
      private function input_control( $options, $value='' ){ ?>
   
         <?php
         if( !empty($options['type']) ){
            switch ($options['type']) {
               case 'textarea':?>
                       <span class="customize-control-title"><?php echo esc_html( $options['label'] ); ?></span>
                       <textarea class="<?php echo esc_attr( $options['class'] ); ?>" placeholder="<?php echo esc_attr( $options['label'] ); ?>"><?php echo ( !empty($options['sanitize_callback']) ?  esc_attr(call_user_func_array( $options['sanitize_callback'], array( $value ) )) : esc_attr($value) ); ?></textarea>
                  <?php
                  break;
               case 'color':
                  $style_to_add = '';
                  if( $options['choice'] !== 'customizer_repeater_icon' ){
                     $style_to_add = 'display:none';
                  }?>
                       <span class="customize-control-title" <?php if( !empty( $style_to_add ) ) { echo 'style="'.esc_attr( $style_to_add ).'"';} ?>><?php echo esc_html( $options['label'] ); ?></span>
                       <div class="<?php echo esc_attr($options['class']); ?>" <?php if( !empty( $style_to_add ) ) { echo 'style="'.esc_attr( $style_to_add ).'"';} ?>>
                           <input type="text" value="<?php echo ( !empty($options['sanitize_callback']) ?  esc_attr(call_user_func_array( $options['sanitize_callback'], array( $value ) )) : esc_attr($value) ); ?>" class="<?php echo esc_attr($options['class']); ?>" />
                       </div>
                  <?php
                  break;
            }
         } else { ?>
               <span class="customize-control-title"><?php echo esc_html( $options['label'] ); ?></span>
               <input type="text" value="<?php echo ( !empty($options['sanitize_callback']) ?  esc_attr(call_user_func_array( $options['sanitize_callback'], array( $value ) )) : esc_attr($value) ); ?>" class="<?php echo esc_attr($options['class']); ?>" placeholder="<?php echo esc_attr( $options['label'] ); ?>"/>
            <?php
         }
      }
   
      private function icon_picker_control($value = '', $show = ''){
         ?>
           <div class="social-repeater-general-control-icon" <?php if( $show === 'customizer_repeater_image' || $show === 'customizer_repeater_none' ) { echo 'style="display:none;"'; } ?>>
               <span class="customize-control-title">
                   <?php esc_html_e('Icon','newseqo'); ?>
               </span>
            
               <div class="input-group icp-container">
                   <input data-placement="bottomRight" class="icp icp-auto" value="<?php if(!empty($value)) { echo esc_attr( $value );} ?>" type="text">
                   <span class="input-group-addon">
                       <i class="fa <?php echo esc_attr($value); ?>"></i>
                   </span>
               </div>
            <?php get_template_part( $this->customizer_icon_container ); 
               
            ?>
           </div>
         <?php
      }
   
      private function image_control($value = '', $show = ''){ ?>
           <div class="customizer-repeater-image-control" <?php if( $show === 'customizer_repeater_icon' || $show === 'customizer_repeater_none' || empty( $show ) ) { echo 'style="display:none;"'; } ?>>
               <span class="customize-control-title">
                   <?php esc_html_e('Image','newseqo')?>
               </span>
               <input type="text" class="widefat custom-media-url" value="<?php echo esc_attr( $value ); ?>">
               <input type="button" class="button button-secondary customizer-repeater-custom-media-button" value="<?php esc_attr_e( 'Upload Image','newseqo' ); ?>" />
           </div>
         <?php
      }
   
      private function icon_type_choice($value='customizer_repeater_icon'){ ?>
           <span class="customize-control-title">
               <?php esc_html_e('Image type','newseqo');?>
           </span>
           <select class="customizer-repeater-image-choice">
               <option value="customizer_repeater_icon" <?php selected($value,'customizer_repeater_icon');?>><?php esc_html_e('Icon','newseqo'); ?></option>
               <option value="customizer_repeater_image" <?php selected($value,'customizer_repeater_image');?>><?php esc_html_e('Image','newseqo'); ?></option>
               <option value="customizer_repeater_none" <?php selected($value,'customizer_repeater_none');?>><?php esc_html_e('None','newseqo'); ?></option>
           </select>
         <?php
      }
   
      private function repeater_control($value = ''){
         $social_repeater = array();
         $show_del        = 0; ?>
           <span class="customize-control-title"><?php esc_html_e( 'Social icons', 'newseqo' ); ?></span>
         <?php
      
         if(!empty($value)) {
            $social_repeater = json_decode( html_entity_decode( $value ), true );
         }
         if ( ( count( $social_repeater ) == 1 && '' === $social_repeater[0] ) || empty( $social_repeater ) ) { ?>
               <div class="customizer-repeater-social-repeater">
                   <div class="customizer-repeater-social-repeater-container">
                       <div class="customizer-repeater-rc input-group icp-container">
                           <input data-placement="bottomRight" class="icp icp-auto" value="<?php if(!empty($value)) { echo esc_attr( $value ); } ?>" type="text">
                           <span class="input-group-addon"></span>
                       </div>
                  <?php get_template_part( $this->customizer_icon_container ); ?>
                       <input type="text" class="customizer-repeater-social-repeater-link"
                              placeholder="<?php esc_attr_e( 'Link', 'newseqo' ); ?>">
                       <input type="hidden" class="customizer-repeater-social-repeater-id" value="">
                       <button class="social-repeater-remove-social-item" style="display:none">
                     <?php esc_html_e( 'Remove Icon', 'newseqo' ); ?>
                       </button>
                   </div>
                   <input type="hidden" id="social-repeater-socials-repeater-colector" class="social-repeater-socials-repeater-colector" value=""/>
               </div>
               <button class="social-repeater-add-social-item button-secondary"><?php esc_html_e( 'Add Icon', 'newseqo' ); ?></button>
            <?php
         } else { ?>
               <div class="customizer-repeater-social-repeater">
               <?php
               foreach ( $social_repeater as $social_icon ) {
                  $show_del ++; ?>
                       <div class="customizer-repeater-social-repeater-container">
                           <div class="customizer-repeater-rc input-group icp-container">
                               <input data-placement="bottomRight" class="icp icp-auto" value="<?php if( !empty($social_icon['icon']) ) { echo esc_attr( $social_icon['icon'] ); } ?>" type="text">
                               <span class="input-group-addon"><i class="fa <?php echo esc_attr( $social_icon['icon'] ); ?>"></i></span>
                           </div>
                     <?php get_template_part( $this->customizer_icon_container ); ?>
                           <input type="text" class="customizer-repeater-social-repeater-link"
                                  placeholder="<?php esc_attr_e( 'Link', 'newseqo' ); ?>"
                                  value="<?php if ( ! empty( $social_icon['link'] ) ) {
                               echo esc_url( $social_icon['link'] );
                            } ?>">
                           <input type="hidden" class="customizer-repeater-social-repeater-id"
                                  value="<?php if ( ! empty( $social_icon['id'] ) ) {
                               echo esc_attr( $social_icon['id'] );
                            } ?>">
                           <button class="social-repeater-remove-social-item"
                                   style="<?php if ( $show_del == 1 ) {
                                echo "display:none";
                             } ?>"><?php esc_html_e( 'Remove Icon', 'newseqo' ); ?></button>
                       </div>
                  <?php
               } ?>
                   <input type="hidden" id="social-repeater-socials-repeater-colector"
                          class="social-repeater-socials-repeater-colector"
                          value="<?php echo esc_textarea( html_entity_decode( $value ) ); ?>" />
               </div>
               <button class="social-repeater-add-social-item button-secondary"><?php esc_html_e( 'Add Icon', 'newseqo' ); ?></button>
            <?php
         }
      }
   }
   

endif;