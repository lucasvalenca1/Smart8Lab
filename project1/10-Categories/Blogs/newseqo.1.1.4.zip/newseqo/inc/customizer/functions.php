<?php
define( 'NEWSEQO_CUSTOMIZER_VERSION', '1.0' );
require apply_filters("newseqo_customizer_get_template_directory",get_template_directory() . '/inc').'/customizer/class/controls.php';
require apply_filters("newseqo_customizer_get_template_directory",get_template_directory() . '/inc').'/customizer/class/xs_customizer.php';
// customizer framework preview js
function newseqo_customize_preview_js() {
	wp_enqueue_script( '_newseqo-customize-preview', apply_filters('newseqo_customizer_get_template_directory_uri',get_template_directory_uri() . '/inc') . '/customizer/js/customize-preview.js', array( 'customize-preview' ), '20181231', true );
}
add_action( 'customize_preview_init', 'newseqo_customize_preview_js' );

require apply_filters('newseqo_customizer_get_template_directory',get_template_directory() . '/inc').'/customizer/inc/customizer.php';

add_filter("newseqo_customizer_get_template_directory_abs_path",function($value){

	return '/inc';
});

add_filter("newseqo_customizer_get_template_directory",function(){
   return get_template_directory().'/inc';
});

add_filter("newseqo_customizer_get_template_directory_uri",function(){
   return get_template_directory_uri().'/inc';
});

// Include customizer all theme settings panel from here
newseqo_xs_customizer::addPanel([
   "id"=>"newseqo_general",
   "title"=> esc_html__(" General ","newseqo"),
   "description" => esc_html__("General options","newseqo"),
   "sections" => [
     
      [
         "id" =>  "newseqo_general_header_ad_section",
         "title" =>  esc_html__("Header Ad","newseqo"),
      ],

      [
         "id" =>  "newseqo_general_header_section",
         "title" =>  esc_html__("Header","newseqo"),
      ],

      [
         "id" =>  "newseqo_general_newsticket_section",
         "title" =>  esc_html__("News ticker","newseqo"),
      ],
      [
         "id" =>  "newseqo_general_breadcrumb_section",
         "title" =>  esc_html__("Breadcrumb","newseqo"),
      ],
    
      [
         "id" =>  "newseqo_general_footer_section",
         "title" =>  esc_html__("Footer","newseqo"),
     ],
     [
      "id" =>  "newseqo_general_style_section",
      "title" =>  esc_html__("Style","newseqo"),
     ],
    
   ]
]);

newseqo_xs_customizer::addPanel([
   "id"=>"newseqo_style",
   "title"=> esc_html__(" Style ","newseqo"),
   "description" => esc_html__("Style settings","newseqo"),
   "sections" => [
     [
         "id" =>  "newseqo_blog_style_color_section",
         "title" =>  esc_html__("Color","newseqo"),
     ],
     [
         "id" =>  "newseqo_blog_style_typhography_section",
         "title" =>  esc_html__("Typhography","newseqo"),
     ],
    
   ]
]);

newseqo_xs_customizer::addPanel([
   "id"=>"newseqo_banner",
   "title"=> esc_html__(" Banner ","newseqo"),
   "description" => esc_html__("Banner settings","newseqo"),
   "sections" => [
     [
         "id" =>  "newseqo_blog_banner_section",
         "title" =>  esc_html__("Blog","newseqo"),
     ],
     [
         "id" =>  "newseqo_page_banner_section",
         "title" =>  esc_html__("Page","newseqo"),
     ],
    
   ]
]);

newseqo_xs_customizer::addPanel([
   "id"=>"newseqo_blog",
   "title"=> esc_html__(" Blog ","newseqo"),
   "description" => esc_html__("Blog","newseqo"),
   "sections" => [
     [
         "id" =>  "newseqo_blog_section",
         "title" =>  esc_html__("Blog list","newseqo"),
     ],
     [
         "id" =>  "newseqo_single_blog_section",
         "title" =>  esc_html__("Single blog","newseqo"),
     ],

     [
         "id" =>  "newseqo_blog_category_section",
         "title" =>  esc_html__("Category and tag","newseqo"),
     ],
    
   ]
]);
