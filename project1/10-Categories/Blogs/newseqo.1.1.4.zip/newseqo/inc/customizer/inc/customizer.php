<?php


function newseqo_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'refresh';
   $wp_customize->remove_section( 'background_image' );  //Remove background image 
}
add_action( 'customize_register', 'newseqo_customize_register' );


function newseqo_customizer_repeater_register( $wp_customizer ) {
  
   newseqo_xs_customizer::build($wp_customizer);
   
   // Display site title and tagline checkbox
   $wp_customizer->add_setting( 'header_textcolor', array(
      'default'        => get_theme_support( 'custom-header', 'default-text-color' ),
   ) );

   $wp_customizer->add_control( 'display_header_text', array(
         'settings' => 'header_textcolor',
         'label'    => __( 'Display Site Title and Tagline', 'newseqo' ),
         'section'  => 'title_tagline',
         'type'     => 'checkbox',
         'priority' => 40,
   ) ); 

       //genaral
     $wp_customizer->add_setting( 'newseqo_blog_layout', array(
         'default'   => 'right',
         'transport' => 'refresh', //postMessage
         'type'=>'theme_mod',
         'sanitize_callback' => function($data){
            return esc_html($data);
         },
      ) );
   $wp_customizer->add_control( new Newseqo_Image_Radio_Button_Custom_Control( $wp_customizer, 'newseqo_blog_layout_clr',
         array(
            'label' => esc_html__( 'Blog layout', 'newseqo' ),
            'description' => esc_html__( ' Blog layout ', 'newseqo' ),
            'section' => 'newseqo_blog_section',
            'settings' => 'newseqo_blog_layout',
            'choices' => array(
               'left' => array(
                  'image' => NEWSEQO_IMG . '/admin/customizer/sidebar-left.png',
                  'name' => esc_html__( 'Left Sidebar', 'newseqo' )
               ),
               'full' => array(
                  'image' => NEWSEQO_IMG . '/admin/customizer/sidebar-none.png',
                  'name' => esc_html__( 'No Sidebar', 'newseqo' )
               ),
               'right' => array(
                  'image' => NEWSEQO_IMG . '/admin/customizer/sidebar-right.png',
                  'name' => esc_html__( 'Right Sidebar', 'newseqo' )
               )
            )
         )
      ) );
  
   $wp_customizer->add_setting( 'newseqo_blog_author', array(
      'default'   =>1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' ,
      'sanitize_callback' => function($data){
         return $data;
        },
      ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_author_clr', 
      array(
         'label'	=> esc_html__( 'Blog Author', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_author',
        
      ) 
   ));

   $wp_customizer->add_setting( 'newseqo_blog_comment', array(
      'default'   => 1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod',
      
   ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_comment_clr', 
      array(
         'label'	=> esc_html__( 'Blog Comment', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_comment',
        
      ) 
   ));

 

   $wp_customizer->add_setting( 'newseqo_blog_date', array(
      'default'   => 1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );


   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_date_clr', 
      array(
         'label'	=> esc_html__( 'Blog date', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_date',
        
      ) 
   ));

   $wp_customizer->add_setting( 'newseqo_blog_category', array(
      'default'   => 1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_category_clr', 
      array(
         'label'	=> esc_html__( 'Blog category', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_category',
       
      ) 
   ));
   
   $wp_customizer->add_setting( 'newseqo_blog_category_single', array(
      'default'   => 0,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_category_single', 
      array(
         'label'	=> esc_html__( 'Blog category single', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_category_single',
         'active_callback' => function () {
          
            if ( get_theme_mod( 'newseqo_blog_category' ) == 1 ) {
               return true;
            }
   
            return false;
         }
       
      ) 
   ));

  

   // title
   $wp_customizer->add_setting( 'newseqo_blog_listing_title_length', array(
      'default'   => 1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_listing_title_length', 
      array(
         'label'	=> esc_html__( 'Blog list title length', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_listing_title_length',
       
      ) 
   ));

   $wp_customizer->add_setting( 'newseqo_blog_post_title_char_limit_length', array(
      'default'   => 20,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );
  
   $wp_customizer->add_control(
      'newseqo_blog_post_title_char_limit_length', 
      array(
         'label'    => esc_html__( 'Post title Limit', 'newseqo' ),
         'section'  => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_post_title_char_limit_length',
         'type'     => 'number',
         'active_callback' => function () {
          
            if ( get_theme_mod( 'newseqo_blog_listing_title_length' ) == 1 ) {
               return true;
            }
   
            return false;
         }
         
      )
   );
   // end title



   $wp_customizer->add_setting( 'newseqo_blog_post_char_limit_length', array(
      'default'   => 30,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );
  
   $wp_customizer->add_control(
      'newseqo_blog_post_char_length_clr', 
      array(
         'label'    => esc_html__( 'Post Char Limit', 'newseqo' ),
         'section'  => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_post_char_limit_length',
         'type'     => 'number',
         'active_callback' => function () {
          
            if ( get_theme_mod( 'newseqo_blog_listing_desc_length' ) == 1 ) {
               return true;
            }
   
            return false;
         }
         
      )
   );
  
  
   $wp_customizer->add_setting( 'newseqo_blog_readmore', array(
      'default'   => 1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_readmore_clr', 
      array(
         'label'	=> esc_html__( 'Blog readmore', 'newseqo' ),
         'section' => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_readmore',
         
       
      ) 
   ));

   $wp_customizer->add_setting( 'newseqo_blog_readmore_text', array(
      'default'   => esc_html__( 'readmore', 'newseqo' ),
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod',
      'sanitize_callback' => function($data){
         return esc_html($data);
        },
   ) );

   $wp_customizer->add_control(
      'newseqo_blog_readmore_text_clr', 
      array(
         'label'    => esc_html__( 'Readmore text', 'newseqo' ),
         'section'  => 'newseqo_blog_section',
         'settings' => 'newseqo_blog_readmore_text',
         'type'     => 'text',
         'active_callback' => function () {
          
            if ( get_theme_mod( 'newseqo_blog_readmore' ) == 1 ) {
               return true;
            }
   
            return false;
         }
         
      )
   );

  

   $wp_customizer->add_setting( 'newseqo_blog_read_time', array(
      'default'   => 0,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod',
      'sanitize_callback' => function($data){
         return esc_html($data);
        },
   ) );

   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_read_time', 
      array(
         'label'	=> esc_html__( 'Blog read time', 'newseqo' ),
         'section' => 'newseqo_single_blog_section',
         'settings' => 'newseqo_blog_read_time',
       
      ) 
   ));

   // blog single page
   
   $wp_customizer->add_setting( 'newseqo_blog_single_layout', array(
      'default'   => 'right',
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod',
      'sanitize_callback' => function($data){
         return esc_html($data);
        },
   ) );

  $wp_customizer->add_control( new Newseqo_Image_Radio_Button_Custom_Control( $wp_customizer, 'newseqo_blog_single_layout',
      array(
         'label' => esc_html__( 'Blog single layout', 'newseqo' ),
         'description' => esc_html__( ' Blog single layout ', 'newseqo' ),
         'section' => 'newseqo_single_blog_section',
         'settings' => 'newseqo_blog_single_layout',
         'choices' => array(
            'left' => array(
               'image' => NEWSEQO_IMG . '/admin/customizer/sidebar-left.png',
               'name' => esc_html__( 'Left Sidebar', 'newseqo' )
            ),
            'full' => array(
               'image' => NEWSEQO_IMG . '/admin/customizer/sidebar-none.png',
               'name' => esc_html__( 'No Sidebar', 'newseqo' )
            ),
            'right' => array(
               'image' => NEWSEQO_IMG . '/admin/customizer/sidebar-right.png',
               'name' => esc_html__( 'Right Sidebar', 'newseqo' )
            )
         ),
      )
   ) );


   $wp_customizer->add_setting( 'newseqo_blog_post_comment_open', array(
   'default'   => 1,
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option

   ) );
 
   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
      $wp_customizer, 
      'newseqo_blog_post_comment_open_clr', 
      array(
         'label'	=> esc_html__( 'Single Post Comment', 'newseqo' ),
         'section' => 'newseqo_single_blog_section',
         'settings' => 'newseqo_blog_post_comment_open',
       
      ) 
   )); 

   $wp_customizer->add_setting( 'newseqo_blog_feature_image', array(
      'default'   => 1,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   
      ) );
    
      $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
         $wp_customizer, 
         'newseqo_blog_feature_image', 
         array(
            'label'	=> esc_html__( 'Post feature image', 'newseqo' ),
            'section' => 'newseqo_single_blog_section',
            'settings' => 'newseqo_blog_feature_image',
          
         ) 
   )); 

  
   $wp_customizer->add_setting( 'newseqo_blog_related_post', array(
      'default'   => 0,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option

      ) );

      
   $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
         $wp_customizer, 
         'newseqo_blog_related_post_clr', 
         array(
            'label'	=> esc_html__( 'Related Post', 'newseqo' ),
            'section' => 'newseqo_single_blog_section',
            'settings' => 'newseqo_blog_related_post',
          
         ) 
   )); 

 
      $wp_customizer->add_setting( 'newseqo_blog_post_author', array(
         'default'   => 1,
         'transport' => 'refresh', //postMessage
         'type'=>'theme_mod' //theme_mod or option
      
         ) );
       
         $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
            $wp_customizer, 
            'newseqo_blog_post_author_clr', 
            array(
               'label'	=> esc_html__( 'Author section', 'newseqo' ),
               'section' => 'newseqo_single_blog_section',
               'settings' => 'newseqo_blog_post_author',
             
            ) 
         )); 

      $wp_customizer->add_setting( 'newseqo_blog_post_tag', array(
            'default'   => 1,
            'transport' => 'refresh', //postMessage
            'type'=>'theme_mod' //theme_mod or option
         
            ) );
          
            $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
               $wp_customizer, 
               'newseqo_blog_post_tag', 
               array(
                  'label'	=> esc_html__( 'Tag section', 'newseqo' ),
                  'section' => 'newseqo_single_blog_section',
                  'settings' => 'newseqo_blog_post_tag',
                
               ) 
      )); 
      
      $wp_customizer->add_setting( 'newseqo_single_blog_post_nav', array(
         'default'   => 1,
         'transport' => 'refresh', //postMessage
         'type'=>'theme_mod' //theme_mod or option
      
         ) );
       
         $wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
            $wp_customizer, 
            'newseqo_single_blog_post_nav', 
            array(
               'label'	=> esc_html__( 'Display navigation', 'newseqo' ),
               'section' => 'newseqo_single_blog_section',
               'settings' => 'newseqo_single_blog_post_nav',
             
            ) 
      )); 

   // Category 
  

   $wp_customizer->add_setting( 'newseqo_categry_title_lenght', array(
      'default'   => 10,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );

   $wp_customizer->add_control(
      'newseqo_categry_title_lenght', 
      array(
         'label'    => esc_html__( ' Title lenght', 'newseqo' ),
         'section'  => 'newseqo_blog_category_section',
         'settings' => 'newseqo_categry_title_lenght',
         'type'     => 'number',
         
      )
   ); 
 
   $wp_customizer->add_setting( 'newseqo_categry_post_desc_lenght', array(
      'default'   => 30,
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );

   $wp_customizer->add_control(
      'newseqo_categry_post_desc_lenght', 
      array(
         'label'    => esc_html__( 'Post desc limit', 'newseqo' ),
         'section'  => 'newseqo_blog_category_section',
         'settings' => 'newseqo_categry_post_desc_lenght',
         'type'     => 'number',
         
      )
   ); 

    

  // footer 

 

$wp_customizer->add_setting('show_footer_widgets' , array(
   'default'   => 0,
   // 'transport' => 'postMessage',
   'type'=>'theme_mod' 
));

$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'show_footer_widgets',
   array(
      'label' => esc_html__('Show Footer Widgets','newseqo'),
      'description' => '',
      'section' => 'newseqo_general_footer_section',
   )
));

$wp_customizer->add_setting('newseqo_number_of_widgets' , array(
   'default'   => 4,
   // 'transport' => 'postMessage',
   'type'=>'theme_mod' 
));

$wp_customizer->add_control( new Newseqo_Range_Value_Control( $wp_customizer, 'newseqo_number_of_widgets',
   array(
      'label' => esc_html__('Number of widgets','newseqo'),
      'description' => '',
      'section' => 'newseqo_general_footer_section',
      'input_attrs' => array(
         'min' => 1, 
         'max' => 6,
         'step' => 1,
      ),
   )
));

$wp_customizer->add_setting( 'newseqo_footer_copyright_padding', array(
   'default'   => '20px',
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control(
   'newseqo_footer_copyright_padding_clr', 
   array(
      'label'    => esc_html__( 'Copyright padding', 'newseqo' ),
      'section'  => 'newseqo_general_footer_section',
      'settings' => 'newseqo_footer_copyright_padding',
      'type'     => 'text',
      
   )
);



$wp_customizer->add_setting('newseqo_footer_copyright_color', //give it an ID
      [ 
         'default' => '', 
         'transport' => 'refresh', 
         'type'=>'theme_mod',
           
      ]
);

$wp_customizer->add_control(
   'newseqo_footer_copyright_color_clr', 
   array(
      'label'    => esc_html__( 'Copyright color', 'newseqo' ),
      'section'  => 'newseqo_general_footer_section',
      'settings' => 'newseqo_footer_copyright_color',
      'type'     => 'color',
   
      
   )
);

   $wp_customizer->add_setting('newseqo_footer_copyright_bg_color', //give it an ID
   [ 
      'default' => '', 
      'transport' => 'refresh', 
      'type'=>'theme_mod',
      
   ]
);

$wp_customizer->add_control(
'newseqo_footer_copyright_bg_color_clr', 
array(
   'label'    => esc_html__( 'Copyright background color', 'newseqo' ),
   'section'  => 'newseqo_general_footer_section',
   'settings' => 'newseqo_footer_copyright_bg_color',
   'type'     => 'color',

   
)
);



$wp_customizer->add_setting('newseqo_copyright', array(
   'default'   => esc_html__('&copy; 2020, All Rights Reserved.','newseqo'),
   // 'transport' => 'postMessage',
   'type'=>'theme_mod' 
));

$wp_customizer->add_control( new Newseqo_TinyMCE_Custom_control( $wp_customizer, 'newseqo_copyright',
   array(
      'label' => esc_html__('Copyright','newseqo'),
      'section' => 'newseqo_general_footer_section',
   )
));

$wp_customizer->add_setting('newseqo_back_to_top' , array(
   'default'   => true,
   // 'transport' => 'postMessage',
   'type'=>'theme_mod' 
));

$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'newseqo_back_to_top',
   array(
      'label' =>  esc_html__('Back to top','newseqo'),
      'description' => '',
      'section' => 'newseqo_general_footer_section',
   )
));

 // banner setting 

 $wp_customizer->add_setting( 'newseqo_blog_banner_enable', array(
   'default'   => 1,
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
   $wp_customizer, 
   'newseqo_blog_banner_enable', 
      array(
         'label'	=> esc_html__( 'Blog banner', 'newseqo' ),
         'section' => 'newseqo_blog_banner_section',
         'settings' => 'newseqo_blog_banner_enable',
      
      ) 
   ));

  $wp_customizer->add_setting( 'newseqo_blog_banner_breadcrumb_enable', array(
   'default'   => 1,
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
   $wp_customizer, 
   'newseqo_blog_banner_breadcrumb_enable', 
   array(
      'label'	=> esc_html__( 'Blog breadcrumb', 'newseqo' ),
      'section' => 'newseqo_blog_banner_section',
      'settings' => 'newseqo_blog_banner_breadcrumb_enable',
    
   ) 
   ));

   $wp_customizer->add_setting( 'newseqo_blog_banner_img', array(
   'default'   => '',
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );


$wp_customizer->add_control( 
   new WP_Customize_Image_Control( 
   $wp_customizer, 
   'newseqo_blog_banner_img', 
   array(
      'label'      => esc_html__( 'Banner Image', 'newseqo' ),
      'section'    => 'newseqo_blog_banner_section',
      'settings'   => 'newseqo_blog_banner_img',
   ) ) 
);

$wp_customizer->add_setting( 'newseqo_blog_banner_title', array(
'default'   => '',
'transport' => 'refresh', //postMessage
'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control(
'newseqo_blog_banner_title', 
   array(
      'label'    => esc_html__( 'Title', 'newseqo' ),
      'section'  => 'newseqo_blog_banner_section',
      'settings' => 'newseqo_blog_banner_title',
      'type'     => 'text',
      
   )
);

//page 

$wp_customizer->add_setting( 'newseqo_page_banner_enable', array(
   'default'   => 1,
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
   $wp_customizer, 
   'newseqo_page_banner_enable', 
      array(
         'label'	=> esc_html__( 'Page banner', 'newseqo' ),
         'section' => 'newseqo_page_banner_section',
         'settings' => 'newseqo_page_banner_enable',
      
      ) 
   ));

  $wp_customizer->add_setting( 'newseqo_page_banner_breadcrumb_enable', array(
   'default'   => 1,
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( 
   $wp_customizer, 
   'newseqo_page_banner_breadcrumb_enable', 
   array(
      'label'	=> esc_html__( 'Breadcrumb', 'newseqo' ),
      'section' => 'newseqo_page_banner_section',
      'settings' => 'newseqo_page_banner_breadcrumb_enable',
    
   ) 
   ));

   $wp_customizer->add_setting( 'newseqo_page_banner_img', array(
   'default'   => '',
   'transport' => 'refresh', //postMessage
   'type'=>'theme_mod' //theme_mod or option
) );


$wp_customizer->add_control( 
   new WP_Customize_Image_Control( 
   $wp_customizer, 
   'newseqo_page_banner_img', 
   array(
      'label'      => esc_html__( 'Banner Image', 'newseqo' ),
      'section'    => 'newseqo_page_banner_section',
      'settings'   => 'newseqo_page_banner_img',
   ) ) 
);

$wp_customizer->add_setting( 'newseqo_page_banner_title', array(
'default'   => '',
'transport' => 'refresh', //postMessage
'type'=>'theme_mod' //theme_mod or option
) );

$wp_customizer->add_control(
'newseqo_page_banner_title', 
   array(
      'label'    => esc_html__( 'Title', 'newseqo' ),
      'section'  => 'newseqo_page_banner_section',
      'settings' => 'newseqo_page_banner_title',
      'type'     => 'text',
      
   )
);
   // banner setting end

   // news ticker
   $wp_customizer->add_setting('newseqo_newsticker_show' , array(
		'default'   => 0,
		// 'transport' => 'postMessage',
		'type'=>'theme_mod' 
	));

	$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'newseqo_newsticker_show',
		array(
			'label' => esc_html__('Show newsticker','newseqo'),
			'description' => ' Newsticker section ',
			'section' => 'newseqo_general_newsticket_section',
		)
   ));

   $wp_customizer->add_setting( 
      'newseqo_newsticker_title'
     
     
  );
    
   $wp_customizer->add_control( 
      'newseqo_newsticker_title', 
      array(
          'label' => esc_html__( 'News ticker title ', 'newseqo' ),
          'section' => 'newseqo_general_newsticket_section',
          'type' => 'text'
      )
   ); 
   $wp_customizer->add_setting( 
      'newseqo_newsticker_source',
      array(
         'default'   => 'latest',
         'type'=>'theme_mod',
         
      )
   ); 

   $wp_customizer->add_control(
      'newseqo_newsticker_source', 
      array(
         'label'    => __( 'Post Select by', 'newseqo' ),
         'section'  => 'newseqo_general_newsticket_section',
         'settings' => 'newseqo_newsticker_source',
         'type'     => 'select',
         'choices'  => array(
            'latest'  => 'Latest post',
            'sticky' => 'Sticky Post',
            'category' => 'Category',
         ),
      )
   );

   $wp_customizer->add_setting( 'newseqo_newsticker_source_category',
      array(
         'default' => '',
         'transport' => 'refresh',
      
      )
   );
   $wp_customizer->add_control( new Newseqo_Dropdown_Select2_Custom_Control( $wp_customizer, 'newseqo_newsticker_source_category',
      array(
         'label' => __( 'Blog Category', 'newseqo' ),
         'description' => esc_html__( 'Newsticker Blog category select', 'newseqo' ),
         'section' => 'newseqo_general_newsticket_section',
         'input_attrs' => array(
            'placeholder' => __( 'Please select a category...', 'newseqo' ),
            'multiselect' => true,
         ),
         'choices' => newseqo_get_post_category(),
         'active_callback' => function () {

            if ( get_theme_mod( 'newseqo_newsticker_source') == 'category' ) {
               return true;
            }
            
            return false;
         }
      )
   ) );

   $wp_customizer->add_setting( 
      'newseqo_newsticker_count',array(
         'default' => 5,
         'transport' => 'refresh',
         'sanitize_callback' => function($data){
            return esc_html($data);
           },
      )
     );
    
  $wp_customizer->add_control( 
      'newseqo_newsticker_count', 
      array(
          'label' => esc_html__( 'News ticker post number ', 'newseqo' ),
          'section' => 'newseqo_general_newsticket_section',
          'type' => 'number'
      )
  );      

   //ad
   
    $wp_customizer->add_setting('newseqo_ad_show' , array(
		'default'   => 0,
		// 'transport' => 'postMessage',
		'type'=>'theme_mod' 
	));

	$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'newseqo_ad_show',
		array(
			'label' => esc_html__('Show Ad','newseqo'),
			'description' => 'Ad section ',
			'section' => 'newseqo_general_header_ad_section',
		)
   ));

   $wp_customizer->add_setting( 'newseqo_ad_banner_img', array(
      'default'   => '',
      'transport' => 'refresh', //postMessage
      'type'=>'theme_mod' //theme_mod or option
   ) );


   $wp_customizer->add_control( 
      new WP_Customize_Image_Control( 
      $wp_customizer, 
      'newseqo_ad_banner_img', 
      array(
         'label'      => esc_html__( 'Ad Image', 'newseqo' ),
         'section'    => 'newseqo_general_header_ad_section',
         'settings'   => 'newseqo_ad_banner_img',
      ) ) 
   );

      $wp_customizer->add_setting( 
         'newseqo_ad_url',
         [
            'sanitize_callback' => 'newseqo_sanitize_ad_url',
         ]      
      );
      
   $wp_customizer->add_control( 
         'newseqo_ad_url', 
         array(
            'label' => esc_html__( 'Ad image url ', 'newseqo' ),
            'section' => 'newseqo_general_header_ad_section',
            'type' => 'url'
         )
   ); 



   $wp_customizer->add_setting('newseqo_header_social_show' , array(
		'default'   => 1,
		'type'=>'theme_mod' 
	));

	$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'newseqo_header_social_show',
		array(
			'label' => esc_html__('Show Social','newseqo'),
			'description' => '',
			'section' => 'newseqo_general_header_section',
		)
   ));

 
   $wp_customizer->add_setting( 'newseqo_social_icons', array(
		'sanitize_callback' => 'newseqo_customizer_repeater_sanitize'
	 ));
	 $wp_customizer->add_control( new Newseqo_Repeater_Control( $wp_customizer, 'newseqo_social_icons', 
		array(
		'label'   => esc_html__('Social Icon','newseqo'),
		'section' => 'newseqo_general_header_section',
		'customizer_repeater_image_control' => false,
		'customizer_repeater_icon_control' => true,
		'customizer_repeater_title_control' => false,
		'customizer_repeater_subtitle_control' => false,
		'customizer_repeater_text_control' => false,
		'customizer_repeater_text2_control' => false,
		'customizer_repeater_link_control' => true,
		'customizer_repeater_link2_control' => false,
		'customizer_repeater_shortcode_control' => false,
		'customizer_repeater_repeater_control' => false,
		'customizer_repeater_color_control' => false,
		'customizer_repeater_color2_control' => false,
		) 
	));


	$wp_customizer->add_setting('newseqo_search_show' , array(
		'default'   => 'no',
		'type'=>'theme_mod' 
	));

	$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'newseqo_search_show',
		array(
			'label' => esc_html__('Show Search','newseqo'),
			'description' => '',
			'section' => 'newseqo_general_header_section',
		)
   ));
   
   $wp_customizer->add_setting('newseqo_topbar_show' , array(
		'default'   => 0,
		// 'transport' => 'postMessage',
		'type'=>'theme_mod' 
	));

	$wp_customizer->add_control( new Newseqo_Toggle_Switch_Custom_control( $wp_customizer, 'newseqo_topbar_show',
		array(
			'label' => esc_html__('Show Topbar','newseqo'),
			'description' => '',
			'section' => 'newseqo_general_header_section',
		)
	));

  

   $wp_customizer->add_setting(
      'newseqo_general_header_button_url', //give it an ID
         [ 
            'default' => '', 
            'transport' => 'refresh', 
            'type'=>'theme_mod',
            'sanitize_callback' => function($url_link){
              
               if (filter_var($url_link, FILTER_VALIDATE_URL) === FALSE) {
                 return '';
              }
              return $url_link;
            }
           
         ]
   );

   $wp_customizer->add_control(
      'newseqo_general_header_button_url_clr', 
      array(
         'label'    => esc_html__( 'Button url', 'newseqo' ),
         'section'  => 'newseqo_general_header_section',
         'settings' => 'newseqo_general_header_button_url',
         'type'     => 'url',
         'active_callback' => function () {

            if ( get_theme_mod( 'newseqo_general_header_button_text') == '' ) {
               return false;
            }
            
            return true;
         }
         
      )
   );

   $wp_customizer->add_setting(
      'newseqo_general_header_button_bg_color', //give it an ID
         [ 
            'default' => '', 
            'transport' => 'refresh', 
            'type'=>'theme_mod',
            
           
         ]
   );

   $wp_customizer->add_control(
      'newseqo_general_header_button_bg_color_clr', 
      array(
         'label'    => esc_html__( 'Button background color', 'newseqo' ),
         'section'  => 'newseqo_general_header_section',
         'settings' => 'newseqo_general_header_button_bg_color',
         'type'     => 'color',
         'active_callback' => function () {

            if ( get_theme_mod( 'newseqo_general_header_button_text') =='' ) {
               return false;
            }
            
            return true;
         }
         
      )
   );

   // style 

   $wp_customizer->add_setting(
      'newseqo_blog_style_body_primary_color_section', //give it an ID
         [ 
            'default' => '', 
            'transport' => 'refresh', 
            'type'=>'theme_mod',
            
           
         ]
   );

   $wp_customizer->add_control(
      'newseqo_blog_style_body_primary_color_section', 
      array(
         'label'    => esc_html__( 'Primary color', 'newseqo' ),
         'section'  => 'newseqo_blog_style_color_section',
         'settings' => 'newseqo_blog_style_body_primary_color_section',
         'type'     => 'color',
          
      )
   );

   
   $wp_customizer->add_setting(
      'newseqo_blog_style_title_color_section', //give it an ID
         [ 
            'default' => '', 
            'transport' => 'refresh', 
            'type'=>'theme_mod',
            
           
         ]
   );

   $wp_customizer->add_control(
      'newseqo_blog_style_title_color_section', 
      array(
         'label'    => esc_html__( 'Title color', 'newseqo' ),
         'section'  => 'newseqo_blog_style_color_section',
         'settings' => 'newseqo_blog_style_title_color_section',
         'type'     => 'color',
         
      )
   );
   
   // typhograpy
   

   $wp_customizer->add_setting( 'newseqo_blog_body_typhography' );

   $wp_customizer->add_control( new Newseqo_Custom_Typography_Group_Control( $wp_customizer, 'newseqo_blog_body_typhography',
	array(
   
      'label' => __( 'Body Typhography','newseqo' ),
	   'section' => 'newseqo_blog_style_typhography_section',
	    )
     )
   );

   $wp_customizer->add_setting( 'newseqo_blog_h1_2_typhography' );

   $wp_customizer->add_control( new Newseqo_Custom_Typography_Group_Control( $wp_customizer, 'newseqo_blog_h1_2_typhography',
	array(
      'label' => __( 'H1 H2 Typhography' ,'newseqo'),
      'description' => ' This typhograpy aplicable for h1 h2 tag ',
	   'section' => 'newseqo_blog_style_typhography_section',
	    )
     )
   );

   $wp_customizer->add_setting( 'newseqo_blog_h3_4_typhography' );

   $wp_customizer->add_control( new Newseqo_Custom_Typography_Group_Control( $wp_customizer, 'newseqo_blog_h3_4_typhography',
	array(
      'label' => __( 'H3 H4 Typhography' ,'newseqo'),
      'description' => ' This typhograpy aplicable for h3 h4 tag ',
	   'section' => 'newseqo_blog_style_typhography_section',
	    )
     )
   );


 

    

}
add_action( 'customize_register', 'newseqo_customizer_repeater_register' );

function newseqo_customizer_repeater_sanitize($input){
	$input_decoded = json_decode($input,true);

	if(!empty($input_decoded)) {
		foreach ($input_decoded as $boxk => $box ){
			foreach ($box as $key => $value){
				$input_decoded[$boxk][$key] = wp_kses_post( $value );
			}
		}
		return json_encode($input_decoded);
	}
	return $input;
}