<?php 

   function newseqo_sanitize_ad_url( $url ) {
      return esc_url_raw( $url );
   }

   

   

