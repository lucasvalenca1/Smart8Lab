/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

(function( $ ) {

	// Primary color.


	// Body Typography.
	wp.customize( 'body_typhography', function( value ) {
		value.bind( function( to ) {
        
         $("body").css(JSON.parse(to));
			
		} );
   } );


	wp.customize( 'customizer_repeater_example', function( value ) {
		value.bind( function( to ) {
        var repeat = JSON.parse(to);
        $(".entry-header b").remove();
        $(".entry-header b").append("");
       
        $.each(repeat,function(k,v){
            
         $(".entry-header").append("<b>"+ ++k +" = " + v.title +"<br/></b>");
        })
      

			
		} );
   } );

	wp.customize( 'custom_gradient_asdasd', function( value ) {
		value.bind( function( to ) {
         var background = JSON.parse(to).background;
           if(background!=''){
              $.each(background,function(k,v){
               $("body").css({"background":v } );
              });
           }
        
			
		} );
   } );
   
   function addcss(css,id){
      var head = document.getElementsByTagName('head')[0];
      var s = document.createElement('style');
      s.setAttribute('type', 'text/css');
       s.setAttribute('id', id);
      if (s.styleSheet) {   // IE
          s.styleSheet.cssText = css;
      } else {               
          s.appendChild(document.createTextNode(css));
      }
   
      head.appendChild(s);
   }

   wp.customize.bind( 'preview-ready', function() {

      wp.customize.preview.bind( '_newseqo_control', function( message ) {
        
         wp.customize( message.id, function( value ) {
            value.bind( function( to ) {
                
               var responsive = JSON.parse(to);
               if ( responsive.hasOwnProperty("desktop") ) {
                 $(message.selector).css(JSON.parse(responsive.desktop) ) ;
                
               } 
                if( responsive.hasOwnProperty("tablet") ) {
                  
               } 
               if ( responsive.hasOwnProperty("mobile") ) {
                
               } else {
                  $(message.selector).css(JSON.parse(to) ) ;
               }
              
            
            } );
         } );


      } );
    } );

})( jQuery );
