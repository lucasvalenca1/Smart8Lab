<?php if (!defined('ABSPATH')) die('Direct access forbidden.');
/**
 * hooks for adding google fonts for frontend
 */

class Newseqo_Google_Fonts {

	static private $data = array(
		'subset' => array(),
		'family' => array(),
	);

	public static function add_typography_v2( $value ) {
      $value = (array) $value; 
      if(isset($value[ 'font-family' ]) && isset( $value[ 'font-weight' ] ) )
		self::$data[ 'family' ][ $value[ 'font-family' ] ][ 'variants' ][ (string) $value[ 'font-weight' ] ] = true;
		//self::$data[ 'subset' ][ 0 ] = true;
		
	}

	public static function clear() {
		self::$data = array();
	}

	public static function generate_url() {
		
		if ( empty( self::$data[ 'family' ] ) ) {
			return false;
		}

		$query = array(
			'family' => array(),
			'subset' => implode( ',', array_keys( self::$data[ 'subset' ] ) ),
		);

		foreach ( self::$data[ 'family' ] as $family => $family_data ) {
			if ( !empty( $family ) ) {
				$family_data[ 'variants' ][900] = $family_data[ 'variants' ][700] = $family_data[ 'variants' ][400] = 1;
				$query[ 'family' ][] = $family . ':' . implode( ',', array_keys( $family_data[ 'variants' ] ) );
			}
		}
		$query[ 'family' ] = implode( '|', $query[ 'family' ] );
		return add_query_arg( 'family', urlencode( $query[ 'family' ] ), "https://fonts.googleapis.com/css" );

	}

	public static function output_url() {
      if ( $url = self::generate_url() ):
         wp_enqueue_style( 'google-fonts', esc_url($url) );
         ?>
      
         <?php
		endif;
	}


	/*
  google font style transform function
*/
	public static function  newseqo_advanced_font_styles( $style ) {
		$style = (array) $style;

		$font_styles = '';

		$font_styles .= (isset( $style[ 'font-weight' ] ) && $style[ 'font-weight' ]) ? 'font-weight:' . esc_attr( $style[ 'font-weight' ] ) . ';' : '';
		$font_styles .= (isset( $style[ 'text-decoration' ] ) && $style[ 'text-decoration' ]) ? 'text-decoration:' . esc_attr( $style[ 'text-decoration' ] ) . ';' : 'initial';

		$font_styles .= isset( $style[ 'font-family' ] ) ? 'font-family:"' . $style[ 'font-family' ] . '";' : '';

		$font_styles .= isset( $style[ 'trasnform' ] ) && !empty( $style[ 'trasnform' ] ) ? 'text-transform:' . esc_attr( $style[ 'trasnform' ] ) . ';' : '';
		$font_styles .= isset( $style[ 'line-height' ] ) && !empty( $style[ 'line-height' ] ) ? 'line-height:' . esc_attr( $style[ 'line-height' ] ) . ';' : '';
		$font_styles .= isset( $style[ 'letter-spacing' ] ) && !empty( $style[ 'letter-spacing' ] ) ? 'letter-spacing:' . esc_attr( $style[ 'letter-spacing' ] ) . ';' : '';
		$font_styles .= isset( $style[ 'font-size' ] ) && !empty( $style[ 'font-size' ] ) ? 'font-size:' . esc_attr( $style[ 'font-size' ] ) . ';' : '';

		$font_styles .= !empty( $font_weight ) ? $font_weight : '';

		return !empty( $font_styles ) ? $font_styles : '';
	}


//Extra function for guntenberg block editor
	public static function newseqo_google_fonts_url($font_families	 = []) {
		$fonts_url		 = '';
		/*
        Translators: If there are characters in your language that are not supported
        by chosen font(s), translate this to 'off'. Do not translate into your own language.
        */
		if ( $font_families && 'off' !== _x( 'on', 'Google font: on or off', 'newseqo' ) ) {
			$query_args = array(
				'family' => urlencode( implode( '|', $font_families ) )
			);

			$fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
		}

		return esc_url_raw( $fonts_url );
	}


}
add_action( 'wp_enqueue_scripts', array( 'Newseqo_Google_Fonts', 'output_url' ), 999 );
