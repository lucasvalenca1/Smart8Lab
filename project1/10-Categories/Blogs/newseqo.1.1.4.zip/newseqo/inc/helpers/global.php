<?php 



// WP kses allowed tags
// ----------------------------------------------------------------------------------------
function newseqo_kses( $raw ) {
    $allowed_tags = array(
        'a' => array(
            'class' => array(),
            'href'  => array(),
            'rel'   => array(),
            'title' => array(),
        ),
        'option' => array(
            'value' => array(),

        ),
        'abbr' => array(
            'title' => array(),
        ),
        'b' => array(),
        'blockquote' => array(
            'cite'  => array(),
        ),
        'cite' => array(
            'title' => array(),
        ),
        'code' => array(),
        'del' => array(
            'datetime' => array(),
            'title' => array(),
        ),
        'dd' => array(),
        'div' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'dl' => array(),
        'dt' => array(),
        'em' => array(),
        'h1' => array(),
        'h2' => array(),
        'h3' => array(),
        'h4' => array(),
        'h5' => array(),
        'h6' => array(),
        'i' => array(),
        'img' => array(
            'alt'    => array(),
            'class'  => array(),
            'height' => array(),
            'src'    => array(),
            'width'  => array(),
        ),
        'li' => array(
            'class' => array(),
        ),
        'sup'=> array(
            'class' => array(),
        ),
        'ol' => array(
            'class' => array(),
        ),
        'p' => array(
            'class' => array(),
        ),
        'q' => array(
            'cite' => array(),
            'title' => array(),
        ),
        'span' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'i' => array(
            'class' => array(),
            'title' => array(),
            'style' => array(),
        ),
        'strike' => array(),
        'strong' => array(),
        'ul' => array(
            'class' => array(),
        ),
    );


	if ( function_exists( 'wp_kses' ) ) { // WP is here
		$allowed = wp_kses( $raw, $allowed_tags );
	} else {
		$allowed = $raw;
	}

	return $allowed;
}

function newseqo_get_crop_title( $title , $count = 10 ) { 
  
   if(get_theme_mod('newseqo_categry_title_lenght')) {
      $count = get_theme_mod('newseqo_categry_title_lenght');
   }

   return wp_trim_words($title,$count,'');
}
/*
Excerp limit function 
default 100
*/
function newseqo_get_excerpt($count = 100 ) {
 
   $count = newseqo_desc_limit($count);
  
   $newseqo_blog_read_more_text = get_theme_mod('newseqo_blog_readmore_text',esc_html__('readmore','newseqo'));
  
   $excerpt = get_the_excerpt();
   $excerpt = esc_html($excerpt);
   $words   = str_word_count($excerpt, 2);
   $pos     = array_keys($words);
   if(count($words)>$count){
      $excerpt = substr($excerpt, 0, $pos[$count]); 
   }
   $newseqo_blog_read_more = get_theme_mod('newseqo_blog_readmore');
   if($newseqo_blog_read_more){
      $excerpt = wp_kses_post($excerpt .'<a class="readmore-btn" href="'.esc_url(get_the_permalink()).'">'. $newseqo_blog_read_more_text. '<i class="icon icon-arrow-right"> </i> .</a>');
   }
  
   return $excerpt;
   }

   function newseqo_desc_limit($default){
      if(!is_single() && !is_page()) {
        
         if(get_theme_mod('newseqo_categry_post_desc_lenght') ){
            return get_theme_mod('newseqo_categry_post_desc_lenght');
         }else{
            return $default;
         }
      }else{
         return $default;
      }
   }

   // newseqo related post by tags
function newseqo_related_posts_by_tags( $post_id = '', $related_count = 4, $feature_image = false ) {
    
   try{
       if($post_id==''){
       $post_id = get_the_ID();
       }
       $tags      = wp_get_post_tags($post_id);
       $term_tags = wp_list_pluck($tags,'term_id');
       $args = array(
 
          'tag__in' => $term_tags,
          'post__not_in' => array($post_id),
          'posts_per_page'=>$related_count,
          'ignore_sticky_posts'=>1,
       );
       if($feature_image){
          $args["meta_query"] = array(
             array(
                'key' => '_thumbnail_id',
                'compare' => 'EXISTS'
             ),
          );
       }
 
       return new WP_Query($args);
 
    } catch(Exception $e) {
 
    return new WP_Query( [] ); 
 
   }
 
 }
    // newseqo feature post by sticky
function newseqo_related_posts_by_sticky(  ) {
    if(!is_category()){
      return new WP_Query( [] ); 
    }
   try{
      
       $term = get_queried_object();
       $args = [
      
            'post_type'           => 'post',
            'post__in'            => get_option( 'sticky_posts' ),
            'posts_per_page'      => 10,
            'ignore_sticky_posts' => 1,
            'tax_query' => array(
               array (
                  'taxonomy' => 'category',
                  'field' => 'slug',
                  'terms' => $term->slug,
               )
         ),

       ];
   
 
       return new WP_Query($args);
 
    } catch(Exception $e) {
 
    return new WP_Query( [] ); 
 
   }
 
 }

 function newseqo_src($key='',$default=''){
       
     if($key=='' || !get_theme_mod($key)){
        return $default;
     }

     return get_theme_mod($key);
 }
/*
 theme_mod alter function
 check json value
 */
 function newseqo_option($key='',$default=''){
       
   if($key=='' || !get_theme_mod($key)){
      return $default;
   }
   
   $option = get_theme_mod($key,$default);
   if(newseqo_isJson($option)){
     return json_decode($option);
   } 
   return $option;
}

function newseqo_isJson($string) {
   json_decode($string);
   return (json_last_error() == JSON_ERROR_NONE);
}
/*
Advertisement area function 
settings come from customizer
*/
function newseqo_ad($key='',$default=''){
  
   if(!get_theme_mod('newseqo_ad_show',false) || $key==''){
      return;
   }
   
   $img_link = get_theme_mod($key);
  
   if($default =='' && $img_link==''){
      return;
   }
   if(!$img_link){
     $img_link = NEWSEQO_IMG.$default;  
   }
   
   ?>  
 
      <a href="<?php echo esc_url(get_theme_mod('newseqo_ad_url')); ?>">
         <img class="img-fluid" src="<?php echo esc_url($img_link); ?>" alt="<?php echo esc_attr__('Newseqo ads', 'newseqo'); ?>">
      </a>

   <?php
	
}


