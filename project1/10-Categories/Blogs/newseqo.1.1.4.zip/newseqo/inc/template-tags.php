<?php

if ( ! function_exists( 'newseqo_post_thumbnail' ) ) :
	
	function newseqo_post_thumbnail() {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>

			<div class="post-thumbnail">
				<?php the_post_thumbnail(); ?>
			</div>

		<?php else : ?>

		<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php
			the_post_thumbnail( 'post-thumbnail', array(
				'alt' => the_title_attribute( array(
					'echo' => false,
				) ),
			) );
			?>
		</a>

		<?php
		endif; 
	}
endif;
if ( ! function_exists( 'newseqo_return' ) ) :

  function newseqo_return($arg){
 
   return $arg;
  }

endif;


function newseqo_get_breadcrumbs( $seperator = '/', $word = '' ) {
   $word = get_theme_mod('newseqo_breadcrumb_lenght',20);	
  
	echo '<ol class="breadcrumb" data-wow-duration="2s">';
	if ( !is_home() ) {
	
		echo sprintf('<li><a href=%s>',esc_url( get_home_url( '/' ) ));
		echo esc_html__( 'Home', 'newseqo' );
		echo "</a></li> " . esc_attr( $seperator );
		
		if ( is_category() || is_single() ) {
			echo '<li>';
			$category	 = get_the_category();
			$post		 = get_queried_object();
			$postType	 = get_post_type_object( get_post_type( $post ) );
			if ( !empty( $category ) ) {
				echo esc_html( $category[ 0 ]->cat_name ) . '</li>';
			} else if ( $postType ) {
				echo esc_html( $postType->labels->singular_name ) . '</li>';
			}

			if ( is_single() ) {
				echo esc_attr( $seperator ) . "  <li>";
				echo esc_html( $word ) != '' ? esc_html(wp_trim_words( get_the_title(), $word )) : esc_html(get_the_title());
				echo '</li>';
			}
		} elseif ( is_page() ) {
			echo '<li>';
			echo esc_html( $word ) != '' ? esc_html(wp_trim_words( get_the_title(), $word )) : esc_html(get_the_title());
			echo '</li>';
		}
	}
	if ( is_tag() ) {
		single_tag_title();
	} elseif ( is_day() ) {
		echo "<li>" . esc_html__( 'Blogs for', 'newseqo' ) . " ";
		   the_time( 'F jS, Y' );
		echo '</li>';
	} elseif ( is_month() ) {
		echo "<li>" . esc_html__( 'Blogs for', 'newseqo' ) . " ";
		  the_time( 'F, Y' );
		echo '</li>';
	} elseif ( is_year() ) {
		echo "<li>" . esc_html__( 'Blogs for', 'newseqo' ) . " ";
		the_time( 'Y' );
		echo '</li>';
	} elseif ( is_author() ) {
		echo "<li>" . esc_html__( 'Author Blogs', 'newseqo' );
		echo '</li>';
	} elseif ( isset( $_GET[ 'paged' ] ) && !empty( $_GET[ 'paged' ] ) ) {
		echo "<li>" . esc_html__( 'Blogs', 'newseqo' );
		echo'</li>';
	} elseif ( is_search() ) {
		echo "<li>" . esc_html__( 'Search Result', 'newseqo' );
		echo '</li>';
	} elseif ( is_404() ) {
		echo "<li>" . esc_html__( '404 Not Found', 'newseqo' );
		echo '</li>';
	}
	echo '</ol>';
}