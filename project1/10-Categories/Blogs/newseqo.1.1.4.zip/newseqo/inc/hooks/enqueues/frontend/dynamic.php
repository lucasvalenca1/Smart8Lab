<?php 

function newseqo_dynamic_style(){

   $newseqo_footer_copyright_bg_color = get_theme_mod('newseqo_footer_copyright_bg_color','#000');
   $newseqo_footer_copyright_padding  = get_theme_mod('newseqo_footer_copyright_padding','8px 0px');
   $newseqo_footer_copyright_color    = get_theme_mod('newseqo_footer_copyright_color','white');
   $newseqo_blog_body_typhography     = newseqo_option('newseqo_blog_body_typhography'); 
   $newseqo_blog_h1_2_typhography     = newseqo_option('newseqo_blog_h1_2_typhography'); 
   $newseqo_blog_h3_4_typhography     = newseqo_option('newseqo_blog_h3_4_typhography'); 
   
   Newseqo_Google_Fonts::add_typography_v2($newseqo_blog_body_typhography);
   $newseqo_blog_body_typhography =  Newseqo_Google_Fonts::newseqo_advanced_font_styles($newseqo_blog_body_typhography);
   Newseqo_Google_Fonts::add_typography_v2($newseqo_blog_h3_4_typhography);
   $newseqo_blog_h3_4_typhography =  Newseqo_Google_Fonts::newseqo_advanced_font_styles($newseqo_blog_h3_4_typhography);
   Newseqo_Google_Fonts::add_typography_v2($newseqo_blog_h1_2_typhography);
   $newseqo_blog_h1_2_typhography =  Newseqo_Google_Fonts::newseqo_advanced_font_styles($newseqo_blog_h1_2_typhography);

   $newseqo_blog_style_title_color               = get_theme_mod('newseqo_blog_style_title_color_section','#1c1c24');
   $newseqo_blog_style_body_bg_color_section     = get_theme_mod('newseqo_blog_style_body_bg_color_section','#fff'); 
   $newseqo_blog_style_body_primary_color_section     = get_theme_mod('newseqo_blog_style_body_primary_color_section','#eb1c23'); 
   $newseqo_header_textcolor = get_header_textcolor();
   $header_image 				= esc_url(get_header_image());

   $custom_css="";

   if(!empty($header_image)){
      $custom_css .= ".header-middle-area {background-image:url(" . "{$header_image}".");}";
   }
   if($newseqo_header_textcolor =='blank'){
      $custom_css .="
      .logo-area .site-title a , .logo-area .site-desc{
         display:none;
      }";
   }else{
      $newseqo_header_textcolor ='#'.get_header_textcolor();
      $custom_css .="
      .logo-area .site-title a , .logo-area .site-desc{
         color:#".get_header_textcolor().";
      }";
   }
   $custom_css .= "
      
        .entry-header .entry-title a, .widget-title ,.post-title a ,h1,h2,h3,h4,h5,h6 {
           color:$newseqo_blog_style_title_color;
        }
        .entry-header .entry-title a:hover,
        .sidebar ul li a:hover, .xs-footer-section ul li a:hover,
        .btn:hover,
        .post-navigation h3:hover, .post-navigation span:hover ,

        .header .navbar-light .navbar-nav li a:hover,
        a

        {
         color:  {$newseqo_blog_style_body_primary_color_section};
        } 
        .tag-lists a:hover, .tagcloud a:hover,
        .sticky.post .meta-featured-post,
        .widget-title:before,
        .btn ,
        .block-title.title-border .title-bg,
        .block-title.title-border .title-bg::before ,
        .owl-next, .owl-prev,
        .xs-footer-section .widget.widget_search .input-group-btn, .sidebar .widget.widget_search .input-group-btn,
        .blog-single .tag-lists span{
           background:{$newseqo_blog_style_body_primary_color_section};
        }
        .tag-lists a:hover, .tagcloud a:hover{
           border-color: {$newseqo_blog_style_body_primary_color_section};
        }
        .block-title.title-border .title-bg::after{
           border-left-color: {$newseqo_blog_style_body_primary_color_section};
        }
        .block-title.title-border{
           border-bottom-color: {$newseqo_blog_style_body_primary_color_section};
        }
       .copyright-area{
               background: {$newseqo_footer_copyright_bg_color};
               padding-top: {$newseqo_footer_copyright_padding};
       }
       .copyright-area{
         color:  {$newseqo_footer_copyright_color};
      }
       
      body{
         background:{$newseqo_blog_style_body_bg_color_section};
        
       } 
       ";
       if($newseqo_blog_body_typhography!='initial'){
        $custom_css.= " body {
           
               {$newseqo_blog_body_typhography}
            }
          ";  
       }
       if($newseqo_blog_h1_2_typhography!='initial'){
         $custom_css.= " h1, h2 {
            {$newseqo_blog_h1_2_typhography}
          }
       ";  
       }

       if($newseqo_blog_h3_4_typhography!='initial'){
         $custom_css.= "  h3, h4 {
            {$newseqo_blog_h3_4_typhography}
          }
       ";  
       }
   
      
   wp_add_inline_style( 'newseqo-master', $custom_css );
}

add_action( 'wp_enqueue_scripts', 'newseqo_dynamic_style' );