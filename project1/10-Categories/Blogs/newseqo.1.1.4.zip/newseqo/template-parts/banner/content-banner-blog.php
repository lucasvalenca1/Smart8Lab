<?php 


  $banner_image             = get_theme_mod('newseqo_blog_banner_img');
  $banner_title             = get_theme_mod('newseqo_blog_banner_title','')!=''?get_theme_mod('newseqo_blog_banner_title'):get_bloginfo( 'name' );
  $show                     = get_theme_mod('newseqo_blog_banner_enable',true);
  $show_breadcrumb          = get_theme_mod('newseqo_blog_banner_breadcrumb_enable',true);

  if( isset($banner_image) && $banner_image != ''){
      $banner_image = 'style="background-image:url('.esc_url( $banner_image ).');"';
  }

?>

<?php if($show): ?>
           <div class="container" <?php echo wp_kses_post( $banner_image ); ?>>
               <div class=" text-center banner-area <?php echo esc_attr($banner_image == ''?'banner-solid':'banner-bg'); ?>">
                     <h2 class="banner-title">
                        <?php 
                           if(is_archive()){
                                 the_archive_title();
                           }elseif(is_single()){
                              the_title();
                           }
                           else{
                              $newseqo_title = str_replace(['{', '}'], ['<span>', '</span>'],$banner_title ); 
                              echo wp_kses_post( $newseqo_title);
                           }
                        ?> 
                     </h2>
                     <?php if($show_breadcrumb): ?>
                       
                        <?php newseqo_get_breadcrumbs(' / '); ?>
                     <?php endif; ?>
               </div>
            </div>
 <?php endif; ?>     