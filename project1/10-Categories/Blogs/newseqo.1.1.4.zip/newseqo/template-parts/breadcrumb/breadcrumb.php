<?php if( get_theme_mod( 'newseqo_breadcrumb_show',true)) { ?>
   <div class="container">
         <div class="row">
            <div class="col-lg-12">
                   
                  <?php newseqo_get_breadcrumbs(' / '); ?>
            </div>     
         </div>     
   </div> 
<?php  } ?> 

    
    