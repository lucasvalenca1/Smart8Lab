<?php if(has_post_thumbnail()): ?>
      <div class="post-media post-video">
         
            <img class="img-fluid" alt="<?php the_title_attribute(); ?>" src="<?php echo esc_url(get_the_post_thumbnail_url()); ?>" >
            <?php 
                if ( is_sticky() ) {
                        echo '<sup class="meta-featured-post"> <i class="fa fa-thumb-tack"></i> ' . esc_html__( 'Sticky', 'newseqo' ) . ' </sup>';
                 }  
            ?>
          
      
      </div>
<?php endif; ?>
         <div class="post-body clearfix">
            <div class="entry-header">
               <?php newseqo_post_meta(); ?>
               <h2 class="entry-title">
                  <a href="<?php esc_url(the_permalink()); ?>"><?php the_title(); ?></a>
               </h2>
            </div>
         
          
         <div class="post-content">
            <div class="entry-content">
               <p>
                  <?php newseqo_excerpt( get_theme_mod('newseqo_blog_post_char_limit_length'), null ); ?>
               </p>
            </div>
            <?php
               if(!is_single()):
                  $newseqo_blog_read_more = get_theme_mod('newseqo_blog_readmore',true);
                  $newseqo_blog_read_more_text = get_theme_mod('newseqo_blog_readmore_text',esc_html__('readmore','newseqo'));  
                  if($newseqo_blog_read_more){
                        printf('<div class="post-footer readmore-btn-area"><a class="readmore" href="%1$s"> '.esc_html($newseqo_blog_read_more_text).' <i class="icon icon-arrow-right"></i></a></div>',
                     esc_url(get_the_permalink())
                        );
                  }
               endif; 
        ?>
         </div>
   <!-- Post content right-->
</div>
<!-- post-body end-->