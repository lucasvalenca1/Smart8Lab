
   <div class="category-main-title">
      <h2 class="block-title title-border">
         <span class="title-bg"> <?php echo esc_html__('Category :','newseqo'); ?> <?php single_cat_title(); ?> </span>
      </h2>
   </div>

