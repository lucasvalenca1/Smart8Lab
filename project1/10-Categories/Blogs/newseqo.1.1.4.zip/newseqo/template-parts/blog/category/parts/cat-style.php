<?php $newseqo_cat = get_the_category();  ?> 
  
   <a 
      class="post-cat" 
      href="<?php echo esc_url(get_category_link($newseqo_cat[0]->term_id)); ?>"      
      >
      <span class="before"></span> 
        <?php echo esc_html(get_cat_name($newseqo_cat[0]->term_id)); ?>   
      <span class="after"></span>
 
   </a>