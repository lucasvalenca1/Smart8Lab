<?php
 
  $newseqo_cat_layout = get_theme_mod('newseqo_blog_category_layout','style2'); 

  get_template_part( 'template-parts/blog/category/style/content', $newseqo_cat_layout );
  

