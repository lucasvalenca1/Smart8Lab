<?php
   $newseqo_class = '';
 
   $newseqo_header_top_info_show = get_theme_mod('newseqo_topbar_show',false); 
   $newseqo_header_nav_search_section = get_theme_mod('newseqo_search_show',true); 
   $newseqo_header_nav_sticky = false; 
   $newseqo_header_social_share = get_theme_mod('newseqo_header_social_show',false); 
  
?>
 <?php if( $newseqo_header_top_info_show ): ?>
<div class="topbar">
   <div class="container">
      <div class="row text-md-left text-center">
         <div class="col-md-7 col-lg-8 xs-center">
            <div class="topbar-left-content">
               <ul class="top-info">
                  <li> <i class="fa fa-calendar-check-o" aria-hidden="true"></i>  <?php echo esc_html(date(get_option('date_format'))); ?>
                  </li>
               </ul>
               <?php
                  if ( has_nav_menu( 'topbarmenu' ) ) {
                  
                     wp_nav_menu( array( 
                        'theme_location' => 'topbarmenu', 
                        'menu_class' => 'top-nav', 
                        'container' => '' 
                     ) );
                  }

               ?>
         
            </div>
         </div>
         <div class="col-md-5 col-lg-4 align-self-center">
         <?php
         
            if($newseqo_header_social_share): 
              $newseqo_social_links = newseqo_option('newseqo_social_icons',[]); 
              
              
   
              ?>
              <ul class="social-links text-md-right">
                  <?php if(count($newseqo_social_links)):   
                        foreach($newseqo_social_links as $newseqo_sl):
                        $newseqo_class = $newseqo_sl->icon_value;
                  ?>
                        <li>
                           <a title="<?php the_title_attribute(); ?>" href="<?php echo esc_url($newseqo_sl->link); ?>">
                           <span class="social-icon">  <i class="fa <?php echo esc_attr($newseqo_class); ?>"></i> </span>
                           </a>
                        </li>
                  <?php endforeach; ?>
               <?php endif; ?>
              </ul>
         <?php endif; ?>  
         </div>
      <!-- end col -->
      </div>
      <div class="b-bottom"></div>
   <!-- end row -->
   </div>
<!-- end container -->
</div>
<?php endif; ?>

<div class="header-middle-area">
   <div class="container">
      <div class="row">
          <div class="col-md-3 align-self-center">
              <div class="logo-area">
              <?php

              if( function_exists( 'the_custom_logo' ) ) : ?>
               <a class="logo" href="<?php echo esc_url(home_url('/')); ?>">
               <?php
                  if(has_custom_logo()) :
                     the_custom_logo();
                ?> 
               </a>
               <?php else: ?>  
               <h1 class="site-title">
                  <a rel="home" href=" <?php echo esc_url(home_url('/')); ?> "> <?php bloginfo('name'); ?> </a>   
               </h1>
               <p class="site-desc"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
              <?php endif; ?> 
              <?php endif; ?>     

              </div>
          </div>    
         <!-- col end  -->
         <div class="col-md-9 d-none d-md-block">
       
            <div class="banner-img text-right">
               
					<?php echo wp_kses_post(newseqo_ad('newseqo_ad_banner_img')) ; ?>
				</div>

         </div>
         <!-- col end  -->
      </div>
   </div>                     
</div>
<header id="header" class="header header-classic">
      <div class=" header-wrapper <?php echo esc_attr($newseqo_header_nav_sticky=='yes'?'navbar-sticky':''); ?> ">
         <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
               <a class="logo d-none" href="<?php echo esc_url(home_url('/')); ?>">
                     <img  class="img-fluid" src="<?php 
                        echo esc_url(
                           newseqo_src(
                              'newseqo_blog_site_dark_logo',
                              NEWSEQO_IMG . '/logo/logo-dark.png'
                           )
                        );
                     ?>" alt="<?php bloginfo('name'); ?>">
                  </a>
                  <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#primary-nav" aria-controls="primary-nav" aria-expanded="false"
                        aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"><i class="icon icon-menu"></i></span>
                  </button>
                  <?php get_template_part( 'template-parts/navigations/nav', 'primary' ); ?>
                  <?php is_user_logged_in() ?  $newseqo_class='w-10 text-right' : $newseqo_class='w-10 text-right'?>
                        <div class="nav-search-area <?php echo esc_attr($newseqo_class) ;?>">
                           <?php if($newseqo_header_nav_search_section): ?>
                              <div class="header-search-icon">
                                 <a href="#modal-popup-2" class="navsearch-button nav-search-button xs-modal-popup"><i class="icon icon-search1"></i></a>
                              </div>
                           <?php endif; ?>
                           <!-- xs modal -->
                           <div class="zoom-anim-dialog mfp-hide modal-searchPanel ts-search-form" id="modal-popup-2">
                              <div class="modal-dialog modal-lg">
                                 <div class="modal-content">
                                    <div class="xs-search-panel">
                                          <?php get_search_form(); ?>
                                    </div>
                                 </div>
                              </div>
                           </div><!-- End xs modal --><!-- end language switcher strart -->
                        </div>
                 <!-- Site search end-->
             </nav>
         </div><!-- container end-->
      </div>
</header>
<!-- tranding bar -->
<?php 
  get_template_part( 'template-parts/newsticker/news', 'ticker' ); 
 ?>