<?php
   get_header();
   get_template_part( 'template-parts/banner/content', 'banner-blog' );
   
   $newseqo_layout = get_theme_mod('newseqo_blog_single_layout','right');
   $newseqo_column = $newseqo_layout=="full" || !is_active_sidebar('sidebar-1')? 'col-lg-8 mx-auto' : 'col-lg-8 col-md-12';
  

?>
<div id="main-content" class="blog-single main-container" role="main">
	<div class="container">
		<div class="row">
            <?php
               if($newseqo_layout == "left"):
                  get_sidebar();
               endif;
            ?>
          <div class="<?php echo esc_attr($newseqo_column); ?>">
               <?php
                     while ( have_posts() ) :
                        the_post();

                        get_template_part( 'template-parts/blog/single/content', $newseqo_layout ); 
                     
                        if(get_theme_mod('newseqo_single_blog_post_nav',true)):  
                           newseqo_post_nav();
                        endif;  
                        get_template_part( 'template-parts/blog/post-parts/part', 'author' );
                  
                        if(get_theme_mod('newseqo_blog_post_comment_open',true)):  
                           if ( comments_open() || get_comments_number() ) :
                              comments_template();
                           endif;
                        endif;   
                        get_template_part( 'template-parts/blog/post-parts/part', 'related-post' );
                     endwhile; // End of the loop.
               ?>
         </div><!-- #col -->
         <?php 
            if($newseqo_layout == "right"):
				   get_sidebar();
            endif; 
         ?>
     </div><!-- #row -->
	</div><!-- #container -->
</div>
<?php

get_footer();
