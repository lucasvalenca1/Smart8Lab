<?php
/**
 * Demo configuration
 *
 * @package Lifestyle Fashion
 */

$config = array(
	'ocdi'           => array(
		array(
			'import_file_name'             => esc_html__( 'Import - Layout One', 'lifestyle-fashion' ),
			'local_import_file'            => trailingslashit( get_stylesheet_directory() ) . 'inc/demo/contents.xml',
      		'local_import_widget_file'     => trailingslashit( get_stylesheet_directory() ) . 'inc/demo/widget.wie',
      		'local_import_customizer_file' => trailingslashit( get_stylesheet_directory() ) . 'inc/demo/customizer.dat',
      		'import_notice'					=> esc_html__( 'It will overwrite your settings', 'lifestyle-fashion' ),
      		'preview_url'					=> esc_url( 'https://thebootstrapthemes.com/demo/lifestyle-fashion/' ),
      		'import_preview_image_url'		=> esc_url( 'https://thebootstrapthemes.com/wp-content/uploads/edd/lifestyle-fashion.jpg' )
		),		
		
	),
);

Lifestyle_Fashion_Demo::init( apply_filters( 'lifestyle_fashion_demo_filter', $config ) );