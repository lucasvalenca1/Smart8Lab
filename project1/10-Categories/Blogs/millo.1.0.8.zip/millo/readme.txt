=== millo === 

Contributors: Afrothemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, portfolio
Requires at least: 4.5
Tested up to: 5.0
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

millo is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

millo is a simple WordPress theme for photographers & bloggers, use it for a travel, food or photography bloging & portfolio. millo can also be use be used for creative agency or photo studio. Try it out for free today.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

millo includes support for Infinite Scroll in Jetpack.


== Credits ==
Images used in screenshot:
License(for all of them): https://stocksnap.io/license
https://stocksnap.io/photo/4AGMHST0M6 - japan street
https://stocksnap.io/photo/ZM6UUXW2SB -- Yoga
https://stocksnap.io/photo/4GJOVOEYTH - Wall Art
https://stocksnap.io/photo/PRF1NPBVNB - asian woman
https://stocksnap.io/photo/NNW5IOOD6F - baby
https://stocksnap.io/photo/UIT7R0DIJR -rings



== Changelog ==
= 1.0.4 - July 2, 2019 =
* added AJAX load more feature

= 1.0.3 - June 13, 2019 =
*Fixed mobile view
= 1.0.2 - June 13, 2019 =
* fixed archive template 

= 1.0 - May 3, 2019 =
* Initial release