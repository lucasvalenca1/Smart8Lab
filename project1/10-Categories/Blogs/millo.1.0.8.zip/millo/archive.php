<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package millo
 */

get_header();
?>

	<div id="primary" class="content-area grid-wide">
		<header class="page-header">
			<?php
			the_archive_title( '<h1 class="page-title">', '</h1>' );
			the_archive_description( '<div class="archive-description">', '</div>' );
			?>
		</header><!-- .page-header -->
		<main id="masonry" class="site-main">

		<?php if ( have_posts() ) : ?>



			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class('post-item'); ?>>

				<a href="<?php the_permalink();?>">
				<?php if (has_post_thumbnail()) {
					the_post_thumbnail('millo-large'); 
				} else {
					$thumb = get_template_directory_uri() .'/img/default.png';
					echo '<img src="'.$thumb.'">';
				} ?>
				</a>
					<header class="entry-header">
						<a href="<?php the_permalink();?>">
							<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
						</a>			

						<?php echo esc_html(millo_post_category()); 
						echo esc_html(do_action('pro-portfolio-type'));
						
						?>			
					</header><!-- .entry-header -->
				</article>

			<?php endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
