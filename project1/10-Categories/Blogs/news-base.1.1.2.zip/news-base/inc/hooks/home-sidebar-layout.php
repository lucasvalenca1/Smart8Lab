<?php
if ( ! function_exists( 'news_base_widget_section' ) ) :
    /**
     *
     * @since News Base 1.0.0
     *
     * @param null
     * @return null
     *
     */
    function news_base_widget_section() {
        $sidebar_home_1 = '';
        ?>
        <!-- Main Content section -->
        <?php if (! is_active_sidebar( 'sidebar-home-2') ) {
            $sidebar_home_1 = "full-width";
        }?>
        <?php if ( is_active_sidebar( 'sidebar-home-1') || is_active_sidebar( 'sidebar-home-2') ) {  ?>
            <section class="section-block section-block-upper">
                <div class="container">
                    <div id="tm-primary" class="content-area <?php echo esc_attr($sidebar_home_1); ?>">
                        <div class="theiaStickySidebar">
                            <main id="main" class="site-main">
                                <?php dynamic_sidebar('sidebar-home-1'); ?>
                            </main>
                        </div>
                    </div>
                    <?php if (is_active_sidebar( 'sidebar-home-2') ) { ?>
                        <aside id="tm-secondary" class="widget-area">
                            <div class="theiaStickySidebar">
                                <?php dynamic_sidebar('sidebar-home-2'); ?>
                            </div>
                        </aside>
                    <?php } ?>
                </div>
            </section>
        <?php } ?>
    <?php
    }
endif;
add_action( 'news_base_action_sidebar_section', 'news_base_widget_section', 50 );