<?php
/**
 * Collection of other function file.
 */
require get_template_directory() . '/inc/layout-meta/layout-meta.php';
require get_template_directory() . '/inc/custom-functions.php';

/*load tgm plugin activation*/
require get_template_directory() . '/assets/libraries/tgm/class-tgm-plugin-activation.php';


/*widget init*/
require get_template_directory() . '/inc/widget-init.php';

/*layout meta*/

/*header css*/
require get_template_directory() . '/inc/hooks/added-style.php';

/*widgets init*/
require get_template_directory() . '/inc/widgets/widgets.php';

/*sidebar init*/
require get_template_directory() . '/inc/hooks/slider.php';
require get_template_directory() . '/inc/hooks/related-post.php';
require get_template_directory() . '/inc/hooks/fullwidth-slider.php';
require get_template_directory() . '/inc/hooks/trending-news.php';
require get_template_directory() . '/inc/hooks/footer-recomended.php';

/*section hook init*/
require get_template_directory() . '/inc/hooks/breadcrumb.php';
require get_template_directory() . '/inc/hooks/header-inner-page.php';
require get_template_directory() . '/inc/hooks/home-sidebar-layout.php';
require get_template_directory() . '/inc/hooks/fullwidth-video.php';