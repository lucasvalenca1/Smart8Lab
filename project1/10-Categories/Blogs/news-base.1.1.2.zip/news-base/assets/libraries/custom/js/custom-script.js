(function (e) {
    "use strict";
    var n = window.Thememattic_JS || {};
    n.stickyMenu = function () {
        if (e(window).scrollTop() > 350) {
            e("#masthead").addClass("nav-affix");
        } else {
            e("#masthead").removeClass("nav-affix");
        }
    };
    n.mobileMenu = {
        init: function () {
            this.toggleMenu();
            this.menuMobile();
            this.menuArrow();
            this.submenuHover();
        },
        toggleMenu: function () {
            e('#masthead').on('click', '.toggle-menu', function (event) {
                var ethis = e('.main-navigation .menu .menu-mobile');
                if (ethis.css('display') == 'block') {
                    ethis.slideUp('300');
                } else {
                    ethis.slideDown('300');
                }
                e('.ham').toggleClass('exit');
            });
            e('#masthead .main-navigation ').on('click', '.menu-mobile a i', function (event) {
                event.preventDefault();
                var ethis = e(this),
                    eparent = ethis.closest('li'),
                    esub_menu = eparent.find('> .sub-menu');
                if (esub_menu.css('display') == 'none') {
                    esub_menu.slideDown('300');
                    ethis.addClass('active');
                } else {
                    esub_menu.slideUp('300');
                    ethis.removeClass('active');
                }
                return false;
            });
        },
        menuMobile: function () {
            if (e('.main-navigation .menu > ul').length) {
                var ethis = e('.main-navigation .menu > ul'),
                    eparent = ethis.closest('.main-navigation'),
                    pointbreak = eparent.data('epointbreak'),
                    window_width = window.innerWidth;
                if (typeof pointbreak == 'undefined') {
                    pointbreak = 991;
                }
                if (pointbreak >= window_width) {
                    ethis.addClass('menu-mobile').removeClass('menu-desktop');
                    e('.main-navigation .toggle-menu').css('display', 'block');
                } else {
                    ethis.addClass('menu-desktop').removeClass('menu-mobile').css('display', '');
                    e('.main-navigation .toggle-menu').css('display', '');
                }
            }
        },
        menuArrow: function () {
            if (e('#masthead .main-navigation div.menu > ul').length) {
                e('#masthead .main-navigation div.menu > ul .sub-menu').parent('li').find('> a').append('<i class="ion-ios-arrow-down">');
            }
        },
        submenuHover: function () {
            e('.site-header .main-navigation li.mega-menu .sub-cat-list li').on('hover', function () {
                if (!e(this).hasClass('current')) {
                    var eposts = e(this).parents('.sub-cat-list').first().siblings('.sub-cat-posts').first();
                    e(this).siblings('.current').removeClass('current').end().addClass('current');
                    eposts.children('.current').removeClass('current');
                    eposts.children('.' + e(this).attr('data-id')).addClass('current');
                }
            });
        }
    };
    n.ThemematticWidgetsNav = function () {
        e('.trending-news').sidr({
            side: 'left'
        });

        e('.trending-news').click(function(){
            e('.sidr-class-sidr-button-close').focus();
        });

        e( '.tmt-canvas-focus' ).on( 'focus', function() {
            e('.sidr-class-sidr-button-close').focus();
        } );

        e('.sidr-class-sidr-button-close').click(function () {
            e.sidr('close', 'sidr');
            e('.trending-news').focus();
        });
    };
    n.DataBackground = function () {
        var pageSection = e(".data-bg");
        pageSection.each(function (indx) {
            if (e(this).attr("data-background")) {
                e(this).css("background-image", "url(" + e(this).data("background") + ")");
            }
        });
    };
    n.SlickCarousel = function () {
        e(".banner-slider").slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true,
            autoplay: true,
            autoplaySpeed: 8000,
            infinite: true,
            dots: false,
            nextArrow: '<i class="slide-icon slide-next ion-ios-arrow-right"></i>',
            prevArrow: '<i class="slide-icon slide-prev ion-ios-arrow-left"></i>',
        });
        e(".mainbanner-jumbotron").slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true,
            autoplay: true,
            autoplaySpeed: 8000,
            infinite: true,
            dots: false,
            arrows: false,
            asNavFor: '.jumbotron-pagenav'
        });
        e('.jumbotron-pagenav').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            asNavFor: '.mainbanner-jumbotron',
            dots: false,
            arrows: false,
            focusOnSelect: true,
            responsive: [
                {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
        e(".tm-videos").slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            fade: true,
            autoplay: true,
            autoplaySpeed: 8000,
            infinite: true,
            dots: false,
            arrows: false,
            asNavFor: '.video-pagenav'
        });
        e('.video-pagenav').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            asNavFor: '.tm-videos',
            dots: false,
            arrows: false,
            focusOnSelect: true,
            responsive: [
                {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
        e('.trending-slider').slick({
            slidesToShow: 4,
            slidesToScroll: 1,
            dots: false,
            arrows: false,
            nextArrow: '<i class="slide-icon slide-next ion-ios-arrow-right"></i>',
            prevArrow: '<i class="slide-icon slide-prev ion-ios-arrow-left"></i>',
            focusOnSelect: true,
            responsive: [
                {
                    breakpoint: 991,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        arrows: true
                    }
                },
                {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        arrows: true
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        arrows: true
                    }
                }
            ]
        });
        e(".tm-slider-widget").each(function () {
            e(this).slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                fade: true,
                autoplay: true,
                autoplaySpeed: 8000,
                infinite: true,
                dots: false,
                nextArrow: '<i class="slide-icon slide-next ion-ios-arrow-right"></i>',
                prevArrow: '<i class="slide-icon slide-prev ion-ios-arrow-left"></i>',
            });
        });
        e(".tm-carousel-widget").each(function () {
            e(this).slick({
                infinite: true,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 8000,
                dots: false,
                nextArrow: '<i class="slide-icon slide-next ion-ios-arrow-right"></i>',
                prevArrow: '<i class="slide-icon slide-prev ion-ios-arrow-left"></i>',
                responsive: [
                    {
                        breakpoint: 768,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 2,
                            arrows: true
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            arrows: true
                        }
                    }
                ]
            });
        });
        e(".gallery-columns-1, ul.wp-block-gallery.columns-1, .wp-block-gallery.columns-1 .blocks-gallery-grid").each(function () {
            e(this).slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                fade: true,
                autoplay: true,
                autoplaySpeed: 8000,
                infinite: true,
                dots: false,
                nextArrow: '<i class="slide-icon slide-next ion-ios-arrow-right"></i>',
                prevArrow: '<i class="slide-icon slide-prev ion-ios-arrow-left"></i>',
            });
        });
    },
        n.MagnificPopup = function () {
            e('.popup-video').magnificPopup({
                type: 'iframe',
                mainClass: 'mfp-fade',
                preloader: true,
            });
            e('.entry-content .gallery, .entry-content .wp-block-gallery').each(function () {
                e(this).magnificPopup({
                    delegate: 'a',
                    type: 'image',
                    gallery: {
                        enabled: true
                    },
                    zoom: {
                        enabled: true,
                        duration: 300,
                        opener: function (element) {
                            return element.find('img');
                        }
                    }
                });
            });
            e('.widget .gallery').each(function () {
                e(this).magnificPopup({
                    delegate: 'a',
                    type: 'image',
                    gallery: {
                        enabled: true
                    },
                    zoom: {
                        enabled: true,
                        duration: 300,
                        opener: function (element) {
                            return element.find('img');
                        }
                    }
                });
            });
        };
    n.Thememattic_preloader = function () {
        e(window).load(function () {
            e("body").addClass("page-loaded");
        });
    };
    n.InnerBanner = function () {
        var pageSection = e(".data-bg");
        pageSection.each(function (indx) {
            if (e(this).attr("data-background")) {
                e(this).css("background-image", "url(" + e(this).data("background") + ")");
            }
        });
    };
    n.show_hide_scroll_top = function () {
        if (e(window).scrollTop() > e(window).height() / 2) {
            e("#scroll-up").fadeIn(300);
        } else {
            e("#scroll-up").fadeOut(300);
        }
    };
    n.scroll_up = function () {
        e("#scroll-up").on("click", function () {
            e("html, body").animate({
                scrollTop: 0
            }, 800);
            return false;
        });
    };
    n.Thememattic_sticky = function () {
        e('.widget-area, .sidebar').theiaStickySidebar({
            additionalMarginTop: 30
        });
    };
    e(document).ready(function () {
        n.mobileMenu.init();
        n.ThemematticWidgetsNav();
        n.DataBackground();
        n.SlickCarousel();
        n.MagnificPopup();
        n.Thememattic_preloader();
        n.Thememattic_sticky();
        n.scroll_up();
    });
    e(window).scroll(function () {
        n.stickyMenu();
        n.show_hide_scroll_top();
    });
    e(window).resize(function () {
        n.mobileMenu.menuMobile();
    });
})(jQuery);