<?php
/**
 * The template for displaying home page.
 * @package news-base
 */

get_header();
if ( is_paged()) { ?>
    <div id="content" class="site-content">
        <div id="content-container">
            <div class="container">
<?php } else {
    do_action('news_base_action_trending_slider');
    /**
     * news_base_action_fullwidth_slider hook
     * @since news-base 0.0.2
     *
     * @hooked news_base_action_fullwidth_slider -  10
     * @sub_hooked news_base_action_fullwidth_slider -  10
     */
    do_action('news_base_action_fullwidth_slider');
    /**
     * news_base_action_front_page hook
     * @since news-base 0.0.2
     *
     * @hooked news_base_action_front_page -  10
     * @sub_hooked news_base_action_front_page -  10
     */
    do_action('news_base_action_front_page');
    ?>
    <div id="content" class="site-content">
    <?php
        /**
         * news_base_action_sidebar_section hook
         * @since News Base 0.0.1
         * @hooked news_base_action_sidebar_section -  20
         * @sub_hooked news_base_action_sidebar_section -  20
         */
        do_action('news_base_action_sidebar_section');
        /**
         * news_base_fullwidth_video hook
         * @since news-base 0.0.2
         *
         * @hooked news_base_fullwidth_video -  10
         * @sub_hooked news_base_fullwidth_video -  10
         */
        do_action('news_base_action_fullwidth_video');
    ?>
    <div id="content-container">
        <div class="container">
<?php } ?>
        <?php if ('posts' == get_option('show_on_front')) {
            include(get_home_template());
        } else {
        if (news_base_get_option('home_page_content_status') == 1) { ?>
           <div id="content-container">
                <div class="container">
                    <div id="primary" class="content-area">
                        <?php
                        while (have_posts()) : the_post();
                            the_title('<h2 class="section-title">', '</h2>');
                            get_template_part('template-parts/content', 'page');

                        endwhile; // End of the loop.
                        ?>
                    </div><!-- #primary -->
                    <?php get_sidebar(); ?>
                </div>
            </div>
    <?php }
}
get_footer();