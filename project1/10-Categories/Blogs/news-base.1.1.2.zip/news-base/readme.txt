=== News Base ===

Contributors: Thememattic

Requires at least: 4.0
Tested up to: 5.2.0
Requires PHP: 5.2.4
Stable tag: 1.1.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

A clean, elegant and professional News WordPress News Theme.

Description:
News Base is a clean, creative and modern WordPress theme with an elegant, carefully crafted design. The clean and uncluttered design invites your users to lose themselves in the creative space you have brought to life. News Base is excellent for news portal, newspaper, magazine, or publishing site. Make your content more appealing, engaging and usable.

== License ==

News Base WordPress Theme, Copyright (C) 2019, Themematic
News Base is distributed under the terms of the GNU GPL

== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Changelog ==

= 1.1.2 - April 22 2020 =
= Fixed design issue with cookie consent checkbox on comment =
= Bug Fix some other design issue =

= 1.1.0 - Mar 03 2020 =
= Removed Breadcrumb from 404 page =
= Update language POT file =
= Update meta fields design =
= Feature enable & disable option added into metabox =
= Focun functionality added into offcanvas active =
= Single page design issue fixed while no feature image =
= Keybord navigation support =

= 1.1.0 - Feb 13 2020 =
= Removed About page =
= Update language POT file =

= 1.0.9 - Feb 04 2020 =
= Removed One Click Demo Import =

= 1.0.8 - Jan 07 2020 =
= Breadcrumb structure issue fix =
= Update customizer color option code =
= Update content gallery issue =

= 1.0.7 - (Nov 25 2019) =
=Issue on script fixed=

= 1.0.6 (Nov - 04) =
= Updated fixing the menu issue in ie=

= 1.0.5 (Aug - 14) =
= RTL css added for managing content=
= Added skip link on navigation=

= 1.0.4 (jun - 12) =
=Made the theme RTL ready=

= 1.0.3 (jun - 5) =
=Fixed the bug on single related post=

= 1.0.2 (may-23) =
=Fixed the bug on main date=


= 1.0.1 (may-15) =
=Update with some fix on related post option=


= 1.0.0 =
=Initial release=


== Credits ==

Underscores:
Author: 2012-2015 Automattic
Source: http://underscores.me
License: GPLv3 or later](https://www.gnu.org/licenses/gpl-3.0.html)

normalize:
Author: 2012-2015 Nicolas Gallagher and Jonathan Neal
Source: http://necolas.github.io/normalize.css
License: [MIT/GPL2 Licensed](http://opensource.org/licenses/MIT)

html5shiv:
Author: 2014 Alexander Farkas (aFarkas)
Source: https://github.com/afarkas/html5shiv
License: [MIT/GPL2 Licensed](http://opensource.org/licenses/MIT)

jquery.easing:
Author: 2008 George McGinley Smith
Source: https://raw.github.com/gdsmith/jquery-easing/master
License: [MIT](http://opensource.org/licenses/MIT)

Bootstrap:
Author: Twitter
Source: http://getbootstrap.com
License: Licensed under the MIT license

BreadcrumbTrail:
Author: Justin Tadlock
Source: http://themehybrid.com/plugins/breadcrumb-trail
License: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Ionicons:
Author: Ben Sperry for the Ionic Framework
Source: https://github.com/driftyco/ionicons
License: Licensed under the MIT license

Magnific Popup
Author: Chubby Ninja
Source: https://github.com/dimsemenov/Magnific-Popup
License: Licensed under the MIT license

Sidr:
Author: Alberto Varela
Source: http://www.berriart.com/sidr/
License: Licensed under the MIT license

TGM-Plugin-Activation:
Author: Thomas Griffin (thomasgriffinmedia.com)
URL:  https://github.com/TGMPA/TGM-Plugin-Activation
License: GNU General Public License, version 2

Theia Sticky Sidebar
Author: WeCodePixels
Source: https://github.com/WeCodePixels/theia-sticky-sidebar
License: Licensed under the MIT License (MIT) https://github.com/WeCodePixels/theia-sticky-sidebar

slick carousel:
Author: Ken Wheeler
Source: https://github.com/kenwheeler/slick
License: Licensed under the MIT license

jquery match height
Author: Liam liabru https://github.com/liabru
License Detail at: https://github.com/liabru/jquery-match-height

== Image Used ==

https://stocksnap.io/photo/VU6KGYIFRL
https://stocksnap.io/photo/SFKZHJODOV
https://stocksnap.io/photo/G3YOGRBLF3
https://stocksnap.io/photo/ZRTVKONAVU
https://stocksnap.io/photo/4SRA1ZTKGU
https://stocksnap.io/photo/37CB0NNMNC
https://stocksnap.io/photo/4CNNMKE9IQ

All are Licensed under CC0 https://creativecommons.org/publicdomain/zero/1.0/
StockSnap's CC0 License: https://stocksnap.io/license


== Google Fonts ==
Open Sans by Steve Matteson
Source: https://fonts.google.com/specimen/Open+Sans
License: Apache License, Version 2.0 (http://www.apache.org/licenses/LICENSE-2.0)

Libre Franklin by Impallari Type
Source: https://fonts.google.com/specimen/Libre+Franklin
License: Open Font License (http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web)

Merriweather by Sorkin Type
Source: https://fonts.google.com/specimen/Merriweather
License: Open Font License (http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL_web)