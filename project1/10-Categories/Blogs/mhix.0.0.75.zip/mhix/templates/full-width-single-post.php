<?php 
/**
 * The template for displaying details of the posts
 *
 * @version    0.0.75
 * @package    mhix
 * @author     Zidithemes
 * @copyright  Copyright (C) 2020 zidithemes.tumblr.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Template Name: Full Width Post Template
 * Template Post Type: post
 * 
 */
?>

<?php get_header(); ?>


<main id="main" class="site-main" role="main">

	<header class="page-header">
		
	</header>

<div class="page-content">


<div class="flowid mhix-single-full-width">

	    <div class="mg-auto wid-100 mobwid-100">
	        
	        <div class="inner dsply-fl fl-wrap">
	            
	            <div class="wid-100 blog-2-col-inner">
	            	
	                <div class=" dsply-fl fl-wrap">
	                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>	

	                	
	                	
	                	<div class="items wid-100 mobwid-100">
	                            <div class="items-inner dsply-fl fl-wrap  mn-dz">
	                                <div class="img-box wid-100 relative">
	                                	<h2 class="mg-bt-20 text-center">
                                        	<?php the_title(); ?>
                                        </h2>
                                        <div class="by-author">
                                    		<span class="meta-btn dsply-ib date"><?php the_time(get_option('date_format')); ?></span>
                                            <span class="meta-btn dsply-ib mg-left-15 author"><?php esc_html_e( 'By:  ', 'mhix'); ?> <?php the_author_posts_link(); ?></span>
                                            
                                        </div>

	                                    <div class="details-box ">
	                                        <div class="details-box-inner">
	                                            <p><?php the_content(); ?></p>
	                                            
	                                        </div>
	                                    </div>
	                                </div>
	                                <div class="tags">
										<?php the_tags(); ?>
									</div>
	                            </div>

	                            
						        <?php comments_template(); ?>

	                    
		                    <?php endwhile; else : ?>
							<h2><?php esc_html__('No posts Found!', 'mhix'); ?></h2>
		                    <?php endif; ?>
	                    </div>
	                    <!-- SIDEBAR HERE -->
	                </div>
	                
	            </div>

	            <div class="mhix_link_pages">
		            <?php wp_link_pages(); ?>
		        </div>
	        </div>
	    </div>
	</div>

</div>

</main>


<?php get_footer(); ?>