
<div id="post-<?php the_ID(); ?>" <?php post_class('items wid-49 mobwid-100'); ?> >
        <div class="items-inner dsply-fl fl-wrap">
            <div class="img-box wid-100 relative">
            	<?php if ( has_post_thumbnail()) : ?>
            		<a href="<?php esc_url( the_permalink() ); ?>"  >
                		<?php the_post_thumbnail(); ?>
                	</a>
                <?php else: ?>
                    <div class="user-no-img-items">
                        <div class="user-no-img-items-inner text-center">
                            <div class=""><?php esc_html_e( 'No Image', 'mhix'); ?></div>
                        </div>
                    </div>
                <?php endif; ?>	
                <div class="details-box ">
                    <div class="details-box-inner">
                        <h2>
                        	<a href="<?php esc_url( the_permalink() ); ?>"  >
                        		<?php the_title(); ?>
                        	</a>
                        </h2>
                        <span class="mg-rt-10 date"><?php the_time(get_option('date_format')); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="mhix_link_pages">
            <?php wp_link_pages(); ?>
        </div>
</div>