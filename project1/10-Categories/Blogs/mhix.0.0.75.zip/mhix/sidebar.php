<?php 
/**
 * The template for displaying widgets in the sidebar
 *
 * @version    0.0.75
 * @package    mhix
 * @author     Zidithemes
 * @copyright  Copyright (C) 2020 zidithemes.tumblr.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * 
 */
?>
<aside class="mobwid-100 no-show-mob sidebar wid-30">
	<div class="sidebar-inner">
		<?php dynamic_sidebar('sidebar-widgets'); ?>
	</div>
</aside>