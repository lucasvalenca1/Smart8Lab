 ( function( $ ) {

	wp.customize( 'mhix_navbar_section_bg_color_settings', function( value ) {
		value.bind( function( val ) {
			$( '.nav-outer' ).css('background-color', val );
		});
	});	

	wp.customize( 'mhix_showgrid_date_bg_color_settings', function( value ) {
		value.bind( function( val ) {
			$( '.mhix-show .left-side .mhix-show-items .mhix-show-items-content .date' ).css('background-color', val );
		});
	});	

	wp.customize( 'mhix_sidebar_header_bg_color_settings', function( value ) {
		value.bind( function( val ) {
			$( '.sidebar .sidebar-inner .sidebar-items h2' ).css('background-color', val );
		});
	});	

	wp.customize( 'mhix_search_btn_sidebar_bg_color_settings', function( value ) {
		value.bind( function( val ) {
			$( '.sidebar .sidebar-inner .sidebar-items .searchform div #searchsubmit' ).css('background-color', val );
		});
	});	

	wp.customize( 'mhix_pagination_bg_color_settings', function( value ) {
		value.bind( function( val ) {
			$( '.page-numbers' ).css('background-color', val );
		});
	});	

	wp.customize( 'mhix_footer_bg_color_settings', function( value ) {
		value.bind( function( val ) {
			$( '.footer-4-col' ).css('background-color', val );
		});
	});	


} )( jQuery );