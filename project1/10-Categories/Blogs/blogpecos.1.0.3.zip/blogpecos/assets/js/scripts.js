jQuery(document).ready(function($){

	// Primary menu
	$('#primary-menu').slicknav({
		'prependTo': '#site-navigation'
	});

	// mobile view menu show hide menu
	$('.meanmenu-reveal').on('click', function(){
		$('.menu-main-menu-container').toggleClass('show-menu');
	});

	// bailboard
	$('.bailboard').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		dots: true,
		arrows: true,
		fade: true,
		nav: true,
		autoplay: false,
		autoplaySpeed: 2000
	});


	// site footer reposition on mobile view
	function siteFooterSwap(e) {
		if ($(window).width() <= 991.98) {  
			$( ".site-footer" ).insertAfter( ".wrapper" );
		}   
	}	
	$(window).on('resize load', function(){
		siteFooterSwap()
	});


	// masonry reload
	function gridReload(e) {
		$('.grid').masonry({
			itemSelector: '.col-xl-6'
		});
	}

	$(window).on("load",function(){
		gridReload()
	});

});