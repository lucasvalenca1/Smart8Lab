<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package blogpecos
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php blogpecos_post_thumbnail(); ?>

	<header class="entry-header">


		<?php
		blogpecos_category_list();
		if ( is_singular() ) :
			the_title( '<h1 class="entry-title">', '</h1>' );
		else :
			the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
		endif;
		?>

	</header><!-- .entry-header -->

	

	<div class="entry-content">
		<?php
		if ( is_archive() || is_home() || is_front_page() ) { // Makes EVERY Post on an index page an excerpt
                    	the_excerpt();
                } else {
		the_content( sprintf(
			wp_kses(
				/* translators: %s: Name of current post. Only visible to screen readers */
				__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'blogpecos' ),
				array(
					'span' => array(
						'class' => array(),
					),
				)
			),
			get_the_title()
		) );

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'blogpecos' ),
			'after'  => '</div>',
		) );
	}
		?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php 



		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta">
				<?php
				blogpecos_posted_by(); 
				blogpecos_posted_on();
				blogpecos_entry_footer();
				blogpecos_tags_list(); 
		 
				
				?>
			</div><!-- .entry-meta -->
		<?php endif; ?>
	</footer><!-- .entry-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
