<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package blogpecos
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>
	<?php
	if ( function_exists( 'wp_body_open' ) ) {
		wp_body_open();
	}
	?>
	<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'blogpecos' ); ?></a>

	<div class="wrapper">
		<div class="side-container">
			<div class="side-content-holder">
				<header id="masthead" class="site-header">
					<div class="site-branding">
						<?php
						the_custom_logo();
						if ( is_front_page() && is_home() ) :
							?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						<?php
					else :
						?>
						<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
						<?php
					endif;
					$blogpecos_description = get_bloginfo( 'description', 'display' );
					if ( $blogpecos_description || is_customize_preview() ) :
						?>
						<p class="site-description"><?php echo $blogpecos_description; /* WPCS: xss ok. */ ?></p>
					<?php endif; ?>
				</div><!-- .site-branding -->

				<nav id="site-navigation" class="main-navigation">
					
					<?php
					wp_nav_menu( array(
						'theme_location' => 'menu-1',
						'menu_id'        => 'primary-menu'


					) );
					?>

				</nav><!-- #site-navigation -->
			</header><!-- #masthead -->
			<footer id="colophon" class="site-footer">

				<?php
				wp_nav_menu( array(
					'theme_location' => 'social-link',					
					'menu_class'     => 'social-list',								

				) );
				?>

				<div class="site-info">
					<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'blogpecos' ) ); ?>">
						<?php
						/* translators: %s: CMS name, i.e. WordPress. */
						printf( esc_html__( 'Proudly powered by %s', 'blogpecos' ), 'WordPress' );
						?>
					</a>
					<span class="sep"> | </span>
					<?php echo wp_kses_post( sprintf( esc_html__( 'Theme: %1$s by %2$s.', 'blogpecos' ), 'Blogpecos', '<a href="' . esc_url( 'https://profoxstudio.com/' ) . '">Profoxstudio</a>' ) ); ?>
				</div><!-- .site-info -->
			</footer><!-- #colophon -->
		</div>	

	</div> <!-- end / left-sidebar -->



	<div id="content" class="site-content main-container">
		<?php
		if ( is_home() || is_front_page()) :	
			do_action('blogpecos_bailboard_slider_cat');
	endif;
	?>