<?php 
	include get_template_directory() . '/inc/customizers/header.php';
	include get_template_directory() . '/inc/customizers/bailboard.php';
