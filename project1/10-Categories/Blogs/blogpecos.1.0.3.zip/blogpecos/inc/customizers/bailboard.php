<?php 

/* Option list of all categories */
$args = array(
	'type'                     => 'post',
	'orderby'                  => 'name',
	'order'                    => 'ASC',
	'hide_empty'               => 1,
	'hierarchical'             => 1,
	'taxonomy'                 => 'category'
); 
$option_categories = array();
$category_lists = get_categories( $args );
$option_categories[''] = __( 'Choose Category', 'blogpecos' );
foreach( $category_lists as $category ){
	$option_categories[$category->term_id] = $category->name;
}

// bailboard slider
$wp_customize->add_panel( 'blogpecos_bailboard_slider', array(
	'title' => __( 'Banner', 'blogpecos' ),
	'priority' => 20,
) );


$wp_customize->add_section( 'blogpecos_bailboard_slider_section' , array(
	'title' => __('Custom Banner', 'blogpecos'),
	'panel' => 'blogpecos_bailboard_slider'
) );




/** Select Category */
$wp_customize->add_setting(
	'blogpecos_slider_cat',
	array(
		'default' => '',
		'sanitize_callback' => 'sanitize_text_field',
	)
);

$wp_customize->add_control(
	'blogpecos_slider_cat',
	array(
		'label' => __( 'Choose Slider Category', 'blogpecos' ),
		'section' => 'blogpecos_bailboard_slider_section',
		'type' => 'select',
		'choices' => $option_categories	
	)
);


/** button **/
$wp_customize->add_setting( 'blogpecos_bailboard_button',
	array(
		'default'			=> 'Read more',
		'sanitize_callback' => 'sanitize_text_field',
	)
);
$wp_customize->add_control( 'blogpecos_bailboard_button',
	array(
		'label'           => __( 'Slider button text ', 'blogpecos' ),
		'section'         => 'blogpecos_bailboard_slider_section',
		'type'            => 'text'
	)
); 