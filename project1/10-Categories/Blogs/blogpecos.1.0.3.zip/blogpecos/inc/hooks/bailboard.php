<?php 
if( !function_exists('blogpecos_bailboard_slider_category')) :
	function blogpecos_bailboard_slider_category( $options ){

		$category_id = get_theme_mod('blogpecos_slider_cat');
		$args = array(
			'post_type' => 'post',
			'tax_query' => array(
				array(
					'taxonomy' => 'category',
					'field'    => 'term_id',
					'terms'    => $category_id,
				),
			),
		);

		$query = new WP_Query($args);

		if ( $query->have_posts() ): ?>
			<div class="bailboard">
				<?php

				while($query -> have_posts()) : $query -> the_post(); ?>
					<div class="bailboard-item">
						<div class="bailboard-content align-items-center ">
							<div class="bailboard-pic">
								<?php if ( has_post_thumbnail() ) {
									echo get_the_post_thumbnail( get_the_ID(), 'full' );

								} else { ?>
									<a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/img/default-no-post-thumb.jpg" alt="<?php the_title(); ?>" /></a>
								<?php } ?>
							</div>					
							<div class="bailboard-caption">
								<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>		
								<?php the_excerpt(); ?>					

								<a href="<?php the_permalink(); ?>" title="<?php echo esc_html(get_theme_mod('blogpecos_bailboard_button',__('Read More','blogpecos'))); ?>" class="btn btn-primary">
									<?php echo esc_html(get_theme_mod('blogpecos_bailboard_button',__('Read More','blogpecos')));?>					
								</a>		
							</div>
						</div>				
					</div> <!-- end / bailboard-item -->
					<?php
				endwhile;
				?>
			</div>
			<?php
		endif; 
		wp_reset_query() ;
		?>

		<?php
	}
endif;
add_action('blogpecos_bailboard_slider_cat', 'blogpecos_bailboard_slider_category');