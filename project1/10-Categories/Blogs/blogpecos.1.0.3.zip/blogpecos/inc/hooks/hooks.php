<?php 
	include get_template_directory() . '/inc/hooks/header.php';
	include get_template_directory() . '/inc/hooks/bailboard.php';