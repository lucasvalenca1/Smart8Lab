<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package blogpecos
 */

get_header();
?>

	<div id="primary" class="content-area container-fluid h-100">
		<div class="row justify-content-center h-100">		
		<main id="main" class="site-main col-sm-12 col-md-12 col-lg-6 col-xl-6 h-100 text-center">
			<div class="vertical-content">
					<section class="error-404 not-found ">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'blogpecos' ); ?></h1>
				</header><!-- .page-header -->
				<div class="page-content">
					<p><?php esc_html_e( 'It looks like nothing was found at this location.', 'blogpecos' ); ?></p>

					<?php
					get_search_form();
					?>

				</div><!-- .page-content -->
			</section><!-- .error-404 -->
			</div>
		</main><!-- #main -->
	</div>
</div><!-- #primary -->

<?php
get_footer();
