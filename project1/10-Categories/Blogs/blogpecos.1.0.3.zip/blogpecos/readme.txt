=== blogpecos ===

Contributors: profoxstudio
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, blog, photography
Requires at least: 4.5
Requires PHP: 5.5
Tested up to: 5.2.2
Stable tag: 1.0.3
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



== Description ==

Blogpecos is a simple, minimal, attractive, responsive and multi-purpose WordPress theme suitable for blog, holiday, photography, business, fashion and travel.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

blogpecos includes support for Contact From 7 and Jetpack.

== Changelog ==

= 1.0.3 =
* Update theme URI.

= 1.0.2 =
* Update keyboard navigation.

= 1.0.1 =
* Removed unused styles.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.0 = 


* Initial release


== Screenshots ==

  https://pxhere.com/en/photo/1555989 [CC0]
  https://pxhere.com/en/photo/666293 [CC0]
  https://pxhere.com/en/photo/1452903 [CC0]


== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* Popper https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js (C) Federico Zivolo 2017 [MIT](http://opensource.org/licenses/MIT)
* Bootstrap v4.3.1 https://getbootstrap.com/, (C) 2011-2019 Twitter, Inc. [MIT] (https://github.com/twbs/bootstrap/blob/master/LICENSE)
* Font Awesome: https://fontawesome.com/, [MIT] (https://opensource.org/licenses/MIT)
* Slick https://kenwheeler.github.io/slick/, (c) 2013-2016, [MIT](http://opensource.org/licenses/MIT)
* Animate https://daneden.github.io/animate.css/ (c) 2018 Daniel Eden [MIT](http://opensource.org/licenses/MIT)
* Slicknav https://github.com/ComputerWolf/SlickNav, [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Modernizr http://modernizr.com/download/ [MIT](http://opensource.org/licenses/MIT)


