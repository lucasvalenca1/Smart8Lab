<?php

locate_template('/inc/widgets/homepage_header_slider.php', true, true);
locate_template('/inc/widgets/homepage_header_grid.php', true, true);
locate_template('/inc/widgets/posts_grid_1.php', true, true);
locate_template('/inc/widgets/posts_grid_2.php', true, true);

locate_template('/inc/widgets/posts_grid_3.php', true, true);
