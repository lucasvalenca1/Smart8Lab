<?php
/**
 * @author  Gumtheme
 * @package focus-magazine
 * @since   1.0.0
 */
require get_template_directory(). "/inc/admin/class-focus-html.php";
require get_template_directory(). "/inc/admin/class-focus-admin.php";
