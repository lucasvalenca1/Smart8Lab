<?php
/**
 * The sidebar containing the main widget area
 *
 * @package blogists
 */
?>

<div class="sidebar col-sm-12 col-md-4">
	<div class="theiaStickySidebar">
		<?php do_action( 'before_sidebar' ); ?>

		<aside id="author-block" class="widget author-block">
			<?php
				if ( is_active_sidebar( 'sidebar-author-blocks' ) ) : 
					dynamic_sidebar( 'sidebar-author-blocks' );  
				endif; 
			?>
			<div class="sidebar-socials">
				<?php 
                    $facebook = get_theme_mod('facebook_link');		                            
                    $twitter = get_theme_mod('twitter_link');
                    $instagram = get_theme_mod('instagram_link');	                            
                    $pinterest = get_theme_mod('pinterest_link');
                    $youtube = get_theme_mod('youtube_link');

                    if($facebook){?>
                    	<a type="button" data-toggle="tooltip" data-placement="bottom" target="_blank" href="<?php echo esc_url( $facebook ); ?>" title="FaceBook"><i class="fa fa-facebook"></i></a>
                    <?php }
                    if($twitter){?>
                    	<a type="button" data-toggle="tooltip" data-placement="bottom" target="_blank" href="<?php echo esc_url( $twitter ); ?>" title="Twitter"><i class="fa fa-twitter"></i></a>
                    <?php }
                    if($instagram){?>
                      	<a type="button" data-toggle="tooltip" data-placement="bottom" target="_blank" href="<?php echo esc_url( $instagram ); ?>" title="Instagram"><i class="fa fa-instagram"></i></a>
                    <?php }
                    if($pinterest){?>
                      	<a type="button" data-toggle="tooltip" data-placement="bottom" target="_blank" href="<?php echo esc_url( $pinterest ); ?>" title="Pinterest"><i class="fa fa-pinterest"></i></a>
                    <?php }
                    if($youtube) {?>
                      	<a type="button" data-toggle="tooltip" data-placement="bottom" target="_blank" href="<?php echo esc_url( $youtube ); ?>" title="YouTube"><i class="fa fa-youtube"></i></a>
                    <?php }		                            
                ?>
			</div><!-- .top-socials -->
		</aside>

		<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>
			<aside id="search" class="widget widget_search">
				<?php get_search_form(); ?>
			</aside>

			<aside id="archives" class="widget widget_archive">
				<h3 class="widget-title"><?php esc_html_e( 'Archives', 'blogists' ); ?></h3>
				<ul>
					<?php wp_get_archives( array( 'type' => 'monthly' ) ); ?>
				</ul>
			</aside>

			<aside id="meta" class="widget widget_meta">
				<h3 class="widget-title"><?php esc_html_e( 'Meta', 'blogists' ); ?></h3>
				<ul>
					<?php wp_register(); ?>
					<li><?php wp_loginout(); ?></li>
					<?php wp_meta(); ?>
				</ul>
			</aside>

		<?php endif; ?>

	</div><!-- .sidebar-padder -->
</div>