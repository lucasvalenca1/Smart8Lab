<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content after
 *
 * @package blogists
 */
?>

		<footer id="colophon" class="site-footer" role="contentinfo">
			<div class="container-fluid">
				<div class="rows">

					<?php
						if ( is_active_sidebar( 'footer-blocks' ) ) : 
							dynamic_sidebar( 'footer-blocks' );  
						endif; 
					?>

					<div class="site-footer-inner col-sm-12">
						<div class="col-md-12 site-info text-center">
							<?php do_action( 'blogists_credits' ); ?>
							<?php printf( esc_html__( 'Copyright &copy;', 'blogists' ));  echo date_i18n(esc_html__('Y','blogists')); ?> . All rights reserved.
							<span class="sep"> | </span>
							<a type="button" data-toggle="tooltip" data-placement="top" href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'blogists' ); ?>" rel="generator"><?php printf( esc_html__( 'Proudly powered by %s', 'blogists' ), 'WordPress' ); ?></a>
							<span class="sep"> | </span>
							<a type="button" data-toggle="tooltip" data-placement="top" class="credits" rel="nofollow" href="https://sumanshresthaa.com.np/" target="_blank" title="Theme developed by Suman Shrestha" alt="Theme developed by Suman Shrestha"><?php esc_html_e('Theme by Suman Shrestha.','blogists') ?> </a>
						</div><!-- close .site-info -->	
					</div>

				</div>
			</div><!-- close .container -->
		</footer><!-- close #colophon -->

		<?php wp_footer(); ?>

	</body>
</html>