<?php
/**
 * The Template for displaying all single posts.
 *
 * @package blogists
 */

get_header(); ?>
	
	<?php if (get_header_image()) : ?>
		<img src="<?php header_image(); ?>" alt="">
	<?php else : ?>
		<img src="<?php echo get_template_directory_uri(); ?>/img/default-header-image.jpg" alt="<?php the_title(); ?>">
	<?php endif; ?>

	<div class="breadcrumb">
		<div class="container-fluid">
			<div class="rows">
				<?php echo blogists_breadcrumbs(); ?>
			</div>
		</div>
	</div>

	<div class="home-page">
		<div class="container-fluid">
			<div class="rows">

				<div class="col-md-8">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'content', 'single' ); ?>
						<?php blogists_content_nav( 'nav-below' ); ?>
						<?php blogists_pagination_bars(); ?>
						<?php
							// If comments are open or we have at least one comment, load up the comment template
							if ( comments_open() || '0' != get_comments_number() )
								comments_template();
						?>
					<?php endwhile; // end of the loop. ?>

					<div class="related-posts">
						<h2><?php esc_html_e( 'Related Posts', 'blogists' ); ?></h2>
						<?php
			                $related = get_posts( array( 
			                    'category__in' => wp_get_post_categories($post->ID), 
			                    'numberposts' => 6, 
			                    'post__not_in' => array($post->ID) 
			                    ) );
			                if( $related ) foreach( $related as $post ) {
			                setup_postdata($post); ?>

			                <div class="col-md-6 col-sm-12">
		                		<div class="row">
			                		<div class="news-hover latest small text-center">
					                    <a href="<?php the_permalink(); ?>">
					                    	<?php if (has_post_thumbnail()) : ?>
							          			<?php the_post_thumbnail('blogists-latest-news-large', array('class' => 'img-responsive')); ?>
							        		<?php else : ?>
							          			<div class="no-img full"><i class="fa fa-camera"></i></div>
							        		<?php endif; ?>
					                    	<div class="on-hover">
								                <div class="outer">
								                    <div class="middle">
								                        <div class="inner1">
								                            <h3 class="latest-news small"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
								                        </div>
								                    </div>
								                </div>
							                </div>
							            </a>	                    
					                </div><!-- news-hover latest -->
					            </div>
			                </div><!-- col-md-3 -->
			                <?php }
			                wp_reset_postdata(); 
			            ?>
					</div>

				</div>
				<?php get_sidebar(); ?>
			</div>
		</div>
	</div>
<?php get_footer(); ?>