<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package blogists
 */

get_header(); ?>

	<div class="index-page">
		<div class="container-fluid">
			<div class="rows mobile">

				<div id="carousel-blogists" class="carousel slide" data-ride="carousel">
					<div class="carousel-inner" role="listbox">
						<?php
							$sticky = get_option( 'sticky_posts' ); 
							$args = array(
								'posts_per_page' => 3,
								'paged' => 1,
								'post__in'  => $sticky,
								'ignore_sticky_posts' => 0
							);
							$loop = new WP_Query( $args );
							$cn = 0;
			            	if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();
			            	$cn++;
							?>
							<div class="item">
								<div id="stickies-post">
									<div class="sticky-note"><?php esc_html_e( 'Sticky Post', 'blogists' ); ?></div>
									<div class="post-container"></div>
									<div class="image1">
							            <?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>     
							        </div>
							        <div class="post-caption">					    	
								      	<h3><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h3>
								      	<div class="sticky-cats"><?php the_category(); ?></div>
								    </div>										
								</div><!-- #stickies-post -->
							</div>
						    <?php endwhile;
		      					wp_reset_postdata();  
		      				endif; 
						?>
					</div>
					<a class="left carousel-control" href="#carousel-blogists" data-slide="prev">
						<span class="icon-prev"></span>
					</a>
					<a class="right carousel-control" href="#carousel-blogists" data-slide="next">
						<span class="icon-next"></span>
					</a>
				</div>

			</div>
		</div>
	</div>



	<div class="news-page">
		<div class="container-fluid">
			<div class="rows">

				<div class="latest-news">
					<?php
					global $post;
				   	$args = array( 'numberposts' => 1, 'offset'=> 0, 'ignore_sticky_posts' => 1 );
				   	$myposts = get_posts( $args );
				   	foreach( $myposts as $post ) : setup_postdata($post); ?>   						
	                	<div class="col-md-6 col-sm-12">
	                		<div class="row">
		                		<div class="news-hover latest large text-center">
				                    <a href="<?php the_permalink(); ?>">
				                    	<?php if (has_post_thumbnail()) : ?>
						          			<?php the_post_thumbnail('blogists-latest-news-large', array('class' => 'img-responsive')); ?>
						        		<?php else : ?>
						          			<div class="no-img full"><i class="fa fa-camera"></i></div>
						        		<?php endif; ?>
				                    	<div class="on-hover">
							                <div class="outer">
							                    <div class="middle">
							                        <div class="inner1">
							                            <h3 class="latest-news-single"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
			                							<?php the_excerpt(); ?>
							                        </div>
							                    </div>
							                </div>
						                </div>
						            </a>	                    
				                </div><!-- news-hover latest -->						
		                	</div>
		                </div><!-- col-md-3 -->
					<?php endforeach; ?>

					<?php
					global $post;
				   	$args = array( 'numberposts' => 4, 'offset'=> 1, 'ignore_sticky_posts' => 1 );
				   	$myposts = get_posts( $args );
				   	foreach( $myposts as $post ) : setup_postdata($post); ?>  						
	                	<div class="col-md-3 col-sm-12">
	                		<div class="row">
		                		<div class="news-hover latest small text-center">
				                    <a href="<?php the_permalink(); ?>">
				                    	<?php if (has_post_thumbnail()) : ?>
						          			<?php the_post_thumbnail('blogists-latest-news-small', array('class' => 'img-responsive')); ?>
						        		<?php else : ?>
						          			<div class="no-img full"><i class="fa fa-camera"></i></div>
						        		<?php endif; ?>
				                    	<div class="on-hover">
							                <div class="outer">
							                    <div class="middle">
							                        <div class="inner1">
							                            <h3 class="latest-news small"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
							                        </div>
							                    </div>
							                </div>
						                </div>
						            </a>	                    
				                </div><!-- news-hover latest -->
				            </div>
		                </div><!-- col-md-3 -->
					<?php endforeach; ?>
				</div><!-- latest-news -->

			</div><!-- .rows -->
		</div><!-- .container-fluid -->
	</div><!-- .news-page -->


	<div class="clearfix"></div>





	<div class="home-page">
		<div class="container-fluid">
			<div class="roww">

				<div class="col-md-8">

					<div class="category-page">
						<div class="blocknews">
							<h2 class="titleSmall"><?php echo ''.esc_attr( get_cat_name( get_theme_mod('blog_category_display1') ) ).''?></h2>		            
				            <?php
				                $cid = get_theme_mod('blog_category_display1');
				                $category_link = get_category_link($cid);
				                $blogists_cat = get_category($cid);
				                if ($blogists_cat) {
					        ?>        	
				            <?php
				                $args = array(
				                  'posts_per_page' => 1,
				                  'paged' => 1,
				                  'ignore_sticky_posts' => 1,
				                  'offset' => 0,
				                  'cat' => $cid
				                );
				                $loop = new WP_Query($args);  
				                $cn = 0;
				                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
				            ?>
							<div class="news-hover special text-center">
			                    <a href="<?php the_permalink(); ?>">
			                    	<?php if (has_post_thumbnail()) : ?>
					          			<?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>
					        		<?php else : ?>
					          			<div class="no-img full"><i class="fa fa-camera"></i></div>
					        		<?php endif; ?>
			                    	<div class="on-hover">
						                <div class="outer">
						                    <div class="middle">
						                        <div class="inner1">
						                            <i class="fa fa-search"></i>
						                        </div>
						                    </div>
						                </div>
					                </div>
					            </a>	                    
			                </div>	<!-- .news-hover special -->					
		                	<h3 class="news-head"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
		                	<?php the_excerpt(); ?>
							<?php  
				                endwhile;
				                    wp_reset_postdata(); 
				                endif;
				                    }
				            ?>

				            <div class="clearfix"></div>


				            <div class="sub-posts-lists row">
		            			<ul class="sub-post-bordered">
						            <?php
						                $cid = get_theme_mod('blog_category_display1');
						                $category_link = get_category_link($cid);
						                $blogists_cat = get_category($cid);
						                if ($blogists_cat) {
							        ?>        	
						            <?php
						                $args = array(
						                  'posts_per_page' => 3,
						                  'paged' => 1,
						                  'ignore_sticky_posts' => 1,
						                  'offset' => 1,
						                  'cat' => $cid
						                );
						                $loop = new WP_Query($args);  
						                $cn = 0;
						                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
						            ?>						            
						            <li class="sub-posts">
						            	<div class="row">
											<div class="col-md-4 col-sm-12">
					                    		<div class="news-hover default text-center">
								                    <a href="<?php the_permalink(); ?>">
								                    	<?php if (has_post_thumbnail()) : ?>
										          			<?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
										        		<?php else : ?>
										          			<div class="no-img default"><i class="fa fa-camera"></i></div>
										        		<?php endif; ?>
								                    	<div class="on-hover">
											                <div class="outer">
											                    <div class="middle">
											                        <div class="inner1">
											                            <i class="fa fa-search"></i>
											                        </div>
											                    </div>
											                </div>
										                </div>
										            </a>	                    
								                </div>
					                    	</div>
					                    	<div class="col-md-8 col-sm-12">
					                    		<h3 class="headline"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
					                    	</div>
					                    </div>
				                    </li><!-- .sub-posts -->
				                    <?php  
						                endwhile;
						                    wp_reset_postdata(); 
						                endif;
						                    }
						            ?>
			                    </ul><!-- .sub-post-bordered -->
					            

			            		<ul class="sub-post-bordered-none">
						            <?php
						                $cid = get_theme_mod('blog_category_display1');
						                $category_link = get_category_link($cid);
						                $blogists_cat = get_category($cid);
						                if ($blogists_cat) {
							        ?>        	
						            <?php
						                $args = array(
						                  'posts_per_page' => 3,
						                  'paged' => 1,
						                  'ignore_sticky_posts' => 1,
						                  'offset' => 4,
						                  'cat' => $cid
						                );
						                $loop = new WP_Query($args);  
						                $cn = 0;
						                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
						            ?>						            
						            <li class="sub-posts">
						            	<div class="row">
											<div class="col-md-4 col-sm-12">
					                    		<div class="news-hover default text-center">
								                    <a href="<?php the_permalink(); ?>">
								                    	<?php if (has_post_thumbnail()) : ?>
										          			<?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
										        		<?php else : ?>
										          			<div class="no-img default"><i class="fa fa-camera"></i></div>
										        		<?php endif; ?>
								                    	<div class="on-hover">
											                <div class="outer">
											                    <div class="middle">
											                        <div class="inner1">
											                            <i class="fa fa-search"></i>
											                        </div>
											                    </div>
											                </div>
										                </div>
										            </a>	                    
								                </div>
					                    	</div>
					                    	<div class="col-md-8 col-sm-12">
					                    		<h3 class="headline"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
					                    	</div>
					                    </div>
				                    </li><!-- .sub-posts -->
				                    <?php  
						                endwhile;
						                    wp_reset_postdata(); 
						                endif;
						                    }
						            ?>
			                    </ul><!-- .sub-post-bordered -->
						    </div><!-- .sub-posts-lists -->

						</div><!-- .block-news -->	
					</div><!-- .category-page -->






					<div class="category-page-small">
						<div class="row">
							<div class="col-md-6 col-sm-12">

								<div class="blocknews">
									<h2 class="titleSmall"><?php echo ''.esc_attr( get_cat_name( get_theme_mod('blog_category_display2') ) ).''?></h2>

									<div class="row">	            
							            <?php
							                $cid = get_theme_mod('blog_category_display2');
							                $category_link = get_category_link($cid);
							                $blogists_cat = get_category($cid);
							                if ($blogists_cat) {
								        ?>        	
							            <?php
							                $args = array(
							                  'posts_per_page' => 1,
							                  'paged' => 1,
							                  'ignore_sticky_posts' => 1,
							                  'offset' => 0,
							                  'cat' => $cid
							                );
							                $loop = new WP_Query($args);  
							                $cn = 0;
							                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
							            ?>
							            <div class="col-md-12">
											<div class="news-hover special text-center">
							                    <a href="<?php the_permalink(); ?>">
							                    	<?php if (has_post_thumbnail()) : ?>
									          			<?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>
									        		<?php else : ?>
									          			<div class="no-img full"><i class="fa fa-camera"></i></div>
									        		<?php endif; ?>
							                    	<div class="on-hover">
										                <div class="outer">
										                    <div class="middle">
										                        <div class="inner1">
										                            <i class="fa fa-search"></i>
										                        </div>
										                    </div>
										                </div>
									                </div>
									            </a>	                    
							                </div><!-- .news-hover special -->						
						                	<h3 class="news-head"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
						                	<?php the_excerpt(); ?>
						                </div><!-- .col-md-6 -->
										<?php  
							                endwhile;
							                    wp_reset_postdata(); 
							                endif;
							                    }
							            ?>
							        </div><!-- .row -->

				            		<div class="clearfix"></div>


				            		<ul class="sub-posts-lists">
							            <?php
							                $cid = get_theme_mod('blog_category_display2');
							                $category_link = get_category_link($cid);
							                $blogists_cat = get_category($cid);
							                if ($blogists_cat) {
								        ?>        	
							            <?php
							                $args = array(
							                  'posts_per_page' => 6,
							                  'paged' => 1,
							                  'ignore_sticky_posts' => 1,
							                  'offset' => 1,
							                  'cat' => $cid
							                );
							                $loop = new WP_Query($args);  
							                $cn = 0;
							                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
							            ?>
									    <li class="sub-posts">
							            	<div class="row">
												<div class="col-md-4 col-sm-12">
						                    		<div class="news-hover default text-center">
									                    <a href="<?php the_permalink(); ?>">
									                    	<?php if (has_post_thumbnail()) : ?>
											          			<?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
											        		<?php else : ?>
											          			<div class="no-img default"><i class="fa fa-camera"></i></div>
											        		<?php endif; ?>
									                    	<div class="on-hover">
												                <div class="outer">
												                    <div class="middle">
												                        <div class="inner1">
												                            <i class="fa fa-search"></i>
												                        </div>
												                    </div>
												                </div>
											                </div>
											            </a>	                    
									                </div>
						                    	</div>
						                    	<div class="col-md-8 col-sm-12">
						                    		<h3 class="headline"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
						                    	</div>
						                    </div>
					                    </li><!-- .sub-posts -->
										<?php  
							                endwhile;
							                    wp_reset_postdata(); 
							                endif;
							                    }
							            ?>
								    </ul><!-- .sub-posts-lists -->

								</div><!-- .blocknews -->
							</div>



							<div class="col-md-6 col-sm-12">
								<div class="blocknews">
									<h2 class="titleSmall"><?php echo ''.esc_attr( get_cat_name( get_theme_mod('blog_category_display3') ) ).''?></h2>

									<div class="row">	            
							            <?php
							                $cid = get_theme_mod('blog_category_display3');
							                $category_link = get_category_link($cid);
							                $blogists_cat = get_category($cid);
							                if ($blogists_cat) {
								        ?>        	
							            <?php
							                $args = array(
							                  'posts_per_page' => 1,
							                  'paged' => 1,
							                  'ignore_sticky_posts' => 1,
							                  'offset' => 0,
							                  'cat' => $cid
							                );
							                $loop = new WP_Query($args);  
							                $cn = 0;
							                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
							            ?>
							            <div class="col-md-12">
											<div class="news-hover special text-center">
							                    <a href="<?php the_permalink(); ?>">
							                    	<?php if (has_post_thumbnail()) : ?>
									          			<?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>
									        		<?php else : ?>
									          			<div class="no-img full"><i class="fa fa-camera"></i></div>
									        		<?php endif; ?>
							                    	<div class="on-hover">
										                <div class="outer">
										                    <div class="middle">
										                        <div class="inner1">
										                            <i class="fa fa-search"></i>
										                        </div>
										                    </div>
										                </div>
									                </div>
									            </a>	                    
							                </div><!-- .news-hover special -->						
						                	<h3 class="news-head"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
						                	<?php the_excerpt(); ?>
						                </div><!-- .col-md-6 -->
										<?php  
							                endwhile;
							                    wp_reset_postdata(); 
							                endif;
							                    }
							            ?>
							        </div><!-- .row -->

				            		<div class="clearfix"></div>


				            		<ul class="sub-posts-lists">
							            <?php
							                $cid = get_theme_mod('blog_category_display3');
							                $category_link = get_category_link($cid);
							                $blogists_cat = get_category($cid);
							                if ($blogists_cat) {
								        ?>        	
							            <?php
							                $args = array(
							                  'posts_per_page' => 6,
							                  'paged' => 1,
							                  'ignore_sticky_posts' => 1,
							                  'offset' => 1,
							                  'cat' => $cid
							                );
							                $loop = new WP_Query($args);  
							                $cn = 0;
							                if ($loop->have_posts()) :  while ($loop->have_posts()) : $loop->the_post();$cn++;
							            ?>
								        <li class="sub-posts">
							            	<div class="row">
												<div class="col-md-4 col-sm-12">
						                    		<div class="news-hover default text-center">
									                    <a href="<?php the_permalink(); ?>">
									                    	<?php if (has_post_thumbnail()) : ?>
											          			<?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
											        		<?php else : ?>
											          			<div class="no-img default"><i class="fa fa-camera"></i></div>
											        		<?php endif; ?>
									                    	<div class="on-hover">
												                <div class="outer">
												                    <div class="middle">
												                        <div class="inner1">
												                            <i class="fa fa-search"></i>
												                        </div>
												                    </div>
												                </div>
											                </div>
											            </a>	                    
									                </div>
						                    	</div>
						                    	<div class="col-md-8 col-sm-12">
						                    		<h3 class="headline"><a itemprop="url" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
						                    	</div>
						                    </div>
					                    </li><!-- .sub-posts -->
										<?php  
							                endwhile;
							                    wp_reset_postdata(); 
							                endif;
							                    }
							            ?>
								    </ul><!-- .sub-posts-lists -->

								</div><!-- .blocknews -->
							</div>

						</div>
					</div><!-- .category-page-small -->

				</div><!-- .col-md-8 -->

				<?php get_sidebar(); ?>

			</div><!-- .rows -->
		</div><!-- .container-fluid -->
	</div><!-- .index-page -->
<?php get_footer(); ?>