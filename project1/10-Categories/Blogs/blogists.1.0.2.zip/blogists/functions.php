<?php
/**
 * blogists functions and definitions
 *
 * @package blogists
 */
 
 /**
  * Store the theme's directory path and uri in constants
  */
 define('THEME_DIR_PATH', get_template_directory());
 define('THEME_DIR_URI', get_template_directory_uri());



/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) )
	$content_width = 750; /* pixels */

if ( ! function_exists( 'blogists_setup' ) ) :


/**
 * Set up theme defaults and register support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 */
function blogists_setup() {
	global $cap, $content_width;

	// Add html5 behavior for some theme elements
	add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );


    // This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style();


	/**
	 * Add default posts and comments RSS feed links to head
	*/
	add_theme_support( 'automatic-feed-links' );


	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );


	/**
	 * Enable support for Post Thumbnails on posts and pages
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	*/
	add_theme_support( 'post-thumbnails' );
	add_image_size( 'blogists-latest-news-large', 650,450, array( 'top', 'center' ) ); // News Post Thumbnail Image 
	add_image_size( 'blogists-latest-news-small', 450,350, array( 'top', 'center' ) ); // News Post Thumbnail Image 



	/**
	 * Enable support for Post Formats
	*/
	add_theme_support( 'post-formats', array( 'aside', 'image', 'video', 'quote', 'link' ) );


	/**
	 * Setup the WordPress core custom background feature.
	*/
	add_theme_support( 'custom-background', apply_filters( 'blogists_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
		) ) );


	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 80,
		'width'       => 300,
		'flex-width'  => true,
		'flex-height' => true,
	) ); 

	
	/**
	 * Make theme available for translation
	 * Translations can be filed in the /languages/ directory
	 * If you're building a theme based on blogists, use a find and replace
	 * to change 'blogists' to the name of your theme in all the template files
	*/
	load_theme_textdomain( 'blogists', THEME_DIR_PATH . '/languages' );



	/**
	 * This theme uses wp_nav_menu() in one location.
	*/
	register_nav_menus( array(
		'primary'  => __( 'Header top menu', 'blogists' ),
		) );

}
endif; // blogists_setup
add_action( 'after_setup_theme', 'blogists_setup' );




/**
 * Register widgetized area and update sidebar with default widgets
 */
function blogists_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'blogists' ),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
	    'name'          => __( 'Sidebar Author Blocks', 'blogists' ),
	    'id'            => 'sidebar-author-blocks',
	    'before_widget' => '<div class="widget author-blocks">',
		'after_widget'  => '</div>',
	    'before_title'  => '<h3 class="widget-title">',
	    'after_title'   => '</h3>',
    ) );


	register_sidebar( array(
	    'name'          => __( 'Footer Blocks', 'blogists' ),
	    'id'            => 'footer-blocks',
	    'before_widget' => '<div id="%1$s" class="col-md-4 col-sm-12 footer-blocks">',
	    'after_widget'  => '</div>',
	    'before_title'  => '<h3 class="widgettitle">',
	    'after_title'   => '</h3>',
    ) );
}
add_action( 'widgets_init', 'blogists_widgets_init' );




/**
 * Enqueue scripts and styles
 */
function blogists_scripts() {

	// Import the necessary WP CSS additions
	wp_enqueue_style( 'blogists-bootstrap-wp', THEME_DIR_URI . '/includes/css/bootstrap-wp.css' );

	// load bootstrap css
	wp_enqueue_style( 'bootstrap', THEME_DIR_URI . '/includes/resources/bootstrap/css/bootstrap.min.css' );

	// load Font Awesome css
	wp_enqueue_style( 'font-awesome', THEME_DIR_URI . '/includes/css/font-awesome.min.css', false, '4.1.0' );

	// load blogists styles
	wp_enqueue_style( 'blogists-style', get_stylesheet_uri() );

	// load bootstrap js
	wp_enqueue_script('bootstrapjs', THEME_DIR_URI . '/includes/resources/bootstrap/js/bootstrap.min.js', array('jquery') );

	// load bootstrap wp js
	wp_enqueue_script( 'blogists-bootstrapwp', THEME_DIR_URI . '/includes/js/bootstrap-wp.js', array('jquery') );

	// load sticky sidebar js
	wp_enqueue_script( 'theia-sticky-sidebar', THEME_DIR_URI . '/includes/js/theia-sticky-sidebar.js', array('jquery') );


	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

}
add_action( 'wp_enqueue_scripts', 'blogists_scripts' );




/**
 * Implement the Custom Header feature.
 */
require THEME_DIR_PATH . '/includes/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require THEME_DIR_PATH . '/includes/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require THEME_DIR_PATH . '/includes/extras.php';

/**
 * Customizer additions.
 */
require THEME_DIR_PATH . '/includes/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require THEME_DIR_PATH . '/includes/jetpack.php';

/**
 * Load custom WordPress nav walker.
 */
require THEME_DIR_PATH . '/includes/bootstrap-wp-navwalker.php';