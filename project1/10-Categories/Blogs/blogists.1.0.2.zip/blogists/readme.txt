Theme Name: blogists
Theme URI: https://sumanshresthaa.com.np/theme/blogists
Author: Suman Shrestha
Author URI: http://sumanshresthaa.com.np/
Description: Blogists is a yet another clean, beautiful and minimalist WordPress theme truly designed for the bloggers, writers and travelers. Based on Bootstrap Grid framework, it is Responsive and also included with Sticky Menu and Sticky Sidebar features. It has a Sticky Slider Posts with attractive design layout to influence the viewers and magazine type blog layout with Customizer as Theme Options to choose the blog categories for homepage. Most of all, a perfect blog theme to start with your articles. Demo: https://sumanshresthaa.com.np/blogist
Version: 1.0.2
License: GNU General Public License v3.0 /
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: blogists
Tags: blog, news, entertainment, two-columns, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, featured-images, flexible-header, sticky-post,  theme-options, threaded-comments, translation-ready

Requires at least: 4.5
Tested up to: 5.2.2
Stable tag: 1.0.2

Blogists WordPress Theme, Copyright 2019 Suman Shrestha
Blogists is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Blogists WordPress Theme is derived from Underscores WordPress Theme, Copyright 2013 Automattic, Inc.
Underscores WordPress Theme is distributed under the terms of the GNU GPL

Blogists WordPress Theme bundles the following third-party resources:

1. Bootstrap
 * Bootstrap v3.3.6 (http://getbootstrap.com)
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

 * Generated using the Bootstrap Customizer (http://getbootstrap.com/customize/?id=f58353a31151a8c05d7c)
 * Config saved to config.json and https://gist.github.com/f58353a31151a8c05d7c

2. wp_bootstrap_navwalker
* Class Name: wp_bootstrap_navwalker
* GitHub URI: https://github.com/twittem/wp-bootstrap-navwalker

3. Font Awesome
 * http://fontawesome.io - @fontawesome
 * License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

4. Theia Sticky Sidebar v1.7.0
 * Copyright 2013-2016 WeCodePixels and other contributors
 * https://github.com/WeCodePixels/theia-sticky-sidebar

5. Photo Credit
 * https://stocksnap.io/photo/URFCO7DAGB
 * https://stocksnap.io/photo/OXVQOYP7IQ
 * https://stocksnap.io/photo/KQECHSBAOC
 * https://stocksnap.io/photo/BCEIHTVB9R
 * https://stocksnap.io/license



*************************************************************
== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frontpage Setup ==
1. create a page from Pages -> Add New name it "Home". create another page name it "Blog".
2. go to Seetings -> Reading -> Switch Front Page Display to static front Page.
3. select "Home" page for front page and "Blog" for Post page.

you can change or keep pages name that you like. 


== Frequently Asked Questions ==
= Does this theme support any plugins? =
Blogist includes support for Infinite Scroll in Jetpack.



*************************************************************
== Changelog ==

= 1.0.2 - June 20 2019 =
* Fixed some bugs, added sticky posts slider for front-page, related posts for single post and CSS for Gutenberg Editor.

= 1.0.1 - January 25 2019 =
* Fixes as per review's guidence

= 1.0.0 - Octuber 25 2018 =
* Initial release



*************************************************************

Thanks for using blogists Theme.
We hope you enjoy it!

*************************************************************