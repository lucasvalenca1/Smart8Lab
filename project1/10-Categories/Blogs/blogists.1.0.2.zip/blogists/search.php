<?php
/**
 * The template for displaying Search Results pages.
 *
 * @package blogists
 */

get_header(); ?>

	<?php if (get_header_image()) : ?>
		<img src="<?php header_image(); ?>" alt="">
	<?php else : ?>
		<img src="<?php echo get_template_directory_uri(); ?>/img/default-header-image.jpg" alt="<?php the_title(); ?>">
	<?php endif; ?>

	<div class="breadcrumb">
		<div class="container-fluid">
			<div class="rows">
				<?php echo blogists_breadcrumbs(); ?>
			</div>
		</div>
	</div>

	<div class="home-page">
		<div class="container-fluid">
			<div class="rows">

				<div class="col-md-8">
					<?php if ( have_posts() ) : ?>
						<header>
							<h2 class="page-title"><?php printf( esc_html__( 'Search Results for: %s', 'blogists' ), '<span>' . get_search_query() . '</span>' ); ?></h2>
						</header><!-- .page-header -->

						<?php // start the loop. ?>
						<?php while ( have_posts() ) : the_post(); ?>
							<?php get_template_part( 'content', 'search' ); ?>
						<?php endwhile; ?>
						<?php blogists_pagination_bars(); ?>
					<?php else : ?>
						<?php get_template_part( 'no-results', 'search' ); ?>
					<?php endif; // end of loop. ?>
				</div>

				<?php get_sidebar(); ?>

			</div>
		</div>
	</div>
<?php get_footer(); ?>