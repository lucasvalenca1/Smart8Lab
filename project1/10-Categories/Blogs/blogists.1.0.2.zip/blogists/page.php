<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package blogists
 */

get_header(); ?>
	<?php if (get_header_image()) : ?>
		<img src="<?php header_image(); ?>" alt="">
	<?php else : ?>
		<img src="<?php echo get_template_directory_uri(); ?>/img/default-header-image.jpg" alt="<?php the_title(); ?>">
	<?php endif; ?>

	<div class="breadcrumb">
		<div class="container-fluid">
			<div class="rows">
				<?php echo blogists_breadcrumbs(); ?>
			</div>
		</div>
	</div>

	<div class="home-page">
		<div class="container-fluid">
			<div class="rows">

				<div class="col-md-8">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'content', 'page' ); ?>
						<?php
							// If comments are open or we have at least one comment, load up the comment template
							if ( comments_open() || '0' != get_comments_number() )
								comments_template();
						?>
					<?php endwhile; // end of the loop. ?>
				</div>

				<?php get_sidebar(); ?>

			</div>
		</div>
	</div>
<?php get_footer(); ?>