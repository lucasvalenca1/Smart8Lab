<?php
/**
 * Blogists Theme Customizer
 *
 * @package blogists
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function blogists_customize_register( $wp_customize ) {
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';




	$wp_customize->add_panel( 'theme_option', array(
        'priority' => 60,
        'title' => __( 'Blogists Theme Option', 'blogists' ),
        'description' => __( 'Lets configure your site with Blogists Theme Option', 'blogists' ),
    ));    


    /**********************************************/
    /********** SOCIAL ICON LINKS SECTION ***********/
    /**********************************************/

    $wp_customize->add_section('blogists_social_section',array(
        'priority' => 1,
        'title' => __('Top Header Socials Section','blogists'),
        'description' => __('Customize Top Header Social Section in Homepage. Make sure that you have filled all the social links, blank field will not be displayed in site and it will be hidden by default.', 'blogists'),
        'panel' => 'theme_option'
    ));

    $wp_customize->add_setting(
        'facebook_link',
            array(
            'sanitize_callback' => 'esc_url_raw',
            'capability' => 'edit_theme_options',
            'default' => '',
    ));
    $wp_customize->add_control(
        'facebook_link',
            array(
            'label' => __('Facebook link URL', 'blogists'),
            'section' => 'blogists_social_section',
            'settings' => 'facebook_link',
            'type' => 'url',
    ));

    $wp_customize->add_setting(
        'twitter_link',
            array(
            'sanitize_callback' => 'esc_url_raw',
            'capability' => 'edit_theme_options',
            'default' => '',
    ));
    $wp_customize->add_control(
        'twitter_link',
            array(
            'label' => __('Twitter link URL', 'blogists'),
            'section' => 'blogists_social_section',
            'settings' => 'twitter_link',
            'type' => 'url',
    ));

    $wp_customize->add_setting(
        'linkedin_link',
            array(
            'sanitize_callback' => 'esc_url_raw',
            'capability' => 'edit_theme_options',
            'default' => '',
    ));
    $wp_customize->add_control(
        'linkedin_link',
            array(
            'label' => __('LinkedIn link URL', 'blogists'),
            'section' => 'blogists_social_section',
            'settings' => 'linkedin_link',
            'type' => 'url',
    ));

    $wp_customize->add_setting(
        'instagram_link',
            array(
            'sanitize_callback' => 'esc_url_raw',
            'capability' => 'edit_theme_options',
            'default' => '',
    ));      
    $wp_customize->add_control(
        'instagram_link',
            array(
            'label' => __('Instagram link URL', 'blogists'),
            'section' => 'blogists_social_section',
            'settings' => 'instagram_link',
            'type' => 'url',
    ));

    $wp_customize->add_setting(
        'youtube_link',
            array(
            'sanitize_callback' => 'esc_url_raw',
            'capability' => 'edit_theme_options',
            'default' => '',
    ));      
    $wp_customize->add_control(
        'youtube_link',
            array(
            'label' => __('YouTube link URL', 'blogists'),
            'section' => 'blogists_social_section',
            'settings' => 'youtube_link',
            'type' => 'url',
    )); 



    /**********************************************/
    /********** BLOGS CATEGORY SECTION ***********/
    /**********************************************/

    $wp_customize->add_section('blogists_blogs_section',array(
        'priority' => 2,
        'title' => __('Homepage Blog Section','blogists'),
        'description' => __('Choose Blog Category Selection in Homepage.','blogists'),
        'panel' => 'theme_option'
    ));    

    $wp_customize->add_setting('blog_category_display1',array(
        'sanitize_callback' => 'blogists_sanitize_category',
        'default' => ''
    ));

    $wp_customize->add_control(new blogists_Category_Dropdown_Custom_Control($wp_customize,'blog_category_display1',array(
        'label' => __('Choose first blog category to display in homepage','blogists'),
        'section' => 'blogists_blogs_section',
        'settings' => 'blog_category_display1',
        'type'=> 'dropdown-taxonomies',
        )  
    ));


    $wp_customize->add_setting('blog_category_display2',array(
        'sanitize_callback' => 'blogists_sanitize_category',
        'default' => ''
    ));

    $wp_customize->add_control(new blogists_Category_Dropdown_Custom_Control($wp_customize,'blog_category_display2',array(
        'label' => __('Choose second blog category to display in homepage','blogists'),
        'section' => 'blogists_blogs_section',
        'settings' => 'blog_category_display2',
        'type'=> 'dropdown-taxonomies',
        )  
    ));


    $wp_customize->add_setting('blog_category_display3',array(
        'sanitize_callback' => 'blogists_sanitize_category',
        'default' => ''
    ));

    $wp_customize->add_control(new blogists_Category_Dropdown_Custom_Control($wp_customize,'blog_category_display3',array(
        'label' => __('Choose third blog category to display in homepage','blogists'),
        'section' => 'blogists_blogs_section',
        'settings' => 'blog_category_display3',
        'type'=> 'dropdown-taxonomies',
        )  
    ));

}
add_action( 'customize_register', 'blogists_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function blogists_customize_preview_js() {
	wp_enqueue_script( 'blogists_customizer', get_template_directory_uri() . '/includes/js/customizer.js', array( 'customize-preview' ), '20130508', true );
}
add_action( 'customize_preview_init', 'blogists_customize_preview_js' );


function blogists_sanitize_text( $input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}

function blogists_sanitize_category($input){
  $output=intval($input);
  return $output;
}



if ( ! class_exists( 'WP_Customize_Control' ) )
    return NULL;

/**
 * A class to create a dropdown for all categories in your wordpress site
 */
class blogists_Category_Dropdown_Custom_Control extends WP_Customize_Control
    {
    private $cats = false;
    public function __construct($manager, $id, $args = array(), $options = array())
    {
      $this->cats = get_categories($options);
      parent::__construct( $manager, $id, $args );
    }
    /**
     * Render the content of the category dropdown
     *
     * @return HTML
     */
    public function render_content()
      {
        if(!empty($this->cats))
        {
        ?>
          <label>
            <span class="customize-category-select-control"><?php echo esc_html( $this->label ); ?></span>
            <select <?php $this->link(); ?>>
                 <?php
                      foreach ( $this->cats as $cat )
                      {
                          printf('<option value="%s" %s>%s</option>', esc_attr($cat->term_id), selected($this->value(), esc_attr($cat->term_id), false), esc_attr($cat->cat_name));
                      }
                 ?>
            </select>
          </label>
        <?php
      }
  }
}