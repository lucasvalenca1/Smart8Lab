<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package blogists
 */

if ( ! function_exists( 'blogists_content_nav' ) ) :
/**
 * Display navigation to next/previous pages when applicable
 */
function blogists_content_nav( $nav_id ) {
	global $wp_query, $post;

	// Don't print empty markup on single pages if there's nowhere to navigate.
	if ( is_single() ) {
		$previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
		$next = get_adjacent_post( false, '', false );

		if ( ! $next && ! $previous )
			return;
	}

	// Don't print empty markup in archives if there's only one page.
	if ( $wp_query->max_num_pages < 2 && ( is_home() || is_archive() || is_search() ) )
		return;

	$nav_class = ( is_single() ) ? 'post-navigation' : 'paging-navigation';

	?>
	<nav role="navigation" id="<?php echo esc_attr( $nav_id ); ?>" class="<?php echo esc_url( $nav_class ); ?>">
		<h1 class="screen-reader-text"><?php esc_html_e( 'Post navigation', 'blogists' ); ?></h1>
		<ul class="pager">

		<?php if ( is_single() ) : // navigation links for single posts ?>

			<?php previous_post_link( '<li class="nav-previous previous">%link</li>', '<span class="meta-nav">' . _x( '&larr;', 'Previous post link', 'blogists' ) . '</span> %title' ); ?>
			<?php next_post_link( '<li class="nav-next next">%link</li>', '%title <span class="meta-nav">' . _x( '&rarr;', 'Next post link', 'blogists' ) . '</span>' ); ?>

		<?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : // navigation links for home, archive, and search pages ?>

			<?php if ( get_next_posts_link() ) : ?>
			<li class="nav-previous previous"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'blogists' ) ); ?></li>
			<?php endif; ?>

			<?php if ( get_previous_posts_link() ) : ?>
			<li class="nav-next next"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'blogists' ) ); ?></li>
			<?php endif; ?>

		<?php endif; ?>

		</ul>
	</nav><!-- #<?php echo esc_html( $nav_id ); ?> -->
	<?php
}
endif; // blogists_content_nav






if ( ! function_exists( 'blogists_the_attached_image' ) ) :
/**
 * Prints the attached image with a link to the next attached image.
 */
function blogists_the_attached_image() {
	$post                = get_post();
	$attachment_size     = apply_filters( 'blogists_attachment_size', array( 1200, 1200 ) );
	$next_attachment_url = wp_get_attachment_url();

	/**
	 * Grab the IDs of all the image attachments in a gallery so we can get the
	 * URL of the next adjacent image in a gallery, or the first image (if
	 * we're looking at the last image in a gallery), or, in a gallery of one,
	 * just the link to that image file.
	 */
	$attachment_ids = get_posts( array(
		'post_parent'    => $post->post_parent,
		'fields'         => 'ids',
		'numberposts'    => -1,
		'post_status'    => 'inherit',
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'order'          => 'ASC',
		'orderby'        => 'menu_order ID'
	) );

	// If there is more than 1 attachment in a gallery...
	if ( count( $attachment_ids ) > 1 ) {
		foreach ( $attachment_ids as $attachment_id ) {
			if ( $attachment_id == $post->ID ) {
				$next_id = current( $attachment_ids );
				break;
			}
		}

		// get the URL of the next image attachment...
		if ( $next_id )
			$next_attachment_url = get_attachment_link( $next_id );

		// or get the URL of the first image attachment.
		else
			$next_attachment_url = get_attachment_link( array_shift( $attachment_ids ) );
	}

	printf( '<a href="%1$s" title="%2$s" rel="attachment">%3$s</a>',
		esc_url( $next_attachment_url ),
		the_title_attribute( array( 'echo' => false ) ),
		wp_get_attachment_image( $post->ID, $attachment_size )
	);
}
endif;






if ( ! function_exists( 'blogists_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function blogists_posted_on() {
	$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() )
	);

	$time_string = sprintf( '<a href="%1$s" title="%2$s" rel="bookmark">%3$s</a>',
		esc_url( get_permalink() ),
		esc_attr( get_the_time() ),
		$time_string
	);

	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ){
		$time_string_update = '<time class="updated" datetime="%1$s">%2$s</time>';
		$time_string_update = sprintf( $time_string_update,
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);
		$time_string_update = sprintf( '<a href="%1$s" title="%2$s" rel="bookmark">%3$s</a>',
			esc_url( get_permalink() ),
			esc_attr( get_the_time() ),
			$time_string_update
		);
		$time_string .= __(', updated on ', 'blogists') . $time_string_update;
	}

	printf( __( '<span class="posted-on">Posted on %1$s</span><span class="byline"> by %2$s</span>', 'blogists' ),
		$time_string,
		sprintf( '<span class="author vcard"><a class="url fn n" href="%1$s" title="%2$s">%3$s</a></span>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_attr( sprintf( __( 'View all posts by %s', 'blogists' ), get_the_author() ) ),
			esc_html( get_the_author() )
		)
	);
}
endif;






if ( ! function_exists( 'blogists_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function blogists_entry_footer() {
	// Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_html__( ', ', 'blogists' ) );
		if ( $categories_list && blogists_categorized_blog() ) {
			printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s', 'blogists' ) . '</span>', $categories_list ); // WPCS: XSS OK.
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', esc_html__( ', ', 'blogists' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'blogists' ) . '</span>', $tags_list ); // WPCS: XSS OK.
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( esc_html__( 'Leave a comment', 'blogists' ), esc_html__( '1 Comment', 'blogists' ), esc_html__( '% Comments', 'blogists' ) );
		echo '</span>';
	}

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'blogists' ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
		),
		'<span class="edit-link">',
		'</span>'
	);
}
endif;





/**
 * Returns true if a blog has more than 1 category
 */
function blogists_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'all_the_cool_cats' ) ) ) {
		// Create an array of all the categories that are attached to posts
		$all_the_cool_cats = get_categories( array(
			'hide_empty' => 1,
		) );

		// Count the number of categories that are attached to the posts
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'all_the_cool_cats', $all_the_cool_cats );
	}

	if ( '1' != $all_the_cool_cats ) {
		// This blog has more than 1 category so blogists_categorized_blog should return true
		return true;
	} else {
		// This blog has only 1 category so blogists_categorized_blog should return false
		return false;
	}
}




function blogists_comment($comment, $args, $depth) {
	// get theme data.
	global $comment_data;
	// translations.
	$leave_reply = $comment_data['translation_reply_to_coment'] ? $comment_data['translation_reply_to_coment'] : __('Reply', 'blogists');?>
        <div class="row the-comment">
        	<div class="row">
        		<div class="col-md-12">
		            <div class="col-md-2">
		            <?php echo get_avatar($comment, $size = '80'); ?>
		            </div>
	            	<div class="col-md-10">
	                	<div class="comment-items">
	                    	<h4 class="comment-item comment-author"><?php comment_author();?></h4>
		                    <h5 class="comment-item comment-date">
		                        <?php if (('d M  y') == get_option('date_format')): ?>
		                        <?php comment_date('F j, Y');?>
		                        <?php else: ?>
		                        <?php comment_date();?>
		                        <?php endif;?>
		                        <?php esc_html_e('at', 'blogists');?>&nbsp;<?php comment_time('g:i a');?>
		                    </h5>
	                    	<?php comment_reply_link(array_merge($args, array('reply_text' => $leave_reply, 'depth' => $depth, 'max_depth' => $args['max_depth'])))?>
	                    	<?php if ($comment->comment_approved == '0'): ?>
	                    	<em class="comment-item comment-awaiting-moderation"><?php esc_html_e('Your comment is awaiting moderation.', 'blogists');?></em>
	                    	<?php endif;?>
	                	</div>
	                </div>
	            </div>
	            <div class="col-md-12">
	                <div class="comment-text"><?php comment_text();?></div>
	            </div>
	        </div>
        </div>
        <?php
}




/**
 * Flush out the transients used in blogists_categorized_blog
 */
function blogists_category_transient_flusher() {
	// Like, beat it. Dig?
	delete_transient( 'all_the_cool_cats' );
}
add_action( 'edit_category', 'blogists_category_transient_flusher' );
add_action( 'save_post',     'blogists_category_transient_flusher' );





// ================ BLOGISTS BREADCRUMBS ================== //
if ( ! function_exists( 'blogists_breadcrumbs' ) ) :
function blogists_breadcrumbs() {
	if(!is_home()) {
		echo '<ul class="breadbrumb">';
		echo '<li><i class="fa fa-home"></i> <a href="'.esc_url( home_url( '/' ) ).'">'.get_bloginfo('name').'</a></li>';
		if (is_category() || is_single()) {
			echo '<li><i class="fa fa-caret-right"></i>'; the_category(); echo '</li>';
			if (is_single()) {
				echo ' <li><i class="fa fa-caret-right"></i> <a>';
				the_title(); echo '</a></li>';
			}
		} elseif (is_page()) {
			echo '<li><i class="fa fa-caret-right"></i> <a>'; the_title(); echo '</a></li>';
		}
		echo '</ul>';
	}
}
endif;




// ================ BLOGISTS CUSTOM POST EXCERPT ================== //
function blogists_custom_excerpt_length( $length ) {
    return 50;
}
add_filter( 'excerpt_length', 'blogists_custom_excerpt_length', 999 );




// =========================== BLOGISTS PAGINATION BARS ========================== //
if ( ! function_exists( 'blogists_pagination_bars' ) ) :
	/**
	 * Display navigation to next/previous set of posts when applicable.
	 */
	function blogists_pagination_bars() {
		// Don't print empty markup if there's only one page.
		if ( $GLOBALS['wp_query']->max_num_pages < 1 ) {
			return;
		}

		$paged        = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
		$pagenum_link = html_entity_decode( get_pagenum_link() );
		$query_args   = array();
		$url_parts    = explode( '?', $pagenum_link );

		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}

		$pagenum_link = remove_query_arg( array_keys( $query_args ), $pagenum_link );
		$pagenum_link = trailingslashit( $pagenum_link ) . '%_%';

		$format  = $GLOBALS['wp_rewrite']->using_index_permalinks() && ! strpos( $pagenum_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%';

		// Set up paginated links.
		$links = paginate_links( array(
			'base'     => $pagenum_link,
			'format'   => $format,
			'total'    => $GLOBALS['wp_query']->max_num_pages,
			'current'  => $paged,
			'mid_size' => 2,
			'add_args' => array_map( 'urlencode', $query_args ),
			'prev_text' => __( '<span aria-hidden="true">&laquo;</span>', 'blogists' ),
			'next_text' => __( '<span aria-hidden="true">&raquo;</span>', 'blogists' ),
	        'type'      => 'list',
		) );

		if ( $links ) :

		?>
		<nav class="my-pagination">		
				<?php echo $links; ?>
			
		</nav>
		<?php
		endif;
	}
endif;





// ================ BLOGISTS GOOGLE FONTS ================== //
function blogists_fonts_url() {
    $fonts_url = '';
 
    /* Translators: If there are characters in your language that are not
    * supported by Josefin Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $josefin = _x( 'on', 'Josefin Sans font: on or off', 'blogists' );
 
    /* Translators: If there are characters in your language that are not
    * supported by Open Sans, translate this to 'off'. Do not translate
    * into your own language.
    */
    $open_sans = _x( 'on', 'Open Sans font: on or off', 'blogists' );
 
    if ( 'off' !== $josefin || 'off' !== $open_sans ) {
        $font_families = array();
 
        if ( 'off' !== $josefin ) {
            $font_families[] = 'Josefin Sans:300,400,700,400italic';
        }
 
        if ( 'off' !== $open_sans ) {
            $font_families[] = 'Open Sans:700italic,300,400,800,600';
        }
 
        $query_args = array(
            'family' => urlencode( implode( '|', $font_families ) ),
            'subset' => urlencode( 'latin,latin-ext' ),
        );
 
        $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );
    }
 
    return esc_url_raw( $fonts_url );
}

function blogists_scripts_styles() {
    wp_enqueue_style( 'blogists-fonts', blogists_fonts_url(), array(), null );
}
add_action( 'wp_enqueue_scripts', 'blogists_scripts_styles' );



// ================ BLOGISTS EDITOR STYLES FOR GOOGLE FONTS ================== //
function blogists_add_editor_styles() {
    $font_url = str_replace( ',', '%2C', '//fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' );
    add_editor_style( $font_url );
}
add_action( 'after_setup_theme', 'blogists_add_editor_styles' );





// ====================== BLOGISTS TAG CLOUDS ARGUMENTS ========================== //
add_filter( 'widget_tag_cloud_args', 'blogists_tag_cloud_args' );
function blogists_tag_cloud_args( $args ) {
  $args['number'] = 15; // Your extra arguments go here
  $args['largest'] = 14;
  $args['smallest'] = 14;
  $args['unit'] = 'px';
  return $args;
}