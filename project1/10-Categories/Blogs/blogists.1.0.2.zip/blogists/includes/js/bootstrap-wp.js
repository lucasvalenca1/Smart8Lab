/*
 *  Blogists Theme Custom Scripts
 *  Copyright (c) 2018 Blogists Theme
 *  http://www.sumanshresthaa.com.np/
 *  Licensed under MIT
 */

jQuery( document ).ready( function( $ ) {

    //Bootstrap Carousel First Item Active
    $('.carousel-inner .item:first-child').addClass('active');

    /** Bootstrap Tooltip **/ 
    jQuery("a[data-toggle=tooltip], button[data-toggle=tooltip], span[data-toggle=tooltip]").tooltip();
    $(function () {
        $('[data-toggle="tooltip"]').tooltip()
    });

    //sticky nav menubar
    $(window).scroll(function() {
        if ($(window).width() > 768) {
            if ($(this).scrollTop() > 100) {
                $('.site-navigation').addClass('sticky-head');
            } else {
                $('.site-navigation').removeClass('sticky-head');
            }
        } else {
            if ($(this).scrollTop() > 100) {
                $('.site-navigation').addClass('sticky-head');
            } else {
                $('.site-navigation').removeClass('sticky-head');
            }
        }
    });


    //scroll to top
    $(document).ready(function(){
          $('body').append('<div id="toTop"><i class="fa fa-chevron-up" aria-hidden="true" style="color: #111; z-index: 9; font-size: 26px; background-color: transparent; padding: 10px; "></i></div>');
            $(window).scroll(function () {
                if ($(this).scrollTop() != 0) {
                    $('#toTop').fadeIn();
                } else {
                    $('#toTop').fadeOut();
                }
            }); 
        $('#toTop').click(function(){
            $("html, body").animate({ scrollTop: 0 }, 600);
            return false;
        });
    });


    //sticky-sidebar
    jQuery(document).ready(function() {
        jQuery('.content, .sidebar').theiaStickySidebar({
          // Settings
          additionalMarginTop: 30
        });
    });


    //keyboard navigation
    jQuery( document ).ready( function( $ ) {
        $( document ).keydown( function( e ) {
            var url = false;
            if ( e.which === 37 ) {  // Left arrow key code
                url = $( '.previous-image a' ).attr( 'href' );
            }
            else if ( e.which === 39 ) {  // Right arrow key code
                url = $( '.entry-attachment a' ).attr( 'href' );
            }
            if ( url && ( !$( 'textarea, input' ).is( ':focus' ) ) ) {
                window.location = url;
            }
        } );
    } );


    // the search widget
    $( '.widget_search input.search-field' ).addClass( 'form-control' );
    $( '.widget_search input.search-submit' ).addClass( 'btn btn-default' );

    $( '.widget_rss ul' ).addClass( 'media-list' );

    $( '.widget_meta ul, .widget_recent_entries ul, .widget_archive ul, .widget_categories ul, .widget_nav_menu ul, .widget_pages ul' ).addClass( 'nav' );

    $( '.widget_recent_comments ul#recentcomments' ).css( 'list-style', 'none').css( 'padding-left', '0' );
    $( '.widget_recent_comments ul#recentcomments li' ).css( 'padding', '5px 15px');
    $( '.comment-list.media-list .row.the-comment' ).removeClass( 'row');

    $( 'table#wp-calendar' ).addClass( 'table table-striped');

    $( '.my-pagination ul' ).removeClass( 'page-numbers');
    $( '.my-pagination ul' ).addClass( 'pagination');

    $('.comments-link').prepend('<i class="fa fa-comment-o"></i>');
    $('.tagcloud .tag-cloud-link').prepend('<i class="fa fa-tag"></i>');
    $('.sidebar li a').prepend('<i class="fa fa-caret-right"></i>');
    $('.footer-blocks li a').prepend('<i class="fa fa-caret-right"></i>');
} );



//skip link focus fix
( function() {
    var is_webkit = navigator.userAgent.toLowerCase().indexOf( 'webkit' ) > -1,
        is_opera  = navigator.userAgent.toLowerCase().indexOf( 'opera' )  > -1,
        is_ie     = navigator.userAgent.toLowerCase().indexOf( 'msie' )   > -1;

    if ( ( is_webkit || is_opera || is_ie ) && 'undefined' !== typeof( document.getElementById ) ) {
        var eventMethod = ( window.addEventListener ) ? 'addEventListener' : 'attachEvent';
        window[ eventMethod ]( 'hashchange', function() {
            var element = document.getElementById( location.hash.substring( 1 ) );

            if ( element ) {
                if ( ! /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) )
                    element.tabIndex = -1;

                element.focus();
            }
        }, false );
    }
})();