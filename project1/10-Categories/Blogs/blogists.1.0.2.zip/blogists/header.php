<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="main">
 *
 * @package blogists
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>
		<?php do_action( 'before' ); ?>

		<div class="top-header">
			<div class="container-fluid">
				<div class="roww">

					<div class="site-header-inner">
						<div class="col-md-6 col-sm-12">
							<div class="top-date">
								<?php echo date_i18n(esc_html__('d, M, Y','blogists')); ?>
							</div>
						</div><!-- .top-date -->

						<div class="col-md-6 col-sm-12 top-socials">
							<?php 
	                            $facebook = get_theme_mod('facebook_link');		                            
	                            $twitter = get_theme_mod('twitter_link');
	                            $instagram = get_theme_mod('instagram_link');	                            
	                            $pinterest = get_theme_mod('pinterest_link');
	                            $youtube = get_theme_mod('youtube_link');

	                            if($facebook){?>
	                            	<a type="button" data-toggle="tooltip" data-placement="bottom" href="<?php echo esc_url( $facebook ); ?>" title="FaceBook"><i class="fa fa-facebook"></i></a>
	                            <?php }
	                            if($twitter){?>
	                            	<a type="button" data-toggle="tooltip" data-placement="bottom" href="<?php echo esc_url( $twitter ); ?>" title="Twitter"><i class="fa fa-twitter"></i></a>
	                            <?php }
	                            if($instagram){?>
	                              <a type="button" data-toggle="tooltip" data-placement="bottom" href="<?php echo esc_url( $instagram ); ?>" title="Instagram"><i class="fa fa-instagram"></i></a>
	                            <?php }
	                            if($pinterest){?>
	                              <a type="button" data-toggle="tooltip" data-placement="bottom" href="<?php echo esc_url( $pinterest ); ?>" title="Pinterest"><i class="fa fa-pinterest"></i></a>
	                            <?php }
	                            if($youtube) {?>
	                              <a type="button" data-toggle="tooltip" data-placement="bottom" href="<?php echo esc_url( $youtube ); ?>" title="YouTube"><i class="fa fa-youtube"></i></a>
	                            <?php }		                            
	                        ?>
						</div><!-- .top-socials -->
					</div><!-- .site-header-inner -->

				</div><!-- .rows -->
			</div><!-- .container -->
		</div><!-- .top-header -->

		<header id="masthead" class="site-header" role="banner">
			<div class="container-fluid">
				<div class="roww">

					<div class="col-md-6 col-sm-12 site-branding">
						<?php the_custom_logo(); ?>
						<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
						<p class="site-description lead"><?php bloginfo( 'description' ); ?></p>
					</div><!-- .site-branding -->

					<div class="col-md-6 col-sm-12 top-search">
						<?php get_search_form(); ?>
					</div><!-- .top-search -->

				</div><!-- .rows -->
			</div><!-- .container -->
		</header><!-- #masthead -->

		<nav class="site-navigation">
			<div class="container-fluid">
				<div class="roww mobile">
					<div class="site-navigation-inner col-sm-12">
						<div class="navbar navbar-default">
							<div class="navbar-header">
								<!-- .navbar-toggle is used as the toggle for collapsed navbar content -->
								<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-collapse">
									<span class="sr-only"><?php esc_html_e('Toggle navigation','blogists') ?> </span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
									<span class="icon-bar"></span>
								</button>
			
								<!-- Your site title as branding in the menu -->
								<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a>
							</div>

							<!-- The WordPress Menu goes here -->
							<?php wp_nav_menu(
								array(
									'theme_location' 	=> 'primary',
									'depth'             => 4,
									'container'         => 'nav',
									'container_id'      => 'navbar-collapse',
									'container_class'   => 'collapse navbar-collapse',
									'menu_class' 		=> 'nav navbar-nav',
									'fallback_cb' 		=> 'wp_bootstrap_navwalker::fallback',
									'menu_id'			=> 'main-menu',
									'walker' 			=> new wp_bootstrap_navwalker()
								)
							); ?>

						</div><!-- .navbar -->
					</div>
				</div>
			</div><!-- .container -->
		</nav><!-- .site-navigation -->