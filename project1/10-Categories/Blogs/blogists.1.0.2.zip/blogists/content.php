<?php
/**
 * @package blogists
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="row">
		<div class="col-md-12">
			<div class="entry-header">
				<h3 class="blog-title"><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h3>
				<?php if ( 'post' == get_post_type() ) : ?>
				<div class="entry-meta">
					<?php blogists_posted_on(); ?>
				</div><!-- .entry-meta -->
				<?php endif; ?>
			</div><!-- .entry-header -->
		</div>

		<div class="col-md-8 col-sm-12">
			<div class="news-hover text-center">
                <a href="<?php the_permalink(); ?>">
                	<?php if (has_post_thumbnail()) : ?>
	          			<?php the_post_thumbnail('large', array('class' => 'img-responsive')); ?>
	        		<?php else : ?>
	          			<div class="no-img full"><i class="fa fa-camera"></i></div>
	        		<?php endif; ?>
                	<div class="on-hover">
		                <div class="outer">
		                    <div class="middle">
		                        <div class="inner1">
		                            <i class="fa fa-search"></i>
		                        </div>
		                    </div>
		                </div>
	                </div>
	            </a>	                    
            </div><!-- news-hover latest -->
	    </div>

	    <div class="col-md-4 col-sm-12">
			<div class="entry-summary">
				<?php the_excerpt(); ?>				
			</div><!-- .entry-summary -->			
		</div>

		<div class="col-md-12">
			<footer class="entry-meta">
				<?php blogists_entry_footer(); ?>
				<?php edit_post_link( __( 'Edit', 'blogists' ), '<span class="edit-link">', '</span>' ); ?>
			</footer><!-- .entry-meta -->
		</div>

	</div>
</article><!-- #post-## -->