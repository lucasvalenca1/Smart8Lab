<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package blogists
 */

get_header(); ?>

	<div class="home-page">
		<div class="container-fluid">
			<div class="rows">

				<div class="col-md-12">
					<section class="content-padder error-404 not-found text-center">
						<header>
							<h2 class="page-title"><?php esc_html_e( 'Oops! Something went wrong here.', 'blogists' ); ?></h2>
						</header><!-- .page-header -->

						<div class="page-content">
							<p><?php esc_html_e( 'Nothing could be found at this location. Maybe try a search?', 'blogists' ); ?></p>
							<?php get_search_form(); ?>
						</div><!-- .page-content -->
					</section><!-- .content-padder -->	
				</div>

			</div>
		</div>
	</div>
<?php get_footer(); ?>