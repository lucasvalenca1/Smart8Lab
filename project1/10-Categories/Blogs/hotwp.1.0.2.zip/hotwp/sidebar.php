<?php
/**
* The file for displaying the sidebars.
*
* @package HotWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

<div class="hotwp-sidebar-one-wrapper hotwp-sidebar-widget-areas clearfix" id="hotwp-sidebar-one-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPSideBar" role="complementary">
<div class="theiaStickySidebar">
<div class="hotwp-sidebar-one-wrapper-inside clearfix">

<?php dynamic_sidebar( 'hotwp-sidebar-one' ); ?>

</div>
</div>
</div><!-- /#hotwp-sidebar-one-wrapper-->

<div class="hotwp-sidebar-two-wrapper hotwp-sidebar-widget-areas clearfix" id="hotwp-sidebar-two-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPSideBar" role="complementary">
<div class="theiaStickySidebar">
<div class="hotwp-sidebar-two-wrapper-inside clearfix">

<?php dynamic_sidebar( 'hotwp-sidebar-two' ); ?>

</div>
</div>
</div><!-- /#hotwp-sidebar-two-wrapper-->