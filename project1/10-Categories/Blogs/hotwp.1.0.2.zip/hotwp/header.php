<?php
/**
* The header for HotWP theme.
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package HotWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class('hotwp-animated hotwp-fadein'); ?> id="hotwp-site-body" itemscope="itemscope" itemtype="http://schema.org/WebPage">
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#hotwp-posts-wrapper"><?php esc_html_e( 'Skip to content', 'hotwp' ); ?></a>

<?php if ( !(hotwp_get_option('disable_secondary_menu')) ) { ?>
<div class="hotwp-container hotwp-secondary-menu-container clearfix">
<div class="hotwp-secondary-menu-container-inside clearfix">
<nav class="hotwp-nav-secondary" id="hotwp-secondary-navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation" aria-label="<?php esc_attr_e( 'Secondary Menu', 'hotwp' ); ?>">
<div class="hotwp-outer-wrapper">
<button class="hotwp-secondary-responsive-menu-icon" aria-controls="hotwp-menu-secondary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'hotwp' ); ?></button>
<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_id' => 'hotwp-menu-secondary-navigation', 'menu_class' => 'hotwp-secondary-nav-menu hotwp-menu-secondary', 'fallback_cb' => 'hotwp_top_fallback_menu', 'container' => '', ) ); ?>
</div>
</nav>
</div>
</div>
<?php } ?>

<div class="hotwp-container" id="hotwp-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" role="banner">
<div class="hotwp-head-content clearfix" id="hotwp-head-content">

<div class="hotwp-outer-wrapper">

<?php if ( get_header_image() ) : ?>
<div class="hotwp-header-image clearfix">
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="hotwp-header-img-link">
    <img src="<?php header_image(); ?>" width="<?php echo esc_attr(get_custom_header()->width); ?>" height="<?php echo esc_attr(get_custom_header()->height); ?>" alt="" class="hotwp-header-img"/>
</a>
</div>
<?php endif; ?>

<?php if ( !(hotwp_get_option('hide_header_content')) ) { ?>
<div class="hotwp-header-inside clearfix">

<div id="hotwp-logo">
<?php if ( has_custom_logo() ) : ?>
    <div class="site-branding">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="hotwp-logo-img-link">
        <img src="<?php echo esc_url( hotwp_custom_logo() ); ?>" alt="" class="hotwp-logo-img"/>
    </a>
    </div>
<?php else: ?>
    <div class="site-branding">
      <h1 class="hotwp-site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
      <p class="hotwp-site-description"><?php bloginfo( 'description' ); ?></p>
    </div>
<?php endif; ?>
</div><!--/#hotwp-logo -->

<div id="hotwp-header-banner">
<?php dynamic_sidebar( 'hotwp-header-banner' ); ?>
</div><!--/#hotwp-header-banner -->

</div>
<?php } ?>

</div>

</div><!--/#hotwp-head-content -->
</div><!--/#hotwp-header -->

<?php if ( !(hotwp_get_option('disable_primary_menu')) ) { ?>
<div class="hotwp-container hotwp-primary-menu-container clearfix">
<div class="hotwp-primary-menu-container-inside clearfix">
<nav class="hotwp-nav-primary" id="hotwp-primary-navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'hotwp' ); ?>">
<div class="hotwp-outer-wrapper">
<button class="hotwp-primary-responsive-menu-icon" aria-controls="hotwp-menu-primary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'hotwp' ); ?></button>
<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'hotwp-menu-primary-navigation', 'menu_class' => 'hotwp-primary-nav-menu hotwp-menu-primary', 'fallback_cb' => 'hotwp_fallback_menu', 'container' => '', ) ); ?>
<?php if ( !(hotwp_get_option('hide_header_social_buttons')) ) { hotwp_header_social_buttons(); } ?>
</div>
</nav>
</div>
</div>
<?php } ?>

<div id="hotwp-search-overlay-wrap" class="hotwp-search-overlay">
  <button class="hotwp-search-closebtn" aria-label="<?php esc_attr_e( 'Close Search', 'hotwp' ); ?>" title="<?php esc_attr_e('Close Search','hotwp'); ?>">&#xD7;</button>
  <div class="hotwp-search-overlay-content">
    <?php get_search_form(); ?>
  </div>
</div>

<div class="hotwp-outer-wrapper">
<?php hotwp_top_wide_widgets(); ?>
</div>

<div class="hotwp-outer-wrapper">

<div class="hotwp-container clearfix" id="hotwp-wrapper">
<div class="hotwp-content-wrapper clearfix" id="hotwp-content-wrapper">