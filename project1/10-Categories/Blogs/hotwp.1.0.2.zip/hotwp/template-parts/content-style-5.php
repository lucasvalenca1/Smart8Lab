<?php
/**
* Template part for displaying posts.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package HotWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

<div id="post-<?php the_ID(); ?>" class="hotwp-fp05-post">

    <?php if ( has_post_thumbnail() ) { ?>
    <?php if ( !(hotwp_get_option('hide_thumbnail')) ) { ?>
    <div class="hotwp-fp05-post-thumbnail">
        <a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php /* translators: %s: post title. */ echo esc_attr( sprintf( __( 'Permanent Link to %s', 'hotwp' ), the_title_attribute( 'echo=0' ) ) ); ?>" class="hotwp-fp05-post-thumbnail-link"><?php the_post_thumbnail('hotwp-medium-image', array('class' => 'hotwp-fp05-post-thumbnail-img')); ?></a>
    </div>
    <?php } ?>
    <?php } ?>

    <?php if((has_post_thumbnail()) && !(hotwp_get_option('hide_thumbnail'))) { ?><div class="hotwp-fp05-post-details"><?php } ?>
    <?php if(!(has_post_thumbnail()) || (hotwp_get_option('hide_thumbnail'))) { ?><div class="hotwp-fp05-post-details-full"><?php } ?>

    <?php if ( !(hotwp_get_option('hide_post_categories_home')) ) { ?><?php hotwp_style_5_cats(); ?><?php } ?>

    <?php the_title( sprintf( '<h3 class="hotwp-fp05-post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>

    <?php hotwp_style_5_postmeta(); ?>

    <?php if ( !(hotwp_get_option('hide_post_snippet')) ) { ?><div class="hotwp-fp05-post-snippet"><?php the_excerpt(); ?></div><?php } ?>

    <?php if ( !(hotwp_get_option('hide_read_more_button')) ) { ?><div class='hotwp-fp05-post-read-more'><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( hotwp_read_more_text() ); ?></a></div><?php } ?>

    <?php if(!(has_post_thumbnail()) || (hotwp_get_option('hide_thumbnail'))) { ?></div><?php } ?>
    <?php if((has_post_thumbnail()) && !(hotwp_get_option('hide_thumbnail'))) { ?></div><?php } ?>

</div>