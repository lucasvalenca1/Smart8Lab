<?php
/**
* Register widget area.
*
* @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
*
* @package HotWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function hotwp_widgets_init() {

register_sidebar(array(
    'id' => 'hotwp-header-banner',
    'name' => esc_html__( 'Header Banner', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is located on the header of the web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-header-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title">',
    'after_title' => '</h2>'));

register_sidebar(array(
    'id' => 'hotwp-sidebar-one',
    'name' => esc_html__( 'Sidebar 1', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is normally located on the left-hand side of web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-side-widget widget hotwp-box %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-sidebar-two',
    'name' => esc_html__( 'Sidebar 2', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is normally located on the right-hand side of web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-side-widget widget hotwp-box %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-home-fullwidth-widgets',
    'name' => esc_html__( 'Top Full Width Widgets (Home Page Only)', 'hotwp' ),
    'description' => esc_html__( 'This full-width widget area is located at the top of homepage.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-main-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-fullwidth-widgets',
    'name' => esc_html__( 'Top Full Width Widgets (Every Page)', 'hotwp' ),
    'description' => esc_html__( 'This full-width widget area is located at the top of every page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-main-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-home-top-widgets',
    'name' => esc_html__( 'Top Widgets (Home Page Only)', 'hotwp' ),
    'description' => esc_html__( 'This widget area is located at the top of homepage.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-main-widget widget hotwp-box %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-top-widgets',
    'name' => esc_html__( 'Top Widgets (Every Page)', 'hotwp' ),
    'description' => esc_html__( 'This widget area is located at the top of every page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-main-widget widget hotwp-box %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-home-bottom-widgets',
    'name' => esc_html__( 'Bottom Widgets (Home Page Only)', 'hotwp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of homepage.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-main-widget widget hotwp-box %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-bottom-widgets',
    'name' => esc_html__( 'Bottom Widgets (Every Page)', 'hotwp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of every page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-main-widget widget hotwp-box %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-footer-1',
    'name' => esc_html__( 'Footer 1', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is located on the left bottom of web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-footer-2',
    'name' => esc_html__( 'Footer 2', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is located on the middle bottom of web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-footer-3',
    'name' => esc_html__( 'Footer 3', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is located on the middle bottom of web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'hotwp-footer-4',
    'name' => esc_html__( 'Footer 4', 'hotwp' ),
    'description' => esc_html__( 'This sidebar is located on the right bottom of web page.', 'hotwp' ),
    'before_widget' => '<div id="%1$s" class="hotwp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="hotwp-widget-title"><span>',
    'after_title' => '</span></h2>'));

}
add_action( 'widgets_init', 'hotwp_widgets_init' );


function hotwp_top_wide_widgets() { ?>

<?php if ( is_active_sidebar( 'hotwp-home-fullwidth-widgets' ) || is_active_sidebar( 'hotwp-fullwidth-widgets' ) ) : ?>
<div class="hotwp-top-wrapper-outer clearfix">
<div class="hotwp-featured-posts-area hotwp-top-wrapper clearfix">
<?php if(is_front_page() && !is_paged()) { ?>
<?php dynamic_sidebar( 'hotwp-home-fullwidth-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'hotwp-fullwidth-widgets' ); ?>
</div>
</div>
<?php endif; ?>

<?php }


function hotwp_top_widgets() { ?>

<?php if ( is_active_sidebar( 'hotwp-home-top-widgets' ) || is_active_sidebar( 'hotwp-top-widgets' ) ) : ?>
<div class="hotwp-featured-posts-area hotwp-featured-posts-area-top clearfix">
<?php if(is_front_page() && !is_paged()) { ?>
<?php dynamic_sidebar( 'hotwp-home-top-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'hotwp-top-widgets' ); ?>
</div>
<?php endif; ?>

<?php }


function hotwp_bottom_widgets() { ?>

<?php if ( is_active_sidebar( 'hotwp-home-bottom-widgets' ) || is_active_sidebar( 'hotwp-bottom-widgets' ) ) : ?>
<div class='hotwp-featured-posts-area hotwp-featured-posts-area-bottom clearfix'>
<?php if(is_front_page() && !is_paged()) { ?>
<?php dynamic_sidebar( 'hotwp-home-bottom-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'hotwp-bottom-widgets' ); ?>
</div>
<?php endif; ?>

<?php }