<?php
/**
* Enqueue scripts and styles
*
* @package HotWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function hotwp_scripts() {
    wp_enqueue_style('hotwp-maincss', get_stylesheet_uri(), array(), NULL);
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), NULL );
    wp_enqueue_style('hotwp-webfont', '//fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i|Domine:400,700|Oswald:400,700', array(), NULL);
    wp_enqueue_script('fitvids', get_template_directory_uri() .'/assets/js/jquery.fitvids.min.js', array( 'jquery' ), NULL, true);

    $hotwp_primary_menu_active = FALSE;
    if ( !hotwp_get_option('disable_primary_menu') ) {
        $hotwp_primary_menu_active = TRUE;
    }
    $hotwp_secondary_menu_active = FALSE;
    if ( !hotwp_get_option('disable_secondary_menu') ) {
        $hotwp_secondary_menu_active = TRUE;
    }

    $hotwp_sticky_menu = TRUE;
    $hotwp_sticky_mobile_menu = TRUE;
    if ( !hotwp_get_option('enable_sticky_mobile_menu') ) {
        $hotwp_sticky_mobile_menu = FALSE;
    }

    $hotwp_sticky_sidebar = TRUE;
    if ( is_page_template( array( 'template-full-width-page.php', 'template-full-width-post.php' ) ) ) {
       $hotwp_sticky_sidebar = FALSE;
    }
    if ( is_404() ) {
        $hotwp_sticky_sidebar = FALSE;
    }
    if ( $hotwp_sticky_sidebar ) {
        wp_enqueue_script('ResizeSensor', get_template_directory_uri() .'/assets/js/ResizeSensor.min.js', array( 'jquery' ), NULL, true);
        wp_enqueue_script('theia-sticky-sidebar', get_template_directory_uri() .'/assets/js/theia-sticky-sidebar.min.js', array( 'jquery' ), NULL, true);
    }

    $hotwp_slider = FALSE;
    if ( hotwp_get_option('enable_slider') ) {
        $hotwp_slider = TRUE;
    }
    if ( $hotwp_slider ) {
    if(is_front_page() && !is_paged()) {
        wp_enqueue_style('owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.min.css', array(), NULL );
        wp_enqueue_script('owl-carousel', get_template_directory_uri() .'/assets/js/owl.carousel.min.js', array( 'jquery' ), NULL, true);
        wp_enqueue_script('imagesloaded', get_template_directory_uri() .'/assets/js/imagesloaded.pkgd.min.js', array( 'jquery' ), NULL, true);
    }
    }

    wp_enqueue_script('hotwp-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), NULL, true );
    wp_enqueue_script('hotwp-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), NULL, true );
    wp_enqueue_script('hotwp-customjs', get_template_directory_uri() .'/assets/js/custom.js', array( 'jquery' ), NULL, true);
    wp_localize_script( 'hotwp-customjs', 'hotwp_ajax_object',
        array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'primary_menu_active' => $hotwp_primary_menu_active,
            'secondary_menu_active' => $hotwp_secondary_menu_active,
            'sticky_menu' => $hotwp_sticky_menu,
            'sticky_menu_mobile' => $hotwp_sticky_mobile_menu,
            'sticky_sidebar' => $hotwp_sticky_sidebar,
            'slider' => $hotwp_slider,
        )
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'hotwp_scripts' );

/**
 * Enqueue IE compatible scripts and styles.
 */
function hotwp_ie_scripts() {
    wp_enqueue_script( 'html5shiv', get_template_directory_uri(). '/assets/js/html5shiv.min.js', array(), NULL, false);
    wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );

    wp_enqueue_script( 'respond', get_template_directory_uri(). '/assets/js/respond.min.js', array(), NULL, false );
    wp_script_add_data( 'respond', 'conditional', 'lt IE 9' );
}
add_action( 'wp_enqueue_scripts', 'hotwp_ie_scripts' );

/**
 * Enqueue customizer styles.
 */
function hotwp_enqueue_customizer_styles() {
    wp_enqueue_style( 'hotwp-customizer-styles', get_template_directory_uri() . '/inc/admin/css/customizer-style.css', array(), NULL );
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), NULL );
}
add_action( 'customize_controls_enqueue_scripts', 'hotwp_enqueue_customizer_styles' );