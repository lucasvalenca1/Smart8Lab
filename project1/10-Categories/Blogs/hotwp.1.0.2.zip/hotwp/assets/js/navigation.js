/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 */
( function() {
    var hotwp_secondary_container, hotwp_secondary_button, hotwp_secondary_menu, hotwp_secondary_links, hotwp_secondary_i, hotwp_secondary_len;

    hotwp_secondary_container = document.getElementById( 'hotwp-secondary-navigation' );
    if ( ! hotwp_secondary_container ) {
        return;
    }

    hotwp_secondary_button = hotwp_secondary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof hotwp_secondary_button ) {
        return;
    }

    hotwp_secondary_menu = hotwp_secondary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof hotwp_secondary_menu ) {
        hotwp_secondary_button.style.display = 'none';
        return;
    }

    hotwp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === hotwp_secondary_menu.className.indexOf( 'nav-menu' ) ) {
        hotwp_secondary_menu.className += ' nav-menu';
    }

    hotwp_secondary_button.onclick = function() {
        if ( -1 !== hotwp_secondary_container.className.indexOf( 'hotwp-toggled' ) ) {
            hotwp_secondary_container.className = hotwp_secondary_container.className.replace( ' hotwp-toggled', '' );
            hotwp_secondary_button.setAttribute( 'aria-expanded', 'false' );
            hotwp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            hotwp_secondary_container.className += ' hotwp-toggled';
            hotwp_secondary_button.setAttribute( 'aria-expanded', 'true' );
            hotwp_secondary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    hotwp_secondary_links    = hotwp_secondary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( hotwp_secondary_i = 0, hotwp_secondary_len = hotwp_secondary_links.length; hotwp_secondary_i < hotwp_secondary_len; hotwp_secondary_i++ ) {
        hotwp_secondary_links[hotwp_secondary_i].addEventListener( 'focus', hotwp_secondary_toggleFocus, true );
        hotwp_secondary_links[hotwp_secondary_i].addEventListener( 'blur', hotwp_secondary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function hotwp_secondary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'hotwp-focus' ) ) {
                    self.className = self.className.replace( ' hotwp-focus', '' );
                } else {
                    self.className += ' hotwp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( hotwp_secondary_container ) {
        var touchStartFn, hotwp_secondary_i,
            parentLink = hotwp_secondary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, hotwp_secondary_i;

                if ( ! menuItem.classList.contains( 'hotwp-focus' ) ) {
                    e.preventDefault();
                    for ( hotwp_secondary_i = 0; hotwp_secondary_i < menuItem.parentNode.children.length; ++hotwp_secondary_i ) {
                        if ( menuItem === menuItem.parentNode.children[hotwp_secondary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[hotwp_secondary_i].classList.remove( 'hotwp-focus' );
                    }
                    menuItem.classList.add( 'hotwp-focus' );
                } else {
                    menuItem.classList.remove( 'hotwp-focus' );
                }
            };

            for ( hotwp_secondary_i = 0; hotwp_secondary_i < parentLink.length; ++hotwp_secondary_i ) {
                parentLink[hotwp_secondary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( hotwp_secondary_container ) );
} )();


( function() {
    var hotwp_primary_container, hotwp_primary_button, hotwp_primary_menu, hotwp_primary_links, hotwp_primary_i, hotwp_primary_len;

    hotwp_primary_container = document.getElementById( 'hotwp-primary-navigation' );
    if ( ! hotwp_primary_container ) {
        return;
    }

    hotwp_primary_button = hotwp_primary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof hotwp_primary_button ) {
        return;
    }

    hotwp_primary_menu = hotwp_primary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof hotwp_primary_menu ) {
        hotwp_primary_button.style.display = 'none';
        return;
    }

    hotwp_primary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === hotwp_primary_menu.className.indexOf( 'nav-menu' ) ) {
        hotwp_primary_menu.className += ' nav-menu';
    }

    hotwp_primary_button.onclick = function() {
        if ( -1 !== hotwp_primary_container.className.indexOf( 'hotwp-toggled' ) ) {
            hotwp_primary_container.className = hotwp_primary_container.className.replace( ' hotwp-toggled', '' );
            hotwp_primary_button.setAttribute( 'aria-expanded', 'false' );
            hotwp_primary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            hotwp_primary_container.className += ' hotwp-toggled';
            hotwp_primary_button.setAttribute( 'aria-expanded', 'true' );
            hotwp_primary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    hotwp_primary_links    = hotwp_primary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( hotwp_primary_i = 0, hotwp_primary_len = hotwp_primary_links.length; hotwp_primary_i < hotwp_primary_len; hotwp_primary_i++ ) {
        hotwp_primary_links[hotwp_primary_i].addEventListener( 'focus', hotwp_primary_toggleFocus, true );
        hotwp_primary_links[hotwp_primary_i].addEventListener( 'blur', hotwp_primary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function hotwp_primary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'hotwp-focus' ) ) {
                    self.className = self.className.replace( ' hotwp-focus', '' );
                } else {
                    self.className += ' hotwp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( hotwp_primary_container ) {
        var touchStartFn, hotwp_primary_i,
            parentLink = hotwp_primary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, hotwp_primary_i;

                if ( ! menuItem.classList.contains( 'hotwp-focus' ) ) {
                    e.preventDefault();
                    for ( hotwp_primary_i = 0; hotwp_primary_i < menuItem.parentNode.children.length; ++hotwp_primary_i ) {
                        if ( menuItem === menuItem.parentNode.children[hotwp_primary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[hotwp_primary_i].classList.remove( 'hotwp-focus' );
                    }
                    menuItem.classList.add( 'hotwp-focus' );
                } else {
                    menuItem.classList.remove( 'hotwp-focus' );
                }
            };

            for ( hotwp_primary_i = 0; hotwp_primary_i < parentLink.length; ++hotwp_primary_i ) {
                parentLink[hotwp_primary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( hotwp_primary_container ) );
} )();