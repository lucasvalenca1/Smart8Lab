<?php
/**
* The template for displaying the footer
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package HotWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

</div>

</div><!--/#hotwp-content-wrapper -->
</div><!--/#hotwp-wrapper -->


<?php if ( !(hotwp_get_option('hide_footer_widgets')) ) { ?>
<?php if ( is_active_sidebar( 'hotwp-footer-1' ) || is_active_sidebar( 'hotwp-footer-2' ) || is_active_sidebar( 'hotwp-footer-3' ) || is_active_sidebar( 'hotwp-footer-4' ) ) : ?>
<div class='clearfix' id='hotwp-footer-blocks' itemscope='itemscope' itemtype='http://schema.org/WPFooter' role='contentinfo'>
<div class='hotwp-container clearfix'>
<div class="hotwp-outer-wrapper">

<div class='hotwp-footer-block-1'>
<?php dynamic_sidebar( 'hotwp-footer-1' ); ?>
</div>

<div class='hotwp-footer-block-2'>
<?php dynamic_sidebar( 'hotwp-footer-2' ); ?>
</div>

<div class='hotwp-footer-block-3'>
<?php dynamic_sidebar( 'hotwp-footer-3' ); ?>
</div>

<div class='hotwp-footer-block-4'>
<?php dynamic_sidebar( 'hotwp-footer-4' ); ?>
</div>

</div>
</div>
</div><!--/#hotwp-footer-blocks-->
<?php endif; ?>
<?php } ?>


<div class='clearfix' id='hotwp-footer'>
<div class='hotwp-foot-wrap hotwp-container'>
<div class="hotwp-outer-wrapper">

<?php if ( hotwp_get_option('footer_text') ) : ?>
  <p class='hotwp-copyright'><?php echo esc_html(hotwp_get_option('footer_text')); ?></p>
<?php else : ?>
  <p class='hotwp-copyright'><?php /* translators: %s: Year and site name. */ printf( esc_html__( 'Copyright &copy; %s', 'hotwp' ), esc_html(date_i18n(__('Y','hotwp'))) . ' ' . esc_html(get_bloginfo( 'name' ))  ); ?></p>
<?php endif; ?>
<p class='hotwp-credit'><a href="<?php echo esc_url( 'https://themesdna.com/' ); ?>"><?php /* translators: %s: Theme author. */ printf( esc_html__( 'Design by %s', 'hotwp' ), 'ThemesDNA.com' ); ?></a></p>

</div>
</div>
</div><!--/#hotwp-footer -->

<button class="hotwp-scroll-top" title="<?php esc_attr_e('Scroll to Top','hotwp'); ?>"><span class="fa fa-arrow-up" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e('Scroll to Top', 'hotwp'); ?></span></button>

<?php wp_footer(); ?>
</body>
</html>