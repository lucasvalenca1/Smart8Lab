<aside id="sidebar" class="sidebar">
	<div class="inner-sidebar">
	<?php if ( is_active_sidebar('sidebar') ) { dynamic_sidebar('sidebar'); } ?>
	</div>
</aside>
