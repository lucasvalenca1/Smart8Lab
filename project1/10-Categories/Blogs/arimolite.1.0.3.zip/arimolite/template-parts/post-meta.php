<div class="post-meta">
	<div class="auth-name"><i class="far fa-user"></i><?php echo esc_html__('by ','arimolite'); ?><?php the_author() ?></div>
	<div class="post-comment"><i class="far fa-comment"></i><?php comments_number(); ?></div>
</div>