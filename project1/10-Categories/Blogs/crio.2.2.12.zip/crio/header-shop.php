<?php
/**
 * This file is included for WooCommerce overrides.
 *
 * This is left intentionally empty, and loaded so WooCommerce doesn't have any errors and
 * only a single header section is displayed on the site.
 *
 * @package Crio
 */
