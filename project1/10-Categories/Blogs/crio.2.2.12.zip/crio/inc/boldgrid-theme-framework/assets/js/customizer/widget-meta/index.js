export * from './background-color-partial';
export * from './headings-color-partial';
export * from './links-color-partial';
