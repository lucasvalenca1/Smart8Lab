export default {

	// Noop events.
	attachEvents() {},

	// Force contextually active.
	isContextuallyActive() {
		return true;
	}
};
