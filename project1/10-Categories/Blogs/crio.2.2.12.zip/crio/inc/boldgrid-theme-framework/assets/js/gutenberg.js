const { removeEditorPanel } = wp.data.dispatch( 'core/edit-post' );
removeEditorPanel( 'page-attributes' );
