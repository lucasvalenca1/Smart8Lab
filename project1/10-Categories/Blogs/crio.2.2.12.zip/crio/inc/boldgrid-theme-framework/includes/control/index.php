<?php
/**
 * Silence is golden
 *
 * @package Boldgrid_Theme_Framework
 */
