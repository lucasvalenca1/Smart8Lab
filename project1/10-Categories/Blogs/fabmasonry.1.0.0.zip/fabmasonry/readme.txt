=== FabMasonry ===

Contributors: sharkthemes
Tags: translation-ready, custom-header, custom-background, theme-options, custom-menu, threaded-comments, featured-images, footer-widgets, right-sidebar, full-width-template, two-columns, three-columns, grid-layout, custom-logo, blog, portfolio, photography
Requires at least: 4.8
Tested up to: 5.2.2
Requires PHP: 5.6
Stable tag: 1.0.0
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

photography oriented and simple masonry blog child theme

== Description ==

FabMasonry is a photography oriented and masonry gutenberg ready child theme of Fabulist. Theme Demo: http://demo.sharkthemes.com/fabmasonry/

FabMasonry is a child theme of Fabulist WordPress Theme, Copyright 2019 Shark Themes
FabMasonry is distributed under the terms of the GNU General Public License v3

Fabulist WordPress Theme, Copyright 2019 Shark Themes
Fabulist is distributed under the terms of the GNU General Public License v3

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0.0 - Aug 14 2019 =
* Initial release

== Credits ==

== Images Screenshot ==
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/17401
Source: https://pxhere.com/en/photo/1571779
Source: https://pxhere.com/en/photo/1446099
Source: https://pxhere.com/en/photo/797696
Source: https://pxhere.com/en/photo/942925
Source: https://pxhere.com/en/photo/1445507
