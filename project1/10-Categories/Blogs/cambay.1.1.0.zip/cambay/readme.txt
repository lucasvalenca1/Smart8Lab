=== Cambay ===

Contributors: vedathemes
tags: Tags: grid-layout, custom-header, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready, blog, block-styles
Requires at least: 4.9
Tested up to: 5.3
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A WordPress blog theme optimized for fashion and life-style blog.

== Description ==

Cambay is designed for fashion and life-style blog with elegant visual look and feel. This is a modern & minimalist theme with color scheme customizer options and home page widget areas. This theme is also compatible with WooCommerce and Gutenberg.

== Frequently Asked Questions ==
= What are the minimum requirmens for using this theme? =
PHP 5.6+, IE11+, WordPress 4.9+

== Changelog ==

= 1.1.0 =
* Error Fix: Made javascript compatible with IE11.
* Error Fix: Gallery block display error.
* Add: JS closest polyfill.

= 1.0.9 =
* Error Fix: Sidebar padding on smaller screens.
* Error Fix: Admin bar position on smaller screens while header widget toggle.
* Add: Recommendation for WP Gallery enhancer and Display post types.

= 1.0.8 =
* Error Fix: Single pages do not display page title if thumbnail is not set.

= 1.0.7 =
* Styling improvements.

= 1.0.5 =
* wp_body_open action hook has been added.

= 1.0.4 =
* Minor CSS Corrections
* Copyright statement included

= 1.0.3 =
* Add: Header search feature.
* Add: Content and sidebar layout options for single posts and pages.
* Modify: Do not display header widgets if nothing is assigned to it.
* Modify: Screenshot image to include latest modifications.
* Modify: Minor styling changes.

= 1.0.2 =
* Header Widget Styling improvements
* Error Fix: Broken search layout if WooCommerce products are also in search results.
* Add: Object-fit polyfill.
* Add: Navigation sub-menu toggle functionality on smaller-screens.
* Add: Google font support for Simplified Font Manager
* Remove: Widgetlayer settings

= 1.0.1 =
* Styling and animation improvements.
* Updated theme screenshot.

= 1.0 =
* Initial release

== Upgrade Notice ==

= 1.0.9 =
* Upgrade to receive latest error fix and improvements

= 1.0.4 =
* Upgrade to receive latest error fix and improvements

= 1.0.3 =
* Upgrade to receive latest error fix and improvements

= 1.0.2 =
* Upgrade to receive latest error fix and improvements

== Resources ==
* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)
* Font Awesome SVG icons http://fontawesome.io/, (C) Dave Gandy, [CC BY 4.0](https://fontawesome.com/license/free)
* Icomoon SVG icons https://icomoon.io, (C) Roonas, [GPL / CC BY 4.0](https://icomoon.io/icons-icomoon.html)
* Feather SVG icons https://github.com/feathericons/feather, (C) Colebemis, [MIT](http://opensource.org/licenses/MIT)
* Genericons Neue SVG icons https://github.com/Automattic/genericons-neue, (C) Automattic, [GPL](https://github.com/Automattic/genericons-neue/blob/master/LICENSE.md)
* Image in screenshot https://pxhere.com/en/photo/1284656, (C) pxhere, [CC0](https://creativecommons.org/publicdomain/zero/1.0/)
* Image in screenshot https://pxhere.com/en/photo/1427193, (C) pxhere, [CC0](https://creativecommons.org/publicdomain/zero/1.0/)
* Image in screenshot https://pxhere.com/en/photo/1427191, (C) pxhere, [CC0](https://creativecommons.org/publicdomain/zero/1.0/)
* Image in screenshot https://pxhere.com/en/photo/1448327, (C) pxhere, [CC0](https://creativecommons.org/publicdomain/zero/1.0/)
* Incorporates code from Twenty Fifteen WordPress Theme, (C) Automattic & WordPress.org, [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Incorporates code from Twenty Seventeen WordPress Theme, (C) Automattic & WordPress.org, [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Incorporates code from Stargazer WordPress Theme, (C) Justin Tadlock, [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
