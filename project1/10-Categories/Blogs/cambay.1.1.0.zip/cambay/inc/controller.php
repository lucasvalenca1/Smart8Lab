<?php
/**
 * Customizer data
 *
 * Theme Customizer's sections and control field data.
 *
 * @package Cambay
 * @since 1.0.0
 */

/**
 * Set theme customizer panels.
 *
 * @since 1.0.0
 *
 * @param  array $panels Array of theme customizer panels.
 * @return array Returns array of theme customizer panels.
 */
function cambay_get_theme_panels( $panels = [] ) {
	return array_merge(
		$panels,
		[
			'cambay_theme_panel' =>
			[
				'title'       => esc_html__( 'Theme Options', 'cambay' ),
				'priority'    => 6,
				'description' => esc_html__( 'Theme options to customize your site.', 'cambay' ),
			],
		]
	);
}
add_filter( 'cambay_theme_panels', 'cambay_get_theme_panels' );

/**
 * Set theme customizer sections.
 *
 * @since 1.0.0
 *
 * @param  array $sections array of theme customizer sections.
 * @return array Returns array of theme customizer sections.
 */
function cambay_get_theme_sections( $sections = [] ) {
	return array_merge(
		$sections,
		[
			'cambay_general_section' =>
			[
				'title' => esc_html__( 'General Settings', 'cambay' ),
				'panel' => 'cambay_theme_panel',
			],
			'cambay_layout_section'  =>
			[
				'title' => esc_html__( 'Layout Settings', 'cambay' ),
				'panel' => 'cambay_theme_panel',
			],
		]
	);
}
add_filter( 'cambay_theme_sections', 'cambay_get_theme_sections' );

/**
 * Set theme customizer controls and settings.
 *
 * @since 1.0.0
 *
 * @param  array $controls array of theme controls and settings.
 * @return array Returns array of theme controls and settings.
 */
function cambay_get_theme_controls( $controls = [] ) {
	return array_merge(
		$controls,
		[
			[
				'label'     => esc_html__( 'Display Site Title', 'cambay' ),
				'section'   => 'title_tagline',
				'setting'   => 'cambay_display_site_title',
				'type'      => 'checkbox',
				'transport' => 'postMessage',
			],
			[
				'label'     => esc_html__( 'Display Tagline', 'cambay' ),
				'section'   => 'title_tagline',
				'setting'   => 'cambay_display_site_desc',
				'type'      => 'checkbox',
				'transport' => 'postMessage',
				'priority'  => 20,
			],
			[
				'label'       => esc_html__( 'Change Color Scheme', 'cambay' ),
				'section'     => 'cambay_general_section',
				'setting'     => 'cambay_color_scheme',
				'class'       => 'WP_Customize_Color_Control',
				'description' => esc_html__( 'Change theme color scheme.', 'cambay' ),
			],
			[
				'label'   => esc_html__( 'Show Primary Navigation', 'cambay' ),
				'section' => 'cambay_general_section',
				'setting' => 'cambay_primary_nav',
				'type'    => 'checkbox',
			],
			[
				'label'   => esc_html__( 'Display Header Search', 'cambay' ),
				'section' => 'cambay_general_section',
				'setting' => 'cambay_header_search',
				'type'    => 'checkbox',
			],
			[
				'label'   => esc_html__( 'Display related posts after post content', 'cambay' ),
				'section' => 'cambay_general_section',
				'setting' => 'cambay_related_posts',
				'type'    => 'checkbox',
			],
			[
				'label'   => esc_html__( 'Show Thumbnail Placeholder', 'cambay' ),
				'section' => 'cambay_general_section',
				'setting' => 'cambay_thumbnail_placeholder',
				'type'    => 'checkbox',
			],
			[
				'label'   => esc_html__( 'Blog Title', 'cambay' ),
				'section' => 'cambay_general_section',
				'setting' => 'cambay_blog_title',
				'type'    => 'text',
			],
			[
				'label'       => esc_html__( 'Footer Text', 'cambay' ),
				'section'     => 'cambay_general_section',
				'setting'     => 'cambay_footer_text',
				'type'        => 'text',
				'description' => esc_html__( 'Change footer copyright & credit text at the bottom of your site.', 'cambay' ) . '<br />' . esc_html__( 'For Site Title, Use ', 'cambay' ) . '[site_title].<br />' . esc_html__( 'For Copyright symbol, Use ', 'cambay' ) . '[copy_symbol].<br />' . esc_html__( 'For Current Year, Use ', 'cambay' ) . '[current_year]',
			],
			[
				'label'   => esc_html__( 'Page Sidebar Layout', 'cambay' ),
				'section' => 'cambay_layout_section',
				'setting' => 'cambay_page_sidebar',
				'type'    => 'select',
				'choices' => [
					'sidebar-left'  => esc_html__( 'Sidebar-Content', 'cambay' ),
					'sidebar-right' => esc_html__( 'Content-Sidebar', 'cambay' ),
					'no-sidebar'    => esc_html__( 'Only Content- No Sidebar', 'cambay' ),
				],
			],
			[
				'label'   => esc_html__( 'Post Sidebar Layout', 'cambay' ),
				'section' => 'cambay_layout_section',
				'setting' => 'cambay_post_sidebar',
				'type'    => 'select',
				'choices' => [
					'sidebar-left'  => esc_html__( 'Sidebar-Content', 'cambay' ),
					'sidebar-right' => esc_html__( 'Content-Sidebar', 'cambay' ),
					'no-sidebar'    => esc_html__( 'Only Content- No Sidebar', 'cambay' ),
				],
			],
		]
	);
}
add_filter( 'cambay_theme_controls', 'cambay_get_theme_controls' );

/**
 * Set default values for theme customization options.
 *
 * @since 1.0.0
 *
 * @param  array $defaults Array of customizer option default values.
 * @return array Returns Array of customizer option default values.
 */
function cambay_get_theme_defaults( $defaults = [] ) {
	return array_merge(
		$defaults,
		[
			'cambay_display_site_title'    => 1,
			'cambay_display_site_desc'     => 1,
			'cambay_primary_nav'           => 1,
			'cambay_header_search'         => 1,
			'cambay_related_posts'         => 1,
			'cambay_thumbnail_placeholder' => 1,
			'cambay_page_sidebar'          => 'sidebar-right',
			'cambay_post_sidebar'          => 'sidebar-right',
			'cambay_blog_title'            => '',
			'cambay_footer_text'           => '[site_title] [copy_symbol] [current_year] &middot; ' . esc_html__( 'All rights reserved', 'cambay' ), // Note: Translation friendly instructions for using footer text placeholders has been given in customizer control description.
		]
	);
}
add_filter( 'cambay_theme_defaults', 'cambay_get_theme_defaults' );
