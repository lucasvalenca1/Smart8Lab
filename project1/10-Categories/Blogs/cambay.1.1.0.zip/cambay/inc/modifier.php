<?php
/**
 * Hook into WordPress core or the Theme to modify default contents
 *
 * @package Cambay
 * @since 1.0.0
 */

/**
 * Extend the default WordPress body classes.
 *
 * @since 1.0.0
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function cambay_body_classes( $classes ) {
	// Adds a class for Single and Index view pages.
	if ( is_singular() ) {
		$classes[] = 'singular-view';

		if ( is_single() ) {
			$classes[] = cambay_get_mod( 'cambay_post_sidebar', 'attr' );
		}

		if ( is_page() ) {
			$classes[] = cambay_get_mod( 'cambay_page_sidebar', 'attr' );
		}
	} else {
		$classes[] = 'index-view';

		if ( ! ( is_home() || is_front_page() ) ) {
			$classes[] = 'archive-view';
		}
	}

	if ( is_singular( 'page' ) && has_post_thumbnail() ) {
		$classes[] = 'has-header-image';
	} elseif ( is_home() && get_header_image() ) {
		$classes[] = 'has-header-image';
	}

	return $classes;
}
add_filter( 'body_class', 'cambay_body_classes' );

/**
 * Change excerpt length.
 *
 * Change excerpt length to be displayed on main, archive and search
 * pages, default excerpt length is 20.
 *
 * @since 1.0.0
 *
 * @param int $length excert length.
 * @return integer
 */
function cambay_excerpt_length( $length ) {
	// Number of words to be shown in post excerpt.
	$length = 15;
	return $length;
}
add_filter( 'excerpt_length', 'cambay_excerpt_length' );

/**
 * Extend the default WordPress post classes.
 *
 * @since 1.0.0
 *
 * @param array $classes Classes for the post element.
 * @return array
 */
function cambay_post_classes( $classes ) {
	// Adds a class for posts.
	$classes[] = 'entry';

	if ( ! ( is_singular() || in_array( 'product', $classes, true ) ) || is_search() ) {
		$classes[] = 'fw-tab-6 fw-tabr-4';
	}

	return $classes;
}
add_filter( 'post_class', 'cambay_post_classes' );

/**
 * Adds a class to control maximum width of primary site elements.
 *
 * @since 1.0.0
 *
 * @param array $attr attribute values array.
 * @return array
 */
function cambay_primary_wrapper( $attr ) {
	$attr['class'] .= ' wrapper';
	return $attr;
}
add_filter( 'cambay_get_attr_header_items', 'cambay_primary_wrapper' );
add_filter( 'cambay_get_attr_footer_items', 'cambay_primary_wrapper' );
add_filter( 'cambay_get_attr_secondary_items', 'cambay_primary_wrapper' );
add_filter( 'cambay_get_attr_page_entry_header', 'cambay_primary_wrapper' );

/**
 * Adds a wrapper class to appropriate site content.
 *
 * @since 1.0.0
 *
 * @param array $attr attribute values array.
 * @return array
 */
function cambay_content_wrapper( $attr ) {
	if ( is_singular() || ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) ) {
		$attr['class'] .= ' wrapper';
	}
	return $attr;
}
add_filter( 'cambay_get_attr_site_content', 'cambay_content_wrapper' );

/**
 * Adds a flex wrapper class to appropriate site elements.
 *
 * @since 1.0.0
 *
 * @param array $attr attribute values array.
 * @return array
 */
function cambay_flex_wrapper( $attr ) {
	if ( ! is_singular() && ! ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) ) {
		$attr['class'] .= ' flex-wrapper';
	}
	return $attr;
}
add_filter( 'cambay_get_attr_site_main', 'cambay_flex_wrapper' );

/**
 * Adds class to site footer.
 *
 * @since 1.0.0
 *
 * @param array $attr attribute values array.
 * @return array
 */
function cambay_site_footer_classes( $attr ) {
	if ( is_active_sidebar( 'footer' ) ) {
		$attr['class'] .= ' has-footer-widgets';
	}
	return $attr;
}
add_filter( 'cambay_get_attr_site_footer', 'cambay_site_footer_classes' );

/**
 * Adding Custom Images Sizes to the WordPress Media Library (Admin).
 *
 * @since 1.0.0
 *
 * @param array $size_names Array of image sizes and their names.
 * @return array
 */
function cambay_custom_image_sizes_to_admin( $size_names ) {
	return array_merge(
		$size_names,
		[
			'cambay-small'  => esc_html__( 'Cambay Small', 'cambay' ),
			'cambay-medium' => esc_html__( 'Cambay Medium', 'cambay' ),
			'cambay-large'  => esc_html__( 'Cambay Large', 'cambay' ),
		]
	);
}
add_filter( 'image_size_names_choose', 'cambay_custom_image_sizes_to_admin' );

/**
 * Create dynamic css for theme color scheme.
 *
 * @since 1.0.0
 *
 * @param str $css Dynamically generated css string.
 * @return str
 */
function cambay_color_scheme_css( $css ) {

	$color = cambay_get_mod( 'cambay_color_scheme', 'color' ); // Escaped by cambay_escape function.
	if ( ! $color ) {
		return $css;
	}

	$rgb_color = cambay_hex_to_rgb( $color, true );

	$css .= sprintf(
		'
		a,
		.social-navigation ul.nav-menu--social a:hover,
		.social-navigation ul.nav-menu--social a:focus,
		.site-navigation ul ul a:hover,
		.site-navigation ul ul a:focus,
		.comment-metadata a:hover,
		.comment-metadata a:focus,
		.comment-author a:hover,
		.comment-author a:focus,
		.woocommerce div.product .star-rating,
		.dp-categories a:hover,
		.dp-categories a:focus,
		ul.products .button,
		ul.products a.added_to_cart,
		.woocommerce-tabs .wc-tabs li a:hover,
		.woocommerce-tabs .wc-tabs li a:focus,
		.entry-featured-content .quick-action,
		.dp-featured-content .quick-action {
			color: %1$s;
		}
		a.button,
		button,
		input[type="button"],
		input[type="reset"],
		input[type="submit"],
		.ui-slider .ui-slider-range.ui-slider-range,
		.ui-slider .ui-slider-handle.ui-slider-handle,
		.ui-widget-content {
			background-color: %1$s;
		}
		input[type="date"]:focus,
		input[type="time"]:focus,
		input[type="datetime-local"]:focus,
		input[type="week"]:focus,
		input[type="month"]:focus,
		input[type="text"]:focus,
		input[type="email"]:focus,
		input[type="url"]:focus,
		input[type="password"]:focus,
		input[type="search"]:focus,
		input[type="tel"]:focus,
		input[type="number"]:focus,
		textarea:focus,
		select:focus {
			-webkit-box-shadow: inset 0 0 1px %1$s;
	        		box-shadow: inset 0 0 1px %1$s;
		}
		.has-featured-img.text-layout1 .custom-widget-thumbnail:before {
			border-color: %1$s;
		}
		',
		$color,
		$rgb_color
	);

	return $css;
}
add_filter( 'cambay_inline_styles', 'cambay_color_scheme_css' );

/**
 * Create dynamic css for theme color scheme.
 *
 * @since 1.0.0
 *
 * @param str $css Dynamically generated css string.
 * @return str
 */
function cambay_editor_color_scheme_css( $css ) {

	$color = cambay_get_mod( 'cambay_color_scheme', 'color' ); // Escaped by cambay_escape function.
	if ( ! $color ) {
		return $css;
	}

	$css .= sprintf(
		'
		a,
		.editor-rich-text__tinymce a,
		.wp-block-freeform.block-library-rich-text__tinymce a {
			color: %1$s;
		}
		a.button,
		.wp-block-freeform.block-library-rich-text__tinymce a.button {
			background-color: %1$s;
		}
		',
		$color
	);

	return $css;
}
add_filter( 'cambay_dynamic_classic_editor_styles', 'cambay_editor_color_scheme_css' );
add_filter( 'cambay_gutenberg_styles', 'cambay_editor_color_scheme_css' );
