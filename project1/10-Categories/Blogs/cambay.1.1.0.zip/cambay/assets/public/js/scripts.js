import Main from './modules/main';
new Main();