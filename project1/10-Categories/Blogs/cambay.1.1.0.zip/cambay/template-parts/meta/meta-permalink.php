<?php
/**
 * The template part for displaying post permalink with quick action toggle.
 *
 * @package Cambay
 * @since 1.0.0
 */

?>
<a href="<?php the_permalink(); ?>"<?php cambay_attr( 'post-permalink' ); ?>>
	<span class="screen-reader-text"><?php the_title(); ?></span>
</a>
