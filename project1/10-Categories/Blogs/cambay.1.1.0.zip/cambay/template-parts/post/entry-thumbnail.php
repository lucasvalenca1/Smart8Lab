<?php
/**
 * The template part for displaying current post thumbnail on index pages.
 *
 * @package Cambay
 * @since 1.0.0
 */

if ( has_post_thumbnail() ) :
	$cambay_thumb_size = is_singular() ? 'cambay-large' : 'cambay-medium';
	?>
	<div<?php cambay_attr( 'entry-thumbnail' ); ?>>
		<?php the_post_thumbnail( $cambay_thumb_size ); ?>
	</div><!-- .entry-thumbnail -->
	<?php
endif;
