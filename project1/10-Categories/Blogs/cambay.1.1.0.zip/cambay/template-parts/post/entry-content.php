<?php
/**
 * The template part for displaying current post/page content.
 *
 * @package Cambay
 * @since 1.0.0
 */

the_content(
	sprintf(
		/* translators: %s: Name of current post */
		esc_html__( 'Continue reading %s', 'cambay' ),
		the_title( '<span class="screen-reader-text">', '</span>', false )
	)
);

wp_link_pages(
	[
		'before' => '<div' . cambay_get_attr( 'page-links' ) . '>' . esc_html__( 'Pages:', 'cambay' ),
		'after'  => '</div>',
	]
);
