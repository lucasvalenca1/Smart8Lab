<?php
/**
 * The template part for displaying site description
 *
 * @package Cambay
 * @since 1.0.0
 */

$cambay_description = get_bloginfo( 'description', 'display' );
if ( $cambay_description || is_customize_preview() ) : ?>
	<h2<?php cambay_attr( 'site-description' ); ?>>
		<span class="site-desc">
		<?php
		echo $cambay_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		?>
		</span>
	</h2>
<?php endif; ?>
