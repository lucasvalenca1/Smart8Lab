<?php
/**
 * Display WooCommerce search form
 *
 * @link https://developer.wordpress.org/reference/functions/get_search_form
 *
 * @package Cambay
 * @since 1.0.0
 */

?>

<form method="get"<?php cambay_attr( 'search-form' ); ?> action="<?php echo esc_url( home_url( '/' ) ); ?>">
<label class="label-search">
	<span class="screen-reader-text"><?php echo esc_html_x( 'Search for:', 'label', 'cambay' ); ?></span>
	<input type="search"<?php cambay_attr( 'search-field' ); ?> placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'cambay' ); ?>" value="<?php echo get_search_query(); ?>" name="s" title="<?php echo esc_attr_x( 'Search for:', 'label', 'cambay' ); ?>" />
</label>
<button type="submit"<?php cambay_attr( 'search-submit' ); ?>><?php cambay_icon( [ 'icon' => 'search' ] ); ?><span class="screen-reader-text"><?php echo esc_html_x( 'Search', 'submit button', 'cambay' ); ?></span></button>
<input type="hidden" name="post_type" value="product" />
</form>
