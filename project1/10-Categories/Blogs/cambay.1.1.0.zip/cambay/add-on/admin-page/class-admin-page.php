<?php
/**
 * Display Cambay theme admin page in Dashboard > Appearance.
 *
 * @package Cambay
 * @since 1.0.2
 */

namespace cambay;

/**
 * Display Cambay theme admin page in Dashboard > Appearance.
 *
 * @since  1.0.2
 */
class Admin_Page {

	/**
	 * Constructor method.
	 *
	 * @since  1.0.2
	 */
	public function __construct() {}

	/**
	 * Register hooked functions.
	 *
	 * @since 1.0.2
	 */
	public function init() {
		global $pagenow;

		// Add Welcome message on Theme activation.
		if ( is_admin() && 'themes.php' === $pagenow && isset( $_GET['activated'] ) ) {
			add_action( 'admin_notices', [ $this, 'welcome_theme_notice' ], 99 );
		}
	}

	/**
	 * Display Welcome Message on Theme activation.
	 *
	 * @since  1.0.2
	 *
	 * @return void
	 */
	public function welcome_theme_notice() {
		// Since Manta is not the active theme, let user know Manta Plus will not work.
		printf(
			'<div class="updated notice is-dismissible theme-welcome-notice">
				<p>%s</p><p>%s</p>
					<ol class="cambay-admin-tips">
						<li>%s</li>
						<li>%s<a href="%s" target="_blank">%s</a>%s</li>
						<li>%s</li>
						<li>%s<a href="%s" target="_blank">%s</a>%s</li>
						<li>%s<a href="%s" target="_blank">%s</a></li>
					</ol>
				<p>%s</p>
			</div>',
			esc_html__( 'Hi there!', 'cambay' ),
			esc_html__( 'Thanks for trying Cambay. Here are some quick tips to get you started.', 'cambay' ),
			esc_html__( 'Use "Display Posts" widget from Appearance > Widgets to create various posts layout.', 'cambay' ),
			esc_html__( 'Alternatively use ', 'cambay' ),
			esc_url( 'https://wordpress.org/plugins/display-post-types/' ),
			esc_html__( 'Display Post Types', 'cambay' ),
			esc_html__( ' plugin for more posts display options.', 'cambay' ),
			esc_html__( 'Use "Blank Widget" widget from Appearance > Widgets to create vertical gaps between widgets.', 'cambay' ),
			esc_html__( 'Visit ', 'cambay' ),
			esc_url( 'https://vedathemes.com/documentation/cambay-documentation/' ),
			esc_html__( 'quick setup guide', 'cambay' ),
			esc_html__( ' to get started', 'cambay' ),
			esc_html__( 'Get Support at ', 'cambay' ),
			esc_url( 'https://wordpress.org/support/theme/cambay/' ),
			esc_html__( 'Support Forum', 'cambay' ),
			esc_html__( 'Thank You', 'cambay' )
		);
	}
}

$cambay_admin_page = new Admin_Page();
$cambay_admin_page->init();
