<?php
/**
 * footer Template.
 *
 * @package CBusiness Consult Lite
 */
?>
<footer>	
	<?php get_template_part('app/template', 'footerbottom');?>		
</footer>
<?php wp_footer(); ?>

</body>
</html>