<?php
/**
 * @package cbusiness-consult-lite
 */
get_header(); ?>
<div id="content" class="container">
    		<div class="site-aligner">
			<?php woocommerce_content(); ?>
		   </div><!-- site-aligner -->
    </div><!-- content -->
     
<?php get_footer(); ?>