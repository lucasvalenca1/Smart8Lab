/* global twentyseventeenScreenReaderText */
/**
 * Theme functions file.
 *
 * Contains handlers for navigation and widget area.
 */

// (function( $ ) {
// 	var masthead, siteNavigation;

// 	masthead       = $( '#mainmenu' );
// 	siteNavigation = masthead.find( '.main-navigation > div > ul' );

// 	(function() {
// 		if ( ! siteNavigation.length || ! siteNavigation.children().length ) {
// 			return;
// 		}

// 		siteNavigation.find( 'a' ).on( 'focus blur', function() {
// 			$( this ).parents( '.menu-item, .page_item' ).toggleClass( 'focus' );
// 		});
// 	})();
// })( jQuery );
