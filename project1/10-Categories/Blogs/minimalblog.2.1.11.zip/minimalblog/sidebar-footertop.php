<?php
/**
 * Display Footer Dynamic sidebar
 */
?>

<section class="footer-top-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<?php
					dynamic_sidebar( 'footer-top' );
				?>
			</div>
		</div>
	</div>
</section>

