<?php get_header(); ?>
<section class="shop-page-main-block section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12 order-0 order-md-0 order-lg-1">
				<?php woocommerce_content(); ?>
			</div>
		</div>
	</div>
</section>
<?php get_footer(); ?>
