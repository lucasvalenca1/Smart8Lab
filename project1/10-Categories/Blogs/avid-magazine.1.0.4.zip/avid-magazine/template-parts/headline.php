<div class="headline-ticker">
<?php
	if( get_theme_mod( 'theme_headline_display_option', false ) ) {		
		avid_magazine_get_headline();
	}
?>
</div>