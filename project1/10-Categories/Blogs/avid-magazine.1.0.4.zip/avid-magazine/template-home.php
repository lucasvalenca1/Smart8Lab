<?php

get_header();


get_template_part( 'template-parts/home-sections/featured', '' );
get_template_part( 'template-parts/home-sections/blog', '' );



get_footer();