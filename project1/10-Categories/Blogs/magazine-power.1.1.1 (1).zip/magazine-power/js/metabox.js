( function( $ ) {

	$( document ).ready( function( $ ) {

		$( '#magazine-power-settings-metabox-container' ).tabs();

	});

} )( jQuery );
