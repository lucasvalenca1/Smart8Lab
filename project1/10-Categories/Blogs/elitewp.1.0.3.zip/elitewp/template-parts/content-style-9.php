<?php
/**
* Template part for displaying posts.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

<div id="post-<?php the_ID(); ?>" class="elitewp-fp09-post">

    <?php if ( has_post_thumbnail() ) { ?>
    <?php if ( !(elitewp_get_option('hide_thumbnail')) ) { ?>
    <div class="elitewp-fp09-post-thumbnail">
        <a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php /* translators: %s: post title. */ echo esc_attr( sprintf( __( 'Permanent Link to %s', 'elitewp' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_post_thumbnail('elitewp-featured-image', array('class' => 'elitewp-fp09-post-thumbnail-img')); ?></a>
    </div>
    <?php } ?>
    <?php } ?>

    <?php if((has_post_thumbnail()) && !(elitewp_get_option('hide_thumbnail'))) { ?><div class="elitewp-fp09-post-details"><?php } ?>
    <?php if(!(has_post_thumbnail()) || (elitewp_get_option('hide_thumbnail'))) { ?><div class="elitewp-fp09-post-details-full"><?php } ?>

    <?php if ( !(elitewp_get_option('hide_post_categories_home')) ) { ?><?php elitewp_style_9_cats(); ?><?php } ?>

    <?php the_title( sprintf( '<h3 class="elitewp-fp09-post-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>

    <?php elitewp_style_9_postmeta(); ?>

    <div class="elitewp-fp09-post-snippet clearfix">
    <?php
    the_content( sprintf(
        wp_kses(
            /* translators: %s: Name of current post. Only visible to screen readers */
            __( 'Continue reading<span class="screen-reader-text"> "%s"</span> <span class="meta-nav">&rarr;</span>', 'elitewp' ),
            array(
                'span' => array(
                    'class' => array(),
                ),
            )
        ),
        get_the_title()
    ) );

    wp_link_pages( array(
     'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'elitewp' ) . '</span>',
     'after'       => '</div>',
     'link_before' => '<span>',
     'link_after'  => '</span>',
     'separator'   => '',
     ) );
    ?>
    </div>

    <?php if ( !(elitewp_get_option('hide_post_tags_home')) ) { ?>
    <footer class="elitewp-fp09-post-footer">
        <?php elitewp_post_tags(); ?>
    </footer>
    <?php } ?>

    <?php if(!(has_post_thumbnail()) || (elitewp_get_option('hide_thumbnail'))) { ?></div><?php } ?>
    <?php if((has_post_thumbnail()) && !(elitewp_get_option('hide_thumbnail'))) { ?></div><?php } ?>

</div>