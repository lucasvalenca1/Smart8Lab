<?php
/**
* The template for displaying the footer
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

</div>

</div><!--/#elitewp-content-wrapper -->
</div><!--/#elitewp-wrapper -->

<?php if ( !(elitewp_get_option('disable_secondary_menu')) ) { ?>
<div class="elitewp-container elitewp-secondary-menu-container clearfix">
<div class="elitewp-secondary-menu-container-inside clearfix">
<nav class="elitewp-nav-secondary" id="elitewp-secondary-navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation" aria-label="<?php esc_attr_e( 'Secondary Menu', 'elitewp' ); ?>">
<div class="elitewp-outer-wrapper">
<button class="elitewp-secondary-responsive-menu-icon" aria-controls="elitewp-menu-secondary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'elitewp' ); ?></button>
<?php wp_nav_menu( array( 'theme_location' => 'secondary', 'menu_id' => 'elitewp-menu-secondary-navigation', 'menu_class' => 'elitewp-secondary-nav-menu elitewp-menu-secondary', 'fallback_cb' => 'elitewp_top_fallback_menu', 'container' => '', ) ); ?>
</div>
</nav>
</div>
</div>
<?php } ?>

<?php if ( !(elitewp_get_option('hide_footer_widgets')) ) { ?>
<?php if ( is_active_sidebar( 'elitewp-footer-1' ) || is_active_sidebar( 'elitewp-footer-2' ) || is_active_sidebar( 'elitewp-footer-3' ) || is_active_sidebar( 'elitewp-footer-4' ) || is_active_sidebar( 'elitewp-top-footer' ) || is_active_sidebar( 'elitewp-bottom-footer' ) ) : ?>
<div class='clearfix' id='elitewp-footer-blocks' itemscope='itemscope' itemtype='http://schema.org/WPFooter' role='contentinfo'>
<div class='elitewp-container clearfix'>
<div class="elitewp-outer-wrapper">

<?php if ( is_active_sidebar( 'elitewp-top-footer' ) ) : ?>
<div class='clearfix'>
<div class='elitewp-top-footer-block'>
<?php dynamic_sidebar( 'elitewp-top-footer' ); ?>
</div>
</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'elitewp-footer-1' ) || is_active_sidebar( 'elitewp-footer-2' ) || is_active_sidebar( 'elitewp-footer-3' ) || is_active_sidebar( 'elitewp-footer-4' ) ) : ?>
<div class='elitewp-footer-block-cols clearfix'>

<div class="elitewp-footer-block-col <?php echo esc_attr( elitewp_footer_grid_cols() ); ?>" id="elitewp-footer-block-1">
<?php dynamic_sidebar( 'elitewp-footer-1' ); ?>
</div>

<div class="elitewp-footer-block-col <?php echo esc_attr( elitewp_footer_grid_cols() ); ?>" id="elitewp-footer-block-2">
<?php dynamic_sidebar( 'elitewp-footer-2' ); ?>
</div>

<div class="elitewp-footer-block-col <?php echo esc_attr( elitewp_footer_grid_cols() ); ?>" id="elitewp-footer-block-3">
<?php dynamic_sidebar( 'elitewp-footer-3' ); ?>
</div>

<div class="elitewp-footer-block-col <?php echo esc_attr( elitewp_footer_grid_cols() ); ?>" id="elitewp-footer-block-4">
<?php dynamic_sidebar( 'elitewp-footer-4' ); ?>
</div>

</div>
<?php endif; ?>

<?php if ( is_active_sidebar( 'elitewp-bottom-footer' ) ) : ?>
<div class='clearfix'>
<div class='elitewp-bottom-footer-block'>
<?php dynamic_sidebar( 'elitewp-bottom-footer' ); ?>
</div>
</div>
<?php endif; ?>

</div>
</div>
</div><!--/#elitewp-footer-blocks-->
<?php endif; ?>
<?php } ?>


<div class='clearfix' id='elitewp-footer'>
<div class='elitewp-foot-wrap elitewp-container'>
<div class="elitewp-outer-wrapper">

<?php if ( elitewp_get_option('footer_text') ) : ?>
  <p class='elitewp-copyright'><?php echo esc_html(elitewp_get_option('footer_text')); ?></p>
<?php else : ?>
  <p class='elitewp-copyright'><?php /* translators: %s: Year and site name. */ printf( esc_html__( 'Copyright &copy; %s', 'elitewp' ), esc_html(date_i18n(__('Y','elitewp'))) . ' ' . esc_html(get_bloginfo( 'name' ))  ); ?></p>
<?php endif; ?>
<p class='elitewp-credit'><a href="<?php echo esc_url( 'https://themesdna.com/' ); ?>"><?php /* translators: %s: Theme author. */ printf( esc_html__( 'Design by %s', 'elitewp' ), 'ThemesDNA.com' ); ?></a></p>

</div>
</div>
</div><!--/#elitewp-footer -->

<button class="elitewp-scroll-top" title="<?php esc_attr_e('Scroll to Top','elitewp'); ?>"><span class="fa fa-arrow-up" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html__('Scroll to Top', 'elitewp'); ?></span></button>

<?php wp_footer(); ?>
</body>
</html>