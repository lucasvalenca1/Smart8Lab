<?php
/**
* Recommended plugins options
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function elitewp_recomm_plugin_options($wp_customize) {

    // Customizer Section: Recommended Plugins
    $wp_customize->add_section( 'sc_recommended_plugins', array( 'title' => esc_html__( 'Recommended Plugins', 'elitewp' ), 'panel' => 'elitewp_main_options_panel', 'priority' => 880 ));

    $wp_customize->add_setting( 'elitewp_options[recommended_plugins]', array( 'type' => 'option', 'capability' => 'install_plugins', 'sanitize_callback' => 'elitewp_sanitize_recommended_plugins' ) );

    $wp_customize->add_control( new EliteWP_Customize_Recommended_Plugins( $wp_customize, 'elitewp_recommended_plugins_control', array( 'label' => esc_html__( 'Recommended Plugins', 'elitewp' ), 'section' => 'sc_recommended_plugins', 'settings' => 'elitewp_options[recommended_plugins]', 'type' => 'tdna-recommended-wpplugins', 'capability' => 'install_plugins' ) ) );

}