<?php
/**
* Upgrade to pro options
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license licennse URI, for example : http://www.gnu.org/licenses/gpl-2.0.html
* @author ThemesDNA <themesdna@gmail.com>
*/

function elitewp_upgrade_to_pro($wp_customize) {

    $wp_customize->add_section( 'sc_elitewp_upgrade', array( 'title' => esc_html__( 'Upgrade to Pro Version', 'elitewp' ), 'priority' => 400 ) );
    
    $wp_customize->add_setting( 'elitewp_options[upgrade_text]', array( 'default' => '', 'sanitize_callback' => '__return_false', ) );
    
    $wp_customize->add_control( new EliteWP_Customize_Static_Text_Control( $wp_customize, 'elitewp_upgrade_text_control', array(
        'label'       => esc_html__( 'EliteWP Pro', 'elitewp' ),
        'section'     => 'sc_elitewp_upgrade',
        'settings' => 'elitewp_options[upgrade_text]',
        'description' => esc_html__( 'Do you enjoy EliteWP? Upgrade to EliteWP Pro now and get:', 'elitewp' ).
            '<ul class="elitewp-customizer-pro-features">' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Color Options', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Font Options', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Layout Options (separate options for singular and non-singular pages)', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( '10+ Custom Page/Post Templates', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( '10 Different Posts Styles', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( '17 Different Featured Posts Widgets(each widget displays recent/popular/random posts or posts from a given category or tag.)', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Slider with More Options(this widget displays recent/popular/random posts or posts from a given category or tag.', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'News Ticker', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Tabbed Widget', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Social Profiles Widget and About Me Widget', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Footer with Layout Options (1/2/3/4 columns)', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Post Share Buttons', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Related Posts with Thumbnails', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Author Bio Box with Social Buttons', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Sticky Menu/Sticky Sidebars with enable/disable capability', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Built-in Contact Form', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'WooCommerce Support', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'Search Engine Optimized', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'More Customizer options', 'elitewp' ) . '</li>' .
                '<li><i class="fa fa-check"></i> ' . esc_html__( 'More Features...', 'elitewp' ) . '</li>' .
            '</ul>'.
            '<strong><a href="'.ELITEWP_PROURL.'" class="button button-primary" target="_blank"><i class="fa fa-shopping-cart"></i> ' . esc_html__( 'Upgrade To EliteWP PRO', 'elitewp' ) . '</a></strong>'
    ) ) ); 

}