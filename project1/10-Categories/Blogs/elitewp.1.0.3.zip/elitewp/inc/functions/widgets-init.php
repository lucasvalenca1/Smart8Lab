<?php
/**
* Register widget area.
*
* @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function elitewp_widgets_init() {

register_sidebar(array(
    'id' => 'elitewp-header-banner',
    'name' => esc_html__( 'Header Banner', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the header of the web page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-header-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title">',
    'after_title' => '</h2>'));

register_sidebar(array(
    'id' => 'elitewp-sidebar-one',
    'name' => esc_html__( 'Sidebar 1', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is normally located on the left-hand side of web page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-side-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-front-fullwidth-widgets',
    'name' => esc_html__( 'Top Full Width Widgets (Front Page Only)', 'elitewp' ),
    'description' => esc_html__( 'This full-width widget area is located at the top of homepage.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-main-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-fullwidth-widgets',
    'name' => esc_html__( 'Top Full Width Widgets (Every Page)', 'elitewp' ),
    'description' => esc_html__( 'This full-width widget area is located at the top of every page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-main-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-front-top-widgets',
    'name' => esc_html__( 'Top Widgets (Front Page Only)', 'elitewp' ),
    'description' => esc_html__( 'This widget area is located at the top of homepage.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-main-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-top-widgets',
    'name' => esc_html__( 'Top Widgets (Every Page)', 'elitewp' ),
    'description' => esc_html__( 'This widget area is located at the top of every page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-main-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-front-bottom-widgets',
    'name' => esc_html__( 'Bottom Widgets (Front Page Only)', 'elitewp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of homepage.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-main-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-bottom-widgets',
    'name' => esc_html__( 'Bottom Widgets (Every Page)', 'elitewp' ),
    'description' => esc_html__( 'This widget area is located at the bottom of every page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-main-widget widget elitewp-box %2$s"><div class="elitewp-box-inside">',
    'after_widget' => '</div></div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-top-footer',
    'name' => esc_html__( 'Footer Top', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the top of the footer.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-footer-1',
    'name' => esc_html__( 'Footer 1', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the left bottom of web page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-footer-2',
    'name' => esc_html__( 'Footer 2', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the middle bottom of web page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-footer-3',
    'name' => esc_html__( 'Footer 3', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the middle bottom of web page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-footer-4',
    'name' => esc_html__( 'Footer 4', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the right bottom of web page.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

register_sidebar(array(
    'id' => 'elitewp-bottom-footer',
    'name' => esc_html__( 'Footer Bottom', 'elitewp' ),
    'description' => esc_html__( 'This sidebar is located on the bottom of the footer.', 'elitewp' ),
    'before_widget' => '<div id="%1$s" class="elitewp-footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h2 class="elitewp-widget-title"><span>',
    'after_title' => '</span></h2>'));

}
add_action( 'widgets_init', 'elitewp_widgets_init' );


function elitewp_top_wide_widgets() { ?>

<?php if ( is_active_sidebar( 'elitewp-front-fullwidth-widgets' ) || is_active_sidebar( 'elitewp-fullwidth-widgets' ) ) : ?>
<div class="elitewp-top-wrapper-outer clearfix">
<div class="elitewp-featured-posts-area elitewp-top-wrapper clearfix">
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'elitewp-front-fullwidth-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'elitewp-fullwidth-widgets' ); ?>
</div>
</div>
<?php endif; ?>

<?php }


function elitewp_top_widgets() { ?>

<?php if ( is_active_sidebar( 'elitewp-front-top-widgets' ) || is_active_sidebar( 'elitewp-top-widgets' ) ) : ?>
<div class="elitewp-featured-posts-area elitewp-featured-posts-area-top clearfix">
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'elitewp-front-top-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'elitewp-top-widgets' ); ?>
</div>
<?php endif; ?>

<?php }


function elitewp_bottom_widgets() { ?>

<?php if ( is_active_sidebar( 'elitewp-front-bottom-widgets' ) || is_active_sidebar( 'elitewp-bottom-widgets' ) ) : ?>
<div class='elitewp-featured-posts-area elitewp-featured-posts-area-bottom clearfix'>
<?php if ( is_front_page() && is_home() && !is_paged() ) { ?>
<?php dynamic_sidebar( 'elitewp-front-bottom-widgets' ); ?>
<?php } ?>

<?php dynamic_sidebar( 'elitewp-bottom-widgets' ); ?>
</div>
<?php endif; ?>

<?php }