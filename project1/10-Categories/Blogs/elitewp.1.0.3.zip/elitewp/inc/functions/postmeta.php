<?php
/**
* Post meta functions
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

if ( ! function_exists( 'elitewp_post_tags' ) ) :
/**
 * Prints HTML with meta information for the tags.
 */
function elitewp_post_tags() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space after the comma */
        $tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'elitewp' ) );
        if ( $tags_list ) {
            /* translators: 1: list of tags. */
            printf( '<span class="elitewp-tags-links"><i class="fa fa-tags" aria-hidden="true"></i> ' . esc_html__( 'Tagged %1$s', 'elitewp' ) . '</span>', $tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;


if ( ! function_exists( 'elitewp_style_9_cats' ) ) :
function elitewp_style_9_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( '&nbsp;', 'elitewp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="elitewp-fp09-post-categories">' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'elitewp' ) . '</div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;


if ( ! function_exists( 'elitewp_style_9_postmeta' ) ) :
function elitewp_style_9_postmeta() { ?>
    <?php if ( !(elitewp_get_option('hide_post_author_home')) || !(elitewp_get_option('hide_posted_date_home')) || !(elitewp_get_option('hide_comments_link_home')) ) { ?>
    <div class="elitewp-fp09-post-footer">
    <?php if ( !(elitewp_get_option('hide_post_author_home')) ) { ?><span class="elitewp-fp09-post-author elitewp-fp09-post-meta"><i class="fa fa-user-circle-o"></i>&nbsp;<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><span class="screen-reader-text"><?php esc_html_e('Author: ', 'elitewp'); ?></span><?php echo esc_html( get_the_author() ); ?></a></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_posted_date_home')) ) { ?><span class="elitewp-fp09-post-date elitewp-fp09-post-meta"><i class="fa fa-clock-o"></i>&nbsp;<span class="screen-reader-text"><?php esc_html_e('Published Date: ', 'elitewp'); ?></span><?php echo get_the_date(); ?></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_comments_link_home')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="elitewp-fp09-post-comment elitewp-fp09-post-meta"><i class="fa fa-comments-o"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'elitewp' ), array( 'span' => array( 'class' => array(), ), ) ), get_the_title() ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;



if ( ! function_exists( 'elitewp_style_4_cats' ) ) :
function elitewp_style_4_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( '&nbsp;', 'elitewp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="elitewp-fp04-post-categories">' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'elitewp' ) . '</div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;


if ( ! function_exists( 'elitewp_style_4_postmeta' ) ) :
function elitewp_style_4_postmeta() { ?>
    <?php if ( !(elitewp_get_option('hide_post_author_home')) || !(elitewp_get_option('hide_posted_date_home')) || !(elitewp_get_option('hide_comments_link_home')) ) { ?>
    <div class="elitewp-fp04-post-footer">
    <?php if ( !(elitewp_get_option('hide_post_author_home')) ) { ?><span class="elitewp-fp04-post-author elitewp-fp04-post-meta"><i class="fa fa-user-circle-o"></i>&nbsp;<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><span class="screen-reader-text"><?php esc_html_e('Author: ', 'elitewp'); ?></span><?php echo esc_html( get_the_author() ); ?></a></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_posted_date_home')) ) { ?><span class="elitewp-fp04-post-date elitewp-fp04-post-meta"><i class="fa fa-clock-o"></i>&nbsp;<span class="screen-reader-text"><?php esc_html_e('Published Date: ', 'elitewp'); ?></span><?php echo get_the_date(); ?></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_comments_link_home')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="elitewp-fp04-post-comment elitewp-fp04-post-meta"><i class="fa fa-comments-o"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'elitewp' ), array( 'span' => array( 'class' => array(), ), ) ), get_the_title() ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;


if ( ! function_exists( 'elitewp_style_5_cats' ) ) :
function elitewp_style_5_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( '&nbsp;', 'elitewp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="elitewp-fp05-post-categories">' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'elitewp' ) . '</div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;


if ( ! function_exists( 'elitewp_style_5_postmeta' ) ) :
function elitewp_style_5_postmeta() { ?>
    <?php if ( !(elitewp_get_option('hide_post_author_home')) || !(elitewp_get_option('hide_posted_date_home')) || !(elitewp_get_option('hide_comments_link_home')) ) { ?>
    <div class="elitewp-fp05-post-footer">
    <?php if ( !(elitewp_get_option('hide_post_author_home')) ) { ?><span class="elitewp-fp05-post-author elitewp-fp05-post-meta"><i class="fa fa-user-circle-o"></i>&nbsp;<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><span class="screen-reader-text"><?php esc_html_e('Author: ', 'elitewp'); ?></span><?php echo esc_html( get_the_author() ); ?></a></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_posted_date_home')) ) { ?><span class="elitewp-fp05-post-date elitewp-fp05-post-meta"><i class="fa fa-clock-o"></i>&nbsp;<span class="screen-reader-text"><?php esc_html_e('Published Date: ', 'elitewp'); ?></span><?php echo get_the_date(); ?></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_comments_link_home')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="elitewp-fp05-post-comment elitewp-fp05-post-meta"><i class="fa fa-comments-o"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'elitewp' ), array( 'span' => array( 'class' => array(), ), ) ), get_the_title() ) ); ?></span>
    <?php } ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;


if ( ! function_exists( 'elitewp_single_cats' ) ) :
function elitewp_single_cats() {
    if ( 'post' == get_post_type() ) {
        /* translators: used between list items, there is a space */
        $categories_list = get_the_category_list( esc_html__( ', ', 'elitewp' ) );
        if ( $categories_list ) {
            /* translators: 1: list of categories. */
            printf( '<div class="elitewp-entry-meta-single elitewp-entry-meta-single-top"><span class="elitewp-entry-meta-single-cats"><i class="fa fa-folder-open-o"></i>&nbsp;' . __( '<span class="screen-reader-text">Posted in </span>%1$s', 'elitewp' ) . '</span></div>', $categories_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }
    }
}
endif;


if ( ! function_exists( 'elitewp_single_postmeta' ) ) :
function elitewp_single_postmeta() { ?>
    <?php if ( !(elitewp_get_option('hide_post_author')) || !(elitewp_get_option('hide_posted_date')) || !(elitewp_get_option('hide_comments_link')) || !(elitewp_get_option('hide_post_edit')) ) { ?>
    <div class="elitewp-entry-meta-single">
    <?php if ( !(elitewp_get_option('hide_post_author')) ) { ?><span class="elitewp-entry-meta-single-author"><i class="fa fa-user-circle-o"></i>&nbsp;<span class="author vcard" itemscope="itemscope" itemtype="http://schema.org/Person" itemprop="author"><a class="url fn n" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><span class="screen-reader-text"><?php esc_html_e('Author: ', 'elitewp'); ?></span><?php echo esc_html( get_the_author() ); ?></a></span></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_posted_date')) ) { ?><span class="elitewp-entry-meta-single-date"><i class="fa fa-clock-o"></i>&nbsp;<span class="screen-reader-text"><?php esc_html_e('Published Date: ', 'elitewp'); ?></span><?php echo get_the_date(); ?></span><?php } ?>
    <?php if ( !(elitewp_get_option('hide_comments_link')) ) { ?><?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
    <span class="elitewp-entry-meta-single-comments"><i class="fa fa-comments-o"></i>&nbsp;<?php comments_popup_link( sprintf( wp_kses( /* translators: %s: post title */ __( 'Leave a Comment<span class="screen-reader-text"> on %s</span>', 'elitewp' ), array( 'span' => array( 'class' => array(), ), ) ), get_the_title() ) ); ?></span>
    <?php } ?><?php } ?>
    <?php if ( !(elitewp_get_option('hide_post_edit')) ) { ?><?php edit_post_link( sprintf( wp_kses( /* translators: %s: Name of current post. Only visible to screen readers */ __( 'Edit<span class="screen-reader-text"> %s</span>', 'elitewp' ), array( 'span' => array( 'class' => array(), ), ) ), get_the_title() ), '<span class="edit-link">&nbsp;&nbsp;<i class="fa fa-pencil" aria-hidden="true"></i> ', '</span>' ); ?><?php } ?>
    </div>
    <?php } ?>
<?php }
endif;