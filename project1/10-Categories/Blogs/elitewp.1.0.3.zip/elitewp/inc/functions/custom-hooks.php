<?php
/**
* Custom Hooks
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function elitewp_before_header() {
    do_action('elitewp_before_header');
}

function elitewp_after_header() {
    do_action('elitewp_after_header');
}

function elitewp_after_primary_menu() {
    do_action('elitewp_after_primary_menu');
}

function elitewp_before_slider() {
    do_action('elitewp_before_slider');
}

function elitewp_after_slider() {
    do_action('elitewp_after_slider');
}

function elitewp_before_main_content() {
    do_action('elitewp_before_main_content');
}

function elitewp_after_main_content() {
    do_action('elitewp_after_main_content');
}

function elitewp_before_sidebar() {
    do_action('elitewp_before_sidebar');
}

function elitewp_after_sidebar() {
    do_action('elitewp_after_sidebar');
}

function elitewp_before_single_post() {
    do_action('elitewp_before_single_post');
}

function elitewp_before_single_post_title() {
    do_action('elitewp_before_single_post_title');
}

if ( !(elitewp_get_option('hide_post_categories')) ) {
    add_action('elitewp_before_single_post_title', 'elitewp_single_cats', 5 );
}

function elitewp_after_single_post_title() {
    do_action('elitewp_after_single_post_title');
}

add_action('elitewp_after_single_post_title', 'elitewp_single_postmeta', 5 );

function elitewp_after_single_post_content() {
    do_action('elitewp_after_single_post_content');
}

if ( !(elitewp_get_option('hide_post_tags')) ) {
    add_action('elitewp_after_single_post_content', 'elitewp_single_post_footer', 5 );
}

if ( !(elitewp_get_option('hide_author_bio_box')) ) {
    add_action('elitewp_after_single_post_content', 'elitewp_add_author_bio_box', 15 );
}

function elitewp_after_single_post() {
    do_action('elitewp_after_single_post');
}

function elitewp_before_single_page() {
    do_action('elitewp_before_single_page');
}

function elitewp_before_single_page_title() {
    do_action('elitewp_before_single_page_title');
}

function elitewp_after_single_page_title() {
    do_action('elitewp_after_single_page_title');
}

function elitewp_after_single_page_content() {
    do_action('elitewp_after_single_page_content');
}

function elitewp_after_single_page() {
    do_action('elitewp_after_single_page');
}