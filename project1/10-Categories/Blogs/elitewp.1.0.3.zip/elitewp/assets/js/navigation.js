/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 */
( function() {
    var elitewp_secondary_container, elitewp_secondary_button, elitewp_secondary_menu, elitewp_secondary_links, elitewp_secondary_i, elitewp_secondary_len;

    elitewp_secondary_container = document.getElementById( 'elitewp-secondary-navigation' );
    if ( ! elitewp_secondary_container ) {
        return;
    }

    elitewp_secondary_button = elitewp_secondary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof elitewp_secondary_button ) {
        return;
    }

    elitewp_secondary_menu = elitewp_secondary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof elitewp_secondary_menu ) {
        elitewp_secondary_button.style.display = 'none';
        return;
    }

    elitewp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === elitewp_secondary_menu.className.indexOf( 'nav-menu' ) ) {
        elitewp_secondary_menu.className += ' nav-menu';
    }

    elitewp_secondary_button.onclick = function() {
        if ( -1 !== elitewp_secondary_container.className.indexOf( 'elitewp-toggled' ) ) {
            elitewp_secondary_container.className = elitewp_secondary_container.className.replace( ' elitewp-toggled', '' );
            elitewp_secondary_button.setAttribute( 'aria-expanded', 'false' );
            elitewp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            elitewp_secondary_container.className += ' elitewp-toggled';
            elitewp_secondary_button.setAttribute( 'aria-expanded', 'true' );
            elitewp_secondary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    elitewp_secondary_links    = elitewp_secondary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( elitewp_secondary_i = 0, elitewp_secondary_len = elitewp_secondary_links.length; elitewp_secondary_i < elitewp_secondary_len; elitewp_secondary_i++ ) {
        elitewp_secondary_links[elitewp_secondary_i].addEventListener( 'focus', elitewp_secondary_toggleFocus, true );
        elitewp_secondary_links[elitewp_secondary_i].addEventListener( 'blur', elitewp_secondary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function elitewp_secondary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'elitewp-focus' ) ) {
                    self.className = self.className.replace( ' elitewp-focus', '' );
                } else {
                    self.className += ' elitewp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( elitewp_secondary_container ) {
        var touchStartFn, elitewp_secondary_i,
            parentLink = elitewp_secondary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, elitewp_secondary_i;

                if ( ! menuItem.classList.contains( 'elitewp-focus' ) ) {
                    e.preventDefault();
                    for ( elitewp_secondary_i = 0; elitewp_secondary_i < menuItem.parentNode.children.length; ++elitewp_secondary_i ) {
                        if ( menuItem === menuItem.parentNode.children[elitewp_secondary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[elitewp_secondary_i].classList.remove( 'elitewp-focus' );
                    }
                    menuItem.classList.add( 'elitewp-focus' );
                } else {
                    menuItem.classList.remove( 'elitewp-focus' );
                }
            };

            for ( elitewp_secondary_i = 0; elitewp_secondary_i < parentLink.length; ++elitewp_secondary_i ) {
                parentLink[elitewp_secondary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( elitewp_secondary_container ) );
} )();


( function() {
    var elitewp_primary_container, elitewp_primary_button, elitewp_primary_menu, elitewp_primary_links, elitewp_primary_i, elitewp_primary_len;

    elitewp_primary_container = document.getElementById( 'elitewp-primary-navigation' );
    if ( ! elitewp_primary_container ) {
        return;
    }

    elitewp_primary_button = elitewp_primary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof elitewp_primary_button ) {
        return;
    }

    elitewp_primary_menu = elitewp_primary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof elitewp_primary_menu ) {
        elitewp_primary_button.style.display = 'none';
        return;
    }

    elitewp_primary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === elitewp_primary_menu.className.indexOf( 'nav-menu' ) ) {
        elitewp_primary_menu.className += ' nav-menu';
    }

    elitewp_primary_button.onclick = function() {
        if ( -1 !== elitewp_primary_container.className.indexOf( 'elitewp-toggled' ) ) {
            elitewp_primary_container.className = elitewp_primary_container.className.replace( ' elitewp-toggled', '' );
            elitewp_primary_button.setAttribute( 'aria-expanded', 'false' );
            elitewp_primary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            elitewp_primary_container.className += ' elitewp-toggled';
            elitewp_primary_button.setAttribute( 'aria-expanded', 'true' );
            elitewp_primary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    elitewp_primary_links    = elitewp_primary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( elitewp_primary_i = 0, elitewp_primary_len = elitewp_primary_links.length; elitewp_primary_i < elitewp_primary_len; elitewp_primary_i++ ) {
        elitewp_primary_links[elitewp_primary_i].addEventListener( 'focus', elitewp_primary_toggleFocus, true );
        elitewp_primary_links[elitewp_primary_i].addEventListener( 'blur', elitewp_primary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function elitewp_primary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'elitewp-focus' ) ) {
                    self.className = self.className.replace( ' elitewp-focus', '' );
                } else {
                    self.className += ' elitewp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( elitewp_primary_container ) {
        var touchStartFn, elitewp_primary_i,
            parentLink = elitewp_primary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, elitewp_primary_i;

                if ( ! menuItem.classList.contains( 'elitewp-focus' ) ) {
                    e.preventDefault();
                    for ( elitewp_primary_i = 0; elitewp_primary_i < menuItem.parentNode.children.length; ++elitewp_primary_i ) {
                        if ( menuItem === menuItem.parentNode.children[elitewp_primary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[elitewp_primary_i].classList.remove( 'elitewp-focus' );
                    }
                    menuItem.classList.add( 'elitewp-focus' );
                } else {
                    menuItem.classList.remove( 'elitewp-focus' );
                }
            };

            for ( elitewp_primary_i = 0; elitewp_primary_i < parentLink.length; ++elitewp_primary_i ) {
                parentLink[elitewp_primary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( elitewp_primary_container ) );
} )();