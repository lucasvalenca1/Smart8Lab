jQuery(document).ready(function($) {

    if(elitewp_ajax_object.secondary_menu_active){

    //$(".elitewp-nav-secondary .elitewp-secondary-nav-menu").addClass("elitewp-secondary-responsive-menu").before('<div class="elitewp-secondary-responsive-menu-icon"></div>');
    $(".elitewp-nav-secondary .elitewp-secondary-nav-menu").addClass("elitewp-secondary-responsive-menu");

    $(".elitewp-secondary-responsive-menu-icon").click(function(){
        $(this).next(".elitewp-nav-secondary .elitewp-secondary-nav-menu").slideToggle();
    });

    $(window).resize(function(){
        if(window.innerWidth > 1112) {
            $(".elitewp-nav-secondary .elitewp-secondary-nav-menu, nav .sub-menu, nav .children").removeAttr("style");
            $(".elitewp-secondary-responsive-menu > li").removeClass("elitewp-secondary-menu-open");
        }
    });

    $(".elitewp-secondary-responsive-menu > li").click(function(event){
        if (event.target !== this)
        return;
        $(this).find(".sub-menu:first").toggleClass('elitewp-submenu-toggle').parent().toggleClass("elitewp-secondary-menu-open");
        $(this).find(".children:first").toggleClass('elitewp-submenu-toggle').parent().toggleClass("elitewp-secondary-menu-open");
    });

    $("div.elitewp-secondary-responsive-menu > ul > li").click(function(event) {
        if (event.target !== this)
            return;
        $(this).find("ul:first").toggleClass('elitewp-submenu-toggle').parent().toggleClass("elitewp-secondary-menu-open");
    });

    }

    if(elitewp_ajax_object.primary_menu_active){

    if(elitewp_ajax_object.sticky_menu){
    // grab the initial top offset of the navigation 
    var elitewpstickyNavTop = $('.elitewp-primary-menu-container').offset().top;
    
    // our function that decides weather the navigation bar should have "fixed" css position or not.
    var elitewpstickyNav = function(){
        var elitewpscrollTop = $(window).scrollTop(); // our current vertical position from the top
             
        // if we've scrolled more than the navigation, change its position to fixed to stick to top,
        // otherwise change it back to relative

        if(elitewp_ajax_object.sticky_menu_mobile){
            if (elitewpscrollTop > elitewpstickyNavTop) {
                $('.elitewp-primary-menu-container').addClass('elitewp-fixed');
            } else {
                $('.elitewp-primary-menu-container').removeClass('elitewp-fixed');
            }
        } else {
            if(window.innerWidth > 1112) {
                if (elitewpscrollTop > elitewpstickyNavTop) {
                    $('.elitewp-primary-menu-container').addClass('elitewp-fixed');
                } else {
                    $('.elitewp-primary-menu-container').removeClass('elitewp-fixed'); 
                }
            }
        }
    };

    elitewpstickyNav();
    // and run it again every time you scroll
    $(window).scroll(function() {
        elitewpstickyNav();
    });
    }

    //$(".elitewp-nav-primary .elitewp-primary-nav-menu").addClass("elitewp-primary-responsive-menu").before('<div class="elitewp-primary-responsive-menu-icon"></div>');
    $(".elitewp-nav-primary .elitewp-primary-nav-menu").addClass("elitewp-primary-responsive-menu");

    $(".elitewp-primary-responsive-menu-icon").click(function(){
        $(this).next(".elitewp-nav-primary .elitewp-primary-nav-menu").slideToggle();
    });

    $(window).resize(function(){
        if(window.innerWidth > 1112) {
            $(".elitewp-nav-primary .elitewp-primary-nav-menu, nav .sub-menu, nav .children").removeAttr("style");
            $(".elitewp-primary-responsive-menu > li").removeClass("elitewp-primary-menu-open");
        }
    });

    $(".elitewp-primary-responsive-menu > li").click(function(event){
        if (event.target !== this)
        return;
        $(this).find(".sub-menu:first").toggleClass('elitewp-submenu-toggle').parent().toggleClass("elitewp-primary-menu-open");
        $(this).find(".children:first").toggleClass('elitewp-submenu-toggle').parent().toggleClass("elitewp-primary-menu-open");
    });

    $("div.elitewp-primary-responsive-menu > ul > li").click(function(event) {
        if (event.target !== this)
            return;
        $(this).find("ul:first").toggleClass('elitewp-submenu-toggle').parent().toggleClass("elitewp-primary-menu-open");
    });

    }

    $(".elitewp-social-icon-search").on('click', function (e) {
        e.preventDefault();
        document.getElementById("elitewp-search-overlay-wrap").style.display = "block";
    });

    $(".elitewp-search-closebtn").on('click', function (e) {
        e.preventDefault();
        document.getElementById("elitewp-search-overlay-wrap").style.display = "none";
    });

    $(".post").fitVids();

    var scrollButtonEl = $( '.elitewp-scroll-top' );
    scrollButtonEl.hide();

    $( window ).scroll( function () {
        if ( $( window ).scrollTop() < 20 ) {
            $( '.elitewp-scroll-top' ).fadeOut();
        } else {
            $( '.elitewp-scroll-top' ).fadeIn();
        }
    } );

    scrollButtonEl.click( function () {
        $( "html, body" ).animate( { scrollTop: 0 }, 300 );
        return false;
    } );

    if(elitewp_ajax_object.slider){
    if ( $().owlCarousel ) {
        var elitewpcarouselwrapper = $('.elitewp-posts-carousel');
        var imgLoad = imagesLoaded(elitewpcarouselwrapper);
        imgLoad.on( 'always', function() {
            elitewpcarouselwrapper.each(function(){
                    var $this = $(this);
                    $this.find('.owl-carousel').owlCarousel({
                        autoplay: true,
                        loop: true,
                        margin: 10,
                        smartSpeed: 250,
                        dots: false,
                        nav: false,
                        autoplayTimeout: 4000,
                        autoHeight: false,
                        navText: [ '<i class="fa fa-arrow-left"></i>', '<i class="fa fa-arrow-right"></i>' ],
                        responsive:{
                        0:{
                            items: 1
                        },
                        480:{
                            items: 2
                        },
                        991:{
                            items: 3
                        },
                        1024:{
                            items: 4
                        }
                    }
                });
            });
        });
    } // end if
    }

    if(elitewp_ajax_object.sticky_sidebar){
    $('.elitewp-main-wrapper, .elitewp-sidebar-one-wrapper').theiaStickySidebar({
        containerSelector: ".elitewp-content-wrapper",
        additionalMarginTop: 0,
        additionalMarginBottom: 0,
        minWidth: 890,
    });
    }

});