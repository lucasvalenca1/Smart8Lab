<?php
/**
* The file for displaying the sidebars.
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/
?>

<div class="elitewp-sidebar-one-wrapper elitewp-sidebar-widget-areas clearfix" id="elitewp-sidebar-one-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPSideBar" role="complementary">
<div class="theiaStickySidebar">
<div class="elitewp-sidebar-one-wrapper-inside clearfix">

<?php elitewp_before_sidebar(); ?>

<?php dynamic_sidebar( 'elitewp-sidebar-one' ); ?>

<?php elitewp_after_sidebar(); ?>

</div>
</div>
</div><!-- /#elitewp-sidebar-one-wrapper-->