<?php
/**
* The template for displaying search results pages.
*
* @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

get_header(); ?>

<div class="elitewp-main-wrapper clearfix" id="elitewp-main-wrapper" itemscope="itemscope" itemtype="http://schema.org/Blog" role="main">
<div class="theiaStickySidebar">
<div class="elitewp-main-wrapper-inside clearfix">

<?php elitewp_before_main_content(); ?>

<?php elitewp_top_widgets(); ?>

<div class="elitewp-posts-wrapper" id="elitewp-posts-wrapper">

<div class="elitewp-posts elitewp-box">
<div class="elitewp-box-inside">

<header class="page-header">
<div class="page-header-inside">
<h1 class="page-title"><?php /* translators: %s: search query. */ printf( esc_html__( 'Search Results for: %s', 'elitewp' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
</div>
</header>

<div class="elitewp-posts-content">

<?php if (have_posts()) : ?>

    <div class="elitewp-posts-container">
    <?php $elitewp_total_posts = $wp_query->post_count; ?>
    <?php $elitewp_post_counter=1; while (have_posts()) : the_post(); ?>

        <?php get_template_part( 'template-parts/content', elitewp_post_style() ); ?>

    <?php $elitewp_post_counter++; endwhile; ?>
    </div>
    <div class="clear"></div>

    <?php elitewp_posts_navigation(); ?>

<?php else : ?>

  <?php get_template_part( 'template-parts/content', 'none' ); ?>

<?php endif; ?>

</div>

</div>
</div>

</div><!--/#elitewp-posts-wrapper -->

<?php elitewp_bottom_widgets(); ?>

<?php elitewp_after_main_content(); ?>

</div>
</div>
</div><!-- /#elitewp-main-wrapper -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>