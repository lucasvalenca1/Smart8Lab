<?php
/**
* The header for EliteWP theme.
*
* @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
*
* @package EliteWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class('elitewp-animated elitewp-fadein'); ?> id="elitewp-site-body" itemscope="itemscope" itemtype="http://schema.org/WebPage">
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#elitewp-posts-wrapper"><?php esc_html_e( 'Skip to content', 'elitewp' ); ?></a>

<?php if ( !(elitewp_get_option('disable_primary_menu')) ) { ?>
<div class="elitewp-container elitewp-primary-menu-container clearfix">
<div class="elitewp-primary-menu-container-inside clearfix">

<nav class="elitewp-nav-primary" id="elitewp-primary-navigation" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'elitewp' ); ?>">
<div class="elitewp-outer-wrapper">
<button class="elitewp-primary-responsive-menu-icon" aria-controls="elitewp-menu-primary-navigation" aria-expanded="false"><?php esc_html_e( 'Menu', 'elitewp' ); ?></button>
<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'elitewp-menu-primary-navigation', 'menu_class' => 'elitewp-primary-nav-menu elitewp-menu-primary', 'fallback_cb' => 'elitewp_fallback_menu', 'container' => '', ) ); ?>
<?php if ( !(elitewp_get_option('hide_header_social_buttons')) ) { elitewp_header_social_buttons(); } ?>
</div>
</nav>

</div>
</div>
<?php } ?>

<div class="elitewp-container" id="elitewp-header" itemscope="itemscope" itemtype="http://schema.org/WPHeader" role="banner">
<div class="elitewp-head-content clearfix" id="elitewp-head-content">

<?php if ( get_header_image() ) : ?>
<div class="elitewp-header-image clearfix">
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="elitewp-header-img-link">
    <img src="<?php header_image(); ?>" width="<?php echo esc_attr(get_custom_header()->width); ?>" height="<?php echo esc_attr(get_custom_header()->height); ?>" alt="" class="elitewp-header-img"/>
</a>
</div>
<?php endif; ?>

<div class="elitewp-outer-wrapper">
<?php elitewp_before_header(); ?>

<?php if ( !(elitewp_get_option('hide_header_content')) ) { ?>
<div class="elitewp-header-inside clearfix">
<div id="elitewp-logo">
<?php if ( has_custom_logo() ) : ?>
    <div class="elitewp-site-branding">
    <div class="elitewp-site-branding-inside">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="elitewp-logo-img-link">
        <img src="<?php echo esc_url( elitewp_custom_logo() ); ?>" alt="" class="elitewp-logo-img"/>
    </a>
    </div>
    </div>
<?php else: ?>
    <div class="elitewp-site-branding">
    <div class="elitewp-site-branding-inside">
      <?php elitewp_site_title(); ?>
    </div>
    </div>
<?php endif; ?>
</div><!--/#elitewp-logo -->
</div>
<?php } ?>

<?php elitewp_after_header(); ?>
</div>

</div><!--/#elitewp-head-content -->
</div><!--/#elitewp-header -->

<?php elitewp_after_primary_menu(); ?>

<div id="elitewp-search-overlay-wrap" class="elitewp-search-overlay">
  <button class="elitewp-search-closebtn" aria-label="<?php esc_attr_e( 'Close Search', 'elitewp' ); ?>" title="<?php esc_attr_e('Close Search','elitewp'); ?>">&#xD7;</button>
  <div class="elitewp-search-overlay-content">
    <?php get_search_form(); ?>
  </div>
</div>

<?php elitewp_slider_area(); ?>

<div class="elitewp-outer-wrapper">
<?php elitewp_top_wide_widgets(); ?>
</div>

<div class="elitewp-outer-wrapper">

<div class="elitewp-container clearfix" id="elitewp-wrapper">
<div class="elitewp-content-wrapper clearfix" id="elitewp-content-wrapper">