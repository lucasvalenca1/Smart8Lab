<?php

/*
 * Recommend Plugin related files goes here
 */

/**
 * Include the TGM_Plugin_Activation class.
 *
 * Depending on your implementation, you may want to change the include call:
 *
 */
require_once centurylib_file_directory('installation/class-tgm-plugin-activation.php');
