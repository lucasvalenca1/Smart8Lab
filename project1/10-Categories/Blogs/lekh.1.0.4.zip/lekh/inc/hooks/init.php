<?php

/**
 * require lekh hooks files.
 */
require_once lekh_file_directory( 'inc/hooks/setup.php' );

/**
 * require recommended plugin hooks files.
 */
require_once lekh_file_directory( 'inc/hooks/recommend.php' );

/**
 * require header hooks files.
 */
require_once lekh_file_directory( 'inc/hooks/ajax.php' );

/**
 * require header hooks files.
 */
require_once lekh_file_directory( 'inc/hooks/jetpack.php' );

/**
 * require header hooks files.
 */
require_once lekh_file_directory( 'inc/hooks/header.php' );