jQuery.noConflict()(function($){

	'use strict';

/* ===============================================
   Tabs
   =============================================== */

	$( '#tabs.anna_lite_metaboxes' ).tabs();

});