<div id="content" class="container">
	
    <?php 
	
		do_action('anna_lite_archive_title');
		do_action('anna_lite_masonry');
		do_action('anna_lite_pagination', 'archive');
		
	?>

</div>