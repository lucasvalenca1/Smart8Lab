<div id="content" class="container masonry-container">
	
	<?php 
	
		do_action('anna_lite_masonry'); 
		do_action('anna_lite_pagination', 'home'); 
	
	?>

</div>