<div id="content" class="container">
	
    <?php 

		do_action('anna_lite_searched_item');
		do_action('anna_lite_masonry');
		do_action('anna_lite_pagination', 'archive');

	?>

</div>