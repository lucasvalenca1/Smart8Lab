<?php

	if ( anna_lite_template('span') == 'col-md-8' ) : 

		do_action('anna_lite_side_sidebar');
	 
	endif; 

?>