<?php
/**
 * Blogstart Popular Post Widget
 *
 * @package blogstart
 */


/**
 * Blogstart Post Gallery
 */
locate_template( '/inc/widgets/class-blogstart-post-gallery.php', true, true );
/**
 * Blogstart Latest Post Slider
 */
locate_template( '/inc/widgets/class-blogstart-latest-post-slider.php', true, true );

