=== Royal Blog ===
Contributors: sparklewpthemes
Tags: blog, news, one-column, two-columns, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, post-formats, sticky-post, translation-ready, featured-images, theme-options
Requires at least: 4.7
Tested up to: 5.0.3
Requires PHP: 5.2.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Royal Blog is a clean & beautiful free child theme of Craft Blog WordPress theme, This theme well suited for fashion bloggers, lifestyle, travel bloggers, personal blogging, music band & singers, photographers, writers, fashion designer, interior designers, wedding, eCommerce and all bloggers sector people. Royal Blog is one of the most accessible themes which can easily accommodate all type of users with no coding skills to advanced WordPress developers. Royal Blog includes excellent advanced features for blogger professionals and practices of all kinds of blogger, with one click demo data import, customizer theme options, page &  post layout options. Royal Blog Free WordPress theme is fully responsive, cross-browser compatible, translation ready, SEO friendly and social media integration.


== Description ==

Royal Blog is a clean & beautiful free child theme of Craft Blog WordPress theme, This theme well suited for fashion bloggers, lifestyle, travel bloggers, personal blogging, music band & singers, photographers, writers, fashion designer, interior designers, wedding, eCommerce and all bloggers sector people. Royal Blog is one of the most accessible themes which can easily accommodate all type of users with no coding skills to advanced WordPress developers. Royal Blog includes excellent advanced features for blogger professionals and practices of all kinds of blogger, with one click demo data import, customizer theme options, page &  post layout options. Royal Blog Free WordPress theme is fully responsive, cross-browser compatible, translation ready, SEO friendly and social media integration. if you have any problem while using our theme, you can refer our theme documentation or contact our friendly support team. Check demo at http://demo.sparklewpthemes.com/royalblog/ and Read theme details at https://sparklewpthemes.com/wordpress-themes/royalblog and get free support at https://sparklewpthemes.com/support/


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Translation ==

Royal Blog theme is translation ready.


== Frequently Asked Questions ==

= Does this theme support any plugins? =

Theme supports Jetpack, Contact Form 7, AccessPress Social Share, AccessPress Social Counter many more.

= Where can I find theme all features ? =

You can check our Theme features at http://demo.sparklewpthemes.com/royalblog/.

= Where can I find theme demo? =

You can check our Theme Demo at http://sparklewpthemes.com/wordpress-themes/royalblog/


== Copyright ==

Royal Blog WordPress Theme is child theme of Craft Blog, Copyright 2017 Sparkle Themes.
Royal Blog is distributed under the terms of the GNU GPL

Craft Blog WordPress Theme, Copyright (C) 2017 Sparkle Themes.
Craft Blog is distributed under the terms of the GNU GPL

== Credits ==

	Images used in screenshot

	https://www.pexels.com/photo/business-close-up-commerce-computer-266176/ License CC0 Public Domain (https://www.pexels.com/creative-commons-images/)
	https://www.pexels.com/photo/portrait-of-young-man-in-autumn-247917/ License CC0 Public Domain (https://www.pexels.com/creative-commons-images/)
	https://www.pexels.com/photo/close-up-of-row-325876/ License CC0 Public Domain (https://www.pexels.com/creative-commons-images/)
	https://www.pexels.com/photo/baby-children-cute-dress-264109/ License CC0 Public Domain (https://www.pexels.com/creative-commons-images/)



== Changelog ==


= 1.0.0 12th Febrary 2019 =

	** Submitted theme for review in http://wordpress.org