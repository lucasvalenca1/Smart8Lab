<?php
/**
 * Search Form
*/?>

<div class="coblog-search">
    <button class="search-button" type="submit">
        <i class="cb-font-search"></i>
    </button>
</div>
