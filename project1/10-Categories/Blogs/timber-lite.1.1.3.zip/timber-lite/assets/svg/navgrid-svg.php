<svg viewBox="0 0 19 19" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
	<g stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd">
		<rect x="16" y="16" width="3" height="3" rx="1"></rect>
		<rect x="8" y="16" width="3" height="3" rx="1"></rect>
		<rect x="0" y="16" width="3" height="3" rx="1"></rect>
		<rect x="16" y="8" width="3" height="3" rx="1"></rect>
		<rect x="8" y="8" width="3" height="3" rx="1"></rect>
		<rect x="0" y="8" width="3" height="3" rx="1"></rect>
		<rect x="16" y="0" width="3" height="3" rx="1"></rect>
		<rect x="8" y="0" width="3" height="3" rx="1"></rect>
		<rect x="0" y="0" width="3" height="3" rx="1"></rect>
	</g>
</svg>
