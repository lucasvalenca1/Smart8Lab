<?php
/**
* Loads all the helper files
*
* @since Travelbiz 1.0.0
*/
require get_parent_theme_file_path( '/modules/helpers/helpers.php' );
require get_parent_theme_file_path( '/modules/helpers/image.php' );