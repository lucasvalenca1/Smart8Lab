=== Magazine News Plus ===
Contributors: dithemes
Tags: one-column, two-columns, left-sidebar, right-sidebar, grid-layout, custom-background, custom-colors, custom-header, custom-logo, custom-menu, editor-style, featured-images, footer-widgets, flexible-header, full-width-template, microformats, post-formats, sticky-post, theme-options, threaded-comments, translation-ready, wide-blocks, blog, news
Requires at least: 4.6
Tested up to: 5.2.2
Requires PHP: 5.3.2
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Magazine News Plus is Responsive, Fast to load, SEO Friendly and Customizable WordPress theme for News and Magazine websites.

== Description ==

Magazine News Plus is Responsive, Fast to load, SEO Friendly and Customizable WordPress theme for News and Magazine websites. it is child theme of Di Magazine theme and adds additional menu in footer. it also adds well designed recent news slider widget. it register five widget areas on front page so you can display ads or any widget before each category. Front page features: Top News Slider, Secondary Left News Slider, Secondary Right News Grid, Categories wise News Section, Front Page Layout. Theme features: One Click Demo Import, Typography Options, Social Profile, Top Bar Section, Header Layouts, Header Widgets for Advertisement and other Elements, Footer Widgets, Footer Copyright Section, Custom Recent News Widget, Social Profile Widget, Full Width Layout, Left Sidebar Layout, Right Sidebar Layout, Sticky Menu, Mega Menu Support, Back To Top Button Icon, Page Preloader and much more.

== Frequently Asked Questions ==

= Installation = 

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in 'Magazine News Plus' in the search form and press the 'Enter' key on your keyboard.
3. Click on 'Install' and then 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel and customize the taste.

= Where are theme settings? =

Navigate to Appearance > Customize in your admin panel.

== Changelog ==

= 1.1 =
* Fix: customize_selective_refresh
* Version dot fix

= 1.0 =
* Initial release.

== Upgrade Notice ==

= 1.1 =
* Normal Update.

= 1.0 =
* Initial release.

== Resources ==

* Parent Theme: Di Magazine Theme © 2019 DiThemes, GPLv2 or later
* OwlCarousel2 - owl.carousel © 2014 owl, MIT
* 