<?php

if( ! defined( 'ABSPATH' ) ) {
	die( "No Direct access" );
}

// Load main class
require_once get_stylesheet_directory() . '/inc/class-magazine-news-plus-engine.php';

// Load recent posts class
require_once get_stylesheet_directory() . '/inc/class-recent-posts-slider.php';

