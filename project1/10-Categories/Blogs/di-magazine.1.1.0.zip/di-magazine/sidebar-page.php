<div class="col-md-4">
	<div class="right-content dflt-pg-sdbr" >
		<?php
		do_action( 'di_magazine_page_sidebar_file' );
		?>
	</div>
</div>
