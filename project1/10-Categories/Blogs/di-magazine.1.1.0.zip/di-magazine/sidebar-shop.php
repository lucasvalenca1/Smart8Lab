<div class="col-md-4">
	<div class="right-content woo-sidebr" >
		<?php
		if( is_active_sidebar( 'sidebar_woo' ) ) {
			dynamic_sidebar( 'sidebar_woo' );
		}
		?>
	</div>
</div>
