<div class="container-fluid front-page-bottom">
	<div class="row">
		<?php

		get_template_part( 'template-parts/header', 'front-bottom-left' );

		get_template_part( 'template-parts/header', 'front-bottom-right' );

		?>
	</div>
</div>