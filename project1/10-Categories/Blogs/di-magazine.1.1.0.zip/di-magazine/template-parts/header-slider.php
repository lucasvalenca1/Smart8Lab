<?php
do_action( 'di_magazine_header_slider_file' );
