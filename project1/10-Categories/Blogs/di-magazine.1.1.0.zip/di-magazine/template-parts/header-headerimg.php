<?php
do_action( 'di_magazine_hdrimg_file' );
