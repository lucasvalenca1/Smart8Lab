<?php if( get_theme_mod( 'back_to_top', '1' ) == 1 ) { ?>
	<a id="back-to-top" href="#"><span class="fa fa-chevron-up"></span></a>
<?php } ?>