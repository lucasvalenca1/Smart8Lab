=== Royale News Lite ===

Contributors: themebeez
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, left-sidebar, right-sidebar, news, blog, custom-header, theme-options, footer-widgets, sticky-post, grid-layout, two-columns, three-columns
Requires at least: 4.8.0
Requires PHP: 5.6
Tested up to: 5.1.1
Stable tag: 1.0.1
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Royale News Lite is a child theme of WordPress theme, Royale News.


== Description ==
Royale News Lite is a child theme of WordPress theme, Royale News. Royale News Lite is clean, responsive, user friendly and easily customizable. Royale News Lite is light weight and can be used to create and run news portal, online magazine, and other online publishing websites. With one click demo import, it is easy to setup your website. Royale News Lite is translation ready. For demos and more information visit, https://themebeez.com/themes/royale-news-lite.


== License ==

Royale News Lite WordPress Theme, Copyright (C) 2019, themebeez.
Royale News Lite is distributed under the terms of the GNU GPLv2 or later

Royale News WordPress Theme, Copyright (C) 2019, themebeez.
Royale News is distributed under the terms of the GNU GPLv2 or later.


== Screenshots ==

City view
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/36771


Women smoking
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/978164


Women Smiling 
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/775024


Man & Women looking each others
License: CC0 Public Domain (http://creativecommons.org/publicdomain/zero/1.0 - CC0)
Source: https://pxhere.com/en/photo/1269390


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Changelog ==

= 1.0.1 - 16, April 2019 =

- Text domain issues fixed


= 1.0.0 - 14, April 2019 =

- Initial release
