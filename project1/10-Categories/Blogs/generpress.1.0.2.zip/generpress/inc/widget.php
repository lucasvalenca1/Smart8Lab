<?php

// Include Popular Posts Widget
require get_template_directory() . '/inc/widgets/tabs-widget.php';