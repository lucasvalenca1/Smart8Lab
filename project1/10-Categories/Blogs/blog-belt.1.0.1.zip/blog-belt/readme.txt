=== Blog Belt ===

Contributors: candidthemes
Tags: two-columns, right-sidebar, custom-background, custom-colors, custom-menu, featured-images, theme-options, threaded-comments, translation-ready, blog
Requires at least: 4.5
Tested up to: 5.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Blog Belt is the Child Theme of Ocius. This theme is best ever crafted free WordPress theme for Blog, news and Magazine. It is a simple, easy to use, modern and creative, user friendly WordPress theme with typography, fonts and color options. In addition Blog Belt is responsive and cross browser compatible. Blog Belt comes with added custom widgets for social and author, sticky sidebar options, footer widget, sidebar options, meta option, copyright option, social options etc. Moreover, it has SEO markup option, site layout option and many more. It comes with dummy data, setup instructions and video documentation as well. 

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== License ===

Blog Belt is a child theme of Ocius WordPress Theme, Copyright 2018 Candid Themes
Blog Belt is distributed under the terms of the GNU General Public License v2

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Ocius WordPress Theme, Copyright 2018 Candid Themes
Ocius is distributed under the terms of the GNU General Public License v2

== Images Used in Screenshot ==
https://pxhere.com/en/photo/1026325
https://pxhere.com/en/photo/1555413
https://pxhere.com/en/photo/591928
https://pxhere.com/en/photo/1423623

== Changelog ==
= 1.0.1 - April 19 2020 =
* Fixed Warning after adding option in parent theme
* Tested with latest WP version

= 1.0.0 - May 19 2019 =
* Initial Release
