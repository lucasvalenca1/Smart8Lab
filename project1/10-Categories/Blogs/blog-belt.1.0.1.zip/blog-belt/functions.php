<?php
/**
 *Recommended way to include parent theme styles.
 *(Please see http://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme)
 */
/**
 * Loads the child theme textdomain.
 */
function blog_belt_load_language() {
    load_child_theme_textdomain( 'blog-belt' );
    add_theme_support( 'custom-header', apply_filters( 'blog_belt_custom_header_args', array(
        'default-image'          => '',
        'default-text-color'     => 'ff8800',
        'width'                  => '',
        'height'                 => '',
        'flex-height'            => true,
    ) ) );
}
add_action( 'after_setup_theme', 'blog_belt_load_language' );

/**
* Enqueue Style
*/
function blog_belt_style() {
    wp_dequeue_style('ocius-header-font');
    wp_enqueue_style('blog-belt-google-fonts', '//fonts.googleapis.com/css?family=Oswald');
    wp_enqueue_style( 'blog-belt-parent-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'blog-belt-style',get_stylesheet_directory_uri() . '/style.css',array( 'blog-belt-parent-style' ) );
}
add_action( 'wp_enqueue_scripts', 'blog_belt_style',99 );

/**
 * Ocius Theme Customizer default values
 *
 * @package Ocius
 */
if ( !function_exists('ocius_default_theme_options_values') ) :
    function ocius_default_theme_options_values() {
        $default_theme_options = array(
            /* Site Layout Added on Child theme*/
            'blog-belt-site-layout-options' => 'clean',
            /* Microdata Option */
            'blog-belt-schema-data-options' => false,
            /*Top Header Section Default Value*/
            'ocius-primary-color' => '#4ea371',
            /*Top Header Section Default Value*/
            'ocius-enable-top-header'=> true,
            'ocius-enable-top-header-social'=> true,
            'ocius-enable-top-header-search'=> true,
            'ocius-enable-top-header-menu'=> true,
            /*Slider Section Default Value*/
            'ocius-enable-slider' => true,
            'ocius-select-category'=> false,
            'ocius-slider-number'=>7,
            /*Blog Page Default Value*/
            'ocius-sidebar-blog-page'=>'right-sidebar',
            'ocius-column-blog-page'=> 'one-column',
            'ocius-content-show-from'=>'excerpt',
            'ocius-excerpt-length'=>25,
            'ocius-pagination-options'=>'numeric',
            'ocius-read-more-text'=> esc_html__('Continue Reading','blog-belt'),
            'ocius-enable-blog-sharing'=> true,
            'ocius-enable-blog-tags' => false,
            /*Single Page Default Value*/
            'ocius-single-page-featured-image'=> true,
            'ocius-single-page-related-posts'=> true,
            'ocius-single-page-related-posts-title'=> esc_html__('Related Posts','blog-belt'),
            'ocius-enable-single-sharing'=> true,
            'ocius-enable-single-tags' => false,
            /*Sticky Sidebar Options*/
            'ocius-enable-sticky-sidebar'=> true,
            /*Footer Section*/
            'ocius-footer-copyright' =>  esc_html__('All Right Reserved 2019.','blog-belt'),
            'ocius-go-to-top'=> true,
            /*Font Options*/
            'ocius-font-family-url'=> esc_url('//fonts.googleapis.com/css?family=Nunito', 'blog-belt'),
            'ocius-font-family-name'=> esc_html__('Nunito, sans-serif', 'blog-belt'),
            'ocius-font-paragraph-font-size'=> 17,
            /*Extra Options*/
            'ocius-extra-breadcrumb'=> true,
            'ocius-breadcrumb-text'=>  esc_html__('You are Here','blog-belt')
        );
        return apply_filters( 'ocius_default_theme_options_values', $default_theme_options );
    }
endif;

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function blog_belt_customize_register( $wp_customize ) {

    $default = ocius_default_theme_options_values();

    /*Site Layout Options*/
        $wp_customize->add_section( 'blog_belt_site_layout_section', array(
            'priority'       => 30,
            'capability'     => 'edit_theme_options',
            'theme_supports' => '',
            'title'          => __( 'Layout Options', 'blog-belt' ),
            'panel'          => 'ocius_panel',
        ) );
        /*Site Layout*/
        $wp_customize->add_setting( 'ocius_options[blog-belt-site-layout-options]', array(
            'capability'        => 'edit_theme_options',
            'transport' => 'refresh',
            'default'           => $default['blog-belt-site-layout-options'],
            'sanitize_callback' => 'ocius_sanitize_select'
        ) );
        $wp_customize->add_control( 'ocius_options[blog-belt-site-layout-options]', array(
           'choices' => array(
            'default'   => __('Default Layout','blog-belt'),
            'clean'    => __('Clean Layout','blog-belt'),
        ),
           'label'     => __( 'Select the preferred layout', 'blog-belt' ),
           'description' => __('You can make clean layout or default theme layout.', 'blog-belt'),
           'section'   => 'blog_belt_site_layout_section',
           'settings'  => 'ocius_options[blog-belt-site-layout-options]',
           'type'      => 'select',
           'priority'  => 10,
        ) );

        /*Schema Options*/
        $wp_customize->add_section( 'blog_belt_schema_data_option', array(
            'priority'       => 30,
            'capability'     => 'edit_theme_options',
            'theme_supports' => '',
            'title'          => __( 'Remove Schema Microdata', 'blog-belt' ),
            'panel'          => 'ocius_panel',
        ) );
        /*Microdata Option*/
        $wp_customize->add_setting( 'ocius_options[blog-belt-schema-data-options]', array(
            'capability'        => 'edit_theme_options',
            'transport' => 'refresh',
            'default'           => $default['blog-belt-schema-data-options'],
            'sanitize_callback' => 'ocius_sanitize_checkbox'
        ) );
        $wp_customize->add_control( 'ocius_options[blog-belt-schema-data-options]', array(
           'label'     => __( 'Checked to remove built in schema microdata.', 'blog-belt' ),
           'description' => __('For SEO, you can enable it.', 'blog-belt'),
           'section'   => 'blog_belt_schema_data_option',
           'settings'  => 'ocius_options[blog-belt-schema-data-options]',
           'type'      => 'checkbox',
           'priority'  => 10,
        ) );
    }
add_action( 'customize_register', 'blog_belt_customize_register' );

if (!function_exists('blog_belt_footer_siteinfo')) {
    /**
     * Add footer site info block
     *
     * @since 1.0.0
     *
     * @param none
     * @return void
     */
    function blog_belt_footer_siteinfo()
    {
        remove_action('ocius_footer', 'ocius_footer_siteinfo', 15);
        ?>

        <div class="site-info" <?php ocius_do_microdata('footer'); ?>>
            <div class="container-inner">
                <?php
                global $ocius_theme_options;
                $ocius_copyright = wp_kses_post($ocius_theme_options['ocius-footer-copyright']);
                if( !empty( $ocius_copyright ) ):
                    ?>
                    <span class="copy-right-text"><?php echo $ocius_copyright; ?></span>
                <?php
                endif; //$ocius_copyright
                ?>
                <a href="<?php echo esc_url(__('https://wordpress.org/', 'blog-belt')); ?>" target="_blank">
                    <?php
                    /* translators: %s: CMS name, i.e. WordPress. */
                    printf(esc_html__('Proudly powered by %s', 'blog-belt'), 'WordPress');
                    ?>
                </a>
                <span class="sep"> | </span>
                <?php
                /* translators: 1: Theme name, 2: Theme author. */
                printf(esc_html__('Theme: %1$s by %2$s.', 'blog-belt'), 'Blog Belt', '<a href="https://www.candidthemes.com/" target="_blank">Candid Themes</a>');
                ?>
            </div> <!-- .container-inner -->
        </div><!-- .site-info -->
        <?php
    }
}
add_action('ocius_footer', 'blog_belt_footer_siteinfo', 13);

/**
 * Function to remove the micro data from child theme
 *
 * @since 1.0.0
 *
 */
function blog_belt_schema_type() {
    global $ocius_theme_options;
     $blog_belt_schema_type = $ocius_theme_options['blog-belt-schema-data-options'];
    if($blog_belt_schema_type == true ){
        return false;
    }else{
        return 'microdata';
    }
}
add_filter('ocius_schema_type','blog_belt_schema_type');


/**
 * Add site layout class in body
 *
 * @since 1.0.0
 *
 */
if (!function_exists('blog_belt_site_layout')) :
    function blog_belt_site_layout($classes)
    {
        global $ocius_theme_options;
        $blog_belt_layout = $ocius_theme_options['blog-belt-site-layout-options'];
        if ($blog_belt_layout == 'clean') {
            $classes[] = 'clean-layout';
        } else {
            $classes[] = 'default-layout';
        }
        return $classes;
    }
endif;

add_filter('body_class', 'blog_belt_site_layout');

if (!function_exists('blog_belt_dynamic_css')) :
    /**
     * Dynamic CSS
     *
     * @since 1.0.0
     *
     * @param null
     * @return null
     *
     */
    function blog_belt_dynamic_css()
    {

        global $ocius_theme_options;
        $blog_belt_font_family = $ocius_theme_options['ocius-font-family-name'] ?  wp_kses_post( $ocius_theme_options['ocius-font-family-name'] ) :  esc_html__('Poppins, sans-serif', 'blog-belt');
        $blog_belt_font_size = $ocius_theme_options['ocius-font-paragraph-font-size'] ? absint( $ocius_theme_options['ocius-font-paragraph-font-size'] ) : 16;
        $blog_belt_primary_color = $ocius_theme_options['ocius-primary-color'] ?  esc_attr( $ocius_theme_options['ocius-primary-color'] ) : '#ff8800';
        $blog_belt_header_color = get_header_textcolor();
        $blog_belt_custom_css = '';

        if (!empty($blog_belt_header_color)) {
            $blog_belt_custom_css .= ".site-title, .site-title a { color: #{$blog_belt_header_color}; }";
        }

        /* Typography Section */
        if (!empty($blog_belt_font_family)) {
            $blog_belt_custom_css .= "body { font-family: {$blog_belt_font_family}; }";
        }

        if (!empty($blog_belt_font_size)) {
            $blog_belt_custom_css .= "body { font-size: {$blog_belt_font_size}px; }";
        }

        /* Primary Color Section */
        if (!empty($blog_belt_primary_color)) {
            //font-color
            $blog_belt_custom_css .= ".entry-content a, .entry-title a:hover, .related-title a:hover, .posts-navigation .nav-previous a:hover, .post-navigation .nav-previous a:hover, .posts-navigation .nav-next a:hover, .post-navigation .nav-next a:hover, #comments .comment-content a:hover, #comments .comment-author a:hover, .main-navigation ul li a:hover, .main-navigation ul li.current-menu-item > a, .offcanvas-menu nav ul.top-menu li a:hover, .offcanvas-menu nav ul.top-menu li.current-menu-item > a, .post-share a:hover, .error-404-title, #ocius-breadcrumbs a:hover, .entry-content a.read-more-text:hover { color : {$blog_belt_primary_color}; }";

            //background-color
            $blog_belt_custom_css .= ".search-form input[type=submit], input[type=\"submit\"], ::selection, #toTop, .breadcrumbs span.breadcrumb, article.sticky .ocius-content-container, .candid-pagination .page-numbers.current, .candid-pagination .page-numbers:hover { background : {$blog_belt_primary_color}; }";

            //border-color
            $blog_belt_custom_css .= "blockquote, .search-form input[type=\"submit\"], input[type=\"submit\"], .candid-pagination .page-numbers { border-color : {$blog_belt_primary_color}; }";
        }

        wp_add_inline_style('blog-belt-style', $blog_belt_custom_css);
    }
endif;
add_action('wp_enqueue_scripts', 'blog_belt_dynamic_css', 99);