<?php
/**
 * Theme sidebar
 *
 * @package Fasto
 * @author fribba
 *
 */
?>
<div id="sidebar" class="col-desktop-4 col-tablet-12 col-small-tablet-12 col-mobile-12" role="complementary">
	<?php dynamic_sidebar('sidebar'); ?>
</div>