<?php
/**
 * Template for WooCommerce sidebar
 *
 * @package Fasto
 * @author fribba
 *
 */
?>
<div id="sidebar" class="woo-sidebar col-desktop-4 col-tablet-12 col-small-tablet-12 col-mobile-12">
	<?php dynamic_sidebar( 'woocommerce' ); ?>
</div>