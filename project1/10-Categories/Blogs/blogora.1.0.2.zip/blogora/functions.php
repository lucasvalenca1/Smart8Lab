<?php
/**
 * Theme functions and definitions
 *
 * @package blogora
 */

if ( ! function_exists( 'blogora_enqueue_styles' ) ) :
	/**
	 * @since Blogora 1.0.0
	 */
	function blogora_enqueue_styles() {
		wp_enqueue_style( 'blogora-style-parent', get_template_directory_uri() . '/style.css' );
		wp_enqueue_style( 'blogora-style', get_stylesheet_directory_uri() . '/style.css', array( 'blogora-style-parent' ), '1.0.0' );
		wp_enqueue_style( 'blogora-google-fonts', '//fonts.googleapis.com/css?family=Montserrat:300,400,400i,500,600,700|Poppins:300,400,500,600,700&display=swap', false );
	}

endif;
add_action( 'wp_enqueue_scripts', 'blogora_enqueue_styles', 99 );

