=== Blogora ===
Contributors: keonthemes
Tags: blog, portfolio, news, grid-Layout, two-columns, flexible-header, left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-logo, custom-menu, featured-images, full-width-template, post-formats, rtl-language-support, theme-options, sticky-post, threaded-comments, translation-ready
Requires at least: 4.7
Requires PHP: 5.4
Tested up to: 5.3.2
Stable tag: 1.0.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Blogora WordPress Theme is child theme of Blogberg, Copyright 2019 Keon Themes
Blogora is distributed under the terms of the GNU General Public License v3

Blogora is clean Masonry and Gutenberg ready WordPress blog theme for all personal or professional lifestyle bloggers.

== Description ==

Blogora is an articulate, flexible, powerful and clean Masonry responsive Gutenberg ready WordPress blog theme. Blogora is ideal for all personal or professional lifestyle bloggers who are looking for a stylish design for their websites.The well-designed post styles let you tell your stories and helps you to put readers attention towards any stunning visual you may be sharing. Blogora, a extensively customizable powerful and advanced blog theme incorporated with awesome features like Site Layout Options, Archive Page Options, Single Post Page Options, Pages Options, Post Layout Options, Sidebar Position Options, Unlimited Color Options, Fixed Header, Site Identity Extra Options, Custom Widget, Thin Font Icons, Bootstrap 4, Instagram Section, Translation Ready, Cross-Browser Compatibility, RTL Language Support, SEO Friendly... the list goes on. Blogora is compatible with WordPress Classic editor and WooCommerce.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Blogora includes support for WooCommerce, Contact From 7 and MailChimp for WordPress.

== Changelog ==

= 1.0.2 =
* Screenshot Updated.
* Style Fixed.

= 1.0.1 =
* Accessibility Update.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.0.2 =
* This version updated screenshot and fixed style issues.

= 1.0.1 =
* This version updated accessibility issues.

= 1.0.0 =
* Initial release.

== Resources ==
* Normalize.css http://necolas.github.io/normalize.css [MIT]
* Google Fonts https://fonts.google.com [Apache License]
* Bootstrap http://getbootstrap.com [MIT]
* BreadcrumbTrail justin@justintadlock.com [GPL]
* Keon Font Icons https://keonthemes.com/kfi-icons [MIT]
* Owlcarousel2 https://owlcarousel2.github.io/OwlCarousel2/docs/started-welcome.html [MIT]
* screenshot.png
  https://pxhere.com/en/photo/1364580 [CC0]
  https://pxhere.com/en/photo/697873 [CC0]
  https://pxhere.com/en/photo/567870 [CC0]

