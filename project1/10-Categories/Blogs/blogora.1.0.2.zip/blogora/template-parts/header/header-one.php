<?php
/**
 * Displays header layout one
 * @since Blogora 1.0.0
 */
?>
<header id="masthead" class="wrapper site-header primary-header" role="banner">
	<?php if( display_header_text() || has_custom_logo() ): ?>
		<div class="main-header">
			<div class="container">
				<?php
					get_template_part( 'template-parts/header/site', 'branding' );
				?>
			</div>
		</div>
	<?php endif; ?>
	<div class="main-navigation-wrap site-header-wrap">
		<div class="container">
			<div class="main-navigation-inner">
				<div class="row align-items-center">
					<div class="d-none d-lg-block col-lg-9" id="primary-nav-container">
						<div class="wrap-nav">
							<div id="navigation" class="d-xl-block">
								<nav id="site-navigation" class="main-navigation">
									<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'blogora' ); ?></button>
									<?php echo blogberg_get_menu( 'primary' ); ?>
								</nav>
							</div>
						</div>
					</div>
					<div class="col-12 col-lg-3" id="header-bottom-right-outer">
						<div class="header-icons-wrap text-right">
							<div class="socialgroup">
								<?php echo blogberg_get_menu( 'social' ); ?>
							</div>
							<?php get_template_part('template-parts/header/header', 'search'); ?>
							<?php
								$hamburger_menu_class = '';
								if( blogberg_get_option( 'disable_hamburger_menu_icon' ) ){
									$hamburger_menu_class = 'd-inline-block d-lg-none';
								}
							?>
							<span class="alt-menu-icon <?php echo esc_attr( $hamburger_menu_class ); ?>">
								<a class="offcanvas-menu-toggler" href="#">
									<span class="icon-bar"></span>
								</a>
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Search form structure -->
	<div class="header-search-wrap">
		<div id="search-form">
			<?php get_search_form(); ?>
		</div>
	</div>
</header>