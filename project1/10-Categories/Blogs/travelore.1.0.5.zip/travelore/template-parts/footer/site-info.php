<?php
/**
 * The template used for displaying credits
 *
 * @package Travelore
 */
?>

<?php
/**
 * travelore_credits hook
 * @hooked travelore_footer_content - 10
 */
do_action( 'travelore_credits' );
