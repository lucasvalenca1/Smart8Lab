<?php
/**
* Social buttons
*
* @package BoxWP WordPress Theme
* @copyright Copyright (C) 2019 ThemesDNA
* @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 or later
* @author ThemesDNA <themesdna@gmail.com>
*/

function boxwp_header_social_buttons() { ?>

<div class='boxwp-top-social-icons'>
    <?php if ( boxwp_get_option('twitterlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('twitterlink') ); ?>" target="_blank" class="boxwp-social-icon-twitter" title="<?php esc_attr_e('Twitter','boxwp'); ?>"><i class="fa fa-twitter" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Twitter', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('facebooklink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('facebooklink') ); ?>" target="_blank" class="boxwp-social-icon-facebook" title="<?php esc_attr_e('Facebook','boxwp'); ?>"><i class="fa fa-facebook" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Facebook', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('googlelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('googlelink') ); ?>" target="_blank" class="boxwp-social-icon-google-plus" title="<?php esc_attr_e('Google Plus','boxwp'); ?>"><i class="fa fa-google-plus" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Google Plus', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('pinterestlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('pinterestlink') ); ?>" target="_blank" class="boxwp-social-icon-pinterest" title="<?php esc_attr_e('Pinterest','boxwp'); ?>"><i class="fa fa-pinterest" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Pinterest', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('linkedinlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('linkedinlink') ); ?>" target="_blank" class="boxwp-social-icon-linkedin" title="<?php esc_attr_e('Linkedin','boxwp'); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Linkedin', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('instagramlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('instagramlink') ); ?>" target="_blank" class="boxwp-social-icon-instagram" title="<?php esc_attr_e('Instagram','boxwp'); ?>"><i class="fa fa-instagram" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Instagram', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('flickrlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('flickrlink') ); ?>" target="_blank" class="boxwp-social-icon-flickr" title="<?php esc_attr_e('Flickr','boxwp'); ?>"><i class="fa fa-flickr" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Flickr', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('youtubelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('youtubelink') ); ?>" target="_blank" class="boxwp-social-icon-youtube" title="<?php esc_attr_e('Youtube','boxwp'); ?>"><i class="fa fa-youtube" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Youtube', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('vimeolink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('vimeolink') ); ?>" target="_blank" class="boxwp-social-icon-vimeo" title="<?php esc_attr_e('Vimeo','boxwp'); ?>"><i class="fa fa-vimeo" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Vimeo', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('soundcloudlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('soundcloudlink') ); ?>" target="_blank" class="boxwp-social-icon-soundcloud" title="<?php esc_attr_e('SoundCloud','boxwp'); ?>"><i class="fa fa-soundcloud" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('SoundCloud', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('lastfmlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('lastfmlink') ); ?>" target="_blank" class="boxwp-social-icon-lastfm" title="<?php esc_attr_e('Lastfm','boxwp'); ?>"><i class="fa fa-lastfm" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Lastfm', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('githublink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('githublink') ); ?>" target="_blank" class="boxwp-social-icon-github" title="<?php esc_attr_e('Github','boxwp'); ?>"><i class="fa fa-github" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Github', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('bitbucketlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('bitbucketlink') ); ?>" target="_blank" class="boxwp-social-icon-bitbucket" title="<?php esc_attr_e('Bitbucket','boxwp'); ?>"><i class="fa fa-bitbucket" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Bitbucket', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('tumblrlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('tumblrlink') ); ?>" target="_blank" class="boxwp-social-icon-tumblr" title="<?php esc_attr_e('Tumblr','boxwp'); ?>"><i class="fa fa-tumblr" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Tumblr', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('digglink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('digglink') ); ?>" target="_blank" class="boxwp-social-icon-digg" title="<?php esc_attr_e('Digg','boxwp'); ?>"><i class="fa fa-digg" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Digg', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('deliciouslink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('deliciouslink') ); ?>" target="_blank" class="boxwp-social-icon-delicious" title="<?php esc_attr_e('Delicious','boxwp'); ?>"><i class="fa fa-delicious" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Delicious', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('stumblelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('stumblelink') ); ?>" target="_blank" class="boxwp-social-icon-stumbleupon" title="<?php esc_attr_e('Stumbleupon','boxwp'); ?>"><i class="fa fa-stumbleupon" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Stumbleupon', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('redditlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('redditlink') ); ?>" target="_blank" class="boxwp-social-icon-reddit" title="<?php esc_attr_e('Reddit','boxwp'); ?>"><i class="fa fa-reddit" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Reddit', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('dribbblelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('dribbblelink') ); ?>" target="_blank" class="boxwp-social-icon-dribbble" title="<?php esc_attr_e('Dribbble','boxwp'); ?>"><i class="fa fa-dribbble" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Dribbble', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('behancelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('behancelink') ); ?>" target="_blank" class="boxwp-social-icon-behance" title="<?php esc_attr_e('Behance','boxwp'); ?>"><i class="fa fa-behance" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Behance', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('vklink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('vklink') ); ?>" target="_blank" class="boxwp-social-icon-vk" title="<?php esc_attr_e('VK','boxwp'); ?>"><i class="fa fa-vk" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('VK', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('codepenlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('codepenlink') ); ?>" target="_blank" class="boxwp-social-icon-codepen" title="<?php esc_attr_e('Codepen','boxwp'); ?>"><i class="fa fa-codepen" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Codepen', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('jsfiddlelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('jsfiddlelink') ); ?>" target="_blank" class="boxwp-social-icon-jsfiddle" title="<?php esc_attr_e('JSFiddle','boxwp'); ?>"><i class="fa fa-jsfiddle" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('JSFiddle', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('stackoverflowlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('stackoverflowlink') ); ?>" target="_blank" class="boxwp-social-icon-stackoverflow" title="<?php esc_attr_e('Stack Overflow','boxwp'); ?>"><i class="fa fa-stack-overflow" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Stack Overflow', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('stackexchangelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('stackexchangelink') ); ?>" target="_blank" class="boxwp-social-icon-stackexchange" title="<?php esc_attr_e('Stack Exchange','boxwp'); ?>"><i class="fa fa-stack-exchange" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Stack Exchange', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('bsalink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('bsalink') ); ?>" target="_blank" class="boxwp-social-icon-buysellads" title="<?php esc_attr_e('BuySellAds','boxwp'); ?>"><i class="fa fa-buysellads" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('BuySellAds', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('slidesharelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('slidesharelink') ); ?>" target="_blank" class="boxwp-social-icon-slideshare" title="<?php esc_attr_e('SlideShare','boxwp'); ?>"><i class="fa fa-slideshare" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('SlideShare', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('skypeusername') ) : ?>
            <a href="skype:<?php echo esc_html( boxwp_get_option('skypeusername') ); ?>?chat" class="boxwp-social-icon-skype" title="<?php esc_attr_e('Skype','boxwp'); ?>"><i class="fa fa-skype" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Skype', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('emailaddress') ) : ?>
            <a href="mailto:<?php echo esc_html( boxwp_get_option('emailaddress') ); ?>" class="boxwp-social-icon-email" title="<?php esc_attr_e('Email Us','boxwp'); ?>"><i class="fa fa-envelope" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Email Us', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('rsslink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('rsslink') ); ?>" target="_blank" class="boxwp-social-icon-rss" title="<?php esc_attr_e('RSS','boxwp'); ?>"><i class="fa fa-rss" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('RSS', 'boxwp'); ?></span></a><?php endif; ?>
    <a href="<?php echo esc_url( '#' ); ?>" class="boxwp-social-icon-search" title="<?php esc_attr_e('Search','boxwp'); ?>"><i class="fa fa-search" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Search', 'boxwp'); ?></span></a>
</div>

<?php }

function boxwp_footer_social_buttons() { ?>

<div class="boxwp-social-icons clearfix">
<div class="boxwp-social-icons-inner clearfix">
<div class='clearfix'>
    <?php if ( boxwp_get_option('twitterlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('twitterlink') ); ?>" target="_blank" class="boxwp-social-icon-twitter" title="<?php esc_attr_e('Twitter','boxwp'); ?>"><i class="fa fa-twitter" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Twitter', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('facebooklink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('facebooklink') ); ?>" target="_blank" class="boxwp-social-icon-facebook" title="<?php esc_attr_e('Facebook','boxwp'); ?>"><i class="fa fa-facebook" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Facebook', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('googlelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('googlelink') ); ?>" target="_blank" class="boxwp-social-icon-google-plus" title="<?php esc_attr_e('Google Plus','boxwp'); ?>"><i class="fa fa-google-plus" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Google Plus', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('pinterestlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('pinterestlink') ); ?>" target="_blank" class="boxwp-social-icon-pinterest" title="<?php esc_attr_e('Pinterest','boxwp'); ?>"><i class="fa fa-pinterest" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Pinterest', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('linkedinlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('linkedinlink') ); ?>" target="_blank" class="boxwp-social-icon-linkedin" title="<?php esc_attr_e('Linkedin','boxwp'); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Linkedin', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('instagramlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('instagramlink') ); ?>" target="_blank" class="boxwp-social-icon-instagram" title="<?php esc_attr_e('Instagram','boxwp'); ?>"><i class="fa fa-instagram" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Instagram', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('vklink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('vklink') ); ?>" target="_blank" class="boxwp-social-icon-vk" title="<?php esc_attr_e('VK','boxwp'); ?>"><i class="fa fa-vk" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('VK', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('flickrlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('flickrlink') ); ?>" target="_blank" class="boxwp-social-icon-flickr" title="<?php esc_attr_e('Flickr','boxwp'); ?>"><i class="fa fa-flickr" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Flickr', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('youtubelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('youtubelink') ); ?>" target="_blank" class="boxwp-social-icon-youtube" title="<?php esc_attr_e('Youtube','boxwp'); ?>"><i class="fa fa-youtube" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Youtube', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('vimeolink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('vimeolink') ); ?>" target="_blank" class="boxwp-social-icon-vimeo" title="<?php esc_attr_e('Vimeo','boxwp'); ?>"><i class="fa fa-vimeo" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Vimeo', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('soundcloudlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('soundcloudlink') ); ?>" target="_blank" class="boxwp-social-icon-soundcloud" title="<?php esc_attr_e('SoundCloud','boxwp'); ?>"><i class="fa fa-soundcloud" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('SoundCloud', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('lastfmlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('lastfmlink') ); ?>" target="_blank" class="boxwp-social-icon-lastfm" title="<?php esc_attr_e('Lastfm','boxwp'); ?>"><i class="fa fa-lastfm" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Lastfm', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('githublink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('githublink') ); ?>" target="_blank" class="boxwp-social-icon-github" title="<?php esc_attr_e('Github','boxwp'); ?>"><i class="fa fa-github" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Github', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('bitbucketlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('bitbucketlink') ); ?>" target="_blank" class="boxwp-social-icon-bitbucket" title="<?php esc_attr_e('Bitbucket','boxwp'); ?>"><i class="fa fa-bitbucket" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Bitbucket', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('tumblrlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('tumblrlink') ); ?>" target="_blank" class="boxwp-social-icon-tumblr" title="<?php esc_attr_e('Tumblr','boxwp'); ?>"><i class="fa fa-tumblr" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Tumblr', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('digglink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('digglink') ); ?>" target="_blank" class="boxwp-social-icon-digg" title="<?php esc_attr_e('Digg','boxwp'); ?>"><i class="fa fa-digg" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Digg', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('deliciouslink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('deliciouslink') ); ?>" target="_blank" class="boxwp-social-icon-delicious" title="<?php esc_attr_e('Delicious','boxwp'); ?>"><i class="fa fa-delicious" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Delicious', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('stumblelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('stumblelink') ); ?>" target="_blank" class="boxwp-social-icon-stumbleupon" title="<?php esc_attr_e('Stumbleupon','boxwp'); ?>"><i class="fa fa-stumbleupon" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Stumbleupon', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('redditlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('redditlink') ); ?>" target="_blank" class="boxwp-social-icon-reddit" title="<?php esc_attr_e('Reddit','boxwp'); ?>"><i class="fa fa-reddit" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Reddit', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('dribbblelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('dribbblelink') ); ?>" target="_blank" class="boxwp-social-icon-dribbble" title="<?php esc_attr_e('Dribbble','boxwp'); ?>"><i class="fa fa-dribbble" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Dribbble', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('behancelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('behancelink') ); ?>" target="_blank" class="boxwp-social-icon-behance" title="<?php esc_attr_e('Behance','boxwp'); ?>"><i class="fa fa-behance" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Behance', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('codepenlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('codepenlink') ); ?>" target="_blank" class="boxwp-social-icon-codepen" title="<?php esc_attr_e('Codepen','boxwp'); ?>"><i class="fa fa-codepen" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Codepen', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('jsfiddlelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('jsfiddlelink') ); ?>" target="_blank" class="boxwp-social-icon-jsfiddle" title="<?php esc_attr_e('JSFiddle','boxwp'); ?>"><i class="fa fa-jsfiddle" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('JSFiddle', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('stackoverflowlink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('stackoverflowlink') ); ?>" target="_blank" class="boxwp-social-icon-stackoverflow" title="<?php esc_attr_e('Stack Overflow','boxwp'); ?>"><i class="fa fa-stack-overflow" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Stack Overflow', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('stackexchangelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('stackexchangelink') ); ?>" target="_blank" class="boxwp-social-icon-stackexchange" title="<?php esc_attr_e('Stack Exchange','boxwp'); ?>"><i class="fa fa-stack-exchange" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Stack Exchange', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('bsalink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('bsalink') ); ?>" target="_blank" class="boxwp-social-icon-buysellads" title="<?php esc_attr_e('BuySellAds','boxwp'); ?>"><i class="fa fa-buysellads" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('BuySellAds', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('slidesharelink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('slidesharelink') ); ?>" target="_blank" class="boxwp-social-icon-slideshare" title="<?php esc_attr_e('SlideShare','boxwp'); ?>"><i class="fa fa-slideshare" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('SlideShare', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('skypeusername') ) : ?>
            <a href="skype:<?php echo esc_html( boxwp_get_option('skypeusername') ); ?>?chat" class="boxwp-social-icon-skype" title="<?php esc_attr_e('Skype','boxwp'); ?>"><i class="fa fa-skype" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Skype', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('emailaddress') ) : ?>
            <a href="mailto:<?php echo esc_html( boxwp_get_option('emailaddress') ); ?>" class="boxwp-social-icon-email" title="<?php esc_attr_e('Email Us','boxwp'); ?>"><i class="fa fa-envelope" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('Email Us', 'boxwp'); ?></span></a><?php endif; ?>
    <?php if ( boxwp_get_option('rsslink') ) : ?>
            <a href="<?php echo esc_url( boxwp_get_option('rsslink') ); ?>" target="_blank" class="boxwp-social-icon-rss" title="<?php esc_attr_e('RSS','boxwp'); ?>"><i class="fa fa-rss" aria-hidden="true"></i><span class="screen-reader-text"><?php esc_html_e('RSS', 'boxwp'); ?></span></a><?php endif; ?>
</div>
</div>
</div>

<?php }