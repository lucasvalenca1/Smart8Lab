/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables TAB key
 * navigation support for dropdown menus.
 */
( function() {
    var boxwp_secondary_container, boxwp_secondary_button, boxwp_secondary_menu, boxwp_secondary_links, boxwp_secondary_i, boxwp_secondary_len;

    boxwp_secondary_container = document.getElementById( 'boxwp-secondary-navigation' );
    if ( ! boxwp_secondary_container ) {
        return;
    }

    boxwp_secondary_button = boxwp_secondary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof boxwp_secondary_button ) {
        return;
    }

    boxwp_secondary_menu = boxwp_secondary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof boxwp_secondary_menu ) {
        boxwp_secondary_button.style.display = 'none';
        return;
    }

    boxwp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === boxwp_secondary_menu.className.indexOf( 'nav-menu' ) ) {
        boxwp_secondary_menu.className += ' nav-menu';
    }

    boxwp_secondary_button.onclick = function() {
        if ( -1 !== boxwp_secondary_container.className.indexOf( 'boxwp-toggled' ) ) {
            boxwp_secondary_container.className = boxwp_secondary_container.className.replace( ' boxwp-toggled', '' );
            boxwp_secondary_button.setAttribute( 'aria-expanded', 'false' );
            boxwp_secondary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            boxwp_secondary_container.className += ' boxwp-toggled';
            boxwp_secondary_button.setAttribute( 'aria-expanded', 'true' );
            boxwp_secondary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    boxwp_secondary_links    = boxwp_secondary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( boxwp_secondary_i = 0, boxwp_secondary_len = boxwp_secondary_links.length; boxwp_secondary_i < boxwp_secondary_len; boxwp_secondary_i++ ) {
        boxwp_secondary_links[boxwp_secondary_i].addEventListener( 'focus', boxwp_secondary_toggleFocus, true );
        boxwp_secondary_links[boxwp_secondary_i].addEventListener( 'blur', boxwp_secondary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function boxwp_secondary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'boxwp-focus' ) ) {
                    self.className = self.className.replace( ' boxwp-focus', '' );
                } else {
                    self.className += ' boxwp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( boxwp_secondary_container ) {
        var touchStartFn, boxwp_secondary_i,
            parentLink = boxwp_secondary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, boxwp_secondary_i;

                if ( ! menuItem.classList.contains( 'boxwp-focus' ) ) {
                    e.preventDefault();
                    for ( boxwp_secondary_i = 0; boxwp_secondary_i < menuItem.parentNode.children.length; ++boxwp_secondary_i ) {
                        if ( menuItem === menuItem.parentNode.children[boxwp_secondary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[boxwp_secondary_i].classList.remove( 'boxwp-focus' );
                    }
                    menuItem.classList.add( 'boxwp-focus' );
                } else {
                    menuItem.classList.remove( 'boxwp-focus' );
                }
            };

            for ( boxwp_secondary_i = 0; boxwp_secondary_i < parentLink.length; ++boxwp_secondary_i ) {
                parentLink[boxwp_secondary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( boxwp_secondary_container ) );
} )();


( function() {
    var boxwp_primary_container, boxwp_primary_button, boxwp_primary_menu, boxwp_primary_links, boxwp_primary_i, boxwp_primary_len;

    boxwp_primary_container = document.getElementById( 'boxwp-primary-navigation' );
    if ( ! boxwp_primary_container ) {
        return;
    }

    boxwp_primary_button = boxwp_primary_container.getElementsByTagName( 'button' )[0];
    if ( 'undefined' === typeof boxwp_primary_button ) {
        return;
    }

    boxwp_primary_menu = boxwp_primary_container.getElementsByTagName( 'ul' )[0];

    // Hide menu toggle button if menu is empty and return early.
    if ( 'undefined' === typeof boxwp_primary_menu ) {
        boxwp_primary_button.style.display = 'none';
        return;
    }

    boxwp_primary_menu.setAttribute( 'aria-expanded', 'false' );
    if ( -1 === boxwp_primary_menu.className.indexOf( 'nav-menu' ) ) {
        boxwp_primary_menu.className += ' nav-menu';
    }

    boxwp_primary_button.onclick = function() {
        if ( -1 !== boxwp_primary_container.className.indexOf( 'boxwp-toggled' ) ) {
            boxwp_primary_container.className = boxwp_primary_container.className.replace( ' boxwp-toggled', '' );
            boxwp_primary_button.setAttribute( 'aria-expanded', 'false' );
            boxwp_primary_menu.setAttribute( 'aria-expanded', 'false' );
        } else {
            boxwp_primary_container.className += ' boxwp-toggled';
            boxwp_primary_button.setAttribute( 'aria-expanded', 'true' );
            boxwp_primary_menu.setAttribute( 'aria-expanded', 'true' );
        }
    };

    // Get all the link elements within the menu.
    boxwp_primary_links    = boxwp_primary_menu.getElementsByTagName( 'a' );

    // Each time a menu link is focused or blurred, toggle focus.
    for ( boxwp_primary_i = 0, boxwp_primary_len = boxwp_primary_links.length; boxwp_primary_i < boxwp_primary_len; boxwp_primary_i++ ) {
        boxwp_primary_links[boxwp_primary_i].addEventListener( 'focus', boxwp_primary_toggleFocus, true );
        boxwp_primary_links[boxwp_primary_i].addEventListener( 'blur', boxwp_primary_toggleFocus, true );
    }

    /**
     * Sets or removes .focus class on an element.
     */
    function boxwp_primary_toggleFocus() {
        var self = this;

        // Move up through the ancestors of the current link until we hit .nav-menu.
        while ( -1 === self.className.indexOf( 'nav-menu' ) ) {

            // On li elements toggle the class .focus.
            if ( 'li' === self.tagName.toLowerCase() ) {
                if ( -1 !== self.className.indexOf( 'boxwp-focus' ) ) {
                    self.className = self.className.replace( ' boxwp-focus', '' );
                } else {
                    self.className += ' boxwp-focus';
                }
            }

            self = self.parentElement;
        }
    }

    /**
     * Toggles `focus` class to allow submenu access on tablets.
     */
    ( function( boxwp_primary_container ) {
        var touchStartFn, boxwp_primary_i,
            parentLink = boxwp_primary_container.querySelectorAll( '.menu-item-has-children > a, .page_item_has_children > a' );

        if ( 'ontouchstart' in window ) {
            touchStartFn = function( e ) {
                var menuItem = this.parentNode, boxwp_primary_i;

                if ( ! menuItem.classList.contains( 'boxwp-focus' ) ) {
                    e.preventDefault();
                    for ( boxwp_primary_i = 0; boxwp_primary_i < menuItem.parentNode.children.length; ++boxwp_primary_i ) {
                        if ( menuItem === menuItem.parentNode.children[boxwp_primary_i] ) {
                            continue;
                        }
                        menuItem.parentNode.children[boxwp_primary_i].classList.remove( 'boxwp-focus' );
                    }
                    menuItem.classList.add( 'boxwp-focus' );
                } else {
                    menuItem.classList.remove( 'boxwp-focus' );
                }
            };

            for ( boxwp_primary_i = 0; boxwp_primary_i < parentLink.length; ++boxwp_primary_i ) {
                parentLink[boxwp_primary_i].addEventListener( 'touchstart', touchStartFn, false );
            }
        }
    }( boxwp_primary_container ) );
} )();