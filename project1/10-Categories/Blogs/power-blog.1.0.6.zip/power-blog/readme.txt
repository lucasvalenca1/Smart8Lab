=== Power Blog ===

Contributors: moralthemes
Tags: translation-ready, custom-header, custom-background, theme-options, custom-menu, threaded-comments, featured-images, footer-widgets, right-sidebar, full-width-template, two-columns, grid-layout, custom-logo, blog, portfolio, photography
Requires at least: 4.7
Requires PHP: 5.6
Tested up to: 5.3.2
Stable tag: 1.0.6
License: GNU General Public License v3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Power Blog is a Child Theme of Reblog. Power Blog is best ever crafted free WordPress theme for Blogger. Power Blog has nice, beautiful and professional layouts. Power Blog is very simple and totally responsive. It has a clean design and smooth presentation. People who loves simple yet attractive way of presenting their articles will choose Power Blog Child theme. You can view the theme demo at - https://demo.moralthemes.com/power-blog

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Screenshots ==
License: CC0 1.0 Universal (CC0 1.0)
https://pxhere.com/en/photo/1418681

License: CC0 1.0 Universal (CC0 1.0)
https://stocksnap.io/photo/SVXFGAE7NB

== Credits ==

Power Blog WordPress Theme, Copyright (C) 2019, Moral Themes
Power Blog is distributed under the terms of the GNU GPL

Power Blog WordPress Theme is child theme of Reblog WordPress Theme, Copyright (C) 2019, Moral Themes
Reblog WordPress Theme is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0.6 - Mar 11 2020 =
* Updated tagcloud spacing and color design

= 1.0.5 - Jan 3 2019 =
* Updated comment css

= 1.0.4 - Nov 21 2019 =
* Updated 404 page design

= 1.0.3 - October 31 2019 =
* Updated minor css

= 1.0.2 - October 21 2019 =
* Updated readme file

= 1.0.1 - October 17 2019 =
* Updated default Site title color

= 1.0.0 - September 26 2019 =
* Initial release
