jQuery('document').ready(function ($){
    $('.top-menu-toggle').on('click', function () {
       $('.top-menu').toggle();
    });
});