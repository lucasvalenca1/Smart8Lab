( function( api ) {

	// Extends our custom "blog-vlog" section.
	api.sectionConstructor['Blog_vlog'] = api.Section.extend( {

		// No events for this type of section.
		attachEvents: function () {},

		// Always make the section active.
		isContextuallyActive: function () {
			return true;
		}
	} );

} )( wp.customize );
