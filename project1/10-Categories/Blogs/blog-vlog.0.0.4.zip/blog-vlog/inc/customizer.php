<?php
/**
 * blog-vlog Theme Customizer.
 *
 * @package blog-vlog
 */


/**
 * Sanitizing the select callback example
 *
 * @since blog-vlog 1.0.0
 *
 * @see sanitize_key()https://developer.wordpress.org/reference/functions/sanitize_key/
 * @see $wp_customize->get_control() https://developer.wordpress.org/reference/classes/wp_customize_manager/get_control/
 *
 * @param $input
 * @param $setting
 * @return sanitized output
 *
 */
if ( !function_exists('blog_vlog_sanitize_select') ) :
    function blog_vlog_sanitize_select( $input, $setting ) 
   {

        // Ensure input is a slug.
        $input = sanitize_key( $input );

        // Get list of choices from the control associated with the setting.
        $choices = $setting->manager->get_control( $setting->id )->choices;

        // If the input is a valid key, return it; otherwise, return the default.
        return ( array_key_exists( $input, $choices ) ? $input : $setting->default );
    }
endif;


/**
 * Sanitize checkbox field
 *
 * @since blog_vlog 1.0.0
 *
 * @param $checked
 * @return Boolean
 */
if ( !function_exists('blog_vlog_sanitize_checkbox') ) :
    function blog_vlog_sanitize_checkbox( $checked ) {
        // Boolean check.
        return ( ( isset( $checked ) && true == $checked ) ? true : false );
    }
endif;
/**
 * Sanitize RGBA color field
 *
 * @since blog_vlog 1.0.0
 *
 * @param $checked
 * @return Boolean
 */
function blog_vlog_sanitize_rgba( $color ) {
    if ( empty( $color ) || is_array( $color ) )
        return 'rgba(0,0,0,0)';

    // If string does not start with 'rgba', then treat as hex
    // sanitize the hex color and finally convert hex to rgba
    if ( false === strpos( $color, 'rgba' ) ) {
        return sanitize_hex_color( $color );
    }

    // By now we know the string is formatted as an rgba color so we need to further sanitize it.
    $color = str_replace( ' ', '', $color );
    sscanf( $color, 'rgba(%d,%d,%d,%f)', $red, $green, $blue, $alpha );
    return 'rgba('.$red.','.$green.','.$blue.','.$alpha.')';
}

/**
 * Sidebar layout options
 *
 * @since blog-vlog 1.0.0
 *
 * @param null
 * @return array $blog_vlog_sidebar_layout
 *
 */
if ( !function_exists('blog_vlog_sidebar_layout') ) :
    function blog_vlog_sidebar_layout()
    {
        $blog_vlog_sidebar_layout =  array(
            'right-sidebar' => __( 'Right Sidebar', 'blog-vlog'),
            'left-sidebar'  => __( 'Left Sidebar' , 'blog-vlog'),
            'no-sidebar'    => __( 'No Sidebar', 'blog-vlog')
        );
        return apply_filters( 'blog_vlog_sidebar_layout', $blog_vlog_sidebar_layout );
    }
endif;




/**
 *  Default Theme options
 *
 * @since blog-vlog 1.0.0
 *
 * @param null
 * @return array $blog_vlog_theme_layout
 *
 */
if ( !function_exists('blog_vlog_default_theme_options') ) :
    function blog_vlog_default_theme_options() 
   {

        $default_theme_options = array(
            /*feature section options*/
            'blog_vlog_top_header_section' =>'show',
            'blog-vlog-feature-cat'             => 0,
            'blog-vlog-promo-cat'               => 0,
            'blog-vlog-footer-copyright'        => esc_html__( 'Blog Vlog WordPress Theme, Copyright 2018', 'blog-vlog'),
            'blog-vlog-layout'                  => 'right-sidebar',   
            'breadcrumb_option'             => 'simple',
            'blog-vlog-realted-post'            => 0,
            'blog-vlog-realted-post-title'      => esc_html__( 'Related Posts', 'blog-vlog' ),
            'hide-breadcrumb-at-home'       => 1 ,
            'primary_color'                 => '#222222',
            'slider_caption_bg_color'       => 'rgba(249,244,242,0.64)',
            'hide-slider-post-at-category'  => 1,


        ); 

        return apply_filters( 'blog_vlog_default_theme_options', $default_theme_options );
    }
endif;

/**
 *  Get theme options
 *
 * @since blog-vlog 1.0.0
 *
 * @param null
 * @return array blog_vlog_theme_options
 *
 */
if ( !function_exists('blog_vlog_get_theme_options') ) :
    function blog_vlog_get_theme_options()
    {

        $blog_vlog_default_theme_options = blog_vlog_default_theme_options();
        

        $blog_vlog_get_theme_options = get_theme_mod( 'blog_vlog_theme_options');
        
        if( is_array( $blog_vlog_get_theme_options )){
          
            return array_merge( $blog_vlog_default_theme_options, $blog_vlog_get_theme_options );
        }

        else{

            return $blog_vlog_default_theme_options;
        }

    }
endif;


/**
     * Load Update to Pro section
     */
     require get_template_directory() . '/inc/customizer-pro/class-customize.php';



/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function blog_vlog_customize_register( $wp_customize )
{
	$wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
	$wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';


     $wp_customize->add_section( 'theme_detail', array(
            'title'    => __( 'About Theme', 'blog-vlog' ),
            'priority' => 9
        ) );
    
        
        $wp_customize->add_setting( 'upgrade_text', array(
            'default' => '',
            'sanitize_callback' => '__return_false'
        ) );
        
        $wp_customize->add_control( new blog_vlog_Customize_Static_Text_Control( $wp_customize, 'upgrade_text', array(
            'section'     => 'theme_detail',
            'label'       => __( 'Upgrade to PRO', 'blog-vlog' ),
            'description' => array('')
        ) ) );


	/*defaults options*/
    $defaults = blog_vlog_get_theme_options();

    
       
    
       
    /**
     * Load customizer custom-controls
     */
    require get_template_directory() . '/inc/customizer-inc/custom-controls.php';

    /**
     * Load customizer feature section
     */
    require get_template_directory() . '/inc/customizer-inc/blog-vlog-theme-options.php';

}
add_action( 'customize_register', 'blog_vlog_customize_register' );


/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function blog_vlog_customize_preview_js() 
{
	wp_enqueue_script( 'blog_vlog_customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), '20151216', true );
}
add_action( 'customize_preview_init', 'blog_vlog_customize_preview_js' );


function blog_vlog_customizer_script() {
  
    wp_enqueue_style( 'blog-vlog-customizer-style', get_template_directory_uri() .'/inc/css/customizer-style.css'); 

   wp_enqueue_script( 'blog-vlog-alpha-color-picker', get_template_directory_uri() .'/inc/js/alpha-color-picker.js',array( 'jquery', 'wp-color-picker' ),
            time());  
}
add_action( 'customize_controls_enqueue_scripts', 'blog_vlog_customizer_script' );




