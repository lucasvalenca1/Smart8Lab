<?php

/**

 * Dynamic css

 *

 * @package ample Themes

 * @subpackage blog_vlog

 *

 * @param null

 * @return void

 *

 */

if ( !function_exists('blog_vlog_dynamic_css') ):

    function blog_vlog_dynamic_css(){

    $blog_vlog_theme_options  = blog_vlog_get_theme_options();
   
   /*====================Basic Color=====================*/

    $blog_vlog_primary_color     = $blog_vlog_theme_options['primary_color'];
    
    $slider_caption_color    = $blog_vlog_theme_options['slider_caption_bg_color'];
   
    

   $custom_css = '';




/*====================Primary Color =====================*/

$custom_css .= " .site-title a, p.site-description, .main-navigation ul li.current-menu-item a, .widget .widget-title, h1, h2, h3, h4, h5, h6

                  {

                      color: " . $blog_vlog_primary_color . ";

                   }

                  ";

$custom_css .= " #featured-slider .feature-description figcaption

                  {

                      background: " . $slider_caption_color . ";

                   }

                  ";                  


  





    /*------------------------------------------------------------------------------------------------- */


    /*custom css*/



    wp_add_inline_style('blog-vlog-style', $custom_css);



}

endif;

add_action('wp_enqueue_scripts', 'blog_vlog_dynamic_css', 99);