<?php

/* Hide/Show Breadcrumb Section */
$wp_customize          -> add_setting( 'blog_vlog_theme_options[hide-breadcrumb-at-home]',
 array(
        'capability'        => 'edit_theme_options',
        'default'           => $defaults['hide-breadcrumb-at-home'],
        'sanitize_callback' => 'blog_vlog_sanitize_checkbox'
      ) );

$wp_customize           -> add_control('blog_vlog_theme_options[hide-breadcrumb-at-home]',
            array(
                    'label'     => __( 'Hide/Show Breadcrumb On Home Page', 'blog-vlog'),
                    'section'   => 'static_front_page',
                    'type'      => 'checkbox',
                    'priority'  => 10
                 )
    );



// Setting site primary color.
$wp_customize->add_setting( 'blog_vlog_theme_options[primary_color]',
    array(
        'default'           => $defaults['primary_color'],
        'sanitize_callback' => 'sanitize_hex_color',
    )
);

$wp_customize->add_control(
    new WP_Customize_Color_Control(
        $wp_customize,
        'blog_vlog_theme_options[primary_color]',
        array(
            'label'       => esc_html__( 'Primary Color', 'blog-vlog' ),
            'description' => esc_html__( 'Applied to main color of site.', 'blog-vlog' ),
            'section'     => 'colors',  
        )
    )
);

    // Overlay Color Picker control. 
        $wp_customize->add_setting(           
             'blog_vlog_separator',
                array(
                    'default' => '',
                    'sanitize_callback' => 'sanitize_text_field',
                )
        );
        $wp_customize->add_control(new Blog_Vlog_Customize_Section_Separator(
            $wp_customize, 
                'blog_vlog_separator', 
                array(
                    'type'      => 'blog_vlog_separator',
                    'label' => esc_html__( 'Slider Caption Background Color', 'blog-vlog' ),
                    'section'   => 'colors',
                    'priority'  => 110,
                )                   
            )
        );

    // Overlay Color Picker control. 
     $wp_customize->add_setting(
        'blog_vlog_theme_options[slider_caption_bg_color]',
        array(
           'default'     =>  $defaults['slider_caption_bg_color'],
           'type'       => 'theme_mod',
           'capability'  => 'edit_theme_options',
           'sanitize_callback' => 'blog_vlog_sanitize_rgba',
          

        )
    );
    $wp_customize->add_control(
        new Blog_Vlog_Color_Control(
            $wp_customize,
             'blog_vlog_theme_options[slider_caption_bg_color]',
            array(
              
                'section' => 'colors',
                'priority' => 110,
                
            )
        )
    );

/**
 * Theme Option
 *
 * @since 1.0.0
 */
$wp_customize->add_panel(
    'blog_vlog_theme_options', 
    	array(
        		'priority'       => 200,
            	'capability'     => 'edit_theme_options',
            	'theme_supports' => '',
            	'title'          => esc_html__( 'Theme Option', 'blog-vlog' ),
             ) 
);



/*adding sections for Breadcrumbs for pages/posts*/
$wp_customize->add_section( 'top_type',
    array(
        'priority'       => 155,
        'capability'     => 'edit_theme_options',
        'title'          => __( 'Top Info Section', 'blog-vlog' ),
        'panel'          => 'blog_vlog_theme_options',


    ) );

$wp_customize->add_setting(
    'blog_vlog_top_header_section',
    array(
        'default' => $default['blog_vlog_top_header_section'],
        'sanitize_callback' => 'blog_vlog_sanitize_select',
    )
);

$hide_show_top_header_option = blog_vlog_slider_option();
$wp_customize->add_control(
    'blog_vlog_top_header_section',
    array(
        'type' => 'radio',
        'label' => esc_html__('Top Header Info Option', 'blog-vlog'),
        'description' => esc_html__('Show/hide Option for Top Header Info Section.', 'blog-vlog'),
        'section' => 'top_type',
        'choices' => $hide_show_top_header_option,
        'priority' => 5
    )
);



   /*adding sections for Breadcrumbs for pages/posts*/
$wp_customize->add_section( 'breadcrumb_type',
 array(
        'priority'       => 160,
        'capability'     => 'edit_theme_options',
        'title'          => __( 'Breadcrumbs Section', 'blog-vlog' ),
        'panel'          => 'blog_vlog_theme_options',
      

      ) );

/* breadcrumb_option*/
$wp_customize->add_setting( 'blog_vlog_theme_options[breadcrumb_option]',
 array(
            'capability'        => 'edit_theme_options',
            'default'           => $defaults['breadcrumb_option'],
            'sanitize_callback' => 'blog_vlog_sanitize_select'
      ) );

$wp_customize->add_control('blog_vlog_theme_options[breadcrumb_option]',
    array(
        'label' => esc_html__('Breadcrumb Options', 'blog-vlog'),
         'section'   => 'breadcrumb_type',
        'settings'  => 'blog_vlog_theme_options[breadcrumb_option]',
        'choices'   => array(
        'simple'     => esc_html__('Simple', 'blog-vlog'),
        'disable'    => esc_html__('Disable', 'blog-vlog'),
          ),
        'type' => 'select',
        'priority' => 10
    )
);


    /*adding sections for category section in front page*/
$wp_customize->add_section( 'blog-vlog-feature-category',
 array(
        'priority'       => 160,
        'capability'     => 'edit_theme_options',
        'title'          => __( 'Featured Section', 'blog-vlog' ),
        'panel'          => 'blog_vlog_theme_options',
        'description'    => __( 'Recommended image for slider is 1920*700', 'blog-vlog' )

      ) );

/* feature cat selection */
$wp_customize->add_setting( 'blog_vlog_theme_options[blog-vlog-feature-cat]',
 array(
            'capability'		=> 'edit_theme_options',
            'default'			=> $defaults['blog-vlog-feature-cat'],
            'sanitize_callback' => 'absint'
      ) );

$wp_customize->add_control(
    new Blog_Vlog_Customize_Category_Dropdown_Control(
        $wp_customize,
        'blog_vlog_theme_options[blog-vlog-feature-cat]',
        array(
                'label'		=> __( 'Select Category', 'blog-vlog' ),
                'section'   => 'blog-vlog-feature-category',
                'settings'  => 'blog_vlog_theme_options[blog-vlog-feature-cat]',
                'type'	  	=> 'category_dropdown',
                'priority'  => 10
             )
    )
);


/* Hide/Show Slider Post in Category Section */

$wp_customize          -> add_setting( 'blog_vlog_theme_options[hide-slider-post-at-category]',
 array(
        'capability'        => 'edit_theme_options',
        'default'           => $defaults['hide-slider-post-at-category'],
        'sanitize_callback' => 'blog_vlog_sanitize_checkbox'
      ) );

$wp_customize           -> add_control('blog_vlog_theme_options[hide-slider-post-at-category]',
            array(
                    'label'     => __( 'Show Slider Post on Category Post', 'blog-vlog'),
                    'section'   => 'blog-vlog-feature-category',
                    'type'      => 'checkbox',
                    'priority'  => 10
                 )
    );




/*adding sections for category selection for promo section in homepage*/
$wp_customize->add_section( 'blog-vlog-promo-category', 
    array(
            'priority'       => 160,
            'capability'     => 'edit_theme_options',
            'title'          => __( 'Promo Section', 'blog-vlog' ),
            'panel'          => 'blog_vlog_theme_options',
            'description'    => __( 'Recommended image for col section is 600*600', 'blog-vlog' )
         ) );

/* feature cat selection */
$wp_customize->add_setting( 'blog_vlog_theme_options[blog-vlog-promo-cat]',
 array(
        'capability'		=> 'edit_theme_options',
        'default'			=> $defaults['blog-vlog-promo-cat'],
        'sanitize_callback' => 'absint'
       ) );

$wp_customize->add_control(
    new Blog_Vlog_Customize_Category_Dropdown_Control(
        $wp_customize,
        'blog_vlog_theme_options[blog-vlog-promo-cat]',
        array(
            'label'		=> __( 'Select Category', 'blog-vlog' ),
            'section'   => 'blog-vlog-promo-category',
            'settings'  => 'blog_vlog_theme_options[blog-vlog-promo-cat]',
            'type'	  	=> 'category_dropdown',
            'priority'  => 10
        )
    )
);


/*adding sections for category selection for promo section in homepage*/
$wp_customize        -> add_section( 'blog-vlog-site-layout',
 array(
        'priority'       => 160,
        'capability'     => 'edit_theme_options',
        'panel'          => 'blog_vlog_theme_options',
        'title'          => __( 'Design Layout', 'blog-vlog' )
      ) );

/* Sidebar selection */
$wp_customize          -> add_setting( 'blog_vlog_theme_options[blog-vlog-layout]',
 array(
        'capability'		=> 'edit_theme_options',
        'default'			=> $defaults['blog-vlog-layout'],
        'sanitize_callback' => 'blog_vlog_sanitize_select'
      ) );

$choices                = blog_vlog_sidebar_layout();
$wp_customize           -> add_control('blog_vlog_theme_options[blog-vlog-layout]',
            array(
                    'choices'   => $choices,
                    'label'		=> __( 'Select Design Layout', 'blog-vlog'),
                    'section'   => 'blog-vlog-site-layout',
                    'settings'  => 'blog_vlog_theme_options[blog-vlog-layout]',
                    'type'	  	=> 'select',
                    'priority'  => 10
                 )
    );

  /**
     * Related Posts title
     */
    $wp_customize->add_setting(
        'blog_vlog_theme_options[blog-vlog-realted-post-title]',
        array(
                'default'           => $defaults['blog-vlog-realted-post-title'],
                'sanitize_callback' => 'sanitize_text_field',
             )
    );
    $wp_customize->add_control('blog_vlog_theme_options[blog-vlog-realted-post-title]',
        array(
                'label'      => esc_html__('Related Posts title ','blog-vlog'),
                'section'   => 'blog-vlog-site-layout',
                'settings'  => 'blog_vlog_theme_options[blog-vlog-realted-post-title]',
                'type'      => 'text',
                'priority'  => 10
             )
    );



/* Related post Section */
$wp_customize          -> add_setting( 'blog_vlog_theme_options[blog-vlog-realted-post]',
 array(
        'capability'        => 'edit_theme_options',
        'default'           => $defaults['blog-vlog-realted-post'],
        'sanitize_callback' => 'blog_vlog_sanitize_checkbox'
      ) );

$wp_customize           -> add_control('blog_vlog_theme_options[blog-vlog-realted-post]',
            array(
                    'label'     => __( 'Hide/Show Related Post', 'blog-vlog'),
                    'section'   => 'blog-vlog-site-layout',
                    'settings'  => 'blog_vlog_theme_options[blog-vlog-realted-post]',
                    'type'      => 'checkbox',
                    'priority'  => 10
                 )
    );


/*adding sections for footer options*/
    $wp_customize        -> add_section( 'blog-vlog-footer-option', 
        array(
                'priority'       => 170,
                'capability'     => 'edit_theme_options',
                'theme_supports' => '',
                'panel'          => 'blog_vlog_theme_options',
                'title'          => __( 'Footer Option', 'blog-vlog' )
             ) );

    /*copyright*/
    $wp_customize           -> add_setting( 'blog_vlog_theme_options[blog-vlog-footer-copyright]',
      array(
                'capability'        => 'edit_theme_options',
                'default'           => $defaults['blog-vlog-footer-copyright'],
                'sanitize_callback' => 'wp_kses_post'
            ) );
    $wp_customize   -> 
    add_control( 'blog-vlog-footer-copyright',
     array(
            'label'     => __( 'Copyright Text', 'blog-vlog' ),
            'section'   => 'blog-vlog-footer-option',
            'settings'  => 'blog_vlog_theme_options[blog-vlog-footer-copyright]',
            'type'      => 'text',
            'priority'  => 10
          ) );


