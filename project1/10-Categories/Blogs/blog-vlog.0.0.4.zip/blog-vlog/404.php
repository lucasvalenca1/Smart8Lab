<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package blog-vlog
 */

get_header();

/**
* Hook - blog_vlog_breadcrumb_type.
*
* @hooked blog_vlog_breadcrumb_type
*/
do_action( 'blog_vlog_breadcrumb_type' );
	
$side_col = 'right-s-bar ';
$designlayout = $blog_vlog_theme_options['blog-vlog-layout'];
if( 'left-sidebar' == $designlayout ){
	$side_col = 'left-s-bar';
}
?>
	<div id="primary" class="content-area col-md-9">
		<main id="main" class="site-main" role="main">
		  	<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'blog-vlog' ); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'blog-vlog' ); ?></p>

					<?php
						get_search_form();
						
					?>				

				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
