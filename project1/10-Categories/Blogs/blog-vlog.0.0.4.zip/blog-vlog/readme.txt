#### Blog Vlog WordPress Theme ####

Contributors: Amplethemes
Tags: two-columns, right-sidebar, custom-background, custom-colors, custom-menu, featured-images, sticky-post, theme-options, threaded-comments, translation-ready, blog, post-formats

Requires at least: 4.4
Tested up to: 4.9.4
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

#### Description ####

Blog Vlog is simple, clean and elegant WordPress Theme for your blog site. This theme comes with slider, promo section, copyright options and social options. In addition this theme has added custom widget for recent post, author and social menu. Use this awesome WordPress theme for your blog site, you will never look for alternative. Demo: http://demo.Amplethemes.com/Blog Vlog/


#### Installation ####

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


Blog Vlog WordPress Theme, Copyright 2017 Ample Themes
Blog Vlog is distributed under the terms of the GNU General Public License v2

#### Credits ####

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Google Fonts - Apache License, version 2.0
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* Bootstrap http://getbootstrap.com/ [MIT](http://opensource.org/licenses/MIT) Copyright 2011-2015 Twitter, Inc.
* Font-Awesome https://github.com/FortAwesome/Font-Awesome FontAwesome 4.6.3 Copyright 2012 Dave Gandy Font License: SIL OFL 1.1 Code License: MIT License http://fontawesome.io/license/
* jQuery OwlCarousel http://www.owlgraphic.com/owlcarousel/ [MIT](http://opensource.org/licenses/MIT) Copyright (c) 2013 Bartosz Wojciechowski
* Fancybox  https://github.com/fancyapps/fancybox/blob/master/README.md, licensed under the GPLv3 license

#### Image used in screenshot ####
https://pixabay.com/en/fuchsia-flowers-macro-pink-purple-3383825/
https://pixabay.com/en/nougat-mousse-chocolate-mousse-3078581/
https://pixabay.com/en/chinese-lantern-plant-husk-fruit-3699126/
https://pixabay.com/en/fly-agaric-mushrooms-468767/



#### Changelog ####


## 0.0.1 - dec 19 2018 ##
* Submitted to WordPress

## 0.0.2 - dec 19 2018 ##
* text domain fixed

#0.0.5 dec-2o-2018 ##
* some url change



