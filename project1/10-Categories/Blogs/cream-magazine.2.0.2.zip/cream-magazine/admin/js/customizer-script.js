( function( $ ) {
	
	jQuery(document).ready(function($) { 

		//Chosen JS
	    jQuery(".hs-chosen-select").chosen({
	        width: "100%"
	    });
	});

} ) ( jQuery );