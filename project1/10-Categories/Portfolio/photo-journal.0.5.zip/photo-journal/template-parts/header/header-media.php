<?php
/**
 * Display Header Media
 *
 * @package Photo_Journal
 */

photo_journal_featured_overall_image();
