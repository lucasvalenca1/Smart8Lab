<?php
/**
 * The template used for displaying credits
 *
 * @package Photo_Journal
 */
?>

<?php
/**
 * photo_journal_credits hook
 * @hooked photo_journal_footer_content - 10
 */
do_action( 'photo_journal_credits' );
