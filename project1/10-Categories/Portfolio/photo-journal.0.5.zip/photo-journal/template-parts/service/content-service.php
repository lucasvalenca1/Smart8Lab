<?php
/**
 * The template used for displaying service
 *
 * @package Photo_Journal
 */
?>

<?php
/**
 * photo_journal_service hook
 * @hooked photo_journal_service_display - 10
 */
do_action( 'photo_journal_service' );
