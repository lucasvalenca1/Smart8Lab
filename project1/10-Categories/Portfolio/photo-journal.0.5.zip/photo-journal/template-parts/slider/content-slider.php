<?php
/**
 * The template used for displaying slider
 *
 * @package Photo_Journal
 */
?>

<?php
/**
 * photo_journal_slider hook
 * @hooked photo_journal_featured_slider - 10
 */
do_action( 'photo_journal_slider' );
