=== Thumbs Portfolio === 

Contributors: Fortisthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, portfolio, blog
Requires at least: 4.5
Requires PHP: 5.4
Tested up to: 5.2
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

Thumbs Portfolio is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

XI portfolio is a free WordPress Ajax portfolio theme built for digital agencies, creative portfolio, photography sites, design studio, illustrators & any content creator. XI portfolio is freely availble, use posts to create portfolio items and display them on a modern responsive grid. Want a more professional look? upgrade to the pro version for  detailed portfolio pages with video and image galleries, a modern looking homepage for a portfolio you'd be proud to share.


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Thumbs Portfolio includes support for Infinite Scroll in Jetpack.


== Credits ==
#ALL https://www.pexels.com/collections/qu5ka5o/
https://www.pexels.com/photo/selective-focus-photography-of-brown-tabby-cat-753037/
https://www.pexels.com/photo/large-medium-coated-fawn-dog-754391/
https://www.pexels.com/photo/woman-wearing-red-top-and-bottoms-leaning-on-yellow-and-green-inflatable-standee-756562/
https://www.pexels.com/photo/photography-of-red-bmw-on-asphalt-road-757186/
https://www.pexels.com/photo/photography-of-red-car-on-asphalt-road-757184/
https://www.pexels.com/photo/photo-of-white-car-at-the-street-761984/
https://www.pexels.com/photo/selective-focus-grayscale-photography-of-baseball-773063/
https://www.pexels.com/photo/close-up-photography-of-red-and-black-nike-running-shoe-786003/
https://www.pexels.com/photo/grayscale-photo-of-a-mountain-covered-with-snow-763097/
https://www.pexels.com/photo/child-in-grey-shorts-sitting-on-road-786220/



== Changelog ==
Released: feb, 5, 2018
