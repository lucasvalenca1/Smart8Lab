=== XI Portfolio === 

Contributors: Fortisthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, portfolio, blog
Requires at least: 4.5
Requires PHP: 5.4
Tested up to: 5.0
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

XI Portfolio is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

XI portfolio is a free WordPress Ajax portfolio theme built for digital agencies, creative portfolio, photography sites, design studio, illustrators & any content creator. XI portfolio is freely availble, use posts to create portfolio items and display them on a modern responsive grid. Want a more professional look? upgrade to the pro version for  detailed portfolio pages with video and image galleries, a modern looking homepage for a portfolio you'd be proud to share.


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

XI Portfolio includes support for Infinite Scroll in Jetpack.


== Credits ==
Photo by Tobi from Pexels https://www.pexels.com/photo/person-wearing-black-cap-and-orange-hoodie-turning-his-back-704857/
https://www.pexels.com/photo/buildings-cars-city-perspective-243756/
https://www.pexels.com/photo/man-walks-beside-train-940365/
https://www.pexels.com/photo/rope-jumping-ropes-human-training-28080/
https://www.pexels.com/photo/jellyfish-digital-wallpaper-753267/
https://www.pexels.com/photo/blur-boy-casual-close-up-428333/
https://www.pexels.com/photo/flying-people-fly-levitate-48262/
https://www.pexels.com/photo/grayscale-photo-of-woman-704900/
https://www.pexels.com/photo/australian-cattle-during-snow-709068/
https://www.pexels.com/photo/photo-of-woman-674268/
https://www.pexels.com/photo/black-and-yellow-p-cap-hanging-in-the-air-171940/



== Changelog ==
Released: feb, 5, 2018
