=== Dankrius === 

Contributors: Fortisthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 4.5
Tested up to: 5.2
Requires PHP: 5.4
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Dank Portfolio is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

Dank portfolio is a free WordPress Ajax portfolio theme built for digital agencies, creative portfolio, photography sites, design studio, illustrators & any content creator. Brix portfolio is freely availble, use posts to create portfolio items and display them on a modern responsive grid. Want a more professional look? upgrade to the pro version for  detailed portfolio pages with video and image galleries, a modern looking homepage for a portfolio you'd be proud to share.


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

adri includes support for Infinite Scroll in Jetpack.

== Copyright ==

Dank Portfolio WordPress Theme, Copyright (C) 2019, FortisThemes.
Dank Portfoli is distributed under the terms of the GNU GPL

== Credits ==
Images used in screenshot:

License: CC0 1.0 Universal (CC0 1.0)
License URI: https://stocksnap.io/license
Source: https://stocksnap.io

https://stocksnap.io/photo/Z6GWRYKC1T
https://stocksnap.io/photo/U94B4HVBAO

Default-image
author: FortisThemes
License: GPL v2


Underscores 
Author: Automattic
License: GPL v2
http://underscores.me/

Normalizing styles
Author: Nicolas Gallagher and Jonathan Neal 
http://necolas.github.io/normalize.css/
License: GPL

Smoothstate
author  Miguel Ángel Pérez
https://github.com/miguel-perez/smoothState.js
License: MIT
license uri: https://github.com/miguel-perez/smoothState.js/blob/master/LICENSE.md

== Changelog ==

= 1.0 - May 2018 =
* Initial release
== 1.0.3 July 2019 ==
* added wp_body_open tag with backward compatibilty