$ = jQuery
jQuery(document).ready(function () {

    if ($(".myshop-section-wrapper").niceScroll != undefined) {

        $(".myshop-section-wrapper").niceScroll({
            cursorcolor: "#0391CE",
            cursorwidth: "5px",
            cursorborder: "1px solid #0c8edc"
        });

    }

    


});	