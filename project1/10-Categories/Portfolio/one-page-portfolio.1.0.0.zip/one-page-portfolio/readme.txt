=== One Page Portfolio ===

Contributors: Rigorous Theme
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, grid-layout, one-column, two-columns, full-width-template, post-formats, theme-options, blog, news, portfolio

Requires at least: 4.5
Tested up to: 5.0.3
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
One Page Portfolio is child theme of RT Portfolio.RT Portfolio is a pixel perfect creative multi-purpose WordPress theme.It's clean and modern for any need: portfolio, business, agency, freelance, designer, web designer, developers, marketing, startup, blog, magazine, photography, architect, corporate, event, artist, music, restaurant.If you are searching for innovative WordPress Theme,RT Portfolio is top recommendation. Build beautiful, intelligent websites.



== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== License ===

One Page Portfolio WordPress Theme is child theme of RT Portfolio WordPress Theme, Copyright 2018 Rigorous Theme
One Page Portfolio WordPress Theme is distributed under the terms of the GNU GPL

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

RT Portfolio WordPress Theme, Copyright (C) 2018, Rigorous Theme
RT Portfolio is distributed under the terms of the GNU GPL


== Images Used in Screenshot ==
All the images are CCO license,
https://stocksnap.io/photo/KVJUCEE9JY
arrow-bg.png: self created GPLv2

Myshop.jpg:  
https://stocksnap.io/photo/I93PW8NE0F
screenshot.png: self created GPLv2

== Changelog ==
= 1.0.0 - January 11 2019 =
* Initial release