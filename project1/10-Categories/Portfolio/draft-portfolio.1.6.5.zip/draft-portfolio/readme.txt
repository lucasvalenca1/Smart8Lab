=== Draft Portfolio === 

Contributors: Fortisthemes
Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, translation-ready, portfolio, blog, photgraphy
Requires at least: 4.5
Requires PHP: 5.4
Tested up to: 5.2
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: LICENSE

Draft Portfolio is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

Draft Portfolio is a minimally beautiful WordPress theme for Photographers, designer, illustrators, creative agencies and for anybody building a beautiful portfolio websites. Set it up in a few minutes. Are you serious about your portfolio website? then check out the PRO version for only $39 , this adds a dedicated portfolio post type with amazing features including a gallery and several layout options. click on "theme homepage" above for more information.



== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Draft Portfolio includes support for Infinite Scroll in Jetpack.


== Credits ==

https://unsplash.com/?photo=5tKtllqhx8U
https://unsplash.com/?photo=GsQwzPaqGB0
https://unsplash.com/search/typing?photo=npxXWgQ33ZQ
http://librestock.com/ with CC 1.0 licence https://creativecommons.org/publicdomain/zero/1.0/
https://stocksnap.io under CCO licence https://stocksnap.io/license
http://bossfight.co/ipad-macbook-pro-iphone-imac/
http://www.clker.com/clipart-404448.html
https://stocksnap.io/photo/CV8I9UJPNW
http://graphicburger.com/brown-paper-bag-mockup/



== Changelog ==
Released: feb, 5, 2018
