<?php
	
	$multipurpose_portfolio_first_theme_color = get_theme_mod('multipurpose_portfolio_first_theme_color');

	$custom_css = '';

	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .=' a.button, #footer input[type="submit"], input[type="submit"], .nav-menu ul ul a, .logo, .read-more a, .post-info, h1.page-title, h1.search-title, .blogbtn a, .footerinner .tagcloud a:hover, .woocommerce span.onsale, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, nav.woocommerce-MyAccount-navigation ul li, #comments input[type="submit"].submit, #sidebar h3, #sidebar input[type="submit"], #sidebar .tagcloud a:hover, .pagination a:hover, .pagination .current, span.meta-nav, #comments a.comment-reply-link, .tags a:hover, .woocommerce-product-search button, .back-to-top, .woocommerce .widget_price_filter .ui-slider-horizontal .ui-slider-range, .woocommerce .widget_price_filter .ui-slider .ui-slider-handle{';
			$custom_css .='background-color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
		$custom_css .='}';
	}
	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .='.woocommerce .widget_shopping_cart .buttons a:hover, .woocommerce.widget_shopping_cart .buttons a:hover, .woocommerce .widget_price_filter .price_slider_amount .button:hover{';
			$custom_css .='background-color: '.esc_html($multipurpose_portfolio_first_theme_color).' !important;';
		$custom_css .='}';
	}
	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .=' a, a:hover, .social-icon i:hover, input.search-field,  #footer h3, .woocommerce-message::before,  span.post-title, .tags a i{';
			$custom_css .='color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
		$custom_css .='}';
	}
	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .=' 
		@media screen and (max-width:1000px){
			.nav-menu ul li a:hover{';
				$custom_css .='border-left-color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
			$custom_css .='} 
			.nav-menu ul li a:hover{';
				$custom_css .='color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
			$custom_css .='} 
		}';
	}
	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .=' .nav-menu ul ul a:hover{';
			$custom_css .='border-left-color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
		$custom_css .='}';
	}
	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .=' .back-to-top::before{';
			$custom_css .='border-bottom-color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
		$custom_css .='}';
	}
	if($multipurpose_portfolio_first_theme_color != false){
		$custom_css .='  input.search-field, .blog-sec, .inner, .woocommerce-message, .woocommerce ul.products li.product, .woocommerce-page ul.products li.product, #sidebar .widget, .pagination a:hover, .pagination .current, .tags a:hover, .nav-menu ul ul{';
			$custom_css .='border-color: '.esc_html($multipurpose_portfolio_first_theme_color).';';
		$custom_css .='}';
	}


	// Layout Options
	$multipurpose_portfolio_theme_layout = get_theme_mod( 'multipurpose_portfolio_theme_layout_options','Default Theme');
    if($multipurpose_portfolio_theme_layout == 'Default Theme'){
		$custom_css .='body{';
			$custom_css .='max-width: 100%;';
		$custom_css .='}';
	}else if($multipurpose_portfolio_theme_layout == 'Container Theme'){
		$custom_css .='body{';
			$custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$custom_css .='}';
		$custom_css .='.page-template-custom-front-page #header{';
			$custom_css .='right:0;';
		$custom_css .='}';
	}else if($multipurpose_portfolio_theme_layout == 'Box Container Theme'){
		$custom_css .='body{';
			$custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$custom_css .='}';
		$custom_css .='.page-template-custom-front-page #header{';
			$custom_css .='right:0;';
		$custom_css .='}';
	}


	/*--------------------------- Slider Opacity -------------------*/

	$multipurpose_portfolio_slider_layout = get_theme_mod( 'multipurpose_portfolio_banner_opacity','0.4');
	if($multipurpose_portfolio_slider_layout == '0'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.1'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.1';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.2'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.2';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.3'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.3';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.4'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.4';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.5'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.5';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.6'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.6';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.7'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.7';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.8'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.8';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == '0.9'){
		$custom_css .='#banner img{';
			$custom_css .='opacity:0.9';
		$custom_css .='}';
	}

	/*---------------------------Slider Content Layout -------------------*/

	$multipurpose_portfolio_slider_layout = get_theme_mod( 'multipurpose_portfolio_banner_alignment_option','Left Align');
    if($multipurpose_portfolio_slider_layout == 'Left Align'){
		$custom_css .='#banner .banner-box{';
			$custom_css .='text-align:left;';
		$custom_css .='}';
		$custom_css .='#banner .banner-box{';
		$custom_css .='left:9%; right: auto;';
		$custom_css .='}';
		$custom_css .='#banner .social-media{';
		$custom_css .='left:auto; right: 10%;';
		$custom_css .='}';
		$custom_css .='@media screen and (max-width: 720px) and (min-width: 320px){';
			$custom_css .='#banner .banner-box{';
				$custom_css .='width:auto; ';
			$custom_css .='}';
			$custom_css .='#banner .social-media{';
				$custom_css .='left: 10%; right:auto; text-align:left; width:auto;';
			$custom_css .='}';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == 'Center Align'){
		$custom_css .='#banner .banner-box{';
			$custom_css .='text-align:center; width:auto; left:20%; right:20%;';
		$custom_css .='}';
		$custom_css .='#banner .social-media{';
		$custom_css .='right: 0%; float: none; width: 100%; top: 90%; text-align: center;';
		$custom_css .='}';
		$custom_css .='#banner .social-media i{';
		$custom_css .='display: inline-block;';
		$custom_css .='}';
		$custom_css .='@media screen and (max-width: 720px) and (min-width: 320px){';
			$custom_css .='#banner .social-media{';
				$custom_css .='top:80%;';
			$custom_css .='}';
		$custom_css .='}';
	}else if($multipurpose_portfolio_slider_layout == 'Right Align'){
		$custom_css .='#banner .banner-box{';
			$custom_css .='text-align:right;';
		$custom_css .='}';
		$custom_css .='#banner .banner-box{';
		$custom_css .='left: auto; right:9%;';
		$custom_css .='}';
		$custom_css .='#banner .social-media{';
		$custom_css .='right:auto; left: 10%;';
		$custom_css .='}';
		$custom_css .='@media screen and (max-width: 720px) and (min-width: 320px){';
			$custom_css .='#banner .banner-box{';
				$custom_css .='width:auto; ';
			$custom_css .='}';
			$custom_css .='#banner .social-media{';
				$custom_css .='right: 10%; left:auto; text-align:right;';
			$custom_css .='}';
		$custom_css .='}';
	}

	/*--------- Preloader Color Option -------*/
	$multipurpose_portfolio_preloader_color = get_theme_mod('multipurpose_portfolio_preloader_color');

	if($multipurpose_portfolio_preloader_color != false){
		$custom_css .=' .tg-loader{';
			$custom_css .='border-color: '.esc_html($multipurpose_portfolio_preloader_color).';';
		$custom_css .='} ';
		$custom_css .=' .tg-loader-inner{';
			$custom_css .='background-color: '.esc_html($multipurpose_portfolio_preloader_color).';';
		$custom_css .='} ';
	}

	$multipurpose_portfolio_preloader_bg_color = get_theme_mod('multipurpose_portfolio_preloader_bg_color');

	if($multipurpose_portfolio_preloader_bg_color != false){
		$custom_css .=' #overlayer{';
			$custom_css .='background-color: '.esc_html($multipurpose_portfolio_preloader_bg_color).';';
		$custom_css .='} ';
	}

	/*--------- Top Header ----------*/
	$multipurpose_portfolio_top_bar = get_theme_mod('multipurpose_portfolio_top_header',true);

	if($multipurpose_portfolio_top_bar == false){
		$custom_css .=' .page-template-custom-front-page #header{';
			$custom_css .='top: 10px;';
		$custom_css .='} ';
	}

	/*------------ Button Settings option-----------------*/

	$multipurpose_portfolio_top_button_padding = get_theme_mod('multipurpose_portfolio_top_button_padding');
	$multipurpose_portfolio_bottom_button_padding = get_theme_mod('multipurpose_portfolio_bottom_button_padding');
	$multipurpose_portfolio_left_button_padding = get_theme_mod('multipurpose_portfolio_left_button_padding');
	$multipurpose_portfolio_right_button_padding = get_theme_mod('multipurpose_portfolio_right_button_padding');
	if($multipurpose_portfolio_top_button_padding != false || $multipurpose_portfolio_bottom_button_padding != false || $multipurpose_portfolio_left_button_padding != false || $multipurpose_portfolio_right_button_padding != false){
		$custom_css .='.blogbtn a, .read-more a, #comments input[type="submit"].submit{';
			$custom_css .='padding-top: '.esc_html($multipurpose_portfolio_top_button_padding).'px; padding-bottom: '.esc_html($multipurpose_portfolio_bottom_button_padding).'px; padding-left: '.esc_html($multipurpose_portfolio_left_button_padding).'px; padding-right: '.esc_html($multipurpose_portfolio_right_button_padding).'px; display:inline-block;';
		$custom_css .='}';
	}

	$multipurpose_portfolio_button_border_radius = get_theme_mod('multipurpose_portfolio_button_border_radius');
	$custom_css .='.blogbtn a, .read-more a, #comments input[type="submit"].submit{';
		$custom_css .='border-radius: '.esc_html($multipurpose_portfolio_button_border_radius).'px;';
	$custom_css .='}';

	/*----------- Copyright css -----*/
	$multipurpose_portfolio_copyright_top_padding = get_theme_mod('multipurpose_portfolio_top_copyright_padding');
	$multipurpose_portfolio_copyright_bottom_padding = get_theme_mod('multipurpose_portfolio_top_copyright_padding');
	if($multipurpose_portfolio_copyright_top_padding != false || $multipurpose_portfolio_copyright_bottom_padding != false){
		$custom_css .='.inner{';
			$custom_css .='padding-top: '.esc_html($multipurpose_portfolio_copyright_top_padding).'px; padding-bottom: '.esc_html($multipurpose_portfolio_copyright_bottom_padding).'px; ';
		$custom_css .='}';
	}

	$multipurpose_portfolio_copyright_alignment = get_theme_mod('multipurpose_portfolio_copyright_alignment', 'center');
	if($multipurpose_portfolio_copyright_alignment == 'center' ){
		$custom_css .='#footer .copyright p{';
			$custom_css .='text-align: '. $multipurpose_portfolio_copyright_alignment .';';
		$custom_css .='}';
	}elseif($multipurpose_portfolio_copyright_alignment == 'left' ){
		$custom_css .='#footer .copyright p{';
			$custom_css .=' text-align: '. $multipurpose_portfolio_copyright_alignment .';';
		$custom_css .='}';
	}elseif($multipurpose_portfolio_copyright_alignment == 'right' ){
		$custom_css .='#footer .copyright p{';
			$custom_css .='text-align: '. $multipurpose_portfolio_copyright_alignment .';';
		$custom_css .='}';
	}

	$multipurpose_portfolio_copyright_font_size = get_theme_mod('multipurpose_portfolio_copyright_font_size');
	$custom_css .='#footer .copyright p{';
		$custom_css .='font-size: '.esc_html($multipurpose_portfolio_copyright_font_size).'px;';
	$custom_css .='}';

	/*------ Banner Show/Hide ------*/
	$multipurpose_portfolio_banner = get_theme_mod('multipurpose_portfolio_show_banner');
	if($multipurpose_portfolio_banner == false ){
		$custom_css .='.page-template-custom-front-page #header{';
			$custom_css .='position: static; background-color:#efefef; padding: 10px 0;';
		$custom_css .='}';
	}