=== gute portfolio ===

Contributors: wpthemespace
Requires at least: 4.0
Tested up to: 5.2.2
Tags: portfolio, blog, photography, grid-layout, custom-logo, right-sidebar,  one-column, two-columns, custom-header, custom-menu, featured-image-header, featured-images, flexible-header, full-width-template, theme-options, block-styles, custom-colors, sticky-post, threaded-comments, translation-ready
Version: 1.0.5
Stable tag: 1.0.1
Requires PHP: 5.2.4
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

portfolio WordPress theme

== Copyright License ==
Be 100% GPL and/or 100% GPL-compatible licensed.
Declare copyright and license explicitly. Use the license and license uri header slugs to style.css.
Declare licenses of any resources included such as fonts or images.
All code and design should be your own or legally yours. Cloning of designs is not acceptable.
Any copyright statements on the front end should display the user's copyright, not the theme author's copyright.

gute portfolio WordPress Theme, Copyright 2019 wpthemespace
gute portfolio is distributed under the terms of the GNU GPL


This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.



== Description ==

Gute portfolio is a free responsive portfolio theme. This is the child theme of gute theme. gute portfolio is very good for pesonal portfolio because you can show your personal portfolio by gute portfolio theme. Personal details menu is an awesome feature in the gute portfolio theme.  gute portfolio is editable and super flexible new functionality. The theme has nice, beautiful and professional layouts. This theme is made for any search engine, SEO Compatible.  Bootstrap Framework based so it’s totally responsive.  Html5 and css3 based coded.  It is the multipurpose theme you case to use for the business, corporate, agency, startup, consulting websites.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Credits ==
### Images:
License: All Images are licensed under CC0
License URI: https://creativecommons.org/publicdomain/zero/1.0/

* Defauld header image and screenshot image: CC0 by free photos via pxhere (https://pxhere.com/en/photo/668071 )


    Other images in screenshot are self created and all are under GPLv2.

    Other Images:
        screenshot.png self created GPLv2


== Brand Icons ==

* All brand icons are trademarks of their respective owners.
* The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.



== Changelog ==

= 1.0.5 ==
1. Fixed - PHP error 
= 1.0.4 ==
1. Add custom header image 

= 1.0.3 ==
1. Custom banner section disabled by default
2. replaced esc_attr from esc_html in img alt attribute. 


= 1.0.2 ==
1. Add wp_body_open function
2. replaced esc_attr from esc_html in img alt attribute. 
3. Fixed page menu alignment issue.

= 1.0.1 ==
1. I've used esc_html__()
2. header.php menu issue fixed
3. Add The Requires PHP field in readme.txt
4. Footer menu design issue fixed
5. Screenshot image url fixed
6. Remove unwanted admin notice.

= 1.0.0 ==

* Released


 
	