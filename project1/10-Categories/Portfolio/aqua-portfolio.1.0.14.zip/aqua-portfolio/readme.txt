=== Aquarius === 

Contributors: Afrothemes
Tags: grid-layout, custom-background, custom-menu, custom-logo, featured-images, translation-ready, blog, portfolio, photography
Requires at least: 4.5
Tested up to: 5.2
Requires PHP: 5.2.4
Stable tag: 1.0.5
License: GNU General Public License v2 or later
License URI: LICENSE

Aquarius is a simple WordPress blogging theme focusing on images, use it for a travel, food or photography bloging.

== Description ==

Aquarius is a simple WordPress theme for photographers & bloggers, use it for a travel, food or photography bloging & portfolio. Aquarius can also be use be used for creative agency or photo studio. Try it out for free today.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

adri includes support for Infinite Scroll in Jetpack.


== Credits ==
Images used in screenshot:

License: CC0 1.0 Universal (CC0 1.0)
License URI: https://stocksnap.io/license
Source: https://stocksnap.io

https://stocksnap.io/photo/5TA43Z3DYO
https://stocksnap.io/photo/KRQQUX0GMS


== Changelog ==

= 1.0 - feb 2018 =
* Initial release

== May 3 2019 ==
* added flexbox to header
* fixed logo display