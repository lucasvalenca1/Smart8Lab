		<div class="entry-meta">
			<?php cleanportfolio_posted_on(); ?>
		</div><!-- .entry-meta -->
