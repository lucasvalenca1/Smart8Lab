<?php
/**
 * The template used for displaying slider
 *
  * @package Clean_Portfolio
 */


/**
 * cleanportfolio_slider hook
 * @hooked cleanportfolio_featured_slider - 10
 */
do_action( 'cleanportfolio_slider' );
