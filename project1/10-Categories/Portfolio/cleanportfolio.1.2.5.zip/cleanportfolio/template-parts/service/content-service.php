<?php
/**
 * The template used for displaying service
 *
 * @package Clean_Portfolio
 */
?>

<?php
/**
 * cleanportfolio_service hook
 * @hooked cleanportfolio_service_display - 10
 */
do_action( 'cleanportfolio_service' );
