<?php
/**
 * The template used for displaying slider
 *
 * @package Catch Sketch
 */
?>

<?php
/**
 * catch_sketch_slider hook
 * @hooked catch_sketch_featured_slider - 10
 */
do_action( 'catch_sketch_slider' );
