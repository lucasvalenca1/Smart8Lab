<div class="col-sm-4">
    <form class="search-form" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
      <input name="s" type="text" class="search-input" size="20" maxlength="20" placeholder="<?php echo esc_attr__("Search Here ....", 'videostories');?>" required="">
      <input type="submit" name="submit" class="search-submit">
  </form><!-- /.search-form -->
</div>