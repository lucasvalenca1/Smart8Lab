====== Videofire ===
Author: Liton Arefin

Tags: right-sidebar, custom-menu, editor-style, sticky-post, blog, two-columns, footer-widgets, custom-background, featured-images, post-formats, threaded-comments, translation-ready, full-width-template, entertainment

Requires at least: 4.4
Tested up to: 4.9.7
Stable tag: 1.0.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html


== Description ==
Videofire is Blogging WordPress Theme. Videofire is a Child Theme of VideoStories.

Our Support: https://prowptheme.com/support/

== Installation ==

1. In your WordPress Admin Panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the videofire.zip file. Click Install Now.
3. Click Activate to use your new theme right away.





/** IMAGES **/

 {{{
 Actress Charlize Theron, Copyright Pixabay
 License: Public Domain CC0 License
 Source: https://pixabay.com/en/charlize-theron-entertainer-actress-79562/
 }}}




== Copyrights and License ==

 {{{
 Videofire WordPress Theme, Copyright 2018 Liton Arefin
 Videofire is distributed under the terms of the GNU General Public License v2
 }}}



== Changelog ==
= 1.0.0 =
* Date: [14.Auguest.2018](https://wordpress.org/themes/videofire/)
* Initial Release

