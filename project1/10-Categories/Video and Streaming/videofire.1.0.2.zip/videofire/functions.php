<?php

add_action( 'wp_enqueue_scripts', 'videofire_enqueue_styles' );
function videofire_enqueue_styles() {
    wp_enqueue_style( 'videofire-style', get_stylesheet_directory_uri() . '/style.css', array('videostories-style'));
	wp_enqueue_style( 'videostories-header', get_stylesheet_directory_uri() . '/assets/css/header.css');
	wp_enqueue_style( 'videostories-themes', get_stylesheet_directory_uri() . '/assets/css/themes.css');
	wp_enqueue_style( 'videostories-responsive', get_stylesheet_directory_uri() . '/assets/css/responsive.css');
}

require ( get_stylesheet_directory() . '/inc/videofire-functions.php' );