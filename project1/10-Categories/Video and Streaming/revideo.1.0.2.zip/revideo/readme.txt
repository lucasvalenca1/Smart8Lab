=== ReVideo ===
Contributors: Litonice13
Tags: right-sidebar, custom-menu, editor-style, sticky-post, blog, two-columns, footer-widgets, custom-background, featured-images, post-formats, threaded-comments, translation-ready, full-width-template, entertainment
Requires at least: 4.0
Tested up to: 4.9.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Short description. No more than 150 chars.

== Description ==
ReVideo is Magazine WordPress Theme. ReVideo is a Child Theme of VideoStories.

== Installation ==

1. In your WordPress Admin Panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the revideo.zip file. Click Install Now.
3. Click Activate to use your new theme right away.



== Frequently Asked Questions ==

= From where I can get Support for this Theme? =

Our Support Forum: https://prowptheme.com/support/


== Changelog ==

= 1.0.1 =
* Initial Release


== Copyrights and License ==

 {{{



	ReVideo WordPress Theme is a child theme of Parent Theme, Copyright 2018 Liton Arefin. 
	ReVideo is distributed under the terms of the GNU GPLv3.

	VideoStories WordPress Theme, Copyright 2018 Liton Arefin.
	VideoStories is distributed under the terms of the GNU GPLv3.

 }}}



== Upgrade Notice ==



== Resources ==
* https://pixabay.com/en/woman-girl-female-young-beauty-3599869/ © 2014 darksouls1, CC0

* https://pixabay.com/en/sun-dawn-sch%C3%B6nwetter-nature-bright-3130638/ © 2015 Marys_fotos, CC0

* https://pixabay.com/en/waves-dawn-ocean-sea-dusk-1867285/ © 2016 Marys_fotos, CC0

* https://pixabay.com/en/youth-active-jump-happy-sunrise-570881/ © 2014 Marys_fotos, CC0

* https://pixabay.com/en/woman-girl-female-young-beauty-3599869/ © 2015 Marys_fotos, CC0





