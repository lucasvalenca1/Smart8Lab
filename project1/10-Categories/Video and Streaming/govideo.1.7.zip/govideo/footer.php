<footer>
		<?php get_template_part( 'template-parts/footer/footer', 'top' );?>
		<?php get_template_part( 'template-parts/footer/footer', 'widgets' );?>
		<?php get_template_part( 'template-parts/footer/footer', 'bottom' );?>
	</footer>
<?php wp_footer(); ?>

</body>
</html>
