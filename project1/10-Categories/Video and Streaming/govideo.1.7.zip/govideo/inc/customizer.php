<?php

require_once GOVIDEO_THEME_DIR . 'inc/customizer-controls/iconpicker/class-customize-iconpicker-control.php';