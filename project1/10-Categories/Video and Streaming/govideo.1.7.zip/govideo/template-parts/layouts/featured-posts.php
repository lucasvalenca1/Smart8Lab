<?php

	if ( ! dynamic_sidebar( 'hoo-featured-section' ) ):
		endif;
	
		
?>
