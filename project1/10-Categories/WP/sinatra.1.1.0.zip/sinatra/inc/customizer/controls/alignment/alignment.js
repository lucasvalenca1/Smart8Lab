;(function($) {

 	"use strict";

 	wp.customize.controlConstructor['sinatra-alignment'] = wp.customize.Control.extend({

		ready: function() {

			'use strict';

			var control = this;
		},

	});

})(jQuery);