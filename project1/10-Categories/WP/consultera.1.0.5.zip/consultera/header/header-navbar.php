<?php 

consultera_header_before();

consultera_header();

consultera_header_after();

