<?php 
/**
 // Template Name: Homepage
*/
get_header();

do_action( 'consultera_homepage_sections', false ); 

get_footer();