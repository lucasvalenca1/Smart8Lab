<?php

consultera_footer_before();

consultera_footer();

consultera_footer_after();
