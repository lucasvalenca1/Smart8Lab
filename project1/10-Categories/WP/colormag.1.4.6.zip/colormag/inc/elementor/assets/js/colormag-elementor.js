/**
 * ColorMag Custom Elementor JS settings
 */