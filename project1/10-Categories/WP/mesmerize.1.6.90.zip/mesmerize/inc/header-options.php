<?php

// presets options
require_once get_template_directory() . "/inc/header-options/presets.php";

// background options
require_once get_template_directory() . "/inc/header-options/background.php";
// content options
require_once get_template_directory() . "/inc/header-options/content.php";

// navigation options
require_once get_template_directory() . "/inc/header-options/navigation.php";

