<div data-colibri-id="5-h28" class="h-global-transition-all h-heading style-28 style-local-5-h28 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <h1>
    <?php $component->printTitle(); ?>
  </h1>
</div>
