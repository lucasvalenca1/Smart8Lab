<div data-colibri-id="5-h29" class="h-text h-text-component style-29 style-local-5-h29 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div>
    <p>
      <?php $component->printSubtitle(); ?>
    </p>
  </div>
</div>
