<?php if (is_active_sidebar('sidebar-1')) { ?>
    <aside id="sidebar" class="col-md-3 col-md-pull-9">
        <?php dynamic_sidebar('sidebar-1'); ?>
    </aside>
<?php } ?>
